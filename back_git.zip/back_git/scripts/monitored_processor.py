#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
📊 پردازشگر با مانیتورینگ real-time - نسخه نهایی با اصلاحات
"""

import os
import sys
import json
import time
import logging
import sqlite3
import subprocess
from datetime import datetime
from typing import Dict, List, Any, Optional
from dataclasses import dataclass
from enum import Enum

# اضافه کردن مسیر پروژه
PROJECT_ROOT = r"C:\Users\Kamal\Desktop\py-prg\git\c-data"
sys.path.insert(0, PROJECT_ROOT)

# تنظیم لاگ‌گیری پیشرفته
logging.basicConfig(
    level=logging.DEBUG,  # تغییر به DEBUG برای جزئیات بیشتر
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(os.path.join(PROJECT_ROOT, "logs", "monitored_processing_detailed.log")),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)


class ProcessingStatus(Enum):
    """وضعیت پردازش"""
    PENDING = "pending"
    RUNNING = "running"
    SUCCESS = "success"
    FAILED = "failed"
    SKIPPED = "skipped"


class CycleStage(Enum):
    """مراحل پردازش"""
    CYCLE_02 = "cycle_02"
    CYCLE_03 = "cycle_03"
    CYCLE_04 = "cycle_04"
    COMPLETED = "completed"


@dataclass
class BlockInfo:
    """اطلاعات یک بلوک"""
    block_id: int
    symbols: List[str]
    coin_count: int
    status: str = ProcessingStatus.PENDING.value
    current_stage: str = CycleStage.CYCLE_02.value
    start_time: Optional[str] = None
    end_time: Optional[str] = None
    execution_time: float = 0.0
    stages: Dict[str, Dict] = None
    
    def __post_init__(self):
        if self.stages is None:
            self.stages = {
                CycleStage.CYCLE_02.value: {
                    "status": ProcessingStatus.PENDING.value,
                    "start_time": None,
                    "end_time": None,
                    "execution_time": 0.0
                },
                CycleStage.CYCLE_03.value: {
                    "status": ProcessingStatus.PENDING.value,
                    "start_time": None,
                    "end_time": None,
                    "execution_time": 0.0
                },
                CycleStage.CYCLE_04.value: {
                    "status": ProcessingStatus.PENDING.value,
                    "start_time": None,
                    "end_time": None,
                    "execution_time": 0.0
                }
            }


class EnhancedJSONEncoder(json.JSONEncoder):
    """JSON Encoder برای پشتیبانی از انواع خاص"""
    def default(self, obj):
        if isinstance(obj, Enum):
            return obj.value
        if isinstance(obj, datetime):
            return obj.isoformat()
        return super().default(obj)


class MonitoringProcessor:
    """پردازشگر با مانیتورینگ real-time"""
    
    def __init__(self):
        self.project_root = PROJECT_ROOT
        self.state_file = os.path.join(PROJECT_ROOT, "state", "cycle_state.json")
        self.status_file = os.path.join(PROJECT_ROOT, "monitoring_status.json")
        self.results_dir = os.path.join(PROJECT_ROOT, "reports", "monitored")
        
        # ایجاد پوشه‌های لازم
        os.makedirs(self.results_dir, exist_ok=True)
        
        logger.info("🔍 شروع راه‌اندازی MonitoringProcessor")
        logger.debug(f"مسیر پروژه: {self.project_root}")
        logger.debug(f"فایل وضعیت: {self.state_file}")
        logger.debug(f"فایل مانیتورینگ: {self.status_file}")
        
        # نگاشت مراحل به اسکریپت‌ها - اصلاح شده ✅
        self.script_mapping = {
            CycleStage.CYCLE_02: "cycle_02_process_block.py",
            CycleStage.CYCLE_03: "cycle_03_analyze_block/main_cycle_03.py",  # ✅ اصلاح: main_cycle_03.py
            CycleStage.CYCLE_04: "cycle_04_simple.py"
        }
        
        # بارگذاری بلوک‌ها
        self.blocks = self._load_blocks()
        self.block_infos = self._create_block_infos()
        
        # گزارش کلی
        self.master_report = {
            "start_time": datetime.now().isoformat(),
            "total_blocks": len(self.blocks),
            "total_coins": sum(len(b.get("coins", [])) for b in self.blocks),
            "blocks_by_size": self._calculate_block_stats(),
            "overall_status": ProcessingStatus.PENDING.value,
            "processed_blocks": 0,
            "successful_blocks": 0,
            "failed_blocks": 0,
            "current_block": None,
            "progress_percentage": 0.0,
            "estimated_time_remaining": None,
            "update_time": datetime.now().isoformat()
        }
        
        # ذخیره وضعیت اولیه با اطلاعات بلوک‌ها
        self._save_initial_status()
        
        logger.info(f"📊 MonitoringProcessor راه‌اندازی شد - {len(self.blocks)} بلوک")
        logger.info(f"📈 آمار: {self.master_report['total_coins']} ارز در {len(self.blocks)} بلوک")
        logger.debug(f"نگاشت اسکریپت‌ها: {self.script_mapping}")
    
    def _load_blocks(self) -> List[Dict[str, Any]]:
        """بارگذاری بلوک‌ها از state/cycle_state.json"""
        try:
            logger.debug(f"📖 در حال خواندن فایل: {self.state_file}")
            
            if not os.path.exists(self.state_file):
                logger.error(f"❌ فایل {self.state_file} وجود ندارد!")
                return []
            
            with open(self.state_file, 'r', encoding='utf-8') as f:
                state = json.load(f)
            
            blocks = state.get("blocks", [])
            logger.info(f"📦 {len(blocks)} بلوک از {self.state_file} بارگذاری شد")
            
            # نمایش اطلاعات نمونه
            if blocks:
                for i, block in enumerate(blocks[:3]):  # 3 بلوک اول
                    logger.debug(f"   بلوک {block.get('block_id')}: {len(block.get('coins', []))} ارز")
            
            return blocks
            
        except json.JSONDecodeError as e:
            logger.error(f"❌ خطای JSON در فایل {self.state_file}: {e}")
            return []
        except Exception as e:
            logger.error(f"❌ خطا در بارگذاری بلوک‌ها از {self.state_file}: {e}")
            import traceback
            logger.error(traceback.format_exc())
            return []
    
    def _create_block_infos(self) -> Dict[int, BlockInfo]:
        """ایجاد اطلاعات بلوک‌ها"""
        block_infos = {}
        for block in self.blocks:
            block_id = block.get("block_id")
            symbols = block.get("symbols", [])
            coins = block.get("coins", [])
            
            block_infos[block_id] = BlockInfo(
                block_id=block_id,
                symbols=symbols,
                coin_count=len(coins)
            )
            logger.debug(f"   ایجاد بلوک {block_id}: {len(coins)} ارز")
        return block_infos
    
    def _calculate_block_stats(self) -> Dict[str, Any]:
        """محاسبه آمار بلوک‌ها"""
        sizes = []
        for block in self.blocks:
            sizes.append(len(block.get("coins", [])))
        
        if not sizes:
            logger.warning("⚠️ هیچ بلوکی برای محاسبه آمار وجود ندارد")
            return {
                "min_coins": 0,
                "max_coins": 0,
                "avg_coins": 0,
                "total_coins": 0,
                "blocks_by_size": {"small": 0, "medium": 0, "large": 0}
            }
        
        stats = {
            "min_coins": min(sizes),
            "max_coins": max(sizes),
            "avg_coins": sum(sizes) / len(sizes),
            "total_coins": sum(sizes),
            "blocks_by_size": {
                "small": sum(1 for s in sizes if s <= 15),
                "medium": sum(1 for s in sizes if 15 < s <= 30),
                "large": sum(1 for s in sizes if s > 30)
            }
        }
        
        logger.debug(f"📊 آمار بلوک‌ها: min={stats['min_coins']}, max={stats['max_coins']}, avg={stats['avg_coins']:.1f}")
        return stats
    
    def _save_initial_status(self):
        """ذخیره وضعیت اولیه با اطلاعات بلوک‌ها"""
        try:
            # ساخت اطلاعات اولیه بلوک‌ها
            initial_blocks = {}
            for block in self.blocks:
                block_id = block.get("block_id")
                coins = block.get("coins", [])
                
                # نمونه‌ای از ارزها (حداکثر 5 تا)
                coins_sample = []
                for i, coin in enumerate(coins[:5]):
                    if isinstance(coin, dict):
                        coins_sample.append({
                            "id": coin.get("id", i+1),
                            "symbol": coin.get("symbol", f"COIN_{i+1}")
                        })
                    else:
                        coins_sample.append({"id": i+1, "symbol": str(coin)})
                
                initial_blocks[block_id] = {
                    "block_id": block_id,
                    "symbols": block.get("symbols", []),
                    "coin_count": len(coins),
                    "coins_sample": coins_sample,
                    "status": ProcessingStatus.PENDING.value,
                    "current_stage": CycleStage.CYCLE_02.value,
                    "start_time": None,
                    "end_time": None,
                    "execution_time": 0.0,
                    "stages": {
                        CycleStage.CYCLE_02.value: {
                            "status": ProcessingStatus.PENDING.value,
                            "start_time": None,
                            "end_time": None,
                            "execution_time": 0.0
                        },
                        CycleStage.CYCLE_03.value: {
                            "status": ProcessingStatus.PENDING.value,
                            "start_time": None,
                            "end_time": None,
                            "execution_time": 0.0
                        },
                        CycleStage.CYCLE_04.value: {
                            "status": ProcessingStatus.PENDING.value,
                            "start_time": None,
                            "end_time": None,
                            "execution_time": 0.0
                        }
                    }
                }
            
            status_data = {
                "master_report": self.master_report,
                "blocks": initial_blocks,
                "last_update": datetime.now().isoformat(),
                "system_info": {
                    "project_root": self.project_root,
                    "python_version": sys.version,
                    "platform": sys.platform,
                    "state_file": self.state_file,
                    "total_blocks_found": len(self.blocks),
                    "initialization_time": datetime.now().isoformat(),
                    "script_mapping": {k.value: v for k, v in self.script_mapping.items()}
                }
            }
            
            with open(self.status_file, 'w', encoding='utf-8') as f:
                json.dump(status_data, f, indent=2, ensure_ascii=False, cls=EnhancedJSONEncoder)
            
            logger.info(f"📄 وضعیت اولیه ذخیره شد: {self.status_file}")
            logger.info(f"📊 {len(self.blocks)} بلوک با {self.master_report['total_coins']} ارز بارگذاری شدند")
            
        except Exception as e:
            logger.error(f"❌ خطا در ذخیره وضعیت اولیه: {e}")
            import traceback
            logger.error(traceback.format_exc())
    
    def _save_status(self):
        """ذخیره وضعیت فعلی در فایل JSON"""
        try:
            # تبدیل داده‌ها به dict
            status_data = {
                "master_report": self.master_report,
                "blocks": self._serialize_blocks(),
                "last_update": datetime.now().isoformat(),
                "system_info": {
                    "project_root": self.project_root,
                    "python_version": sys.version,
                    "platform": sys.platform,
                    "current_time": datetime.now().isoformat()
                }
            }
            
            with open(self.status_file, 'w', encoding='utf-8') as f:
                json.dump(status_data, f, indent=2, ensure_ascii=False, cls=EnhancedJSONEncoder)
            
            logger.debug(f"💾 وضعیت ذخیره شد: {self.status_file}")
            
        except Exception as e:
            logger.error(f"❌ خطا در ذخیره وضعیت: {e}")
            import traceback
            logger.error(traceback.format_exc())
    
    def _serialize_blocks(self) -> Dict[str, Dict[str, Any]]:
        """سریالایز کردن block_infos"""
        serialized = {}
        for block_id, block_info in self.block_infos.items():
            serialized[block_id] = {
                "block_id": block_info.block_id,
                "symbols": block_info.symbols,
                "coin_count": block_info.coin_count,
                "status": block_info.status,
                "current_stage": block_info.current_stage,
                "start_time": block_info.start_time,
                "end_time": block_info.end_time,
                "execution_time": block_info.execution_time,
                "stages": block_info.stages
            }
        return serialized
    
    def _update_block_stage(self, block_id: int, stage: CycleStage,
                           status: ProcessingStatus, execution_time: float = None):
        """بروزرسانی وضعیت یک مرحله از بلوک"""
        block_info = self.block_infos.get(block_id)
        if not block_info:
            logger.error(f"بلوک {block_id} پیدا نشد!")
            return
        
        stage_key = stage.value
        if stage_key in block_info.stages:
            block_info.stages[stage_key]["status"] = status.value
            block_info.stages[stage_key]["end_time"] = datetime.now().isoformat()
            
            if execution_time is not None:
                block_info.stages[stage_key]["execution_time"] = execution_time
        
        # بروزرسانی وضعیت کلی بلوک
        if stage == CycleStage.CYCLE_04:
            if status == ProcessingStatus.SUCCESS:
                block_info.status = ProcessingStatus.SUCCESS.value
            else:
                block_info.status = ProcessingStatus.FAILED.value
            block_info.end_time = datetime.now().isoformat()
        
        self._save_status()
    
    def _run_cycle_with_monitoring(self, block_id: int, stage: CycleStage,
                                   timeout: int = 300) -> Dict[str, Any]:
        """اجرای یک تکه با مانیتورینگ پیشرفته"""
        stage_start_time = datetime.now()
        
        # دریافت نام اسکریپت از نگاشت
        script_name = self.script_mapping.get(stage)
        if not script_name:
            error_msg = f"اسکریپتی برای مرحله {stage.value} تعریف نشده!"
            logger.error(f"    ❌ {error_msg}")
            return {"success": False, "error": error_msg, "execution_time": 0}
        
        script_path = os.path.join(self.project_root, "scripts", "cycle", script_name)
        
        logger.info(f"  🔄 {stage.value}: شروع برای بلوک {block_id}")
        logger.debug(f"     اسکریپت: {script_name}")
        logger.debug(f"     مسیر کامل: {script_path}")
        logger.debug(f"     وجود فایل: {os.path.exists(script_path)}")
        
        try:
            # بروزرسانی وضعیت شروع
            block_info = self.block_infos[block_id]
            block_info.current_stage = stage.value
            block_info.stages[stage.value]["start_time"] = stage_start_time.isoformat()
            block_info.stages[stage.value]["status"] = ProcessingStatus.RUNNING.value
            self._save_status()
            
            # بررسی وجود اسکریپت
            if not os.path.exists(script_path):
                error_msg = f"اسکریپت {script_name} پیدا نشد! مسیر: {script_path}"
                logger.error(f"    ❌ {error_msg}")
                self._update_block_stage(block_id, stage, ProcessingStatus.FAILED, 0)
                return {"success": False, "error": error_msg, "execution_time": 0}
            
            cmd = [
                sys.executable,
                script_path,
                "--block", str(block_id)
            ]
            
            logger.debug(f"     دستور اجرا: {' '.join(cmd)}")
            logger.debug(f"     دایرکتوری کار: {self.project_root}")
            
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                encoding='utf-8',
                cwd=self.project_root,
                timeout=timeout,
                shell=True  # برای ویندوز بهتر است
            )
            
            execution_time = (datetime.now() - stage_start_time).total_seconds()
            
            # لاگ جزئیات اجرا
            logger.debug(f"     کد خروج: {result.returncode}")
            logger.debug(f"     زمان اجرا: {execution_time:.2f} ثانیه")
            
            if result.returncode == 0:
                logger.info(f"    ✅ {stage.value} برای بلوک {block_id} تکمیل شد ({execution_time:.1f}ثانیه)")
                if result.stdout and len(result.stdout) > 0:
                    # نمایش 200 کاراکتر اول خروجی
                    stdout_preview = result.stdout[:200].replace('\n', ' ')
                    logger.debug(f"     stdout پیش‌نمایش: {stdout_preview}...")
                self._update_block_stage(block_id, stage, ProcessingStatus.SUCCESS, execution_time)
                return {"success": True, "execution_time": execution_time}
            else:
                # 🔴 لاگ کامل خطا
                logger.error(f"    ❌ {stage.value} برای بلوک {block_id} ناموفق!")
                logger.error(f"     کد خروج: {result.returncode}")
                
                if result.stderr:
                    logger.error(f"     stderr (اولین ۱۰۰۰ کاراکتر):")
                    logger.error("=" * 50)
                    stderr_lines = result.stderr.split('\n')
                    for i, line in enumerate(stderr_lines[:20]):  # 20 خط اول
                        if line.strip():
                            logger.error(f"     خط {i+1}: {line}")
                    logger.error("=" * 50)
                
                if result.stdout:
                    stdout_preview = result.stdout[:500].replace('\n', ' ')
                    logger.debug(f"     stdout (اولین ۵۰۰ کاراکتر): {stdout_preview}")
                
                self._update_block_stage(block_id, stage, ProcessingStatus.FAILED, execution_time)
                return {
                    "success": False,
                    "error": result.stderr[:1000] if result.stderr else "Unknown error",
                    "returncode": result.returncode,
                    "execution_time": execution_time
                }
                
        except subprocess.TimeoutExpired:
            execution_time = (datetime.now() - stage_start_time).total_seconds()
            logger.error(f"    ⏰ تایم‌اوت {stage.value} برای بلوک {block_id} بعد از {execution_time} ثانیه")
            self._update_block_stage(block_id, stage, ProcessingStatus.FAILED, execution_time)
            return {"success": False, "error": f"Timeout expired after {execution_time} seconds", "execution_time": execution_time}
            
        except FileNotFoundError as e:
            execution_time = (datetime.now() - stage_start_time).total_seconds()
            logger.error(f"    ❌ فایل پیدا نشد: {e}")
            self._update_block_stage(block_id, stage, ProcessingStatus.FAILED, execution_time)
            return {"success": False, "error": f"File not found: {e}", "execution_time": execution_time}
            
        except Exception as e:
            execution_time = (datetime.now() - stage_start_time).total_seconds()
            logger.error(f"    ❌ خطای غیرمنتظره در {stage.value} برای بلوک {block_id}: {e}")
            import traceback
            logger.error(f"     Traceback:\n{traceback.format_exc()}")
            self._update_block_stage(block_id, stage, ProcessingStatus.FAILED, execution_time)
            return {"success": False, "error": str(e), "execution_time": execution_time}
    
    def process_single_block(self, block_data: Dict[str, Any]) -> Dict[str, Any]:
        """پردازش یک بلوک با مانیتورینگ"""
        block_id = block_data.get("block_id")
        symbols = block_data.get("symbols", [])
        
        logger.info(f"\n{'='*60}")
        logger.info(f"📦 شروع پردازش بلوک {block_id}")
        logger.info(f"   ارزها: {len(symbols)} عدد")
        logger.info(f"   نمونه: {', '.join(symbols[:3])}{'...' if len(symbols) > 3 else ''}")
        logger.info(f"{'='*60}")
        
        block_start_time = datetime.now()
        
        # بروزرسانی وضعیت کلی
        self.master_report["current_block"] = block_id
        self.block_infos[block_id].start_time = block_start_time.isoformat()
        self.block_infos[block_id].status = ProcessingStatus.RUNNING.value
        self._save_status()
        
        # اجرای مراحل
        results = {}
        
        # 1. تکه ۲
        logger.info("   مرحله ۱: جمع‌آوری کندل‌ها (تکه ۲)")
        results["cycle_02"] = self._run_cycle_with_monitoring(
            block_id, CycleStage.CYCLE_02
        )
        
        if not results["cycle_02"].get("success", False):
            logger.error(f"❌ توقف پردازش بلوک {block_id} به دلیل شکست تکه ۲")
            self.block_infos[block_id].status = ProcessingStatus.FAILED.value
            self.block_infos[block_id].end_time = datetime.now().isoformat()
            self._save_status()
            return {"block_id": block_id, "status": "failed", "failed_at": "cycle_02"}
        
        logger.info("   ⏳ وقفه ۲ ثانیه‌ای قبل از مرحله بعدی...")
        time.sleep(2)
        
        # 2. تکه ۳
        logger.info("   مرحله ۲: تحلیل اندیکاتورها (تکه ۳)")
        results["cycle_03"] = self._run_cycle_with_monitoring(
            block_id, CycleStage.CYCLE_03
        )
        
        if not results["cycle_03"].get("success", False):
            logger.error(f"❌ توقف پردازش بلوک {block_id} به دلیل شکست تکه ۳")
            # 🔴 نمایش جزئیات خطا
            error_info = results["cycle_03"].get("error", "No error details")
            returncode = results["cycle_03"].get("returncode", -1)
            logger.error(f"   کد خروج: {returncode}")
            logger.error(f"   پیام خطا: {error_info[:500]}...")
            
            self.block_infos[block_id].status = ProcessingStatus.FAILED.value
            self.block_infos[block_id].end_time = datetime.now().isoformat()
            self._save_status()
            return {"block_id": block_id, "status": "failed", "failed_at": "cycle_03"}
        
        logger.info("   ⏳ وقفه ۲ ثانیه‌ای قبل از مرحله بعدی...")
        time.sleep(2)
        
        # 3. تکه ۴
        logger.info("   مرحله ۳: تحلیل پیشرفته (تکه ۴)")
        results["cycle_04"] = self._run_cycle_with_monitoring(
            block_id, CycleStage.CYCLE_04
        )
        
        # محاسبه زمان کل
        execution_time = (datetime.now() - block_start_time).total_seconds()
        
        # بروزرسانی وضعیت نهایی
        all_success = all(r.get("success", False) for r in results.values())
        
        if all_success:
            self.block_infos[block_id].status = ProcessingStatus.SUCCESS.value
            self.master_report["successful_blocks"] += 1
        else:
            self.block_infos[block_id].status = ProcessingStatus.FAILED.value
            self.master_report["failed_blocks"] += 1
        
        self.block_infos[block_id].end_time = datetime.now().isoformat()
        self.block_infos[block_id].execution_time = execution_time
        
        # بروزرسانی پیشرفت کلی
        self.master_report["processed_blocks"] += 1
        self.master_report["progress_percentage"] = (
            self.master_report["processed_blocks"] / self.master_report["total_blocks"] * 100
        )
        
        # تخمین زمان باقی‌مانده
        if self.master_report["processed_blocks"] > 0:
            completed_blocks = [b for b in self.block_infos.values() if b.execution_time > 0]
            if completed_blocks:
                avg_time = sum(b.execution_time for b in completed_blocks) / len(completed_blocks)
                remaining = avg_time * (self.master_report["total_blocks"] - self.master_report["processed_blocks"])
                self.master_report["estimated_time_remaining"] = remaining
        
        self.master_report["update_time"] = datetime.now().isoformat()
        self._save_status()
        
        logger.info(f"\n📊 نتیجه بلوک {block_id}:")
        logger.info(f"   وضعیت: {'✅ موفق' if all_success else '❌ ناموفق'}")
        logger.info(f"   زمان اجرا: {execution_time:.2f} ثانیه")
        
        cycle_02_time = results.get('cycle_02', {}).get('execution_time', 0)
        cycle_03_time = results.get('cycle_03', {}).get('execution_time', 0)
        cycle_04_time = results.get('cycle_04', {}).get('execution_time', 0)
        
        logger.info(f"   تکه ۲: {'✅' if results.get('cycle_02', {}).get('success') else '❌'} ({cycle_02_time:.1f}ثانیه)")
        logger.info(f"   تکه ۳: {'✅' if results.get('cycle_03', {}).get('success') else '❌'} ({cycle_03_time:.1f}ثانیه)")
        logger.info(f"   تکه ۴: {'✅' if results.get('cycle_04', {}).get('success') else '❌'} ({cycle_04_time:.1f}ثانیه)")
        
        return {
            "block_id": block_id,
            "status": "completed" if all_success else "partial",
            "execution_time": execution_time,
            "results": results
        }
    
    def process_all_blocks(self, start_from: int = 1, max_blocks: Optional[int] = None):
        """پردازش همه بلوک‌ها"""
        logger.info("\n" + "=" * 60)
        logger.info("🚀 شروع پردازش ترتیبی با مانیتورینگ real-time")
        logger.info("=" * 60)
        
        # فیلتر بلوک‌ها
        blocks_to_process = [b for b in self.blocks if b.get("block_id", 0) >= start_from]
        
        if max_blocks:
            blocks_to_process = blocks_to_process[:max_blocks]
            logger.info(f"🔧 محدودیت: پردازش {max_blocks} بلوک اول")
        
        logger.info(f"📊 تعداد بلوک‌های قابل پردازش: {len(blocks_to_process)}")
        
        # بروزرسانی وضعیت کلی
        self.master_report["overall_status"] = ProcessingStatus.RUNNING.value
        self.master_report["start_time"] = datetime.now().isoformat()
        self._save_status()
        
        # پردازش بلوک‌ها
        for i, block in enumerate(blocks_to_process, 1):
            block_id = block.get("block_id")
            
            logger.info(f"\n📋 بلوک {i}/{len(blocks_to_process)} (ID: {block_id})")
            
            try:
                self.process_single_block(block)
                
                # وقفه بین بلوک‌ها
                if i < len(blocks_to_process):
                    logger.info(f"⏳ وقفه ۱۰ ثانیه‌ای قبل از بلوک بعدی...")
                    time.sleep(10)
                    
            except Exception as e:
                logger.error(f"❌ خطای غیرمنتظره در بلوک {block_id}: {e}")
                import traceback
                logger.error(traceback.format_exc())
                
                # بروزرسانی وضعیت خطا
                self.block_infos[block_id].status = ProcessingStatus.FAILED.value
                self.block_infos[block_id].end_time = datetime.now().isoformat()
                self.master_report["failed_blocks"] += 1
                self.master_report["processed_blocks"] += 1
                self._save_status()
        
        # بروزرسانی وضعیت نهایی
        self.master_report["overall_status"] = ProcessingStatus.SUCCESS.value
        self.master_report["end_time"] = datetime.now().isoformat()
        self._save_status()
        
        # تولید گزارش نهایی
        self.generate_final_report()
        
        logger.info("\n" + "=" * 60)
        logger.info("🎉 پردازش با مانیتورینگ تکمیل شد!")
        logger.info(f"📊 وضعیت ذخیره شده در: {self.status_file}")
        logger.info(f"📊 داشبورد: {os.path.join(self.project_root, 'monitoring_dashboard.html')}")
        logger.info("=" * 60)
    
    def generate_final_report(self):
        """تولید گزارش نهایی"""
        try:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"final_report_{timestamp}.json"
            filepath = os.path.join(self.results_dir, filename)
            
            report_data = {
                "generated_at": datetime.now().isoformat(),
                "master_report": self.master_report,
                "blocks": self._serialize_blocks(),
                "statistics": self._generate_statistics()
            }
            
            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump(report_data, f, indent=2, ensure_ascii=False, cls=EnhancedJSONEncoder)
            
            logger.info(f"💾 گزارش نهایی ذخیره شد: {filepath}")
            
        except Exception as e:
            logger.error(f"❌ خطا در تولید گزارش نهایی: {e}")
    
    def _generate_statistics(self):
        """تولید آمار نهایی"""
        successful_blocks = sum(1 for b in self.block_infos.values()
                               if b.status == ProcessingStatus.SUCCESS.value)
        failed_blocks = sum(1 for b in self.block_infos.values()
                           if b.status == ProcessingStatus.FAILED.value)
        
        stage_times = {"cycle_02": [], "cycle_03": [], "cycle_04": []}
        for block in self.block_infos.values():
            for stage, data in block.stages.items():
                if data.get("execution_time"):
                    stage_times[stage].append(data["execution_time"])
        
        return {
            "success_rate": (successful_blocks / len(self.block_infos) * 100) if self.block_infos else 0,
            "total_execution_time": sum(b.execution_time for b in self.block_infos.values()),
            "average_stage_times": {
                stage: sum(times)/len(times) if times else 0
                for stage, times in stage_times.items()
            },
            "performance_by_coin_count": self._analyze_performance_by_size()
        }
    
    def _analyze_performance_by_size(self):
        """تحلیل عملکرد بر اساس اندازه بلوک"""
        small = {"count": 0, "total_time": 0}
        medium = {"count": 0, "total_time": 0}
        large = {"count": 0, "total_time": 0}
        
        for block in self.block_infos.values():
            if block.coin_count <= 15:
                small["count"] += 1
                small["total_time"] += block.execution_time
            elif block.coin_count <= 30:
                medium["count"] += 1
                medium["total_time"] += block.execution_time
            else:
                large["count"] += 1
                large["total_time"] += block.execution_time
        
        return {
            "small_blocks": small,
            "medium_blocks": medium,
            "large_blocks": large
        }


def main():
    """تابع اصلی"""
    import argparse
    
    parser = argparse.ArgumentParser(description='پردازش ترتیبی با مانیتورینگ real-time')
    parser.add_argument('--start-from', type=int, default=1,
                       help='شروع از بلوک چندم (پیش‌فرض: ۱)')
    parser.add_argument('--max-blocks', type=int,
                       help='حداکثر تعداد بلوک‌های پردازش')
    parser.add_argument('--test', action='store_true',
                       help='حالت تست (فقط ۲ بلوک اول)')
    parser.add_argument('--debug', action='store_true',
                       help='حالت دیباگ با لاگ کامل')
    
    args = parser.parse_args()
    
    # تنظیم سطح لاگ بر اساس آرگومان
    if args.debug:
        logger.setLevel(logging.DEBUG)
        logger.info("🔍 حالت دیباگ فعال شد")
    
    max_blocks = 2 if args.test else args.max_blocks
    
    processor = MonitoringProcessor()
    processor.process_all_blocks(
        start_from=args.start_from,
        max_blocks=max_blocks
    )
    
    return 0


if __name__ == "__main__":
    sys.exit(main())