#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
دریافت 800 ارز برتر - با فیلترهای کامل و مدیریت Rate Limit
wrapped tokens و stablecoins ذخیره نمی‌شوند
"""

import requests
import sqlite3
import time
import random
import sys
from datetime import datetime
import logging
from typing import List, Dict, Optional
from dataclasses import dataclass

DB_FILE = r"C:\Users\Kamal\Desktop\py-prg\git\c-data\data\crypto_master.db"
TARGET_COINS = 800  # تعداد هدف ارزها
MAX_PAGES = 20      # حداکثر صفحات برای مرور
COINS_PER_PAGE = 100  # ارز در هر صفحه
MIN_DELAY = 7       # حداقل تاخیر بین درخواست‌ها (ثانیه)
MAX_DELAY = 15      # حداکثر تاخیر بین درخواست‌ها (ثانیه)
MAX_RETRIES = 3     # حداکثر تلاش مجدد برای هر درخواست

# لیست User-Agentهای مختلف برای چرخش
USER_AGENTS = [
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36',
    'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/119.0',
    'Mozilla/5.0 (iPhone; CPU iPhone OS 16_6 like Mac OS X) AppleWebKit/605.1.15'
]

# تنظیمات لاگ
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    datefmt='%H:%M:%S'
)
logger = logging.getLogger(__name__)

@dataclass
class CoinData:
    """کلاس برای نگهداری داده‌های ارز"""
    symbol: str
    base_asset: str
    coin_name: str
    coingecko_id: str
    current_price: float
    price_change_24h: float
    price_change_percent_24h: float
    high_24h: float
    low_24h: float
    volume_24h: float
    market_cap: float
    market_cap_rank: int
    circulating_supply: float
    total_supply: float
    max_supply: float
    last_updated: str

class RateLimiter:
    """مدیریت Rate Limit و تاخیرهای هوشمند"""
    
    def __init__(self, min_delay=MIN_DELAY, max_delay=MAX_DELAY):
        self.min_delay = min_delay
        self.max_delay = max_delay
        self.last_request_time = 0
        
    def wait(self):
        """تاخیر هوشمند با تغییر تصادفی"""
        current_time = time.time()
        time_since_last = current_time - self.last_request_time
        
        if time_since_last < self.min_delay:
            wait_time = self.min_delay - time_since_last + random.uniform(0, 3)
            logger.debug(f"⏳ تاخیر {wait_time:.1f} ثانیه")
            time.sleep(wait_time)
        
        # تاخیر تصادفی اضافی برای شبیه‌سازی رفتار انسانی
        extra_delay = random.uniform(0, self.max_delay - self.min_delay)
        time.sleep(extra_delay)
        
        self.last_request_time = time.time()
    
    def exponential_backoff(self, retry_count):
        """تاخیر نمایی برای تلاش مجدد"""
        delay = min(60, (2 ** retry_count) + random.uniform(0, 5))
        logger.warning(f"⏸️ تاخیر نمایی: {delay:.1f} ثانیه (تلاش {retry_count})")
        time.sleep(delay)

class CoinGeckoAPI:
    """کلاس برای مدیریت ارتباط با CoinGecko API"""
    
    def __init__(self):
        self.base_url = "https://api.coingecko.com/api/v3"
        self.rate_limiter = RateLimiter()
        self.session = requests.Session()
        self.session.headers.update({'Accept': 'application/json'})
        
    def get_random_user_agent(self):
        """انتخاب تصادفی User-Agent"""
        return random.choice(USER_AGENTS)
    
    def make_request(self, endpoint: str, params: Dict, retry_count: int = 0):
        """انجام درخواست با مدیریت خطا و تلاش مجدد"""
        
        if retry_count >= MAX_RETRIES:
            logger.error(f"❌ حداکثر تلاش مجدد برای {endpoint}")
            return None
        
        # تنظیم هدر با User-Agent تصادفی
        headers = {'User-Agent': self.get_random_user_agent()}
        
        try:
            self.rate_limiter.wait()
            
            logger.debug(f"🌐 درخواست به {endpoint} (صفحه {params.get('page', 1)})")
            
            response = self.session.get(
                f"{self.base_url}/{endpoint}",
                params=params,
                headers=headers,
                timeout=30
            )
            
            # بررسی status code
            if response.status_code == 200:
                return response.json()
            
            elif response.status_code == 429:  # Rate Limit
                logger.warning(f"⚠️ Rate Limit (429) - تلاش مجدد {retry_count + 1}")
                self.rate_limiter.exponential_backoff(retry_count)
                return self.make_request(endpoint, params, retry_count + 1)
            
            elif response.status_code == 403:  # Forbidden
                logger.error("❌ دسترسی ممنوع (403) - ممکن است IP بلاک شده باشد")
                time.sleep(60)  # تاخیر طولانی
                return None
            
            else:
                logger.error(f"❌ خطای HTTP {response.status_code}")
                time.sleep(10)
                return None
                
        except requests.exceptions.Timeout:
            logger.warning(f"⏱️ Timeout - تلاش مجدد {retry_count + 1}")
            self.rate_limiter.exponential_backoff(retry_count)
            return self.make_request(endpoint, params, retry_count + 1)
            
        except requests.exceptions.ConnectionError:
            logger.warning(f"🔌 Connection Error - تلاش مجدد {retry_count + 1}")
            time.sleep(30)
            return self.make_request(endpoint, params, retry_count + 1)
            
        except Exception as e:
            logger.error(f"❌ خطای غیرمنتظره: {e}")
            time.sleep(10)
            return None
    
    def fetch_coins_market(self, page: int = 1):
        """دریافت داده‌های بازار از CoinGecko"""
        params = {
            'vs_currency': 'usd',
            'order': 'market_cap_desc',
            'per_page': COINS_PER_PAGE,
            'page': page,
            'sparkline': False,
            'price_change_percentage': '24h'
        }
        
        return self.make_request("coins/markets", params)

def is_valid_main_coin(coin_data: Dict) -> bool:
    """بررسی کامل اعتبار ارز اصلی"""
    symbol = str(coin_data['symbol']).upper()
    name = str(coin_data['name']).lower()
    
    # لیست wrapped tokens و کلمات کلیدی
    wrapped_keywords = [
        'wrapped', 'bridged', 'staked', 'vault', 'tokenized',
        'weth', 'wbtc', 'wbnb', 'wmatic', 'wavax', 'wsol',
        'cb', 'binance', 'coinbase', 'polygon', 'avalanche',
        'wormhole', 'cross-chain', 'multichain', 'liquid',
        'ren', 'fantom', 'moonriver', 'moonbeam', 'celer',
        'ankr', 'axelar', 'layerzero', 'stargate'
    ]
    
    # بررسی نام
    for keyword in wrapped_keywords:
        if keyword in name:
            logger.debug(f"❌ رد شده (wrapped): {symbol} - {name}")
            return False
    
    # بررسی symbolهای wrapped
    wrapped_symbols = [
        'WBTC', 'WETH', 'WBNB', 'WMATIC', 'WAVAX', 'WSOL', 'WDOT',
        'CBETH', 'BTCB', 'STETH', 'JITOSOL', 'STSOL', 'MSOL',
        'WSTETH', 'WEETH', 'WBETH', 'CBBTC', 'CBETH', 'TBTC',
        'RENBTC', 'HBTC', 'SBTC', 'BBTC', 'OBTC', 'PBTC',
        'LDO', 'RETH', 'FRXETH', 'SFRXETH', 'RPL', 'SWISE'
    ]
    
    if symbol in wrapped_symbols:
        logger.debug(f"❌ رد شده (wrapped symbol): {symbol}")
        return False
    
    # حذف stablecoins (به جز USDT که خودش stablecoin است)
    stablecoin_symbols = ['USDC', 'DAI', 'BUSD', 'TUSD', 'USDP', 'USDN', 'GUSD']
    if symbol in stablecoin_symbols:
        logger.debug(f"❌ رد شده (stablecoin): {symbol}")
        return False
    
    # حذف ارزهای با کاراکترهای خاص
    if any(char in symbol for char in ['-', '.', '_', ' ', '/']):
        logger.debug(f"❌ رد شده (کاراکتر خاص): {symbol}")
        return False
    
    # حذف ارزهای با اعداد در ابتدا
    if symbol and symbol[0].isdigit():
        logger.debug(f"❌ رد شده (شروع با عدد): {symbol}")
        return False
    
    # حذف نمادهای خیلی کوتاه یا خیلی طولانی
    if len(symbol) < 2 or len(symbol) > 10:
        logger.debug(f"❌ رد شده (طول نامناسب): {symbol} ({len(symbol)})")
        return False
    
    # بررسی حجم معاملات (حداقل $100,000 برای فیلتر نویز)
    volume = coin_data.get('total_volume', 0)
    if volume and volume < 100000:
        logger.debug(f"❌ رد شده (حجم کم): {symbol} (${volume:,.0f})")
        return False
    
    logger.debug(f"✅ پذیرفته شده: {symbol}")
    return True

def add_usdt_if_needed(symbol: str) -> str:
    """اضافه کردن USDT اگر نیاز باشد"""
    symbol_upper = symbol.upper().strip()
    
    if symbol_upper.endswith('USDT'):
        return symbol_upper
    elif symbol_upper.endswith('usdt'):
        base = symbol_upper[:-4]
        return f"{base}USDT"
    else:
        return f"{symbol_upper}USDT"

def fetch_filtered_coins_with_retry() -> List[Dict]:
    """دریافت ارزها با فیلتر و مدیریت خطا"""
    logger.info(f"📥 دریافت {TARGET_COINS} ارز برتر (با فیلتر)...")
    
    api = CoinGeckoAPI()
    all_coins = []
    page = 1
    consecutive_failures = 0
    
    while len(all_coins) < TARGET_COINS and page <= MAX_PAGES:
        logger.info(f"📄 صفحه {page} - جمع آوری شده: {len(all_coins)}/{TARGET_COINS}")
        
        coins_data = api.fetch_coins_market(page)
        
        if not coins_data:
            consecutive_failures += 1
            logger.warning(f"⚠️ دریافت ناموفق صفحه {page} (شکست متوالی: {consecutive_failures})")
            
            if consecutive_failures >= 3:
                logger.error("❌ 3 شکست متوالی - توقف عملیات")
                break
                
            # تاخیر بیشتر پس از شکست
            time.sleep(30)
            continue
        
        # ریست کردن شمارشگر شکست
        consecutive_failures = 0
        
        # اعمال فیلتر
        filtered_coins = [c for c in coins_data if is_valid_main_coin(c)]
        
        logger.info(f"   دریافت: {len(coins_data)} | اصلی: {len(filtered_coins)}")
        all_coins.extend(filtered_coins)
        
        # اگر کمتر از 50% ارزهای صفحه معتبر بودند، احتمالا به انتهای لیست رسیده‌ایم
        if len(filtered_coins) / len(coins_data) < 0.5:
            logger.warning("⚠️ درصد کم ارزهای معتبر - ممکن است به انتهای لیست رسیده باشیم")
        
        # اگر صفحه آخر کمتر از 20 ارز داشت، احتمالا داده بیشتری نیست
        if len(coins_data) < COINS_PER_PAGE:
            logger.info("📄 به آخر داده‌ها رسیدیم")
            break
        
        page += 1
        
        # نمایش پیشرفت هر 5 صفحه
        if page % 5 == 0:
            logger.info(f"📊 پیشرفت: {len(all_coins)}/{TARGET_COINS} ارز")
    
    # محدود کردن به تعداد هدف
    final_coins = all_coins[:TARGET_COINS]
    
    if len(final_coins) < TARGET_COINS:
        logger.warning(f"⚠️ فقط {len(final_coins)} ارز معتبر یافت شد (هدف: {TARGET_COINS})")
    else:
        logger.info(f"✅ {len(final_coins)} ارز اصلی (فیلتر شده) دریافت شد")
    
    return final_coins

def prepare_coin_data(coin: Dict) -> Optional[CoinData]:
    """آماده‌سازی داده‌های ارز برای ذخیره"""
    try:
        symbol = str(coin['symbol']).upper()
        binance_symbol = add_usdt_if_needed(symbol)
        base_asset = binance_symbol.replace('USDT', '')
        
        return CoinData(
            symbol=binance_symbol,
            base_asset=base_asset,
            coin_name=coin['name'],
            coingecko_id=coin['id'],
            current_price=coin.get('current_price', 0.0) or 0.0,
            price_change_24h=coin.get('price_change_24h', 0.0) or 0.0,
            price_change_percent_24h=coin.get('price_change_percentage_24h', 0.0) or 0.0,
            high_24h=coin.get('high_24h', 0.0) or 0.0,
            low_24h=coin.get('low_24h', 0.0) or 0.0,
            volume_24h=coin.get('total_volume', 0.0) or 0.0,
            market_cap=coin.get('market_cap', 0.0) or 0.0,
            market_cap_rank=coin.get('market_cap_rank', 9999) or 9999,
            circulating_supply=coin.get('circulating_supply', 0.0) or 0.0,
            total_supply=coin.get('total_supply', 0.0) or 0.0,
            max_supply=coin.get('max_supply', 0.0) or 0.0,
            last_updated=coin.get('last_updated', '')
        )
    except Exception as e:
        logger.warning(f"⚠️ خطا در آماده‌سازی {coin.get('symbol', 'unknown')}: {e}")
        return None

def save_coins_filtered(coins_data: List[Dict]):
    """ذخیره ارزهای فیلتر شده"""
    logger.info("💾 ذخیره ارزهای فیلتر شده...")
    
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    
    # پاک کردن جدول قبلی
    cursor.execute("DELETE FROM crypto_coins")
    logger.info("🗑️  جدول قبلی پاک شد")
    
    saved = 0
    rejected = 0
    processed = 0
    
    for coin in coins_data:
        processed += 1
        
        try:
            coin_obj = prepare_coin_data(coin)
            if not coin_obj:
                rejected += 1
                continue
            
            cursor.execute('''
                INSERT OR REPLACE INTO crypto_coins 
                (symbol, base_asset, coin_name, coingecko_id,
                 current_price, price_change_24h, price_change_percent_24h,
                 high_24h, low_24h, volume_24h, market_cap, market_cap_rank,
                 circulating_supply, total_supply, max_supply, last_updated)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                coin_obj.symbol,
                coin_obj.base_asset,
                coin_obj.coin_name,
                coin_obj.coingecko_id,
                coin_obj.current_price,
                coin_obj.price_change_24h,
                coin_obj.price_change_percent_24h,
                coin_obj.high_24h,
                coin_obj.low_24h,
                coin_obj.volume_24h,
                coin_obj.market_cap,
                coin_obj.market_cap_rank,
                coin_obj.circulating_supply,
                coin_obj.total_supply,
                coin_obj.max_supply,
                coin_obj.last_updated
            ))
            
            saved += 1
            
            if processed % 50 == 0:
                logger.info(f"📝 {processed} ارز پردازش شد ({saved} ذخیره، {rejected} رد)")
                
        except Exception as e:
            logger.warning(f"⚠️ خطا در ذخیره {coin.get('symbol', 'unknown')}: {str(e)[:50]}")
            rejected += 1
            continue
    
    conn.commit()
    
    # آمار نهایی
    cursor.execute("SELECT COUNT(*) FROM crypto_coins")
    total = cursor.fetchone()[0]
    
    cursor.execute("SELECT symbol, coin_name, market_cap_rank FROM crypto_coins ORDER BY market_cap_rank ASC LIMIT 10")
    top_coins = cursor.fetchall()
    
    # نمایش مارکت‌کپ‌ها
    cursor.execute("SELECT SUM(market_cap) FROM crypto_coins")
    total_market_cap = cursor.fetchone()[0]
    
    conn.close()
    
    return saved, rejected, total, top_coins, total_market_cap

def print_statistics(coins_data: List[Dict]):
    """چاپ آمار جمع‌آوری شده"""
    if not coins_data:
        return
    
    # محاسبه آمار
    market_caps = [c.get('market_cap', 0) for c in coins_data]
    volumes = [c.get('total_volume', 0) for c in coins_data]
    
    avg_market_cap = sum(market_caps) / len(market_caps) if market_caps else 0
    avg_volume = sum(volumes) / len(volumes) if volumes else 0
    
    print("\n📊 آمار مجموعه ارزها:")
    print(f"   • تعداد کل: {len(coins_data)} ارز")
    print(f"   • میانگین مارکت‌کپ: ${avg_market_cap:,.0f}")
    print(f"   • میانگین حجم 24h: ${avg_volume:,.0f}")
    print(f"   • مجموع مارکت‌کپ: ${sum(market_caps):,.0f}")
    
    # توزیع مارکت‌کپ
    print("\n   توزیع بر اساس مارکت‌کپ:")
    ranges = [
        ("$10B+", lambda x: x >= 10_000_000_000),
        ("$1B-$10B", lambda x: 1_000_000_000 <= x < 10_000_000_000),
        ("$100M-$1B", lambda x: 100_000_000 <= x < 1_000_000_000),
        ("$10M-$100M", lambda x: 10_000_000 <= x < 100_000_000),
        ("<$10M", lambda x: x < 10_000_000),
    ]
    
    for label, condition in ranges:
        count = sum(1 for mc in market_caps if condition(mc))
        percent = (count / len(coins_data)) * 100
        print(f"     {label}: {count} ارز ({percent:.1f}%)")

def main():
    """تابع اصلی"""
    print("=" * 70)
    print("🔄 سیستم دریافت ارزها - با فیلترهای کامل")
    print("=" * 70)
    print(f"📅 {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"🎯 هدف: {TARGET_COINS} ارز اصلی")
    print("=" * 70)
    
    print("\n🛡️  ویژگی‌های امنیتی:")
    print("   • مدیریت Rate Limit هوشمند")
    print("   • تاخیرهای تصادفی (7-15 ثانیه)")
    print("   • چرخش User-Agent")
    print("   • تلاش مجدد با تاخیر نمایی")
    
    print("\n🔍 فیلترهای اعمال شده:")
    print("   • ❌ Wrapped tokens (WBTC, WETH, etc)")
    print("   • ❌ Stablecoins (USDC, DAI, BUSD, etc)")
    print("   • ❌ نمادهای با کاراکترهای خاص")
    print("   • ✅ اضافه کردن خودکار USDT")
    print("   • ✅ حداقل حجم معاملات: $100,000")
    
    confirm = input("\nادامه؟ (y/n): ").strip().lower()
    if confirm != 'y':
        print("❌ لغو شد")
        return
    
    try:
        start_time = time.time()
        
        # دریافت ارزهای فیلتر شده
        coins = fetch_filtered_coins_with_retry()
        
        if not coins:
            print("❌ هیچ ارز اصلی دریافت نشد!")
            return
        
        # نمایش آمار اولیه
        print_statistics(coins)
        
        # ذخیره
        saved, rejected, total, top_coins, total_market_cap = save_coins_filtered(coins)
        
        # نمایش نتیجه
        print("\n" + "=" * 70)
        print("📊 نتیجه نهایی:")
        print("=" * 70)
        print(f"• دریافت شده: {len(coins)} ارز")
        print(f"• ذخیره شده: {saved} ارز")
        print(f"• رد شده: {rejected} ارز")
        print(f"• کل در دیتابیس: {total} ارز")
        print(f"• مجموع مارکت‌کپ: ${total_market_cap:,.0f}")
        
        print(f"\n🏆 10 ارز برتر:")
        for i, (symbol, name, rank) in enumerate(top_coins, 1):
            print(f"  {i:2}. {symbol:12} - {name[:30]:30} (رتبه: {rank})")
        
        elapsed_time = time.time() - start_time
        print(f"\n⏱️  زمان اجرا: {elapsed_time:.1f} ثانیه")
        print(f"✅ تکمیل شد در {datetime.now().strftime('%H:%M:%S')}")
        
        # پیشنهاد برای اجرای بعدی
        if len(coins) < TARGET_COINS:
            print(f"\n⚠️  نکته: فقط {len(coins)} ارز معتبر یافت شد.")
            print("   برای دریافت ارزهای بیشتر:")
            print("   1. کاهش شدت فیلترها")
            print("   2. افزایش زمان تاخیر بین درخواست‌ها")
            print("   3. استفاده از API Key (اگر دارید)")
        
    except KeyboardInterrupt:
        print("\n\n❌ توسط کاربر لغو شد")
    except Exception as e:
        logger.error(f"❌ خطا در اجرای اصلی: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    # تنظیم سطح لاگ برای debug در صورت نیاز
    if '--debug' in sys.argv:
        logger.setLevel(logging.DEBUG)
    
    main()