"""
main.py - سیستم اصلی هماهنگ‌کننده - نسخه نهایی
تاریخ: 2025-12-21
هدف: هماهنگی و زمان‌بندی اجرای مراحل مختلف سیستم
"""

import time
import sys
import os
import logging
from datetime import datetime

# راه‌اندازی لاگ
logging.basicConfig(
    level=logging.INFO,
    format='[%(asctime)s] %(message)s',
    datefmt='%H:%M:%S'
)
logger = logging.getLogger(__name__)


class SystemCoordinator:
    """هماهنگ‌کننده اصلی سیستم"""
    
    def __init__(self):
        logger.info("🔧 در حال راه‌اندازی هماهنگ‌کننده...")
        
        # بارگذاری config_manager
        try:
            from config_manager import get, get_database_path
            self.config_get = get
            self.get_database_path = get_database_path
            logger.info("✅ config_manager بارگذاری شد")
        except ImportError as e:
            logger.error(f"❌ خطا در بارگذاری config_manager: {e}")
            sys.exit(1)
        
        # خواندن تنظیمات
        self.load_config()
        
        # 🔴 **اول دیتابیس را بررسی کن**
        self._verify_database()
        
        # دیکشنری برای نگهداری instance ماژول‌ها
        self.modules = {}
        self._shared_db = None  # دیتابیس مشترک برای همه ماژول‌ها
        
    def _verify_database(self):
        """بررسی وجود و سلامت دیتابیس"""
        logger.info("🔍 بررسی سلامت دیتابیس...")
        
        try:
            # دریافت مسیر دیتابیس از config_manager
            db_path = self.get_database_path()
            logger.info(f"📁 مسیر دیتابیس: {db_path}")
            
            # بررسی وجود فایل دیتابیس
            if not os.path.exists(db_path):
                logger.error(f"❌ فایل دیتابیس یافت نشد: {db_path}")
                logger.error("🚨 لطفا ابتدا Collector را اجرا کنید تا دیتابیس ایجاد شود.")
                sys.exit(1)
            
            # بررسی اتصال به دیتابیس
            from database_manager import DatabaseManager
            
            # تلاش برای اتصال به دیتابیس
            test_db = DatabaseManager()
            
            # بررسی وجود جداول اصلی
            required_tables = ['crypto_coins', 'crypto_klines']
            missing_tables = []
            
            for table in required_tables:
                if not test_db.table_exists(table):
                    missing_tables.append(table)
            
            if missing_tables:
                logger.error(f"❌ جدول‌های ضروری وجود ندارند: {missing_tables}")
                logger.error("🚨 لطفا ابتدا Collector را اجرا کنید تا جداول ایجاد شوند.")
                test_db.close()
                sys.exit(1)
            
            # بررسی داده‌ها
            coins_count = test_db.count_rows('crypto_coins')
            klines_count = test_db.count_rows('crypto_klines')
            
            logger.info(f"✅ دیتابیس سالم است: {coins_count} ارز, {klines_count} کندل")
            
            test_db.close()
            
        except FileNotFoundError as e:
            logger.error(f"❌ دیتابیس یافت نشد: {e}")
            sys.exit(1)
        except Exception as e:
            logger.error(f"❌ خطا در بررسی دیتابیس: {e}")
            sys.exit(1)
    
    def load_config(self):
        """بارگذاری تنظیمات از config_manager"""
        logger.info("⚙️ خواندن تنظیمات...")
        
        # تنظیمات سیستم
        system_config = self.config_get('system', {})
        self.system_name = system_config.get('name', 'Crypto Analysis System')
        self.system_version = system_config.get('version', '1.0.0')
        
        # تنظیمات زمان‌بندی
        collection_config = self.config_get('collection', {})
        self.interval_minutes = collection_config.get('update_interval_minutes', 5)
        self.interval_seconds = self.interval_minutes * 60
        
        # تنظیمات ماژول‌ها
        self.enabled_modules = {
            'collector': self.config_get('modules.collector.enabled', True),
            'analyzer': self.config_get('modules.analyzer.enabled', True),
            'signal': self.config_get('modules.signal_generator.enabled', True),
            'alerts': self.config_get('modules.alert_sender.enabled', True)
        }
        
        logger.info(f"✅ تنظیمات بارگذاری شد: interval={self.interval_minutes}m ({self.interval_seconds}s)")
    
    def load_module(self, module_name):
        """بارگذاری یک ماژول"""
        if module_name in self.modules:
            return self.modules[module_name]
        
        try:
            # ایجاد instance دیتابیس مشترک (اگر وجود نداشت)
            if not self._shared_db:
                from database_manager import DatabaseManager
                self._shared_db = DatabaseManager()
                logger.info("✅ دیتابیس مشترک برای ماژول‌ها ایجاد شد")
            
            if module_name == 'collector':
                from collector_final import EnhancedCollector
                coin_limit = self.config_get('collection.top_coins_limit', 50)
                self.modules['collector'] = EnhancedCollector(coin_limit=coin_limit)
                logger.info(f"✅ ماژول '{module_name}' بارگذاری شد")
                
            elif module_name == 'analyzer':
                from technical_analyzer import TechnicalAnalyzer
                self.modules['analyzer'] = TechnicalAnalyzer(self._shared_db)
                logger.info(f"✅ ماژول '{module_name}' بارگذاری شد")
                
            elif module_name == 'signal':
                from signal_generator import SignalGenerator
                self.modules['signal'] = SignalGenerator(self._shared_db)
                logger.info(f"✅ ماژول '{module_name}' بارگذاری شد")
                
            elif module_name == 'alerts':
                from alert_sender import AlertSender
                self.modules['alerts'] = AlertSender(self._shared_db)
                logger.info(f"✅ ماژول '{module_name}' بارگذاری شد")
                
            else:
                logger.warning(f"⚠️ ماژول ناشناخته: {module_name}")
                return None
            
            return self.modules[module_name]
            
        except ImportError as e:
            logger.error(f"❌ خطا در بارگذاری ماژول '{module_name}': {e}")
            return None
    
    def execute_module(self, module_name):
        """اجرای یک ماژول"""
        if not self.enabled_modules.get(module_name, False):
            logger.info(f"⏸️ ماژول '{module_name}' غیرفعال است")
            return True
        
        logger.info(f"🚀 اجرای ماژول '{module_name}'...")
        
        try:
            # بارگذاری ماژول اگر نیاز باشد
            module = self.load_module(module_name)
            if not module:
                logger.error(f"❌ ماژول '{module_name}' بارگذاری نشد")
                return False
            
            # اجرای ماژول بر اساس نام آن
            if module_name == 'collector':
                success = module.collect_all_coins()
                
            elif module_name == 'analyzer':
                coin_limit = self.config_get('analysis.coins_to_analyze', 10)
                min_candles = self.config_get('analysis.min_candles_for_analysis', 50)
                success = module.analyze_all_coins(
                    coin_limit=coin_limit,
                    min_candles=min_candles
                )
                
            elif module_name == 'signal':
                min_confidence = self.config_get('signals.min_confidence_score', 70)
                success = module.generate_all_signals(min_confidence)
                
            elif module_name == 'alerts':
                success = module.check_and_send_alerts()
                
            else:
                logger.error(f"❌ تابع اجرا برای '{module_name}' تعریف نشده")
                return False
            
            if success:
                logger.info(f"✅ ماژول '{module_name}' با موفقیت اجرا شد")
            else:
                logger.warning(f"⚠️ ماژول '{module_name}' با مشکل مواجه شد")
            
            return success
            
        except Exception as e:
            logger.error(f"❌ خطا در اجرای ماژول '{module_name}': {e}")
            return False
    
    def run_cycle(self):
        """اجرای یک چرخه کامل"""
        logger.info(" " * 60)
        logger.info("🔄" + "=" * 58 + "🔄")        
        logger.info(f"🚀 شروع چرخه جدید - {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        logger.info("🔄" + "=" * 58 + "🔄")
        
        start_time = time.time()
        
        # ترتیب اجرای ماژول‌ها
        execution_order = ['collector', 'analyzer', 'signal', 'alerts']
        
        results = {}
        
        for module_name in execution_order:
            logger.info(f"\n{'━' * 60}")
            logger.info(f"🎯 اجرای: {module_name}")
            logger.info(f"{'━' * 60}")
            
            try:
                success = self.execute_module(module_name)
                results[module_name] = success
                
                if success:
                    logger.info(f"✅ {module_name} تکمیل شد")
                else:
                    logger.warning(f"⚠️ {module_name} با مشکل مواجه شد")
                    
            except Exception as e:
                logger.error(f"❌ خطای غیرمنتظره در {module_name}: {e}")
                results[module_name] = False
            
            time.sleep(1)  # وقفه کوتاه بین ماژول‌ها
        
        # گزارش نتایج
        execution_time = time.time() - start_time
        
        logger.info("\n" + "📊" + "=" * 58 + "📊")
        logger.info("نتایج اجرا:")
        
        successful = 0
        for module_name, success in results.items():
            status = "✅" if success else "❌"
            logger.info(f"  {status} {module_name}: {'موفق' if success else 'ناموفق'}")
            if success:
                successful += 1
        
        logger.info(f"\n⏱️ زمان کل اجرا: {execution_time:.1f} ثانیه")
        logger.info(f"🎯 موفقیت: {successful}/{len(results)} ماژول")
        logger.info(f"🔄 چرخه بعدی: {self.interval_minutes} دقیقه دیگر")
        logger.info("📊" + "=" * 58 + "📊")
        
        return successful > 0
    
    def start(self):
        """شروع سیستم"""
        logger.info(" " * 60)
        logger.info("🌟" + "=" * 58 + "🌟")
        logger.info(f"🚀 سیستم تحلیل کریپتو - نسخه {self.system_version}")
        logger.info(f"🏷️ {self.system_name}")
        logger.info("🌟" + "=" * 58 + "🌟")
        logger.info(f"📅 تاریخ شروع: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        logger.info(f"⏰ فاصله چرخه‌ها: {self.interval_minutes} دقیقه")
        logger.info("ماژول‌های فعال:")
        
        for module_name, enabled in self.enabled_modules.items():
            status = "✅ فعال" if enabled else "⏸️ غیرفعال"
            logger.info(f"  • {module_name}: {status}")
        
        logger.info("\nبرای توقف Ctrl+C را فشار دهید")
        logger.info("🌟" + "=" * 58 + "🌟")
        
        # اجرای اولیه
        logger.info("\n🔧 در حال اجرای چرخه اول...")
        self.run_cycle()
        
        # زمان‌بندی برای اجراهای بعدی
        try:
            import schedule
            
            # زمان‌بندی با استفاده از تنظیمات
            schedule.every(self.interval_minutes).minutes.do(self.run_cycle)
            
            logger.info(f"\n🔄 زمان‌بندی تنظیم شد: هر {self.interval_minutes} دقیقه")
            
            # حلقه اصلی
            while True:
                schedule.run_pending()
                time.sleep(1)
                
        except ImportError:
            logger.error("❌ کتابخانه schedule نصب نشده")
            logger.info("📦 لطفا با دستور زیر نصب کنید: pip install schedule")
            return False
        except KeyboardInterrupt:
            logger.info("\n\n🛑 سیستم توسط کاربر متوقف شد")
            return True
        except Exception as e:
            logger.error(f"❌ خطای غیرمنتظره: {e}")
            return False


def main():
    """تابع اصلی اجرا"""
    try:
        coordinator = SystemCoordinator()
        coordinator.start()
    except KeyboardInterrupt:
        logger.info("\n🛑 سیستم متوقف شد")
        return 0
    except Exception as e:
        logger.error(f"❌ خطای بحرانی: {e}")
        return 1
    
    return 0


if __name__ == "__main__":
    exit(main())