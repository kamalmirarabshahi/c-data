"""
alert_sender.py - ارسال هشدارها به تلگرام
تاریخ: 2025-12-21
"""

import logging
from datetime import datetime, timedelta
import requests
import time

logger = logging.getLogger(__name__)


class AlertSender:
    """ارسال کننده هشدارها به تلگرام"""
    
    def __init__(self, db_manager=None):
        self.db = db_manager
        self.telegram_bot_token = None
        self.telegram_chat_id = None
        self.telegram_enabled = False
        self._load_config()
    
    def _load_config(self):
        """بارگذاری تنظیمات تلگرام"""
        try:
            from config_manager import get, get_alert_config
            
            alert_config = get_alert_config()
            telegram_config = alert_config.get('telegram', {})
            
            self.telegram_enabled = telegram_config.get('enabled', False)
            self.telegram_bot_token = telegram_config.get('bot_token', '').strip()
            self.telegram_chat_id = telegram_config.get('chat_id', '')
            
            # اعتبارسنجی توکن
            if self.telegram_enabled:
                if not self.telegram_bot_token:
                    logger.error("❌ توکن تلگرام تنظیم نشده!")
                    self.telegram_enabled = False
                elif ':' not in self.telegram_bot_token:
                    logger.error("❌ فرمت توکن تلگرام اشتباه است! باید شامل ':' باشد")
                    self.telegram_enabled = False
                elif not self.telegram_chat_id:
                    logger.error("❌ Chat ID تلگرام تنظیم نشده!")
                    self.telegram_enabled = False
                else:
                    # تست اتصال به ربات
                    test_result = self._test_telegram_connection()
                    if test_result:
                        logger.info("✅ تلگرام راه‌اندازی شد و آماده است")
                    else:
                        logger.error("❌ تلگرام راه‌اندازی نشد - توکن یا Chat ID اشتباه است")
                        self.telegram_enabled = False
            
            logger.info(f"📱 تلگرام: {'✅ فعال' if self.telegram_enabled else '❌ غیرفعال'}")
            
        except Exception as e:
            logger.error(f"❌ خطا در بارگذاری تنظیمات تلگرام: {e}")
            self.telegram_enabled = False
    
    def _test_telegram_connection(self):
        """تست اتصال به تلگرام"""
        try:
            if not self.telegram_bot_token or not self.telegram_chat_id:
                return False
            
            url = f"https://api.telegram.org/bot{self.telegram_bot_token}/getMe"
            response = requests.get(url, timeout=10)
            
            if response.status_code == 200:
                bot_info = response.json()
                if bot_info.get('ok'):
                    logger.info(f"🤖 ربات: @{bot_info['result']['username']}")
                    return True
            return False
            
        except Exception as e:
            logger.error(f"❌ خطا در تست اتصال تلگرام: {e}")
            return False
    
    def check_and_send_alerts(self):
        """بررسی و ارسال هشدارها"""
        if not self.db:
            logger.error("❌ دیتابیس متصل نیست")
            return False
        
        try:
            total_sent = 0
            
            # 1. هشدارهای Breakout
            breakout_alerts = self._get_breakout_alerts()
            if breakout_alerts:
                logger.info(f"📊 {len(breakout_alerts)} هشدار Breakout یافت شد")
                for alert in breakout_alerts:
                    if self._send_breakout_to_telegram(alert):
                        total_sent += 1
                        self._mark_alert_sent(alert['id'])
                        time.sleep(1)  # تاخیر بین ارسال‌ها
            
            # 2. سیگنال‌های معاملاتی
            signal_alerts = self._get_signal_alerts()
            if signal_alerts:
                logger.info(f"📊 {len(signal_alerts)} سیگنال جدید یافت شد")
                for signal in signal_alerts:
                    if self._send_signal_to_telegram(signal):
                        total_sent += 1
                        self._mark_signal_sent(signal['id'])
                        time.sleep(1)  # تاخیر بین ارسال‌ها
            
            if total_sent > 0:
                logger.info(f"✅ {total_sent} هشدار به تلگرام ارسال شد")
            else:
                logger.info("ℹ️ هیچ هشدار جدیدی برای ارسال وجود ندارد")
            
            return total_sent > 0
            
        except Exception as e:
            logger.error(f"❌ خطا در ارسال هشدارها: {e}")
            return False
    
    def _get_breakout_alerts(self):
        """دریافت هشدارهای Breakout"""
        try:
            # کوئری بدون شرط alert_sent (حتی اگر ستون وجود ندارد)
            query = """
            SELECT ba.*, cc.coin_name, cc.symbol
            FROM breakout_alerts ba
            JOIN crypto_coins cc ON cc.id = ba.coin_id
            WHERE ba.alert_time > datetime('now', '-2 hour')
            AND ba.is_confirmed = 1
            ORDER BY ba.breakout_strength DESC
            LIMIT 5
            """
            
            results = self.db.fetch_all(query)
            return results
            
        except Exception as e:
            logger.error(f"❌ خطا در دریافت هشدارهای Breakout: {e}")
            return []
    
    def _get_signal_alerts(self):
        """دریافت سیگنال‌های جدید"""
        try:
            query = """
            SELECT ts.*, cc.coin_name, cc.symbol
            FROM trading_signals ts
            JOIN crypto_coins cc ON cc.id = ts.coin_id
            WHERE ts.signal_time > datetime('now', '-2 hour')
            AND ts.status = 'ACTIVE'
            AND ts.confidence_score >= 70
            ORDER BY ts.confidence_score DESC
            LIMIT 5
            """
            
            results = self.db.fetch_all(query)
            return results
            
        except Exception as e:
            logger.error(f"❌ خطا در دریافت سیگنال‌ها: {e}")
            return []
    
    def _send_breakout_to_telegram(self, alert_data):
        """ارسال هشدار Breakout به تلگرام"""
        if not self.telegram_enabled:
            return False
        
        try:
            coin_name = alert_data.get('coin_name', 'Unknown')
            symbol = alert_data.get('symbol', 'UNKNOWN')
            strength = alert_data.get('breakout_strength', 0)
            price = alert_data.get('breakout_price', 0)
            alert_time = alert_data.get('alert_time', '')
            
            # فرمت کردن پیام
            message = f"""
🚨 *BREAKOUT ALERT* 🚨

*ارز:* {coin_name} ({symbol})
*قدرت:* {strength:.1f}%
*قیمت:* ${price:.4f}
*زمان:* {alert_time}

📈 مقاومت شکسته شده
            """
            
            success = self._send_telegram_message(message)
            if success:
                logger.info(f"✅ هشدار Breakout برای {symbol} ارسال شد")
            return success
            
        except Exception as e:
            logger.error(f"❌ خطا در ارسال هشدار Breakout: {e}")
            return False
    
    def _send_signal_to_telegram(self, signal_data):
        """ارسال سیگنال به تلگرام"""
        if not self.telegram_enabled:
            return False
        
        try:
            coin_name = signal_data.get('coin_name', 'Unknown')
            symbol = signal_data.get('symbol', 'UNKNOWN')
            signal_type = signal_data.get('signal_type', 'UNKNOWN')
            confidence = signal_data.get('confidence_score', 0)
            entry_price = signal_data.get('entry_price', 0)
            stop_loss = signal_data.get('stop_loss', 0)
            take_profit = signal_data.get('take_profit_1', 0)
            current_price = signal_data.get('current_price', 0)
            
            # تعیین ایموجی بر اساس نوع سیگنال
            if 'BUY' in signal_type:
                emoji = "🟢"
                action = "خرید"
            elif 'SELL' in signal_type:
                emoji = "🔴"
                action = "فروش"
            else:
                emoji = "⚪"
                action = "خنثی"
            
            # فرمت کردن پیام
            message = f"""
{emoji} *TRADING SIGNAL* {emoji}

*ارز:* {coin_name} ({symbol})
*عمل:* {action} ({signal_type})
*اطمینان:* {confidence}%

💵 *قیمت‌ها:*
   قیمت فعلی: ${current_price:.4f}
   نقطه ورود: ${entry_price:.4f}
   حد ضرر: ${stop_loss:.4f}
   حد سود: ${take_profit:.4f}

📊 *ریسک/سود:* {(take_profit - entry_price) / (entry_price - stop_loss):.2f}
            """
            
            success = self._send_telegram_message(message)
            if success:
                logger.info(f"✅ سیگنال {signal_type} برای {symbol} ارسال شد")
            return success
            
        except Exception as e:
            logger.error(f"❌ خطا در ارسال سیگنال: {e}")
            return False
    
    def _send_telegram_message(self, message):
        """ارسال پیام به تلگرام"""
        try:
            url = f"https://api.telegram.org/bot{self.telegram_bot_token}/sendMessage"
            
            payload = {
                'chat_id': self.telegram_chat_id,
                'text': message,
                'parse_mode': 'Markdown',
                'disable_web_page_preview': True
            }
            
            response = requests.post(url, data=payload, timeout=10)
            
            if response.status_code == 200:
                return True
            else:
                logger.error(f"❌ خطای تلگرام: {response.status_code}")
                return False
                
        except requests.exceptions.Timeout:
            logger.error("❌ تایم‌اوت در ارسال به تلگرام")
            return False
        except Exception as e:
            logger.error(f"❌ خطا در ارسال به تلگرام: {e}")
            return False
    
    def _mark_alert_sent(self, alert_id):
        """علامت‌گذاری هشدار به عنوان ارسال شده"""
        try:
            # بررسی وجود ستون
            columns = self.db.get_table_columns('breakout_alerts')
            
            if 'alert_sent' in columns:
                query = "UPDATE breakout_alerts SET alert_sent = 1 WHERE id = ?"
                self.db.execute_query(query, (alert_id,))
            else:
                # اگر ستون وجود ندارد، ایجادش کن
                self._add_alert_sent_column()
                query = "UPDATE breakout_alerts SET alert_sent = 1 WHERE id = ?"
                self.db.execute_query(query, (alert_id,))
            
            return True
            
        except Exception as e:
            logger.error(f"❌ خطا در بروزرسانی هشدار: {e}")
            return False
    
    def _add_alert_sent_column(self):
        """اضافه کردن ستون alert_sent به جدول breakout_alerts"""
        try:
            query = "ALTER TABLE breakout_alerts ADD COLUMN alert_sent INTEGER DEFAULT 0"
            self.db.execute_query(query)
            logger.info("✅ ستون alert_sent به جدول breakout_alerts اضافه شد")
            return True
        except Exception as e:
            # ممکن است ستون قبلاً اضافه شده باشد
            logger.debug(f"⚠️ خطا در اضافه کردن ستون (احتمالاً وجود دارد): {e}")
            return False
    
    def _mark_signal_sent(self, signal_id):
        """علامت‌گذاری سیگنال به عنوان ارسال شده"""
        try:
            columns = self.db.get_table_columns('trading_signals')
            
            if 'alert_sent' in columns:
                query = "UPDATE trading_signals SET alert_sent = 1 WHERE id = ?"
                self.db.execute_query(query, (signal_id,))
            else:
                # اضافه کردن ستون اگر وجود ندارد
                query = "ALTER TABLE trading_signals ADD COLUMN alert_sent INTEGER DEFAULT 0"
                self.db.execute_query(query)
                query = "UPDATE trading_signals SET alert_sent = 1 WHERE id = ?"
                self.db.execute_query(query, (signal_id,))
            
            return True
            
        except Exception as e:
            logger.error(f"❌ خطا در بروزرسانی سیگنال: {e}")
            return False
    
    def send_test_message(self):
        """ارسال پیام تست به تلگرام"""
        if not self.telegram_enabled:
            logger.error("❌ تلگرام غیرفعال است")
            return False
        
        try:
            message = """
✅ *TEST MESSAGE* ✅

ربات Crypto Alert فعال شد!
ساعت سیستم: {time}

🤖 ربات آماده دریافت هشدارهاست.
            """.format(time=datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
            
            success = self._send_telegram_message(message)
            if success:
                logger.info("✅ پیام تست به تلگرام ارسال شد")
            return success
            
        except Exception as e:
            logger.error(f"❌ خطا در ارسال پیام تست: {e}")
            return False


# تست مستقل
if __name__ == "__main__":
    print("🔧 تست فایل alert_sender.py")
    print("=" * 50)
    
    from database_manager import DatabaseManager
    
    try:
        db = DatabaseManager()
        alert_sender = AlertSender(db)
        
        print("\n📊 وضعیت تلگرام:")
        print(f"  فعال: {'✅' if alert_sender.telegram_enabled else '❌'}")
        
        if alert_sender.telegram_enabled:
            print("  در حال ارسال پیام تست...")
            test_result = alert_sender.send_test_message()
            print(f"  نتیجه تست: {'✅ موفق' if test_result else '❌ ناموفق'}")
        else:
            print("  ⚠️ لطفا تنظیمات تلگرام را در settings.json بررسی کنید")
            print("""
  تنظیمات مورد نیاز در settings.json:
  {
    "telegram": {
      "bot_token": "توکن_ربات_شما",
      "chat_id": "شماره_چت_شما",
      "enabled": true
    }
  }
            """)
        
        print("\n✅ تست کامل شد")
        db.close()
        
    except Exception as e:
        print(f"❌ خطا در تست: {e}")
    
    print("=" * 50)