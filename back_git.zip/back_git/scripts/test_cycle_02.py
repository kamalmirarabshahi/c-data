﻿import sys
import os
import json
import sqlite3
import requests
import time
from datetime import datetime, timedelta

PROJECT_ROOT = r"C:\Users\Kamal\Desktop\py-prg\git\c-data"
sys.path.insert(0, os.path.join(PROJECT_ROOT, "scripts"))

try:
    from config_manager import get
    DB_PATH = get('database.path')
    BINANCE_URL = get('api.binance.base_url')
    CANDLES_PER_REQUEST = get('collection.candles_per_request', 200)
except:
    DB_PATH = os.path.join(PROJECT_ROOT, "data", "crypto_master.db")
    BINANCE_URL = "https://api.binance.com/api/v3"
    CANDLES_PER_REQUEST = 10  # فقط 10 کندل برای تست

def test_collect_block(block_id=1, test_mode=True):
    """تست جمع‌آوری داده برای یک بلوک"""
    
    print("🧪 تست تکه 2 - جمع‌آوری کندل‌ها")
    print("=" * 50)
    
    # خواندن state
    state_path = os.path.join(PROJECT_ROOT, "state", "cycle_state.json")
    with open(state_path, 'r', encoding='utf-8') as f:
        state = json.load(f)
    
    if block_id > len(state['blocks']):
        print(f"❌ بلوک {block_id} وجود ندارد!")
        return
    
    coins = state['blocks'][block_id-1]['coins'][:3] if test_mode else state['blocks'][block_id-1]['coins']
    print(f"📊 بلوک {block_id}: {len(coins)} ارز برای پردازش")
    
    # اتصال به دیتابیس
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    total_results = {
        'success': 0,
        'failed': 0,
        'total_candles': 0,
        'coins': []
    }
    
    for i, coin in enumerate(coins, 1):
        symbol = coin['symbol']
        coin_id = coin['id']
        
        print(f"\n[{i}/{len(coins)}] پردازش {symbol}...")
        
        try:
            # تبدیل symbol به فرمت Binance
            binance_symbol = symbol.replace('USDT', '') + 'USDT'
            
            # پارامترهای درخواست
            params = {
                'symbol': binance_symbol,
                'interval': '5m',
                'limit': CANDLES_PER_REQUEST
            }
            
            # درخواست API
            start_time = time.time()
            response = requests.get(f"{BINANCE_URL}/klines", params=params, timeout=15)
            response_time = time.time() - start_time
            
            if response.status_code == 200:
                klines = response.json()
                candles_received = len(klines)
                
                # شبیه‌سازی ذخیره در دیتابیس
                print(f"  ✅ {candles_received} کندل دریافت شد ({response_time:.2f} ثانیه)")
                
                # بررسی کندل‌های موجود
                cursor.execute('SELECT COUNT(*) FROM crypto_klines WHERE coin_id = ?', (coin_id,))
                existing = cursor.fetchone()[0]
                
                result = {
                    'symbol': symbol,
                    'status': 'SUCCESS',
                    'candles_received': candles_received,
                    'existing_candles': existing,
                    'response_time': response_time
                }
                
                total_results['success'] += 1
                total_results['total_candles'] += candles_received
                
            else:
                print(f"  ❌ خطای API: کد {response.status_code}")
                result = {
                    'symbol': symbol,
                    'status': 'FAILED',
                    'error_code': response.status_code
                }
                total_results['failed'] += 1
            
        except requests.exceptions.Timeout:
            print(f"  ⏰ تایم‌اوت در دریافت داده")
            result = {'symbol': symbol, 'status': 'TIMEOUT'}
            total_results['failed'] += 1
        except Exception as e:
            print(f"  ❌ خطا: {str(e)[:50]}...")
            result = {'symbol': symbol, 'status': 'ERROR', 'error': str(e)}
            total_results['failed'] += 1
        
        total_results['coins'].append(result)
        
        # تاخیر برای رعایت rate limit
        if i < len(coins):
            time.sleep(1)  # 1 ثانیه تاخیر بین ارزها
    
    conn.close()
    
    # نمایش خلاصه
    print(f"\n{'='*50}")
    print("📊 خلاصه نتایج تست:")
    print(f"  ✅ موفق: {total_results['success']}/{len(coins)}")
    print(f"  ❌ ناموفق: {total_results['failed']}/{len(coins)}")
    print(f"  🕯️ کل کندل‌های دریافتی: {total_results['total_candles']}")
    
    if total_results['success'] > 0:
        avg_candles = total_results['total_candles'] / total_results['success']
        print(f"  📈 میانگین کندل‌ها: {avg_candles:.1f} در هر ارز")
    
    return total_results

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description='تست تکه 2')
    parser.add_argument('--block', type=int, default=1, help='شماره بلوک')
    parser.add_argument('--test', action='store_true', help='حالت تست')
    
    args = parser.parse_args()
    
    results = test_collect_block(args.block, args.test)
    
    if results and results['success'] > 0:
        print("\n🎉 تست تکه 2 موفق بود!")
    else:
        print("\n⚠️ تست تکه 2 با مشکلاتی مواجه شد.")
