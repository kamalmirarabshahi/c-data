#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
سیستم جمع‌آوری 200 کندل 5 دقیقه‌ای - نسخه نهایی
"""

import requests
import sqlite3
import time
import threading
from datetime import datetime, timedelta
import json
import sys
import os
import logging
from concurrent.futures import ThreadPoolExecutor, as_completed

# ==================== تنظیمات ====================
DB_PATH = r"C:\Users\Kamal\Desktop\py-prg\git\c-data\data"
DB_FILE = os.path.join(DB_PATH, "crypto_master.db")
TIMEFRAME = "5m"
LIMIT_CANDLES = 200
MAX_WORKERS = 3
REQUEST_INTERVAL = 1.0
UPDATE_INTERVAL = 300

if not os.path.exists(DB_PATH):
    os.makedirs(DB_PATH, exist_ok=True)

print(f"📁 دیتابیس: {DB_FILE}")
print(f"🎯 هدف: {LIMIT_CANDLES} کندل {TIMEFRAME} برای هر ارز")

# ==================== لاگ‌گیری ====================
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(os.path.join(DB_PATH, 'collector_final.log'), encoding='utf-8'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# ==================== مدیریت دیتابیس ====================
class DatabaseManager:
    def __init__(self, db_file):
        self.db_file = db_file
        self.setup_tables()
    
    def setup_tables(self):
        """ایجاد جدول‌های لازم"""
        conn = sqlite3.connect(self.db_file)
        cursor = conn.cursor()
        
        # بررسی جدول crypto_coins
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='crypto_coins'")
        if not cursor.fetchone():
            logger.error("❌ جدول crypto_coins وجود ندارد!")
            conn.close()
            return False
        
        # بررسی محتوای جدول
        cursor.execute("SELECT COUNT(*) FROM crypto_coins")
        total_coins = cursor.fetchone()[0]
        logger.info(f"📊 تعداد کل ارزها در دیتابیس: {total_coins}")
        
        # ایجاد جدول crypto_klines اگر وجود ندارد
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='crypto_klines'")
        if not cursor.fetchone():
            logger.info("🔧 ایجاد جدول crypto_klines...")
            cursor.execute('''
                CREATE TABLE crypto_klines (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    coin_id INTEGER NOT NULL,
                    timeframe TEXT NOT NULL,
                    open_time TIMESTAMP NOT NULL,
                    close_time TIMESTAMP NOT NULL,
                    candle_date DATE,
                    open_price REAL NOT NULL,
                    high_price REAL NOT NULL,
                    low_price REAL NOT NULL,
                    close_price REAL NOT NULL,
                    volume REAL NOT NULL,
                    quote_volume REAL NOT NULL,
                    number_of_trades INTEGER NOT NULL,
                    taker_buy_volume REAL NOT NULL,
                    taker_sell_volume REAL NOT NULL,
                    taker_buy_quote_volume REAL NOT NULL,
                    source_exchange TEXT DEFAULT 'binance',
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    UNIQUE(coin_id, timeframe, open_time),
                    FOREIGN KEY (coin_id) REFERENCES crypto_coins (id)
                )
            ''')
        
        # جدول لاگ‌گیری
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS collection_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TIMESTAMP NOT NULL,
                symbol TEXT NOT NULL,
                timeframe TEXT NOT NULL,
                candles_requested INTEGER DEFAULT 0,
                candles_received INTEGER DEFAULT 0,
                candles_saved INTEGER DEFAULT 0,
                candles_duplicate INTEGER DEFAULT 0,
                status TEXT NOT NULL,
                error_msg TEXT
            )
        ''')
        
        conn.commit()
        conn.close()
        logger.info("✅ دیتابیس آماده شد")
        return True
    
    def get_top_valid_coins(self, limit=100):
        """دریافت ارزهای برتر معتبر"""
        conn = sqlite3.connect(self.db_file)
        cursor = conn.cursor()
        
        # کوئری ایمن و ساده
        cursor.execute('''
            SELECT id, symbol, base_asset, market_cap_rank
            FROM crypto_coins 
            WHERE symbol IS NOT NULL 
            AND TRIM(symbol) != ''
            AND symbol LIKE '%USDT'
            AND symbol NOT LIKE '%USDTUSDT%'
            AND symbol NOT LIKE '%-%'
            AND symbol NOT LIKE '%.%'
            AND symbol NOT IN ('USDTUSDT', 'STETHUSDT', 'FIGR_HELOCUSDT')
            ORDER BY market_cap_rank ASC
            LIMIT ?
        ''', (limit,))
        
        coins = []
        invalid_coins = []
        
        for row in cursor.fetchall():
            symbol = str(row[1]).strip().upper()
            
            # لیست سمبل‌های شناخته شده نامعتبر
            known_invalid = [
                'QUSDTUSDT', 'SYRUPUSDTUSDT', 'USDTUSDT', 'WAETHUSDTUSDT',
                'BSC-USDUSDT', 'MF-ONEUSDT', 'BTC.BUSDT', 'MAG7.SSIUSDT', 
                'USDC.EUSDT', 'STETHUSDT', 'FIGR_HELOCUSDT', 'WBTUSDT',
                'USDT0USDT', 'USDTBUSDT', 'SUSDT', 'MUSDT'
            ]
            
            if symbol in known_invalid:
                invalid_coins.append(symbol)
                continue
            
            # بررسی طول مناسب
            if len(symbol) < 6 or len(symbol) > 12:
                invalid_coins.append(f"{symbol} (طول: {len(symbol)})")
                continue
            
            # بررسی پایان با USDT
            if not symbol.endswith('USDT'):
                invalid_coins.append(f"{symbol} (بدون USDT)")
                continue
            
            coins.append({
                'id': row[0],
                'symbol': symbol,
                'base_asset': row[2] or symbol.replace('USDT', ''),
                'rank': row[3] or 9999
            })
        
        conn.close()
        
        # گزارش
        logger.info(f"✅ ارزهای معتبر انتخاب شده: {len(coins)}")
        
        if invalid_coins:
            logger.warning(f"❌ ارزهای حذف شده: {len(invalid_coins)}")
            if len(invalid_coins) <= 10:
                for invalid in invalid_coins:
                    logger.warning(f"  • {invalid}")
            else:
                for invalid in invalid_coins[:5]:
                    logger.warning(f"  • {invalid}")
                logger.warning(f"  • و {len(invalid_coins)-5} مورد دیگر...")
        
        if coins:
            logger.info("🏆 10 ارز برتر انتخاب شده:")
            for i, coin in enumerate(coins[:10], 1):
                logger.info(f"  {i:2d}. {coin['symbol']} (رتبه: {coin['rank']})")
        else:
            logger.error("⚠️  هیچ ارز معتبری یافت نشد!")
        
        return coins
    
    def save_batch_klines(self, coin_id, symbol, klines):
        """ذخیره دسته‌ای کندل‌ها"""
        if not klines:
            return 0, 0
        
        conn = sqlite3.connect(self.db_file)
        cursor = conn.cursor()
        
        inserted = 0
        duplicate = 0
        
        for kline in klines:
            try:
                open_time = datetime.fromtimestamp(kline[0] / 1000)
                close_time = datetime.fromtimestamp(kline[6] / 1000)
                
                # محاسبه taker_sell_volume
                volume = float(kline[5])
                taker_buy_volume = float(kline[9])
                taker_sell_volume = max(0, volume - taker_buy_volume)
                
                cursor.execute('''
                    INSERT OR IGNORE INTO crypto_klines (
                        coin_id, timeframe, open_time, close_time, candle_date,
                        open_price, high_price, low_price, close_price,
                        volume, quote_volume, number_of_trades,
                        taker_buy_volume, taker_sell_volume, taker_buy_quote_volume,
                        source_exchange, created_at, updated_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ''', (
                    coin_id, TIMEFRAME, open_time, close_time, open_time.date(),
                    float(kline[1]), float(kline[2]), float(kline[3]), float(kline[4]),
                    volume, float(kline[7]), int(kline[8]),
                    taker_buy_volume, taker_sell_volume, float(kline[10]),
                    'binance', datetime.now(), datetime.now()
                ))
                
                if cursor.rowcount > 0:
                    inserted += 1
                else:
                    duplicate += 1
                    
            except sqlite3.IntegrityError:
                duplicate += 1
            except Exception as e:
                logger.error(f"خطای ذخیره {symbol}: {e}")
                duplicate += 1
        
        if inserted > 0:
            conn.commit()
        
        conn.close()
        return inserted, duplicate
    
    def log_result(self, symbol, requested, received, saved, duplicate, status, error_msg=None):
        """ذخیره لاگ نتیجه"""
        try:
            conn = sqlite3.connect(self.db_file)
            cursor = conn.cursor()
            
            cursor.execute('''
                INSERT INTO collection_logs 
                (timestamp, symbol, timeframe, candles_requested, candles_received,
                 candles_saved, candles_duplicate, status, error_msg)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                datetime.now(), symbol, TIMEFRAME, requested, received,
                saved, duplicate, status, error_msg
            ))
            
            conn.commit()
            conn.close()
        except Exception as e:
            logger.error(f"خطای ذخیره لاگ: {e}")

# ==================== مدیریت Rate Limit ====================
class SmartRateLimiter:
    """مدیریت هوشمند Rate Limit"""
    
    def __init__(self, max_per_minute=1200):
        self.max_per_minute = max_per_minute
        self.request_times = []
        self.lock = threading.Lock()
        self.consecutive_errors = 0
        
    def wait(self):
        """انتظار برای مجوز درخواست"""
        with self.lock:
            now = time.time()
            
            # حذف درخواست‌های قدیمی
            self.request_times = [t for t in self.request_times if now - t < 60]
            
            # اگر خطاهای متوالی داریم، بیشتر صبر کن
            if self.consecutive_errors > 0:
                wait_base = REQUEST_INTERVAL * (self.consecutive_errors + 1)
                time.sleep(min(wait_base, 10))
                self.consecutive_errors = 0
            
            # بررسی محدودیت
            if len(self.request_times) >= self.max_per_minute:
                oldest = min(self.request_times)
                wait_time = 60 - (now - oldest) + 0.1
                logger.warning(f"⏳ Rate Limit - صبر {wait_time:.1f}ث")
                time.sleep(wait_time)
                return self.wait()
            
            # ثبت درخواست
            self.request_times.append(now)
            return True
    
    def record_error(self):
        """ثبت خطا برای افزایش فاصله"""
        with self.lock:
            self.consecutive_errors += 1
    
    def record_success(self):
        """ثبت موفقیت"""
        with self.lock:
            self.consecutive_errors = 0

# ==================== Binance API ====================
class BinanceAPI:
    def __init__(self, rate_limiter):
        self.rate_limiter = rate_limiter
        self.session = requests.Session()
        self.base_url = "https://api.binance.com/api/v3"
        
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'Accept': 'application/json'
        })
        
        self.max_retries = 2
    
    def get_klines(self, symbol):
        """دریافت 200 کندل"""
        if not self.rate_limiter.wait():
            return False, [], "Rate Limit Failed"
        
        url = f"{self.base_url}/klines"
        params = {
            'symbol': symbol,
            'interval': TIMEFRAME,
            'limit': LIMIT_CANDLES
        }
        
        for retry in range(self.max_retries + 1):
            try:
                response = self.session.get(url, params=params, timeout=15)
                
                if response.status_code == 200:
                    self.rate_limiter.record_success()
                    data = response.json()
                    
                    # بررسی تعداد کندل‌های دریافتی
                    if len(data) < LIMIT_CANDLES:
                        logger.warning(f"⚠️  {symbol}: فقط {len(data)} کندل دریافت شد")
                    
                    return True, data, None
                
                elif response.status_code == 400:
                    error_data = response.json() if response.content else {}
                    error_msg = error_data.get('msg', 'Invalid symbol')
                    
                    # اگر سمبل نامعتبر است، دیگر تلاش نکن
                    if "Invalid symbol" in error_msg:
                        return False, [], f"Invalid symbol: {symbol}"
                    
                    self.rate_limiter.record_error()
                    
                    if retry < self.max_retries:
                        time.sleep(2 ** retry)
                        continue
                    
                    return False, [], f"HTTP 400: {error_msg}"
                
                elif response.status_code == 429:
                    self.rate_limiter.record_error()
                    retry_after = int(response.headers.get('Retry-After', 60))
                    
                    if retry < self.max_retries:
                        logger.warning(f"⏳ Rate Limit برای {symbol} - صبر {retry_after}ث")
                        time.sleep(retry_after)
                        continue
                    
                    return False, [], f"Rate Limit Exceeded"
                
                elif response.status_code == 418:
                    logger.critical(f"🚨 IP بلاک شد برای {symbol}!")
                    time.sleep(300)
                    return False, [], "IP Banned"
                
                else:
                    self.rate_limiter.record_error()
                    
                    if retry < self.max_retries:
                        time.sleep(2 ** retry)
                        continue
                    
                    return False, [], f"HTTP {response.status_code}"
                    
            except requests.exceptions.Timeout:
                self.rate_limiter.record_error()
                
                if retry < self.max_retries:
                    logger.warning(f"⏳ Timeout برای {symbol} - تلاش مجدد {retry+1}")
                    time.sleep(2 ** retry)
                    continue
                
                return False, [], "Timeout"
                
            except Exception as e:
                self.rate_limiter.record_error()
                
                if retry < self.max_retries:
                    time.sleep(2 ** retry)
                    continue
                
                return False, [], str(e)
        
        return False, [], "Max retries exceeded"

# ==================== سیستم اصلی ====================
class Collector:
    def __init__(self, coin_limit=50):
        print("\n" + "="*70)
        print("🚀 سیستم جمع‌آوری 200 کندل 5 دقیقه‌ای")
        print(f"📁 دیتابیس: {DB_FILE}")
        print(f"🎯 تعداد ارزها: حداکثر {coin_limit} ارز برتر")
        print("="*70)
        
        self.coin_limit = coin_limit
        self.db = DatabaseManager(DB_FILE)
        self.rate_limiter = SmartRateLimiter()
        self.api = BinanceAPI(self.rate_limiter)
        self.running = True
        
        self.stats = {
            'cycles': 0,
            'coins_processed': 0,
            'success': 0,
            'failed': 0,
            'candles_saved': 0,
            'candles_duplicate': 0,
            'candles_requested': 0,
            'start_time': datetime.now()
        }
    
    def process_coin(self, coin):
        """پردازش یک ارز"""
        symbol = coin['symbol']
        
        logger.info(f"🔄 پردازش {symbol}")
        
        success, klines, error = self.api.get_klines(symbol)
        
        if success and klines:
            saved, duplicate = self.db.save_batch_klines(coin['id'], symbol, klines)
            
            # آپدیت آمار
            self.stats['candles_requested'] += LIMIT_CANDLES
            
            self.db.log_result(
                symbol=symbol,
                requested=LIMIT_CANDLES,
                received=len(klines),
                saved=saved,
                duplicate=duplicate,
                status="SUCCESS"
            )
            
            if saved > 0:
                logger.info(f"✅ {symbol}: {len(klines)} کندل دریافت، {saved} جدید ذخیره شد")
            else:
                logger.info(f"ℹ️  {symbol}: {len(klines)} کندل دریافت، همه تکراری بودند")
            
            return {
                'symbol': symbol,
                'success': True,
                'received': len(klines),
                'saved': saved,
                'duplicate': duplicate,
                'error': None
            }
        else:
            # فقط خطاهای مهم را لاگ کن
            if "Invalid symbol" not in str(error):
                self.db.log_result(
                    symbol=symbol,
                    requested=LIMIT_CANDLES,
                    received=0,
                    saved=0,
                    duplicate=0,
                    status="FAILED",
                    error_msg=error
                )
            
            logger.warning(f"❌ {symbol}: {error}")
            
            return {
                'symbol': symbol,
                'success': False,
                'received': 0,
                'saved': 0,
                'duplicate': 0,
                'error': error
            }
    
    def run_cycle(self):
        """اجرای یک سیکل"""
        self.stats['cycles'] += 1
        cycle_num = self.stats['cycles']
        
        logger.info(f"\n📅 شروع سیکل #{cycle_num}")
        
        # دریافت ارزهای برتر
        coins = self.db.get_top_valid_coins(self.coin_limit)
        
        if not coins:
            logger.error("❌ هیچ ارز معتبری یافت نشد")
            return False
        
        total_coins = len(coins)
        self.stats['coins_processed'] = total_coins
        
        logger.info(f"📊 تعداد ارزهای انتخاب شده: {total_coins}")
        
        success_count = 0
        fail_count = 0
        total_received = 0
        total_saved = 0
        total_duplicate = 0
        
        # پردازش موازی
        with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
            futures = []
            
            # ارسال درخواست‌ها
            for coin in coins:
                if not self.running:
                    break
                
                future = executor.submit(self.process_coin, coin)
                futures.append(future)
                time.sleep(0.3)  # فاصله بین ارسال درخواست‌ها
            
            # پردازش نتایج
            completed = 0
            for future in as_completed(futures):
                if not self.running:
                    break
                
                result = future.result()
                
                if result['success']:
                    success_count += 1
                    total_received += result['received']
                    total_saved += result['saved']
                    total_duplicate += result['duplicate']
                else:
                    fail_count += 1
                
                completed += 1
                
                # نمایش پیشرفت
                if completed % 10 == 0 or completed == total_coins:
                    logger.info(f"📊 پیشرفت: {completed}/{total_coins}")
        
        # آپدیت آمار کلی
        self.stats['success'] += success_count
        self.stats['failed'] += fail_count
        self.stats['candles_saved'] += total_saved
        self.stats['candles_duplicate'] += total_duplicate
        
        logger.info(f"✅ سیکل #{cycle_num} تکمیل شد")
        logger.info(f"   • موفق: {success_count} ارز")
        logger.info(f"   • ناموفق: {fail_count} ارز")
        logger.info(f"   • کندل‌های دریافت شده: {total_received:,}")
        logger.info(f"   • کندل‌های جدید ذخیره: {total_saved:,}")
        logger.info(f"   • کندل‌های تکراری: {total_duplicate:,}")
        
        if total_received > 0:
            success_rate = (total_saved / total_received) * 100
            logger.info(f"   • نرخ موفقیت ذخیره: {success_rate:.1f}%")
        
        return True
    
    def print_detailed_report(self):
        """چاپ گزارش کامل"""
        total_time = datetime.now() - self.stats['start_time']
        hours = total_time.total_seconds() / 3600
        
        print("\n" + "="*80)
        print("📊 گزارش کامل سیستم جمع‌آوری")
        print("="*80)
        
        # آمار اجرا
        print(f"\n⏱️  آمار اجرا:")
        print(f"   • مدت زمان: {str(total_time).split('.')[0]}")
        print(f"   • سیکل‌های اجرا شده: {self.stats['cycles']}")
        print(f"   • کل ارزهای پردازش شده: {self.stats['coins_processed']:,}")
        print(f"   • موفقیت‌ها: {self.stats['success']:,}")
        print(f"   • خطاها: {self.stats['failed']:,}")
        
        # آمار کندل‌ها
        print(f"\n📈 آمار کندل‌ها:")
        print(f"   • کندل‌های درخواست شده: {self.stats['candles_requested']:,}")
        print(f"   • کندل‌های ذخیره شده: {self.stats['candles_saved']:,}")
        print(f"   • کندل‌های تکراری: {self.stats['candles_duplicate']:,}")
        
        if self.stats['candles_requested'] > 0:
            success_rate = (self.stats['candles_saved'] / self.stats['candles_requested']) * 100
            duplicate_rate = (self.stats['candles_duplicate'] / self.stats['candles_requested']) * 100
            print(f"   • نرخ موفقیت: {success_rate:.1f}%")
            print(f"   • نرخ تکراری: {duplicate_rate:.1f}%")
        
        if hours > 0:
            candles_per_hour = self.stats['candles_saved'] / hours
            print(f"   • میانگین کندل/ساعت: {candles_per_hour:,.0f}")
        
        # وضعیت دیتابیس
        conn = sqlite3.connect(DB_FILE)
        cursor = conn.cursor()
        
        cursor.execute("SELECT COUNT(*) FROM crypto_klines WHERE timeframe = ?", (TIMEFRAME,))
        total_klines = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(DISTINCT coin_id) FROM crypto_klines WHERE timeframe = ?", (TIMEFRAME,))
        coins_with_data = cursor.fetchone()[0]
        
        cursor.execute("""
            SELECT c.symbol, COUNT(k.id) as candle_count,
                   MIN(k.open_time) as first_candle,
                   MAX(k.open_time) as last_candle
            FROM crypto_klines k 
            JOIN crypto_coins c ON k.coin_id = c.id 
            WHERE k.timeframe = ?
            GROUP BY k.coin_id 
            ORDER BY COUNT(k.id) DESC 
            LIMIT 10
        """, (TIMEFRAME,))
        top_coins = cursor.fetchall()
        
        print(f"\n💾 وضعیت دیتابیس:")
        print(f"   • کل کندل‌های {TIMEFRAME}: {total_klines:,}")
        print(f"   • ارزهای با داده: {coins_with_data}")
        
        if top_coins:
            print(f"\n🏆 10 ارز برتر (تعداد کندل):")
            print("-" * 70)
            print(f"{'نماد':<10} {'تعداد کندل':<12} {'اولین کندل':<20} {'آخرین کندل':<20}")
            print("-" * 70)
            
            for symbol, count, first, last in top_coins:
                first_str = first[:19] if first else "N/A"
                last_str = last[:19] if last else "N/A"
                print(f"{symbol:<10} {count:<12,} {first_str:<20} {last_str:<20}")
        
        conn.close()
        print("\n" + "="*80)
    
    def run(self):
        """اجرای اصلی"""
        logger.info("🚀 سیستم شروع شد")
        
        try:
            while self.running:
                cycle_start = time.time()
                
                if not self.run_cycle():
                    logger.error("❌ خطا در اجرای سیکل")
                    break
                
                # چاپ گزارش
                self.print_detailed_report()
                
                # انتظار برای سیکل بعدی
                cycle_duration = time.time() - cycle_start
                wait_time = max(10, UPDATE_INTERVAL - cycle_duration)
                
                if self.running and wait_time > 0:
                    logger.info(f"⏳ انتظار {wait_time:.0f} ثانیه برای سیکل بعدی...")
                    
                    # نمایش countdown
                    for i in range(int(wait_time)):
                        if not self.running:
                            break
                        time.sleep(1)
                        
                        if i % 30 == 29 and i < wait_time - 1:
                            remaining = wait_time - i - 1
                            logger.info(f"⏳ {remaining:.0f} ثانیه باقی‌مانده...")
        
        except KeyboardInterrupt:
            logger.info("\n🛑 دریافت سیگنال توقف...")
        except Exception as e:
            logger.error(f"💥 خطای اصلی: {e}")
        finally:
            self.stop()
    
    def stop(self):
        """توقف سیستم"""
        self.running = False
        logger.info("🛑 سیستم متوقف شد")

# ==================== اجرا ====================
def main():
    print("\n" + "="*70)
    print("🚀 سیستم جمع‌آوری 200 کندل 5 دقیقه‌ای")
    print("="*70)
    
    # بررسی کتابخانه‌ها
    try:
        import requests
    except ImportError:
        print("❌ کتابخانه requests نصب نیست!")
        print("📦 دستور: pip install requests")
        return
    
    # تعیین تعداد ارزها
    try:
        coin_limit = int(input("👉 تعداد ارزهای برتر برای جمع‌آوری (پیشفرض: 50): ") or "50")
        if coin_limit <= 0 or coin_limit > 500:
            print("⚠️  تعداد نامعتبر، از 50 استفاده می‌شود")
            coin_limit = 50
    except:
        coin_limit = 50
    
    collector = Collector(coin_limit=coin_limit)
    
    try:
        collector.run()
    except KeyboardInterrupt:
        print("\n\n🛑 توسط کاربر متوقف شد")
    except Exception as e:
        print(f"\n💥 خطا: {e}")
    
    # گزارش نهایی
    collector.print_detailed_report()
    
    print(f"\n📝 فایل لاگ: {os.path.join(DB_PATH, 'collector_final.log')}")
    print("✅ پایان اجرا")

if __name__ == "__main__":
    main()