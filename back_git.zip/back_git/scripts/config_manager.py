import json
import os
from pathlib import Path

# مسیر کامل فایل settings.json
# بر اساس ساختار پوشه شما:
# C:\Users\Kamal\Desktop\py-prg\git\c-data\
#   ├── config\settings.json
#   ├── scripts\config_manager.py
#   └── data\crypto_master.db

# پیدا کردن مسیر پروژه به صورت خودکار
# اگر config_manager.py در scripts باشد:
# __file__ = C:\Users\Kamal\Desktop\py-prg\git\c-data\scripts\config_manager.py
# parent.parent = C:\Users\Kamal\Desktop\py-prg\git\c-data
PROJECT_ROOT = Path(__file__).parent.parent
CONFIG_DIR = PROJECT_ROOT / "config"
DATA_DIR = PROJECT_ROOT / "data"
SCRIPTS_DIR = PROJECT_ROOT / "scripts"
LOGS_DIR = PROJECT_ROOT / "logs"

# مسیر فایل تنظیمات
CONFIG_PATH = CONFIG_DIR / "settings.json"

# متغیر جهانی تنظیمات
_SETTINGS = None


def _load_settings():
    """بارگذاری تنظیمات از فایل JSON"""
    global _SETTINGS
    
    try:
        if CONFIG_PATH.exists():
            with open(CONFIG_PATH, 'r', encoding='utf-8') as f:
                _SETTINGS = json.load(f)
            print(f"✅ تنظیمات از {CONFIG_PATH} بارگذاری شد")
            
            # اطمینان از وجود مسیرهای ضروری
            _ensure_directories()
            
            return True
        else:
            print(f"⚠️ فایل تنظیمات یافت نشد: {CONFIG_PATH}")
            _SETTINGS = {}
            return False
    except json.JSONDecodeError as e:
        print(f"❌ خطا در خواندن JSON: {e}")
        _SETTINGS = {}
        return False
    except Exception as e:
        print(f"❌ خطای ناشناخته: {e}")
        _SETTINGS = {}
        return False


def _ensure_directories():
    """ایجاد پوشه‌های ضروری اگر وجود ندارند"""
    try:
        # پوشه‌های اصلی
        directories = [
            CONFIG_DIR,
            DATA_DIR,
            SCRIPTS_DIR,
            LOGS_DIR,
            PROJECT_ROOT / "backups"
        ]
        
        for directory in directories:
            directory.mkdir(parents=True, exist_ok=True)
            print(f"📁 پوشه آماده است: {directory}")
            
    except Exception as e:
        print(f"⚠️ خطا در ایجاد پوشه‌ها: {e}")


def get(key_path, default=None):
    """
    دریافت مقدار از تنظیمات با کلید نقطه‌ای
    
    مثال:
        config.get('api.binance.base_url')
        config.get('analysis.rsi_period', 14)
        config.get('database.path', 'data/crypto_master.db')
    """
    global _SETTINGS
    
    # اگر تنظیمات هنوز بارگذاری نشده
    if _SETTINGS is None:
        _load_settings()
    
    if _SETTINGS is None or not _SETTINGS:
        return default
    
    # تقسیم کلید به بخش‌ها
    keys = key_path.split('.')
    value = _SETTINGS
    
    # دنبال کردن مسیر کلید
    for key in keys:
        if isinstance(value, dict) and key in value:
            value = value[key]
        else:
            return default
    
    return value


# توابع کمکی برای دسترسی راحت‌تر
def get_system_config():
    """دریافت تنظیمات سیستم"""
    return get('system', {})


def get_database_config():
    """دریافت تنظیمات دیتابیس"""
    return get('database', {})


def get_api_config(service='binance'):
    """دریافت تنظیمات API"""
    return get(f'api.{service}', {})


def get_collection_config():
    """دریافت تنظیمات جمع‌آوری داده"""
    return get('collection', {})


def get_analysis_config():
    """دریافت تنظیمات تحلیل تکنیکال"""
    return get('analysis', {})


def get_signal_config():
    """دریافت تنظیمات سیگنال"""
    return get('signals', {})


def get_alert_config():
    """دریافت تنظیمات هشدار"""
    return get('alerts', {})


def get_logging_config():
    """دریافت تنظیمات لاگ‌گیری"""
    return get('logging', {})


# توابع جدید برای مسیرها
def get_path_config():
    """دریافت تنظیمات مسیرها"""
    return get('paths', {})


def get_project_root():
    """دریافت مسیر اصلی پروژه"""
    paths = get_path_config()
    return paths.get('project_root', str(PROJECT_ROOT))


def get_scripts_dir():
    """دریافت مسیر فایل‌های اجرایی"""
    paths = get_path_config()
    return paths.get('scripts_dir', str(SCRIPTS_DIR))


def get_config_dir():
    """دریافت مسیر فایل‌های کانفیگ"""
    paths = get_path_config()
    return paths.get('config_dir', str(CONFIG_DIR))


def get_data_dir():
    """دریافت مسیر دیتابیس و داده‌ها"""
    paths = get_path_config()
    return paths.get('data_dir', str(DATA_DIR))


def get_logs_dir():
    """دریافت مسیر لاگ‌ها"""
    paths = get_path_config()
    return paths.get('logs_dir', str(LOGS_DIR))


def get_database_path():
    """دریافت مسیر دیتابیس"""
    db_config = get_database_config()
    path = db_config.get('path', '')
    
    if path and os.path.isabs(path):
        return path
    else:
        # اگر مسیر نسبی است، نسبت به data_dir بساز
        data_dir = get_data_dir()
        return os.path.join(data_dir, 'crypto_master.db')


def reload():
    """بارگذاری مجدد تنظیمات از فایل"""
    return _load_settings()


# بارگذاری اولیه تنظیمات هنگام import
_load_settings()


# تست مستقل
if __name__ == "__main__":
    print("=" * 50)
    print("🔧 تست فایل config_manager.py")
    print("=" * 50)
    
    print(f"\n📁 ساختار پروژه:")
    print(f"  1. مسیر اصلی پروژه: {get_project_root()}")
    print(f"  2. مسیر اسکریپت‌ها: {get_scripts_dir()}")
    print(f"  3. مسیر کانفیگ: {get_config_dir()}")
    print(f"  4. مسیر داده‌ها: {get_data_dir()}")
    print(f"  5. مسیر لاگ‌ها: {get_logs_dir()}")
    
    print(f"\n📁 مسیر دیتابیس:")
    print(f"  6. از config: {get('database.path')}")
    print(f"  7. از تابع: {get_database_path()}")
    
    print("\n📋 نمونه تنظیمات دیگر:")
    print(f"  8. نام سیستم: {get('system.name')}")
    print(f"  9. ورژن: {get('system.version')}")
    
    print("\n🔗 تنظیمات API:")
    print(f"  10. Binance URL: {get('api.binance.base_url')}")
    
    print("\n📈 تنظیمات تحلیل:")
    print(f"  11. RSI Period: {get('analysis.rsi_period')}")
    
    # تست وجود فایل‌ها
    print("\n🔍 بررسی وجود فایل‌ها:")
    print(f"  12. فایل تنظیمات: {os.path.exists(CONFIG_PATH)} ({CONFIG_PATH})")
    print(f"  13. پوشه داده‌ها: {os.path.exists(get_data_dir())}")
    print(f"  14. دیتابیس: {os.path.exists(get_database_path())}")
    
    print("\n" + "=" * 50)
    print("✅ تست کامل شد")
    print("✨ برای استفاده در کدهای دیگر:")
    print("   from config_manager import get, get_database_path, get_project_root")
    print("=" * 50)