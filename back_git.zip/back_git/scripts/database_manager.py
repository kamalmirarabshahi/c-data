"""
database_manager.py - مدیریت اتصال به دیتابیس SQLite
تاریخ: 2025-12-21
هدف: ایجاد اتصال و اجرای کوئری‌های دیتابیس
"""

import sqlite3
import logging
from pathlib import Path
from datetime import datetime
from typing import List, Dict, Any, Optional, Union

# راه‌اندازی لاگر
logger = logging.getLogger(__name__)

# ایمپورت config_manager
try:
    from config_manager import get, get_database_config, reload
    CONFIG_LOADED = True
except ImportError as e:
    logger.error(f"❌ config_manager یافت نشد: {e}")
    logger.error("🚨 سیستم نمی‌تواند ادامه دهد.")
    CONFIG_LOADED = False


class DatabaseManager:
    """مدیریت کامل دیتابیس SQLite"""
    
    def __init__(self, db_path: Optional[str] = None):
        """
        مقداردهی اولیه DatabaseManager
        """
        self.connection = None
        self.cursor = None
        
        # 1️⃣ بررسی وجود config_manager
        if not CONFIG_LOADED:
            error_msg = """
❌ config_manager یافت نشد!
🚨 سیستم متوقف می‌شود.
"""
            logger.error(error_msg)
            raise ImportError("config_manager یافت نشد. سیستم متوقف می‌شود.")
        
        # 2️⃣ تعیین مسیر دیتابیس
        if db_path:
            # اگر کاربر مسیر مشخص کرده، از آن استفاده کن
            self.db_path = db_path
        else:
            # از config_manager بگیر
            self.db_path = self._get_database_path_from_config()
        
        # 3️⃣ بررسی وجود فایل دیتابیس - فقط بررسی، بدون ایجاد
        if not Path(self.db_path).exists():
            error_msg = f"""
❌ فایل دیتابیس یافت نشد!
📁 مسیر: {self.db_path}
🚨 سیستم متوقف می‌شود.
🔧 لطفا ابتدا Collector را اجرا کنید تا دیتابیس ایجاد شود.
"""
            logger.error(error_msg)
            raise FileNotFoundError(f"فایل دیتابیس یافت نشد: {self.db_path}")
        
        # 4️⃣ اتصال به دیتابیس
        try:
            self._connect()
            logger.info(f"✅ اتصال به دیتابیس برقرار شد: {self.db_path}")
        except Exception as e:
            logger.error(f"❌ خطا در اتصال به دیتابیس: {e}")
            raise
    
    def _get_database_path_from_config(self) -> str:
        """دریافت مسیر دیتابیس فقط از config_manager"""
        try:
            # بارگذاری مجدد تنظیمات
            reload()
            
            # دریافت مسیر دیتابیس از config
            db_path = get('database.path')
            
            if not db_path:
                error_msg = """
❌ مسیر دیتابیس در config/settings.json تعریف نشده!
🚨 سیستم متوقف می‌شود.
"""
                logger.error(error_msg)
                raise ValueError("مسیر دیتابیس در تنظیمات تعریف نشده است.")
            
            # تبدیل به Path
            db_path_obj = Path(db_path)
            
            # اگر مسیر نسبی است، آن را به مسیر مطلق تبدیل کن
            if not db_path_obj.is_absolute():
                base_dir = Path.cwd()
                absolute_path = (base_dir / db_path_obj).resolve()
                logger.info(f"📁 مسیر نسبی تبدیل شد: {db_path} → {absolute_path}")
                return str(absolute_path)
            
            return str(db_path_obj.resolve())
            
        except Exception as e:
            logger.error(f"❌ خطا در دریافت مسیر دیتابیس از config: {e}")
            raise
    
    def _connect(self):
        """اتصال به دیتابیس"""
        try:
            # دریافت تنظیمات از config
            reload()
            timeout = get('database.timeout', 30)
            check_same_thread = get('database.check_same_thread', False)
            
            # اتصال به دیتابیس
            self.connection = sqlite3.connect(
                self.db_path,
                timeout=timeout,
                check_same_thread=check_same_thread
            )
            
            # تنظیم row factory
            self.connection.row_factory = sqlite3.Row
            
            # ایجاد cursor
            self.cursor = self.connection.cursor()
            
            # اعمال تنظیمات دیتابیس
            self._apply_database_settings()
            
        except Exception as e:
            logger.error(f"❌ خطا در اتصال به دیتابیس: {e}")
            raise
    
    def _apply_database_settings(self):
        """اعمال تنظیمات اجرایی دیتابیس"""
        try:
            # دریافت تنظیمات از config
            journal_mode = get('database.journal_mode', 'WAL')
            synchronous = get('database.synchronous', 'NORMAL')
            cache_size = get('database.cache_size', -2000)
            
            # اعمال تنظیمات
            self.execute_query(f"PRAGMA journal_mode = {journal_mode}")
            self.execute_query(f"PRAGMA synchronous = {synchronous}")
            self.execute_query(f"PRAGMA cache_size = {cache_size}")
            
            # فعال‌سازی کلیدهای خارجی
            self.execute_query("PRAGMA foreign_keys = ON")
            
            logger.debug(f"✅ تنظیمات دیتابیس اعمال شد")
            
        except Exception as e:
            logger.warning(f"⚠️ خطا در اعمال تنظیمات دیتابیس: {e}")
    
    # ==================== متدهای اصلی ====================
    
    def execute_query(self, query: str, params: Optional[tuple] = None):
        """اجرای یک کوئری"""
        try:
            if params:
                self.cursor.execute(query, params)
            else:
                self.cursor.execute(query)
            self.connection.commit()
            return self.cursor
        except Exception as e:
            logger.error(f"❌ خطا در اجرای کوئری: {e}\nکوئری: {query}")
            raise
    
    def fetch_scalar(self, query: str, params: Optional[tuple] = None) -> Any:
        """اجرای کوئری و دریافت اولین سلول از نتیجه"""
        try:
            if params:
                self.cursor.execute(query, params)
            else:
                self.cursor.execute(query)
            result = self.cursor.fetchone()
            if result:
                return result[0]  # اولین ستون را برگردان
            return None
        except Exception as e:
            logger.error(f"❌ خطا در fetch_scalar: {e}")
            return None
    
    def fetch_all(self, query: str, params: Optional[tuple] = None) -> List[Dict]:
        """دریافت همه نتایج"""
        try:
            cursor = self.execute_query(query, params)
            results = cursor.fetchall()
            return [dict(row) for row in results]
        except Exception as e:
            logger.error(f"❌ خطا در دریافت داده: {e}")
            return []
    
    def fetch_one(self, query: str, params: Optional[tuple] = None) -> Optional[Dict]:
        """دریافت اولین نتیجه"""
        try:
            cursor = self.execute_query(query, params)
            result = cursor.fetchone()
            return dict(result) if result else None
        except Exception as e:
            logger.error(f"❌ خطا در دریافت داده: {e}")
            return None
    
    def table_exists(self, table_name: str) -> bool:
        """بررسی وجود جدول"""
        try:
            query = "SELECT name FROM sqlite_master WHERE type='table' AND name=?"
            result = self.fetch_one(query, (table_name,))
            return result is not None
        except Exception as e:
            logger.error(f"❌ خطا در بررسی وجود جدول '{table_name}': {e}")
            return False
    
    def count_rows(self, table_name: str) -> int:
        """شمردن تعداد ردیف‌های یک جدول"""
        try:
            if not self.table_exists(table_name):
                return 0
            query = f"SELECT COUNT(*) as count FROM {table_name}"
            result = self.fetch_one(query)
            return result['count'] if result else 0
        except Exception as e:
            logger.error(f"❌ خطا در شمارش ردیف‌های '{table_name}': {e}")
            return 0
    
    def get_table_columns(self, table_name: str) -> List[str]:
        """دریافت لیست ستون‌های یک جدول"""
        try:
            if not self.table_exists(table_name):
                return []
            
            query = f"PRAGMA table_info({table_name})"
            results = self.fetch_all(query)
            columns = [row['name'] for row in results]
            return columns
        except Exception as e:
            logger.error(f"❌ خطا در دریافت ستون‌های جدول '{table_name}': {e}")
            return []
    
    def close(self):
        """بستن اتصال به دیتابیس"""
        try:
            if self.connection:
                self.connection.close()
                logger.info("✅ اتصال دیتابیس بسته شد")
        except Exception as e:
            logger.error(f"❌ خطا در بستن اتصال دیتابیس: {e}")
    
    def __enter__(self):
        """برای استفاده با with statement"""
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """برای استفاده با with statement"""
        self.close()


# تست مستقل
if __name__ == "__main__":
    print("🔧 تست فایل database_manager.py")
    print("=" * 50)
    
    try:
        print("🔍 در حال دریافت مسیر دیتابیس از config_manager...")
        
        # ایجاد نمونه دیتابیس
        db = DatabaseManager()
        
        print(f"✅ مسیر دیتابیس: {db.db_path}")
        print(f"📁 فایل دیتابیس وجود دارد: {Path(db.db_path).exists()}")
        
        # تست متد fetch_scalar
        print("\n🧪 تست متد fetch_scalar:")
        test_query = "SELECT COUNT(*) FROM sqlite_master"
        result = db.fetch_scalar(test_query)
        print(f"  تعداد جداول: {result}")
        
        # بررسی جداول اصلی
        print("\n📊 بررسی جداول اصلی:")
        main_tables = ['crypto_coins', 'crypto_klines', 'collection_logs']
        
        for table in main_tables:
            exists = db.table_exists(table)
            status = "✅" if exists else "❌"
            print(f"  {status} {table}: {'وجود دارد' if exists else 'وجود ندارد'}")
            
            if exists:
                count = db.count_rows(table)
                print(f"     تعداد ردیف‌ها: {count}")
        
        print("\n✅ تست با موفقیت انجام شد")
        
        # بستن اتصال
        db.close()
        
    except ImportError as e:
        print(f"❌ خطای حیاتی: {e}")
        print("🚨 سیستم متوقف می‌شود.")
    except FileNotFoundError as e:
        print(f"❌ خطا: {e}")
        print("🚨 سیستم متوقف می‌شود.")
        print("🔧 لطفا ابتدا Collector را اجرا کنید.")
    except Exception as e:
        print(f"❌ خطای غیرمنتظره: {e}")
    
    print("=" * 50)
    