#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
collector_final.py - جمع‌آوری داده از Binance
نسخه سازگار با سیستم اصلی - پردازش بلوک‌های 50 تایی
"""

import requests
import sqlite3
import time
import sys
import os
import random
from datetime import datetime
import logging
from pathlib import Path
from typing import List, Dict, Any, Optional, Tuple

# اضافه کردن مسیر برای import config_manager
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

# اول logger را تعریف کن
logging.basicConfig(
    level=logging.INFO,
    format='[%(asctime)s] %(levelname)s: %(message)s',
    datefmt='%H:%M:%S'
)
logger = logging.getLogger(__name__)

# ایمپورت config_manager
try:
    from config_manager import get, get_database_config, get_api_config, reload
    CONFIG_LOADED = True
except ImportError as e:
    logger.error(f"❌ config_manager.py یافت نشد: {e}")
    logger.error("🚨 config_manager باید در دسترس باشد!")
    CONFIG_LOADED = False
    sys.exit(1)


class EnhancedCollector:
    """جمع‌آوری داده از Binance API - نسخه سازگار"""
    
    def __init__(self, coin_limit: int = 50, **kwargs):
        """
        مقداردهی اولیه کالکتور (سازگار با سیستم اصلی)
        
        پارامترها:
            coin_limit: تعداد ارز در هر بلوک (برای سازگاری)
            **kwargs: پارامترهای اضافی
        """
        logger.info("🔧 راه‌اندازی کالکتور سازگار...")
        
        # پارامترهای سازگاری
        self.block_size = coin_limit  # استفاده از coin_limit برای سازگاری
        self.candles_per_coin = kwargs.get('candles_per_coin', 70)
        
        # نمایش پیام سازگاری
        logger.info(f"📊 استفاده از coin_limit={coin_limit} به عنوان اندازه بلوک")
        logger.info(f"📊 candles_per_coin={self.candles_per_coin}")
        
        # دریافت مسیر دیتابیس فقط از config_manager
        self.db_path = self._get_database_path_from_config_only()
        
        # بررسی وجود دیتابیس
        if not self._verify_database_exists():
            self._handle_database_not_found()
            sys.exit(1)
        
        # بارگذاری سایر تنظیمات
        self.load_configurations()
        
        # تنظیمات Rate Limiting
        self.min_delay_between_requests = 0.1  # حداقل تاخیر بین درخواست‌ها
        self.max_delay_between_requests = 0.3  # حداکثر تاخیر بین درخواست‌ها
        
        # تنظیمات تاخیر بین بلوک‌ها
        self.min_delay_between_blocks = 5.0    # حداقل تاخیر بین بلوک‌ها
        self.max_delay_between_blocks = 15.0   # حداکثر تاخیر بین بلوک‌ها
        
        # آمار جمع‌آوری
        self.total_coins = 0
        self.total_blocks = 0
        self.current_block = 0
        
        logger.info(f"✅ کالکتور راه‌اندازی شد: بلوک‌های {self.block_size} تایی")
    
    def _get_database_path_from_config_only(self) -> str:
        """دریافت مسیر دیتابیس فقط و فقط از config_manager"""
        if not CONFIG_LOADED:
            logger.error("❌ config_manager در دسترس نیست!")
            sys.exit(1)
        
        try:
            # بارگذاری مجدد تنظیمات
            reload()
            
            # دریافت مسیر دیتابیس از config
            db_path = get('database.path')
            
            if not db_path:
                error_msg = """
❌ مسیر دیتابیس در config/settings.json تعریف نشده!

لطفا در فایل config/settings.json بخش زیر را اضافه کنید:
{
    "database": {
        "path": "C:\\\\Users\\\\Kamal\\\\Desktop\\\\py-prg\\\\git\\\\c-data\\\\data\\\\crypto_master.db",
        "timeout": 30,
        "journal_mode": "WAL",
        "synchronous": "NORMAL",
        "cache_size": -2000
    }
}
"""
                logger.error(error_msg)
                raise ValueError("مسیر دیتابیس در تنظیمات تعریف نشده است.")
            
            # تبدیل به Path و بررسی
            db_path_obj = Path(db_path)
            
            # اگر مسیر نسبی است، آن را به مسیر مطلق تبدیل کن
            if not db_path_obj.is_absolute():
                base_dir = Path.cwd()
                absolute_path = (base_dir / db_path_obj).resolve()
                logger.info(f"📁 مسیر نسبی تبدیل شد: {db_path} → {absolute_path}")
                return str(absolute_path)
            
            return str(db_path_obj.resolve())
            
        except Exception as e:
            logger.error(f"❌ خطا در دریافت مسیر دیتابیس از config: {e}")
            raise
    
    def _verify_database_exists(self) -> bool:
        """بررسی وجود دیتابیس"""
        try:
            db_file = Path(self.db_path)
            
            if not db_file.exists():
                logger.error(f"❌ فایل دیتابیس یافت نشد: {self.db_path}")
                return False
            
            if not db_file.is_file():
                logger.error(f"❌ مسیر دیتابیس یک فایل نیست: {self.db_path}")
                return False
            
            # بررسی سایز
            size = db_file.stat().st_size
            if size == 0:
                logger.warning(f"⚠️  دیتابیس خالی است: {self.db_path}")
            
            logger.info(f"✅ دیتابیس یافت شد: {self.db_path}")
            logger.info(f"📏 حجم دیتابیس: {size:,} بایت")
            
            return True
            
        except Exception as e:
            logger.error(f"❌ خطا در بررسی دیتابیس: {e}")
            return False
    
    def _handle_database_not_found(self):
        """مدیریت وضعیت عدم یافتن دیتابیس"""
        error_msg = f"""
🚨 **دیتابیس یافت نشد!**

📁 مسیر جستجو شده: {self.db_path}

🔧 **راه‌حل‌های ممکن:**

1. **اجرای Collector اصلی:**
   - ابتدا Collector اصلی را اجرا کنید تا دیتابیس ایجاد شود
   - معمولاً فایلی به نام main.py یا collector.py

2. **بررسی config/settings.json:**
   - مسیر دیتابیس را در فایل config/settings.json بررسی کنید
   - مطمئن شوید مسیر صحیح است

3. **بررسی وجود فایل دیتابیس:**
   - بررسی کنید دیتابیس در مسیر دیگری وجود ندارد
   - ممکن است توسط اسکریپت دیگری ساخته شده باشد

4. **ایجاد دیتابیس به صورت دستی:**
   - اگر دیتابیس وجود ندارد، باید Collector اصلی اجرا شود
   - این اسکریپت خودش هیچ دیتابیسی نمی‌سازد

📌 **نکته:** این اسکریپت فقط برای جمع‌آوری داده است
   و برای ایجاد دیتابیس باید Collector اصلی اجرا شود.
"""
        logger.error(error_msg)
    
    def load_configurations(self):
        """بارگذاری همه تنظیمات از config_manager"""
        try:
            # تنظیمات جمع‌آوری
            collection_config = get('collection', {})
            self.timeframe = collection_config.get('timeframe', '5m')
            self.update_interval = collection_config.get('update_interval_seconds', 300)
            
            # تنظیمات API
            api_config = get_api_config('binance')
            self.binance_base_url = api_config.get('base_url', 'https://api.binance.com/api/v3')
            self.request_timeout = api_config.get('request_timeout', 10)
            
            # تاخیر بین درخواست‌ها
            self.request_delay = collection_config.get('request_delay', 0.5)
            
            logger.info(f"📁 مسیر دیتابیس: {self.db_path}")
            logger.info(f"⚙️ تنظیمات: timeframe={self.timeframe}")
            logger.info(f"⚙️ اندازه بلوک: {self.block_size}, کندل‌ها در هر ارز: {self.candles_per_coin}")
            
        except Exception as e:
            logger.error(f"❌ خطا در بارگذاری تنظیمات: {e}")
            raise
    
    def get_connection(self) -> Optional[sqlite3.Connection]:
        """ایجاد اتصال به دیتابیس"""
        try:
            # بررسی مجدد وجود دیتابیس
            if not Path(self.db_path).exists():
                logger.error(f"❌ فایل دیتابیس حذف شده: {self.db_path}")
                return None
            
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            
            return conn
            
        except Exception as e:
            logger.error(f"❌ خطا در اتصال به دیتابیس: {e}")
            return None
    
    def get_all_coins_from_database(self) -> List[Dict]:
        """دریافت تمام ارزها از دیتابیس بر اساس market_cap_rank"""
        logger.info("📊 دریافت تمام ارزها از دیتابیس...")
        
        conn = self.get_connection()
        if not conn:
            return []
        
        try:
            cursor = conn.cursor()
            
            # دریافت تمام ارزها بر اساس market_cap_rank (از کم به زیاد)
            cursor.execute("""
                SELECT 
                    id, symbol, base_asset, coin_name,
                    market_cap_rank, current_price, volume_24h,
                    last_updated, created_at
                FROM crypto_coins 
                WHERE market_cap_rank IS NOT NULL 
                AND market_cap_rank > 0
                ORDER BY market_cap_rank ASC
            """)
            
            rows = cursor.fetchall()
            coins = []
            
            for row in rows:
                coins.append({
                    'id': row['id'],
                    'symbol': row['symbol'],
                    'base_asset': row['base_asset'],
                    'coin_name': row['coin_name'],
                    'market_cap_rank': row['market_cap_rank'],
                    'current_price': row['current_price'],
                    'volume_24h': row['volume_24h'],
                    'last_updated': row['last_updated'],
                    'created_at': row['created_at']
                })
            
            logger.info(f"✅ {len(coins)} ارز از دیتابیس دریافت شد")
            return coins
            
        except Exception as e:
            logger.error(f"❌ خطا در دریافت ارزها از دیتابیس: {e}")
            return []
        finally:
            conn.close()
    
    def divide_into_blocks(self, coins: List[Dict]) -> List[List[Dict]]:
        """تقسیم لیست ارزها به بلوک‌های 50 تایی"""
        blocks = []
        
        for i in range(0, len(coins), self.block_size):
            block = coins[i:i + self.block_size]
            blocks.append(block)
        
        self.total_coins = len(coins)
        self.total_blocks = len(blocks)
        
        logger.info(f"📦 {len(coins)} ارز به {len(blocks)} بلوک {self.block_size} تایی تقسیم شد")
        
        return blocks
    
    def apply_random_delay(self, min_delay: float, max_delay: float):
        """اعمال تاخیر رندم بین عملیات"""
        delay = random.uniform(min_delay, max_delay)
        logger.debug(f"⏳ تاخیر {delay:.2f} ثانیه...")
        time.sleep(delay)
    
    def fetch_historical_klines(self, symbol: str, limit: int = 70) -> Optional[List]:
        """دریافت کندل‌های تاریخی از Binance"""
        url = f"{self.binance_base_url}/klines"
        params = {
            'symbol': symbol,
            'interval': self.timeframe,
            'limit': limit
        }
        
        try:
            # تاخیر رندم بین درخواست‌ها برای جلوگیری از Rate Limiting
            self.apply_random_delay(self.min_delay_between_requests, self.max_delay_between_requests)
            
            response = requests.get(url, params=params, timeout=self.request_timeout)
            
            if response.status_code == 200:
                return response.json()
            elif response.status_code == 429:  # Too Many Requests
                logger.warning(f"⚠️  Rate Limit برای {symbol} - منتظر می‌مانیم...")
                time.sleep(30)  # تاخیر طولانی‌تر برای Rate Limit
                return None
            else:
                logger.error(f"❌ خطای API برای {symbol}: {response.status_code}")
                return None
                
        except requests.exceptions.Timeout:
            logger.error(f"⏰ تایم‌اوت برای {symbol}")
            return None
        except requests.exceptions.ConnectionError:
            logger.error(f"🔌 خطای اتصال برای {symbol}")
            return None
        except Exception as e:
            logger.error(f"❌ خطای شبکه برای {symbol}: {e}")
            return None
    
    def process_single_coin(self, coin: Dict) -> Tuple[bool, int]:
        """پردازش یک ارز و دریافت کندل‌ها"""
        symbol = coin['symbol']
        coin_id = coin['id']
        
        try:
            # دریافت کندل‌ها
            klines = self.fetch_historical_klines(symbol, limit=self.candles_per_coin)
            
            if not klines:
                logger.warning(f"⚠️  کندلی دریافت نشد: {symbol}")
                return False, 0
            
            # ذخیره کندل‌ها
            saved_count = self._save_klines_to_database(coin_id, symbol, klines)
            
            if saved_count > 0:
                logger.info(f"✅ {symbol}: {saved_count} کندل ذخیره شد")
                return True, saved_count
            else:
                logger.info(f"ℹ️  {symbol}: همه کندل‌ها قبلاً ذخیره شده‌اند")
                return True, 0
                
        except Exception as e:
            logger.error(f"❌ خطا در پردازش {symbol}: {e}")
            return False, 0
    
    def process_block(self, block: List[Dict], block_number: int) -> Dict[str, Any]:
        """پردازش یک بلوک از ارزها"""
        logger.info(f"🚀 شروع پردازش بلوک {block_number}/{self.total_blocks}")
        
        successful_coins = 0
        failed_coins = 0
        total_candles_saved = 0
        
        start_time = time.time()
        
        for i, coin in enumerate(block, 1):
            symbol = coin['symbol']
            rank = coin.get('market_cap_rank', 'N/A')
            
            logger.info(f"[{i}/{len(block)}] 🔄 پردازش {symbol} (رتبه: {rank})...")
            
            success, saved = self.process_single_coin(coin)
            
            if success:
                successful_coins += 1
                total_candles_saved += saved
            else:
                failed_coins += 1
        
        end_time = time.time()
        duration = end_time - start_time
        
        # گزارش بلوک
        report = {
            'block_number': block_number,
            'total_coins': len(block),
            'successful': successful_coins,
            'failed': failed_coins,
            'candles_saved': total_candles_saved,
            'duration_seconds': duration,
            'avg_time_per_coin': duration / len(block) if len(block) > 0 else 0
        }
        
        logger.info(f"📊 گزارش بلوک {block_number}:")
        logger.info(f"   ✅ موفق: {successful_coins}/{len(block)}")
        logger.info(f"   ❌ ناموفق: {failed_coins}/{len(block)}")
        logger.info(f"   🕒 مدت زمان: {duration:.2f} ثانیه")
        logger.info(f"   📈 کندل‌های ذخیره شده: {total_candles_saved}")
        
        return report
    
    def collect_all_coins(self) -> bool:
        """
        تابع اصلی جمع‌آوری - سازگار با سیستم اصلی
        
        این تابع با نام collect_all_coins برای سازگاری با سیستم اصلی
        از بلوک‌بندی 50 تایی استفاده می‌کند
        """
        logger.info("=" * 60)
        logger.info("🚀 شروع جمع‌آوری داده‌ها از Binance (بلوک‌بندی)")
        logger.info("=" * 60)
        
        # دریافت تمام ارزها از دیتابیس
        all_coins = self.get_all_coins_from_database()
        
        if not all_coins:
            logger.error("❌ هیچ ارزی در دیتابیس یافت نشد!")
            return False
        
        # تقسیم به بلوک‌ها
        blocks = self.divide_into_blocks(all_coins)
        
        if not blocks:
            logger.error("❌ بلوک‌بندی انجام نشد!")
            return False
        
        # آمار کلی
        overall_stats = {
            'total_coins': self.total_coins,
            'total_blocks': self.total_blocks,
            'blocks_completed': 0,
            'total_successful': 0,
            'total_failed': 0,
            'total_candles_saved': 0,
            'total_duration': 0
        }
        
        # پردازش هر بلوک
        for i, block in enumerate(blocks, 1):
            self.current_block = i
            
            # پردازش بلوک فعلی
            block_report = self.process_block(block, i)
            
            # به‌روزرسانی آمار کلی
            overall_stats['blocks_completed'] += 1
            overall_stats['total_successful'] += block_report['successful']
            overall_stats['total_failed'] += block_report['failed']
            overall_stats['total_candles_saved'] += block_report['candles_saved']
            overall_stats['total_duration'] += block_report['duration_seconds']
            
            # اگر آخرین بلوک نیست، تاخیر بین بلوک‌ها
            if i < len(blocks):
                logger.info(f"⏳ تاخیر بین بلوک‌ها...")
                self.apply_random_delay(self.min_delay_between_blocks, self.max_delay_between_blocks)
                
                # گزارش پیشرفت
                progress_percent = (i / len(blocks)) * 100
                logger.info(f"📊 پیشرفت کلی: {progress_percent:.1f}% ({i}/{len(blocks)})")
        
        # گزارش نهایی
        self._print_final_report(overall_stats)
        
        return overall_stats['total_successful'] > 0
    
    def _print_final_report(self, stats: Dict[str, Any]):
        """چاپ گزارش نهایی"""
        logger.info("\n" + "=" * 60)
        logger.info("📊 **گزارش نهایی جمع‌آوری**")
        logger.info("=" * 60)
        logger.info(f"💰 تعداد کل ارزها: {stats['total_coins']:,}")
        logger.info(f"📦 تعداد بلوک‌ها: {stats['total_blocks']}")
        logger.info(f"✅ ارزهای موفق: {stats['total_successful']:,}")
        logger.info(f"❌ ارزهای ناموفق: {stats['total_failed']:,}")
        logger.info(f"📈 کندل‌های ذخیره شده: {stats['total_candles_saved']:,}")
        logger.info(f"🕒 مدت زمان کل: {stats['total_duration']:.2f} ثانیه")
        
        if stats['total_coins'] > 0:
            success_rate = (stats['total_successful'] / stats['total_coins']) * 100
            logger.info(f"📊 نرخ موفقیت: {success_rate:.1f}%")
        
        logger.info("=" * 60)
    
    def _save_klines_to_database(self, coin_id: int, symbol: str, klines: List) -> int:
        """ذخیره کندل‌ها در دیتابیس"""
        if not klines:
            return 0
        
        conn = self.get_connection()
        if not conn:
            return 0
        
        cursor = conn.cursor()
        saved_count = 0
        
        try:
            for kline in klines:
                open_time = datetime.fromtimestamp(kline[0] / 1000)
                close_time = datetime.fromtimestamp(kline[6] / 1000)
                
                cursor.execute("""
                    INSERT OR IGNORE INTO crypto_klines 
                    (coin_id, timeframe, open_time, close_time,
                     open_price, high_price, low_price, close_price,
                     volume, quote_volume, number_of_trades,
                     taker_buy_volume, taker_sell_volume, taker_buy_quote_volume,
                     source_exchange)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    coin_id,
                    self.timeframe,
                    open_time.isoformat(),
                    close_time.isoformat(),
                    float(kline[1]),  # open
                    float(kline[2]),  # high
                    float(kline[3]),  # low
                    float(kline[4]),  # close
                    float(kline[5]),  # volume
                    float(kline[7]),  # quote volume
                    int(kline[8]),    # trades
                    float(kline[9]),  # taker buy volume
                    float(kline[10]), # taker sell volume
                    float(kline[11]), # taker buy quote volume
                    'binance'
                ))
                
                if cursor.rowcount > 0:
                    saved_count += 1
            
            conn.commit()
            return saved_count
            
        except Exception as e:
            logger.error(f"❌ خطا در ذخیره کندل‌های {symbol}: {e}")
            conn.rollback()
            return saved_count
        finally:
            conn.close()


# تابع اصلی برای اجرای مستقل
def main():
    """تابع اصلی برای اجرای مستقل"""
    print("=" * 60)
    print("🚀 کالکتور پیشرفته Binance - بلوک‌بندی 50 تایی")
    print("=" * 60)
    
    try:
        # ایجاد کالکتور با پارامتر coin_limit برای سازگاری
        collector = EnhancedCollector(coin_limit=50, candles_per_coin=70)
        
        print(f"\n⚙️  تنظیمات:")
        print(f"   • اندازه بلوک: {collector.block_size} ارز")
        print(f"   • کندل‌ها در هر ارز: {collector.candles_per_coin}")
        print(f"   • تاخیر بین درخواست‌ها: {collector.min_delay_between_requests}-{collector.max_delay_between_requests} ثانیه")
        print(f"   • تاخیر بین بلوک‌ها: {collector.min_delay_between_blocks}-{collector.max_delay_between_blocks} ثانیه")
        print()
        
        success = collector.collect_all_coins()
        
        if success:
            print("\n✅ کالکتور با موفقیت اجرا شد")
            return True
        else:
            print("\n⚠️  کالکتور با مشکلاتی مواجه شد")
            return False
            
    except KeyboardInterrupt:
        print("\n\n⏹️  جمع‌آوری توسط کاربر متوقف شد")
        return False
    except Exception as e:
        print(f"\n❌ خطای غیرمنتظره: {e}")
        import traceback
        traceback.print_exc()
        return False


# تابع سازگار برای سیستم اصلی
def run_collector(**kwargs):
    """
    تابع سازگار برای اجرا توسط سیستم اصلی
    
    پارامترها:
        coin_limit: تعداد ارز در هر بلوک (پیش‌فرض: 50)
        **kwargs: پارامترهای اضافی
    """
    try:
        coin_limit = kwargs.get('coin_limit', 50)
        candles_per_coin = kwargs.get('candles_per_coin', 70)
        
        print(f"🔧 پیکربندی کالکتور (سازگار):")
        print(f"   • coin_limit: {coin_limit} (به عنوان اندازه بلوک استفاده می‌شود)")
        print(f"   • کندل‌ها در هر ارز: {candles_per_coin}")
        print()
        
        collector = EnhancedCollector(coin_limit=coin_limit, candles_per_coin=candles_per_coin)
        return collector.collect_all_coins()
        
    except Exception as e:
        print(f"❌ خطا در اجرای کالکتور: {e}")
        import traceback
        traceback.print_exc()
        return False


if __name__ == "__main__":
    main()
    