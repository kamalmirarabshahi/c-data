"""
result_saver.py - نسخه نهایی اصلاح شده
"""

import os
import sys
import json
import sqlite3
import logging
from datetime import datetime
from typing import Dict, List, Any, Optional

# ==================== تنظیم مسیرها ====================
current_dir = os.path.dirname(os.path.abspath(__file__))
scripts_dir = os.path.dirname(current_dir)
project_root = os.path.dirname(scripts_dir)

sys.path.insert(0, project_root)
sys.path.insert(0, scripts_dir)

try:
    from config_manager import get_database_path
    print(f"✅ config_manager imported")
except ImportError as e:
    print(f"❌ Import error: {e}")
    sys.exit(1)

# ==================== کلاس‌های کمکی ====================
class SimpleLogger:
    def __init__(self, name="result_saver"):
        self.logger = logging.getLogger(name)
        if not self.logger.handlers:
            self._setup()
    
    def _setup(self):
        formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
        
        console = logging.StreamHandler()
        console.setFormatter(formatter)
        
        self.logger.setLevel(logging.INFO)
        self.logger.addHandler(console)
    
    def info(self, msg): self.logger.info(msg)
    def error(self, msg): self.logger.error(msg)
    def warning(self, msg): self.logger.warning(msg)

class DatabaseManager:
    def __init__(self):
        self.db_path = get_database_path()
        self.logger = SimpleLogger("db")
        print(f"📂 Database: {self.db_path}")
    
    def get_conn(self):
        return sqlite3.connect(self.db_path)
    
    def query(self, sql, params=()):
        conn = self.get_conn()
        try:
            conn.row_factory = sqlite3.Row
            cur = conn.cursor()
            cur.execute(sql, params)
            results = cur.fetchall()
            return [dict(row) for row in results]
        finally:
            conn.close()
    
    def execute(self, sql, params=()):
        conn = self.get_conn()
        try:
            cur = conn.cursor()
            cur.execute(sql, params)
            conn.commit()
            return cur.rowcount
        except Exception as e:
            conn.rollback()
            raise e
        finally:
            conn.close()
    
    def get_columns(self, table):
        result = self.query(f"PRAGMA table_info({table})")
        return {col['name']: {'type': col['type'], 'notnull': col['notnull']} 
                for col in result}
    
    def get_symbol(self, coin_id):
        result = self.query("SELECT symbol FROM crypto_coins WHERE id = ?", (coin_id,))
        return result[0]['symbol'] if result else f"COIN_{coin_id}"

# ==================== کلاس اصلی ====================
class ResultSaver:
    def __init__(self):
        self.logger = SimpleLogger()
        self.db = DatabaseManager()
    
    def save_pattern(self, coin_id, timeframe, data):
        """ذخیره تحلیل الگو"""
        symbol = self.db.get_symbol(coin_id)
        timestamp = datetime.now().isoformat()
        
        columns = self.db.get_columns('trading_signals')
        
        # داده‌های اجباری
        mandatory = {
            'coin_id': coin_id,
            'symbol': symbol,
            'timeframe': timeframe,
            'signal_time': timestamp,
            'signal_type': 'pattern',
            'entry_price': data.get('entry_price', 0.0),  # مقدار پیش‌فرض برای NOT NULL
            'current_price': data.get('current_price', 0.0),
            'stop_loss': data.get('stop_loss', 0.0),
            'signal_strength': data.get('confidence_score', 0),
            'confidence_score': data.get('confidence_score', 0),
            'status': 'active'
        }
        
        # اضافه کردن timestamp اگر ستون دارد
        if 'timestamp' in columns:
            mandatory['timestamp'] = timestamp
        
        # اضافه کردن جزئیات
        details = {
            'pattern_name': data.get('pattern_name'),
            'pattern_type': data.get('pattern_type'),
            'confidence': data.get('confidence_score'),
            'risk_reward': data.get('risk_reward_ratio'),
            'take_profit': data.get('take_profit', []),
            'analysis_time': timestamp
        }
        
        if 'signal_details' in columns:
            mandatory['signal_details'] = json.dumps(details, ensure_ascii=False)
        
        # فقط ستون‌های موجود
        cols = []
        vals = []
        for col, val in mandatory.items():
            if col in columns:
                cols.append(col)
                vals.append(val)
        
        # اجرا
        sql = f"INSERT INTO trading_signals ({', '.join(cols)}) VALUES ({', '.join(['?' for _ in vals])})"
        try:
            self.db.execute(sql, vals)
            self.logger.info(f"Pattern saved: {coin_id} ({symbol})")
            return True
        except Exception as e:
            self.logger.error(f"Pattern save failed: {e}")
            return False
    
    def save_divergence(self, coin_id, timeframe, data):
        """ذخیره تحلیل واگرایی"""
        symbol = self.db.get_symbol(coin_id)
        timestamp = datetime.now().isoformat()
        
        columns = self.db.get_columns('trading_signals')
        
        mandatory = {
            'coin_id': coin_id,
            'symbol': symbol,
            'timeframe': timeframe,
            'signal_time': timestamp,
            'signal_type': 'divergence',
            'entry_price': data.get('entry_price', 0.0),
            'current_price': data.get('current_price', 0.0),
            'stop_loss': data.get('stop_loss', 0.0),
            'signal_strength': data.get('strength_score', 0),
            'confidence_score': data.get('confidence_score', 0),
            'status': 'active'
        }
        
        if 'timestamp' in columns:
            mandatory['timestamp'] = timestamp
        
        details = {
            'divergence_type': data.get('divergence_type'),
            'indicator': data.get('indicator', 'RSI'),
            'strength': data.get('strength_score'),
            'risk_reward': data.get('risk_reward_ratio'),
            'analysis_time': timestamp
        }
        
        if 'signal_details' in columns:
            mandatory['signal_details'] = json.dumps(details, ensure_ascii=False)
        
        # فقط ستون‌های موجود
        cols = []
        vals = []
        for col, val in mandatory.items():
            if col in columns:
                cols.append(col)
                vals.append(val)
        
        sql = f"INSERT INTO trading_signals ({', '.join(cols)}) VALUES ({', '.join(['?' for _ in vals])})"
        try:
            self.db.execute(sql, vals)
            self.logger.info(f"Divergence saved: {coin_id} ({symbol})")
            return True
        except Exception as e:
            self.logger.error(f"Divergence save failed: {e}")
            return False
    
    def save_collection_log(self, coin_id, timeframe, data):
        """ذخیره لاگ جمع‌آوری"""
        symbol = self.db.get_symbol(coin_id)
        timestamp = datetime.now().isoformat()
        
        columns = self.db.get_columns('collection_logs')
        
        # بررسی ستون‌های اجباری
        mandatory = {
            'coin_id': coin_id,
            'symbol': symbol,
            'timeframe': timeframe,  # این ستون NOT NULL است
            'timestamp': timestamp,  # این ستون NOT NULL است
            'status': data.get('status', 'completed'),
            'candles_collected': data.get('candles_collected', 0)
        }
        
        # ستون errors اگر وجود دارد
        if 'errors' in columns:
            mandatory['errors'] = data.get('errors', '')
        
        # فقط ستون‌های موجود
        cols = []
        vals = []
        for col, val in mandatory.items():
            if col in columns:
                cols.append(col)
                vals.append(val)
        
        sql = f"INSERT INTO collection_logs ({', '.join(cols)}) VALUES ({', '.join(['?' for _ in vals])})"
        try:
            self.db.execute(sql, vals)
            self.logger.info(f"Collection log saved: {coin_id}")
            return True
        except Exception as e:
            self.logger.error(f"Collection log failed: {e}")
            return False
    
    def update_coin_status(self, coin_id, data):
        """بروزرسانی وضعیت ارز"""
        symbol = self.db.get_symbol(coin_id)
        
        # بررسی وجود رکورد
        existing = self.db.query("SELECT coin_id FROM coin_collection_status WHERE coin_id = ?", (coin_id,))
        
        if existing:
            # آپدیت
            sql = """
                UPDATE coin_collection_status 
                SET last_collection = ?,
                    total_candles = COALESCE(total_candles, 0) + ?,
                    success_count = COALESCE(success_count, 0) + ?,
                    error_count = COALESCE(error_count, 0) + ?
                WHERE coin_id = ?
            """
            params = (
                datetime.now().isoformat(),
                data.get('candles_collected', 0),
                1 if data.get('success', True) else 0,
                0 if data.get('success', True) else 1,
                coin_id
            )
        else:
            # درج جدید
            sql = """
                INSERT INTO coin_collection_status 
                (coin_id, symbol, last_collection, total_candles, success_count, error_count)
                VALUES (?, ?, ?, ?, ?, ?)
            """
            params = (
                coin_id,
                symbol,
                datetime.now().isoformat(),
                data.get('candles_collected', 0),
                1 if data.get('success', True) else 0,
                0 if data.get('success', True) else 1
            )
        
        try:
            self.db.execute(sql, params)
            self.logger.info(f"Coin status updated: {coin_id}")
            return True
        except Exception as e:
            self.logger.error(f"Coin status failed: {e}")
            return False

# ==================== تست ====================
def test():
    print("\n🧪 TESTING RESULT SAVER - FIXED VERSION")
    print("="*50)
    
    saver = ResultSaver()
    
    # پیدا کردن یک ارز واقعی با symbol
    try:
        # ارزی که در crypto_coins وجود دارد
        coins = saver.db.query("""
            SELECT c.id, c.symbol 
            FROM crypto_coins c 
            JOIN crypto_klines k ON c.id = k.coin_id 
            WHERE c.symbol IS NOT NULL 
            LIMIT 1
        """)
        
        if not coins:
            print("❌ No valid coins found")
            return
        
        test_coin = coins[0]['id']
        test_symbol = coins[0]['symbol']
        print(f"\n📊 Testing with: {test_coin} ({test_symbol})")
        
        # تست 1: الگو
        print("\n1. Testing pattern save...")
        pattern_data = {
            'pattern_name': 'Double Bottom',
            'confidence_score': 0.75,
            'entry_price': 49000.0,
            'current_price': 49150.0,
            'stop_loss': 48500.0,
            'risk_reward_ratio': 2.5
        }
        
        if saver.save_pattern(test_coin, '5m', pattern_data):
            print("   ✅ Pattern saved")
        else:
            print("   ❌ Pattern failed")
        
        # تست 2: واگرایی
        print("\n2. Testing divergence save...")
        divergence_data = {
            'divergence_type': 'bullish',
            'strength_score': 0.8,
            'entry_price': 49200.0,
            'current_price': 49300.0,
            'stop_loss': 48800.0
        }
        
        if saver.save_divergence(test_coin, '5m', divergence_data):
            print("   ✅ Divergence saved")
        else:
            print("   ❌ Divergence failed")
        
        # تست 3: لاگ
        print("\n3. Testing collection log...")
        log_data = {
            'candles_collected': 200,
            'status': 'completed',
            'errors': ''
        }
        
        if saver.save_collection_log(test_coin, '5m', log_data):
            print("   ✅ Log saved")
        else:
            print("   ❌ Log failed")
        
        # تست 4: وضعیت
        print("\n4. Testing coin status...")
        status_data = {
            'candles_collected': 200,
            'success': True
        }
        
        if saver.update_coin_status(test_coin, status_data):
            print("   ✅ Status updated")
        else:
            print("   ❌ Status failed")
        
        print("\n" + "="*50)
        print("✅ ALL TESTS COMPLETED")
        
    except Exception as e:
        print(f"❌ Test error: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    test()