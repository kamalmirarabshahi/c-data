"""
ابزارهای مشترک و کمکی برای تکه ۴
"""

import os
import sys
import json
import logging
import sqlite3
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional
import pandas as pd
import numpy as np

# ==================== تنظیم مسیرها برای import ====================
# اضافه کردن مسیر پروژه به sys.path
current_dir = os.path.dirname(os.path.abspath(__file__))
scripts_dir = os.path.dirname(current_dir)  # یک سطح بالا (scripts/)
project_root = os.path.dirname(scripts_dir)  # دو سطح بالا (c-data/)

sys.path.insert(0, project_root)
sys.path.insert(0, scripts_dir)

# حالا import کنیم
try:
    from config_manager import get, get_database_path, get_project_root, get_logs_dir
    print(f"✅ config_manager imported successfully")
except ImportError as e:
    print(f"❌ Failed to import config_manager: {e}")
    print(f"📁 Current dir: {current_dir}")
    print(f"📁 Scripts dir: {scripts_dir}")
    print(f"📁 Project root: {project_root}")
    sys.exit(1)

# ==================== کلاس لاگر ====================
class Cycle04Logger:
    """لاگر اختصاصی برای تکه ۴"""
    
    def __init__(self, name="cycle_04"):
        self.logger = logging.getLogger(name)
        if not self.logger.handlers:
            self._setup_logging()
    
    def _setup_logging(self):
        """تنظیمات لاگ‌گیری"""
        # دریافت مسیر لاگ‌ها از config_manager
        log_dir = get_logs_dir()
        os.makedirs(log_dir, exist_ok=True)
        
        log_file = os.path.join(log_dir, "cycle_04.log")
        
        # فرمت لاگ
        formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        )
        
        # Handler فایل
        file_handler = logging.FileHandler(log_file, encoding='utf-8')
        file_handler.setFormatter(formatter)
        file_handler.setLevel(logging.INFO)
        
        # Handler کنسول
        console_handler = logging.StreamHandler()
        console_handler.setFormatter(formatter)
        console_handler.setLevel(logging.INFO)
        
        # تنظیم logger اصلی
        self.logger.setLevel(logging.INFO)
        self.logger.addHandler(file_handler)
        self.logger.addHandler(console_handler)
        
        print(f"📝 Logging initialized: {log_file}")
    
    def info(self, message):
        """ثبت اطلاعات"""
        self.logger.info(message)
    
    def warning(self, message):
        """ثبت هشدار"""
        self.logger.warning(message)
    
    def error(self, message):
        """ثبت خطا"""
        self.logger.error(message)
    
    def debug(self, message):
        """ثبت دیباگ"""
        self.logger.debug(message)

# ==================== مدیریت دیتابیس ====================
class DatabaseManager:
    """مدیریت اتصال و کوئری‌های دیتابیس"""
    
    def __init__(self):
        self.db_path = get_database_path()
        self.logger = Cycle04Logger("database")
        
        # بررسی وجود دیتابیس
        if not os.path.exists(self.db_path):
            self.logger.error(f"Database file not found: {self.db_path}")
            print(f"❌ Database file not found: {self.db_path}")
            raise FileNotFoundError(f"Database file not found: {self.db_path}")
        
        self.logger.info(f"Database initialized: {self.db_path}")
        print(f"✅ Database path: {self.db_path}")
    
    def get_connection(self):
        """ایجاد اتصال به دیتابیس"""
        try:
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row  # برای بازگشت دیکشنری
            return conn
        except Exception as e:
            self.logger.error(f"Failed to connect to database: {e}")
            raise
    
    def execute_query(self, query, params=()):
        """اجرای کوئری SELECT و بازگشت نتایج"""
        conn = None
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            cursor.execute(query, params)
            results = cursor.fetchall()
            
            # تبدیل به لیست دیکشنری
            if results:
                columns = [column[0] for column in cursor.description]
                return [dict(zip(columns, row)) for row in results]
            return []
            
        except Exception as e:
            self.logger.error(f"Query execution failed: {e}")
            print(f"❌ Query error: {e}")
            raise
        finally:
            if conn:
                conn.close()
    
    def execute_update(self, query, params=()):
        """اجرای کوئری INSERT/UPDATE/DELETE"""
        conn = None
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            cursor.execute(query, params)
            conn.commit()
            affected_rows = cursor.rowcount
            self.logger.debug(f"Query affected {affected_rows} rows")
            return affected_rows
            
        except Exception as e:
            self.logger.error(f"Update execution failed: {e}")
            if conn:
                conn.rollback()
            raise
        finally:
            if conn:
                conn.close()
    
    def get_candles_for_coin(self, coin_id: str, timeframe: str = "5m", limit: int = 200):
        """دریافت کندل‌های یک ارز"""
        self.logger.info(f"Fetching candles for {coin_id} (timeframe: {timeframe}, limit: {limit})")
        
        query = """
            SELECT 
                id, coin_id, timeframe, open_time, close_time,
                open_price, high_price, low_price, close_price,
                volume, quote_volume, rsi, macd, ma_7, ma_25, ma_99,
                bollinger_upper, bollinger_middle, bollinger_lower,
                atr, volume_ma_20, price_change, price_change_percent,
                is_doji, is_hammer, is_shooting_star
            FROM crypto_klines 
            WHERE coin_id = ? AND timeframe = ?
            ORDER BY open_time ASC
            LIMIT ?
        """
        return self.execute_query(query, (coin_id, timeframe, limit))
    
    def get_coin_info(self, coin_id: str):
        """دریافت اطلاعات یک ارز"""
        query = """
            SELECT id, symbol, name, current_price, price_change_24h,
                   price_change_percent_24h, high_24h, low_24h, volume_24h,
                   market_cap, last_updated
            FROM crypto_coins
            WHERE id = ?
        """
        results = self.execute_query(query, (coin_id,))
        return results[0] if results else None
    
    def get_available_coins(self, limit: int = 10):
        """دریافت لیست ارزهای موجود"""
        query = """
            SELECT DISTINCT coin_id 
            FROM crypto_klines 
            WHERE rsi IS NOT NULL 
            LIMIT ?
        """
        return self.execute_query(query, (limit,))

# ==================== پردازش داده ====================
class DataProcessor:
    """پردازش و تبدیل داده‌ها"""
    
    def __init__(self):
        self.logger = Cycle04Logger("data_processor")
    
    def candles_to_dataframe(self, candles: List[Dict]) -> pd.DataFrame:
        """تبدیل لیست کندل‌ها به DataFrame"""
        if not candles:
            self.logger.warning("Empty candles list provided")
            return pd.DataFrame()
        
        self.logger.info(f"Converting {len(candles)} candles to DataFrame")
        
        try:
            df = pd.DataFrame(candles)
            
            # تبدیل تاریخ‌ها
            if 'open_time' in df.columns:
                df['open_time'] = pd.to_datetime(df['open_time'])
                df.set_index('open_time', inplace=True)
                df.sort_index(inplace=True)
            
            self.logger.info(f"DataFrame created: {len(df)} rows, {len(df.columns)} columns")
            return df
            
        except Exception as e:
            self.logger.error(f"Failed to create DataFrame: {e}")
            return pd.DataFrame()
    
    def calculate_technical_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """محاسبه ویژگی‌های تکنیکال اضافی"""
        if df.empty:
            return df
        
        df_copy = df.copy()
        
        # ویژگی‌های پایه
        df_copy['price_range'] = df_copy['high_price'] - df_copy['low_price']
        df_copy['body_size'] = abs(df_copy['close_price'] - df_copy['open_price'])
        df_copy['body_percentage'] = df_copy['body_size'] / df_copy['open_price'] * 100
        
        # نسبت سایه‌ها
        df_copy['upper_shadow'] = df_copy['high_price'] - df_copy[['open_price', 'close_price']].max(axis=1)
        df_copy['lower_shadow'] = df_copy[['open_price', 'close_price']].min(axis=1) - df_copy['low_price']
        df_copy['total_shadow'] = df_copy['upper_shadow'] + df_copy['lower_shadow']
        
        # نسبت حجم
        if 'volume_ma_20' in df_copy.columns:
            df_copy['volume_ratio'] = df_copy['volume'] / df_copy['volume_ma_20'].replace(0, 1)
        
        # موقعیت قیمت در بولینگر
        if all(col in df_copy.columns for col in ['bollinger_upper', 'bollinger_lower']):
            df_copy['bb_position'] = (df_copy['close_price'] - df_copy['bollinger_lower']) / \
                                    (df_copy['bollinger_upper'] - df_copy['bollinger_lower'])
        
        self.logger.info("Technical features calculated")
        return df_copy
    
    def validate_data(self, df: pd.DataFrame) -> Dict[str, Any]:
        """اعتبارسنجی کیفیت داده‌ها"""
        validation = {
            'total_rows': len(df),
            'quality_score': 100,
            'issues': []
        }
        
        if df.empty:
            validation['quality_score'] = 0
            validation['issues'].append('empty_dataframe')
            return validation
        
        # بررسی ستون‌های ضروری
        required_cols = ['open_price', 'high_price', 'low_price', 'close_price', 'volume']
        for col in required_cols:
            if col not in df.columns:
                validation['issues'].append(f'missing_column:{col}')
                validation['quality_score'] -= 20
            elif df[col].isna().any():
                missing = df[col].isna().sum()
                validation['issues'].append(f'null_values:{col}:{missing}')
                validation['quality_score'] -= (missing / len(df)) * 20
        
        # بررسی سازگاری قیمت‌ها
        if all(col in df.columns for col in required_cols):
            price_errors = (
                (df['high_price'] < df['low_price']) |
                (df['high_price'] < df['close_price']) |
                (df['high_price'] < df['open_price']) |
                (df['low_price'] > df['close_price']) |
                (df['low_price'] > df['open_price'])
            ).sum()
            
            if price_errors > 0:
                validation['issues'].append(f'price_inconsistencies:{price_errors}')
                validation['quality_score'] -= (price_errors / len(df)) * 30
        
        validation['quality_score'] = max(0, round(validation['quality_score'], 2))
        return validation

# ==================== ابزارهای کمکی ====================
class PerformanceTimer:
    """اندازه‌گیری زمان اجرا"""
    
    def __init__(self):
        self.start_time = None
        self.checkpoints = {}
    
    def start(self):
        """شروع اندازه‌گیری"""
        self.start_time = datetime.now()
        self.checkpoints = {}
        return self
    
    def checkpoint(self, name: str):
        """ثبت نقطه زمانی"""
        if self.start_time:
            elapsed = (datetime.now() - self.start_time).total_seconds()
            self.checkpoints[name] = elapsed
    
    def get_report(self) -> Dict[str, Any]:
        """گزارش زمان‌ها"""
        if not self.start_time:
            return {}
        
        total = (datetime.now() - self.start_time).total_seconds()
        report = {
            'total_seconds': round(total, 2),
            'checkpoints': {},
            'timestamp': datetime.now().isoformat()
        }
        
        for name, time in self.checkpoints.items():
            percent = (time / total * 100) if total > 0 else 0
            report['checkpoints'][name] = {
                'seconds': round(time, 2),
                'percent': round(percent, 1)
            }
        
        return report

# ==================== نمونه‌های سراسری ====================
logger = Cycle04Logger()
db = DatabaseManager()
processor = DataProcessor()
timer = PerformanceTimer()

# ==================== تست ماژول ====================
def run_self_test():
    """تست خودکار ماژول"""
    print("\n" + "="*60)
    print("🧪 CYCLE 04 UTILITIES - SELF TEST")
    print("="*60)
    
    timer.start()
    
    # 1. تست دیتابیس
    print("\n1. 📊 Database Test")
    try:
        # بررسی جداول
        tables_query = "SELECT name FROM sqlite_master WHERE type='table'"
        tables = db.execute_query(tables_query)
        print(f"   ✅ Found {len(tables)} tables")
        
        # بررسی ارزهای موجود
        coins = db.get_available_coins(5)
        if coins:
            print(f"   ✅ Available coins: {[c['coin_id'] for c in coins]}")
        
        timer.checkpoint("database_test")
        
    except Exception as e:
        print(f"   ❌ Database test failed: {e}")
    
    # 2. تست دریافت داده
    print("\n2. 📈 Data Retrieval Test")
    try:
        if coins:
            test_coin = coins[0]['coin_id']
            candles = db.get_candles_for_coin(test_coin, limit=5)
            
            if candles:
                print(f"   ✅ Retrieved {len(candles)} candles for {test_coin}")
                
                # پردازش داده
                df = processor.candles_to_dataframe(candles)
                print(f"   ✅ Created DataFrame: {df.shape[0]} rows × {df.shape[1]} cols")
                
                # اعتبارسنجی
                validation = processor.validate_data(df)
                print(f"   ✅ Data quality: {validation['quality_score']}%")
                
                timer.checkpoint("data_processing")
            else:
                print(f"   ⚠️ No candles found for {test_coin}")
    except Exception as e:
        print(f"   ❌ Data test failed: {e}")
    
    # 3. گزارش نهایی
    print("\n3. 📋 Summary")
    report = timer.get_report()
    print(f"   ⏱️ Total time: {report.get('total_seconds', 0):.2f} seconds")
    
    print("\n" + "="*60)
    print("✅ UTILITIES TEST COMPLETED SUCCESSFULLY")
    print("="*60)

# اجرای تست هنگام اجرای مستقیم فایل
if __name__ == "__main__":
    run_self_test()