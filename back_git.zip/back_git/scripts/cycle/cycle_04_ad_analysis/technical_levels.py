"""
ماژول شناسایی سطوح تکنیکال (حمایت، مقاومت، پیوت‌ها، کانال‌ها)
همه تنظیمات از config_manager خوانده می‌شود
"""

import numpy as np
import logging
from typing import List, Dict, Tuple, Optional
from datetime import datetime

# Import config manager
try:
    from config_manager import get, get_database_path
except ImportError:
    # Fallback for relative import
    import sys
    import os
    sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))
    from config_manager import get, get_database_path


class TechnicalLevels:
    """
    کلاس شناسایی سطوح تکنیکال
    - شناسایی حمایت/مقاومت
    - محاسبه پیوت پوینت‌ها
    - شناسایی کانال‌های قیمتی
    """
    
    def __init__(self, logger=None):
        """مقداردهی اولیه با تنظیمات از config_manager"""
        self.logger = logger or logging.getLogger(__name__)
        
        # دریافت تنظیمات از config_manager
        self.window_size = get('technical_levels.window_size', 20)
        self.merge_threshold = get('technical_levels.merge_threshold', 0.005)  # 0.5%
        self.min_touch_count = get('technical_levels.min_touch_count', 2)
        self.validity_period = get('technical_levels.validity_period', 50)  # کندل
        self.price_tolerance = get('technical_levels.price_tolerance', 0.002)  # 0.2%
        
        self.logger.debug(f"تنظیمات TechnicalLevels: window={self.window_size}, "
                         f"merge_threshold={self.merge_threshold}")
    
    # ==================== توابع اصلی تحلیل ====================
    
    def analyze_levels(self, coin_id: int, candles: List[Dict], 
                      timeframe: str = '5m') -> Optional[Dict]:
        """
        تحلیل اصلی سطوح تکنیکال برای یک ارز
        
        Args:
            coin_id: شناسه ارز در دیتابیس
            candles: لیست کندل‌ها
            timeframe: تایم‌فریم تحلیل
            
        Returns:
            دیکشنری حاوی نتایج تحلیل
        """
        try:
            if not candles or len(candles) < self.window_size * 2:
                self.logger.warning(f"داده‌های ناکافی برای ارز {coin_id}: {len(candles)} کندل")
                return None
            
            self.logger.info(f"شروع تحلیل سطوح تکنیکال برای ارز {coin_id} ({len(candles)} کندل)")
            
            # استخراج داده‌ها از کندل‌ها
            close_prices = [c['close_price'] for c in candles]
            high_prices = [c['high_price'] for c in candles]
            low_prices = [c['low_price'] for c in candles]
            
            # محاسبه آخرین قیمت
            current_price = close_prices[-1] if close_prices else 0
            
            # اجرای تمام تحلیل‌ها
            results = {
                'coin_id': coin_id,
                'timeframe': timeframe,
                'analysis_time': datetime.now().isoformat(),
                'candle_count': len(candles),
                'current_price': current_price,
                'supports': self._identify_supports(close_prices, high_prices, low_prices),
                'resistances': self._identify_resistances(close_prices, high_prices, low_prices),
                'pivot_points': self._calculate_pivot_points(high_prices, low_prices, close_prices),
                'price_channels': self._detect_price_channels(close_prices),
                'distance_to_levels': self._calculate_distances(current_price, close_prices),
                'breakout_analysis': self._analyze_breakouts(close_prices, high_prices, low_prices),
                'volume_profile_levels': self._calculate_volume_profile(candles)
            }
            
            # اعتبارسنجی نتایج
            self._validate_results(results)
            
            self.logger.info(f"تحلیل سطوح تکنیکال برای {coin_id} تکمیل شد")
            return results
            
        except Exception as e:
            self.logger.error(f"خطا در تحلیل سطوح تکنیکال برای {coin_id}: {e}", exc_info=True)
            return None
    
    # ==================== شناسایی حمایت‌ها ====================
    
    def _identify_supports(self, closes: List[float], 
                          highs: List[float], 
                          lows: List[float]) -> List[Dict]:
        """شناسایی سطوح حمایت"""
        supports = []
        
        # 1. حمایت‌های مبتنی بر نقاط کف محلی
        for i in range(self.window_size, len(closes) - self.window_size):
            current_low = lows[i]
            local_min = min(lows[i-self.window_size:i+self.window_size+1])
            
            if current_low == local_min:
                strength = self._calculate_strength(lows, i, 'support')
                supports.append({
                    'type': 'local_low',
                    'price': current_low,
                    'index': i,
                    'strength': strength,
                    'touch_count': self._count_touches(lows, current_low, 'support'),
                    'timestamp_index': i
                })
        
        # 2. حمایت‌های مبتنی بر باند پایین بولینگر (اگر محاسبه شده)
        if len(closes) >= 20:
            bb_lower = self._calculate_bollinger_lower(closes)
            if bb_lower:
                supports.append({
                    'type': 'bollinger_lower',
                    'price': bb_lower,
                    'strength': 0.6,
                    'touch_count': 0,
                    'dynamic': True
                })
        
        # ادغام سطوح نزدیک به هم
        merged_supports = self._merge_near_levels(supports)
        
        # فیلتر سطوح معتبر (حداقل 2 بار لمس شده)
        valid_supports = [
            s for s in merged_supports 
            if s.get('touch_count', 0) >= self.min_touch_count
            or s.get('type') in ['bollinger_lower', 'pivot_s1', 'pivot_s2']
        ]
        
        # مرتب‌سازی بر اساس قدرت
        return sorted(valid_supports, key=lambda x: x.get('strength', 0), reverse=True)
    
    # ==================== شناسایی مقاومت‌ها ====================
    
    def _identify_resistances(self, closes: List[float], 
                             highs: List[float], 
                             lows: List[float]) -> List[Dict]:
        """شناسایی سطوح مقاومت"""
        resistances = []
        
        # 1. مقاومت‌های مبتنی بر نقاط اوج محلی
        for i in range(self.window_size, len(closes) - self.window_size):
            current_high = highs[i]
            local_max = max(highs[i-self.window_size:i+self.window_size+1])
            
            if current_high == local_max:
                strength = self._calculate_strength(highs, i, 'resistance')
                resistances.append({
                    'type': 'local_high',
                    'price': current_high,
                    'index': i,
                    'strength': strength,
                    'touch_count': self._count_touches(highs, current_high, 'resistance'),
                    'timestamp_index': i
                })
        
        # 2. مقاومت‌های مبتنی بر باند بالای بولینگر
        if len(closes) >= 20:
            bb_upper = self._calculate_bollinger_upper(closes)
            if bb_upper:
                resistances.append({
                    'type': 'bollinger_upper',
                    'price': bb_upper,
                    'strength': 0.6,
                    'touch_count': 0,
                    'dynamic': True
                })
        
        # ادغام سطوح نزدیک به هم
        merged_resistances = self._merge_near_levels(resistances)
        
        # فیلتر سطوح معتبر
        valid_resistances = [
            r for r in merged_resistances 
            if r.get('touch_count', 0) >= self.min_touch_count
            or r.get('type') in ['bollinger_upper', 'pivot_r1', 'pivot_r2']
        ]
        
        # مرتب‌سازی بر اساس قدرت
        return sorted(valid_resistances, key=lambda x: x.get('strength', 0), reverse=True)
    
    # ==================== محاسبه پیوت پوینت‌ها ====================
    
    def _calculate_pivot_points(self, highs: List[float], 
                               lows: List[float], 
                               closes: List[float]) -> Dict:
        """محاسبه پیوت پوینت‌های کلاسیک"""
        if len(highs) < 5 or len(lows) < 5 or len(closes) < 5:
            return {}
        
        # استفاده از ۵ کندل آخر برای محاسبه
        recent_high = max(highs[-5:])
        recent_low = min(lows[-5:])
        recent_close = closes[-1]
        
        # محاسبه پیوت اصلی
        pivot = (recent_high + recent_low + recent_close) / 3
        
        # محاسبه سطوح
        r1 = 2 * pivot - recent_low
        r2 = pivot + (recent_high - recent_low)
        s1 = 2 * pivot - recent_high
        s2 = pivot - (recent_high - recent_low)
        
        return {
            'pivot': {
                'price': pivot,
                'type': 'pivot_main'
            },
            'resistances': [
                {'price': r1, 'type': 'pivot_r1'},
                {'price': r2, 'type': 'pivot_r2'}
            ],
            'supports': [
                {'price': s1, 'type': 'pivot_s1'},
                {'price': s2, 'type': 'pivot_s2'}
            ]
        }
    
    # ==================== شناسایی کانال‌های قیمتی ====================
    
    def _detect_price_channels(self, prices: List[float]) -> List[Dict]:
        """شناسایی کانال‌های قیمتی"""
        if len(prices) < 30:
            return []
        
        channels = []
        
        # تحلیل رگرسیون خطی برای شناسایی روند
        x = np.arange(len(prices))
        y = np.array(prices)
        
        # محاسبه خط روند
        try:
            coefficients = np.polyfit(x, y, 1)
            trend_line = np.poly1d(coefficients)(x)
            
            # محاسبه انحراف معیار از خط روند
            deviations = y - trend_line
            std_dev = np.std(deviations)
            
            # شناسایی کانال‌های موازی
            upper_channel = trend_line + std_dev
            lower_channel = trend_line - std_dev
            
            # تعیین نوع کانال
            slope = coefficients[0]
            if slope > 0.001:
                channel_type = 'ascending'
            elif slope < -0.001:
                channel_type = 'descending'
            else:
                channel_type = 'horizontal'
            
            # بررسی اعتبار کانال (تعداد نقاط داخل کانال)
            points_in_channel = np.sum((y >= lower_channel) & (y <= upper_channel))
            channel_strength = points_in_channel / len(prices)
            
            if channel_strength > 0.6:  # حداقل ۶۰٪ نقاط داخل کانال
                channels.append({
                    'type': channel_type,
                    'upper_bound': float(upper_channel[-1]),
                    'lower_bound': float(lower_channel[-1]),
                    'width': float(upper_channel[-1] - lower_channel[-1]),
                    'strength': float(channel_strength),
                    'slope': float(slope)
                })
                
        except Exception as e:
            self.logger.warning(f"خطا در شناسایی کانال: {e}")
        
        return channels
    
    # ==================== توابع کمکی ====================
    
    def _calculate_strength(self, prices: List[float], index: int, 
                           level_type: str) -> float:
        """محاسبه قدرت سطح"""
        if len(prices) < 10:
            return 0.5
        
        strength = 0.5  # حداقل قدرت
        
        # 1. تعداد لمس‌های قبلی
        touch_count = self._count_touches(prices, prices[index], level_type)
        strength += min(touch_count * 0.1, 0.3)  # حداکثر ۰.۳
        
        # 2. حجم معاملات در آن سطح (اگر موجود باشد)
        # این قسمت در نسخه کامل با داده‌های حجم تکمیل می‌شود
        
        # 3. قدمت سطح (هر چه قدیمی‌تر قوی‌تر)
        age_factor = 1 - (index / len(prices))
        strength += age_factor * 0.2  # حداکثر ۰.۲
        
        return min(strength, 1.0)  # محدود کردن به ۱
    
    def _count_touches(self, prices: List[float], level_price: float, 
                      level_type: str) -> int:
        """شمارش تعداد لمس‌های یک سطح"""
        tolerance = level_price * self.price_tolerance
        count = 0
        
        for price in prices:
            if level_type == 'support':
                # برای حمایت: قیمت نزدیک به سطح از پایین
                if abs(price - level_price) <= tolerance and price <= level_price:
                    count += 1
            else:  # resistance
                # برای مقاومت: قیمت نزدیک به سطح از بالا
                if abs(price - level_price) <= tolerance and price >= level_price:
                    count += 1
        
        return count
    
    def _merge_near_levels(self, levels: List[Dict]) -> List[Dict]:
        """ادغام سطوح نزدیک به هم"""
        if not levels:
            return []
        
        # مرتب‌سازی بر اساس قیمت
        sorted_levels = sorted(levels, key=lambda x: x['price'])
        merged = []
        
        current = sorted_levels[0].copy()
        
        for level in sorted_levels[1:]:
            price_diff = abs(level['price'] - current['price']) / current['price']
            
            if price_diff <= self.merge_threshold:
                # ادغام سطوح
                current['price'] = (current['price'] + level['price']) / 2  # میانگین
                current['strength'] = max(current.get('strength', 0), level.get('strength', 0))
                current['touch_count'] = current.get('touch_count', 1) + level.get('touch_count', 1)
            else:
                merged.append(current)
                current = level.copy()
        
        merged.append(current)
        return merged
    
    def _calculate_bollinger_upper(self, prices: List[float]) -> Optional[float]:
        """محاسبه باند بالای بولینگر"""
        if len(prices) < 20:
            return None
        
        recent_prices = prices[-20:]
        ma = np.mean(recent_prices)
        std = np.std(recent_prices)
        
        return ma + (2 * std)
    
    def _calculate_bollinger_lower(self, prices: List[float]) -> Optional[float]:
        """محاسبه باند پایین بولینگر"""
        if len(prices) < 20:
            return None
        
        recent_prices = prices[-20:]
        ma = np.mean(recent_prices)
        std = np.std(recent_prices)
        
        return ma - (2 * std)
    
    def _calculate_distances(self, current_price: float, 
                            prices: List[float]) -> Dict:
        """محاسبه فاصله تا سطوح کلیدی"""
        if not prices or current_price <= 0:
            return {}
        
        # محاسبه درصد تغییر از سطوح مختلف
        min_price = min(prices) if prices else current_price
        max_price = max(prices) if prices else current_price
        
        return {
            'distance_to_ath': ((current_price - max_price) / max_price) * 100,
            'distance_to_atl': ((current_price - min_price) / min_price) * 100,
            'current_vs_min': ((current_price - min_price) / min_price) * 100,
            'current_vs_max': ((current_price - max_price) / max_price) * 100
        }
    
    def _analyze_breakouts(self, closes: List[float], 
                          highs: List[float], 
                          lows: List[float]) -> Dict:
        """تحلیل شکست سطوح"""
        if len(closes) < 10:
            return {}
        
        recent_high = max(highs[-10:])
        recent_low = min(lows[-10:])
        current_close = closes[-1]
        
        return {
            'breakout_high': current_close > recent_high,
            'breakout_low': current_close < recent_low,
            'resistance_breakout': self._check_resistance_breakout(closes, highs),
            'support_breakout': self._check_support_breakout(closes, lows)
        }
    
    def _check_resistance_breakout(self, closes: List[float], 
                                  highs: List[float]) -> bool:
        """بررسی شکست مقاومت"""
        if len(closes) < 5:
            return False
        
        # مقاومت اخیر
        recent_resistance = max(highs[-5:-1]) if len(highs) >= 5 else highs[-1]
        current_close = closes[-1]
        
        # شکست با تایید (بسته شدن بالای مقاومت)
        return current_close > recent_resistance * (1 + self.price_tolerance)
    
    def _check_support_breakout(self, closes: List[float], 
                               lows: List[float]) -> bool:
        """بررسی شکست حمایت"""
        if len(closes) < 5:
            return False
        
        # حمایت اخیر
        recent_support = min(lows[-5:-1]) if len(lows) >= 5 else lows[-1]
        current_close = closes[-1]
        
        # شکست با تایید (بسته شدن زیر حمایت)
        return current_close < recent_support * (1 - self.price_tolerance)
    
    def _calculate_volume_profile(self, candles: List[Dict]) -> List[Dict]:
        """محاسبه سطوح پرحجم (Volume Profile)"""
        if not candles or len(candles) < 20:
            return []
        
        # گروه‌بندی قیمت‌ها و جمع‌آوری حجم
        price_volume = {}
        
        for candle in candles:
            price_range = [
                candle['low_price'],
                candle['high_price'],
                candle['open_price'],
                candle['close_price']
            ]
            
            avg_price = sum(price_range) / len(price_range)
            price_key = round(avg_price, 4)  # گرد کردن به ۴ رقم اعشار
            
            if price_key not in price_volume:
                price_volume[price_key] = 0
            
            price_volume[price_key] += candle.get('volume', 0)
        
        # تبدیل به لیست و مرتب‌سازی
        volume_levels = [
            {'price': price, 'volume': volume}
            for price, volume in price_volume.items()
        ]
        
        # مرتب‌سازی بر اساس حجم
        volume_levels.sort(key=lambda x: x['volume'], reverse=True)
        
        # بازگشت ۵ سطح پرحجم برتر
        return volume_levels[:5]
    
    def _validate_results(self, results: Dict) -> bool:
        """اعتبارسنجی نتایج تحلیل"""
        if not results:
            return False
        
        required_fields = ['coin_id', 'current_price', 'supports', 'resistances']
        
        for field in required_fields:
            if field not in results:
                self.logger.warning(f"فیلد ضروری {field} در نتایج وجود ندارد")
                return False
        
        # بررسی مقادیر معتبر
        if results['current_price'] <= 0:
            self.logger.warning(f"قیمت جاری نامعتبر: {results['current_price']}")
            return False
        
        return True
    
    # ==================== توابع کاربردی برای استفاده خارجی ====================
    
    def get_nearest_levels(self, current_price: float, 
                          supports: List[Dict], 
                          resistances: List[Dict]) -> Dict:
        """
        پیدا کردن نزدیک‌ترین سطوح حمایت و مقاومت به قیمت فعلی
        """
        nearest_support = None
        nearest_resistance = None
        min_support_diff = float('inf')
        min_resistance_diff = float('inf')
        
        # نزدیک‌ترین حمایت (بالاتر از قیمت فعلی)
        for support in supports:
            if support['price'] < current_price:
                diff = current_price - support['price']
                if diff < min_support_diff:
                    min_support_diff = diff
                    nearest_support = support
        
        # نزدیک‌ترین مقاومت (پایین‌تر از قیمت فعلی)
        for resistance in resistances:
            if resistance['price'] > current_price:
                diff = resistance['price'] - current_price
                if diff < min_resistance_diff:
                    min_resistance_diff = diff
                    nearest_resistance = resistance
        
        return {
            'nearest_support': nearest_support,
            'nearest_resistance': nearest_resistance,
            'support_distance_percent': (min_support_diff / current_price * 100) 
                if min_support_diff != float('inf') else None,
            'resistance_distance_percent': (min_resistance_diff / current_price * 100) 
                if min_resistance_diff != float('inf') else None
        }
    
    def format_results_for_display(self, results: Dict) -> str:
        """قالب‌بندی نتایج برای نمایش"""
        if not results:
            return "هیچ نتیجه‌ای برای نمایش وجود ندارد"
        
        output = []
        output.append(f"📊 تحلیل سطوح تکنیکال - ارز #{results['coin_id']}")
        output.append(f"⏰ تایم‌فریم: {results.get('timeframe', '5m')}")
        output.append(f"💰 قیمت فعلی: {results['current_price']:.8f}")
        output.append("")
        
        # سطوح حمایت
        if results['supports']:
            output.append("🛡️ **سطوح حمایت:**")
            for i, support in enumerate(results['supports'][:5], 1):
                output.append(f"  {i}. {support['price']:.8f} "
                            f"(قدرت: {support.get('strength', 0):.2f}, "
                            f"لمس: {support.get('touch_count', 0)})")
        
        # سطوح مقاومت
        if results['resistances']:
            output.append("")
            output.append("🛑 **سطوح مقاومت:**")
            for i, resistance in enumerate(results['resistances'][:5], 1):
                output.append(f"  {i}. {resistance['price']:.8f} "
                            f"(قدرت: {resistance.get('strength', 0):.2f}, "
                            f"لمس: {resistance.get('touch_count', 0)})")
        
        # پیوت پوینت‌ها
        if results['pivot_points']:
            output.append("")
            output.append("🎯 **پیوت پوینت‌ها:**")
            pivot_data = results['pivot_points']
            if 'pivot' in pivot_data:
                output.append(f"  • پیوت: {pivot_data['pivot']['price']:.8f}")
            
            for r in pivot_data.get('resistances', []):
                output.append(f"  • R{i}: {r['price']:.8f}")
            
            for s in pivot_data.get('supports', []):
                output.append(f"  • S{i}: {s['price']:.8f}")
        
        return "\n".join(output)


# ==================== تست ماژول ====================

if __name__ == "__main__":
    """تست مستقل ماژول"""
    import sys
    import os
    
    # تنظیم لاگ‌گیری
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    logger = logging.getLogger(__name__)
    
    # ایجاد نمونه‌ای از کلاس
    tech_levels = TechnicalLevels(logger=logger)
    
    # داده‌های نمونه برای تست
    sample_candles = [
        {
            'open_price': 100.0,
            'high_price': 105.0,
            'low_price': 98.0,
            'close_price': 103.0,
            'volume': 1000
        } for _ in range(50)
    ]
    
    # اضافه کردن کمی نوسان
    for i, candle in enumerate(sample_candles):
        candle['high_price'] += i * 0.1
        candle['low_price'] += i * 0.05
        candle['close_price'] += i * 0.08
    
    # اجرای تحلیل
    print("🧪 تست ماژول TechnicalLevels...")
    results = tech_levels.analyze_levels(
        coin_id=1125,  # BTCUSDT
        candles=sample_candles,
        timeframe='5m'
    )
    
    if results:
        print("✅ تست موفقیت‌آمیز بود!")
        print(f"تعداد سطوح حمایت شناسایی شده: {len(results['supports'])}")
        print(f"تعداد سطوح مقاومت شناسایی شده: {len(results['resistances'])}")
        
        # نمایش فرمت شده
        print("\n📋 خلاصه نتایج:")
        print(tech_levels.format_results_for_display(results))
    else:
        print("❌ تست ناموفق بود!")
    
    print("\n✅ ماژول TechnicalLevels آماده استفاده است!")