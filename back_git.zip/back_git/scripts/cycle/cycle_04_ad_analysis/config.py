"""
تنظیمات تخصصی تکه ۴ - تحلیل پیشرفته
"""

CYCLE_04_CONFIG = {
    "version": "1.0.0",
    "description": "Cycle 04 - Advanced Technical Analysis",
    
    # تنظیمات تشخیص الگو
    "pattern_detection": {
        "enabled": True,
        "min_pattern_length": 5,
        "max_pattern_length": 50,
        "confidence_threshold": 0.65,
        "max_patterns_per_coin": 10
    },
    
    # تنظیمات تحلیل واگرایی
    "divergence": {
        "enabled": True,
        "rsi_period": 14,
        "lookback_period": 20,
        "min_divergence_strength": 0.5
    },
    
    # تنظیمات سطوح تکنیکال
    "technical_levels": {
        "enabled": True,
        "support_resistance_distance": 0.02,  # 2%
        "pivot_points_enabled": True,
        "fibonacci_levels": [0.236, 0.382, 0.5, 0.618, 0.786]
    },
    
    # تنظیمات تحلیل چندزمانه
    "multi_timeframe": {
        "enabled": True,
        "timeframes": ["5m", "15m", "1h", "4h"],
        "alignment_threshold": 0.7
    },
    
    # تنظیمات مدیریت ریسک
    "risk_management": {
        "max_risk_per_trade": 0.02,  # 2%
        "min_reward_risk_ratio": 1.5,
        "position_sizing_method": "kelly"  # fixed, percent, kelly
    },
    
    # تنظیمات پایگاه داده
    "database": {
        "advanced_analysis_table": "advanced_analysis",
        "pattern_table": "price_patterns",
        "divergence_table": "divergence_signals"
    },
    
    # تنظیمات اجرا
    "execution": {
        "batch_size": 10,
        "delay_between_coins": 0.5,  # seconds
        "max_retries": 3
    }
}

# تنظیمات API
API_ENDPOINTS = {
    "get_candle_data": """
        SELECT * FROM crypto_klines 
        WHERE coin_id = ? AND timeframe = ? 
        ORDER BY open_time DESC LIMIT ?
    """,
    "get_coin_info": "SELECT * FROM crypto_coins WHERE id = ?"
}

def get_config(key, default=None):
    """دریافت مقدار از تنظیمات"""
    keys = key.split('.')
    value = CYCLE_04_CONFIG
    
    for k in keys:
        if isinstance(value, dict) and k in value:
            value = value[k]
        else:
            return default
    
    return value

def validate_config():
    """اعتبارسنجی تنظیمات"""
    errors = []
    
    # بررسی تنظیمات ضروری
    required_keys = [
        "pattern_detection.enabled",
        "divergence.enabled",
        "technical_levels.enabled"
    ]
    
    for key in required_keys:
        if get_config(key) is None:
            errors.append(f"Missing required config: {key}")
    
    return errors

if __name__ == "__main__":
    # تست تنظیمات
    print("🔧 Testing Cycle 04 Configuration")
    errors = validate_config()
    
    if errors:
        print(f"❌ Config validation errors: {errors}")
    else:
        print("✅ Configuration is valid")
        
    # نمایش برخی تنظیمات
    print(f"\n📊 Sample Config Values:")
    print(f"- Pattern Confidence Threshold: {get_config('pattern_detection.confidence_threshold')}")
    print(f"- RSI Period: {get_config('divergence.rsi_period')}")
    print(f"- Max Risk Per Trade: {get_config('risk_management.max_risk_per_trade')*100}%")