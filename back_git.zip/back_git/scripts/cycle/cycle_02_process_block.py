"""
فایل: cycle_02_process_block.py
مسیر: /cycle/cycle_02_process_block.py
عملکرد: پردازش بلوک فعلی یا مشخص شده و جمع‌آوری داده‌های کندل از Binance
تاریخ: 2024-12-25
ورژن: 2.1 (حل مشکل Open=Close در ارزهای کم‌قیمت - بدون فیلدهای جدید)
"""

import os
import sys
import sqlite3
import json
import time
import requests
import argparse
from datetime import datetime
from pathlib import Path
from decimal import Decimal, getcontext
import math

# ==================== DECIMAL PRECISION SETUP ====================
# تنظیم دقت بالا برای Decimal (حل مشکل دقت ارزهای کم‌قیمت)
getcontext().prec = 15

# ==================== PRICE PRECISION FUNCTIONS ====================
def adjust_price_precision(open_price_str, close_price_str, high_price_str, low_price_str):
    """
    تنظیم دقت برای ارزهای کم‌قیمت و جلوگیری از Open=Close
    فقط برای ارزهای زیر ۰.۰۱ دلار - بدون فیلدهای جدید در دیتابیس
    Returns: (open_final, close_final, high_final, low_final, was_adjusted)
    """
    try:
        # تبدیل به Decimal برای دقت بالا
        open_dec = Decimal(open_price_str)
        close_dec = Decimal(close_price_str)
        high_dec = Decimal(high_price_str)
        low_dec = Decimal(low_price_str)
        
        # فقط برای ارزهای کم‌قیمت (قیمت زیر 0.01 دلار)
        is_low_price = open_dec < Decimal('0.01')
        
        # فقط اگر Open=Close در ارزهای کم‌قیمت بود، اصلاح کن
        if is_low_price and open_dec == close_dec:
            # محاسبه کوچکترین گام ممکن
            if '.' in open_price_str:
                decimal_places = len(open_price_str.split('.')[1])
                smallest_step = Decimal('1') / (Decimal('10') ** decimal_places)
            else:
                smallest_step = Decimal('0.00000001')  # 8 رقم اعشار پیش‌فرض بایننس
            
            # ایجاد تغییر کوچک
            was_adjusted = False
            
            # اگر High > Open، Close را کمی بالا ببر
            if high_dec > open_dec:
                adjusted_close = close_dec + smallest_step
                was_adjusted = True
            # اگر Low < Open، Close را کمی پایین ببر
            elif low_dec < open_dec:
                adjusted_close = close_dec - smallest_step
                was_adjusted = True
            else:
                # اگر همه برابرند، کمی بالا ببر
                adjusted_close = close_dec + smallest_step
                was_adjusted = True
            
            return str(open_dec), str(adjusted_close), str(high_dec), str(low_dec), was_adjusted
        else:
            # برای ارزهای معمولی، بدون تغییر
            return open_price_str, close_price_str, high_price_str, low_price_str, False
            
    except Exception as e:
        print(f"⚠️ خطا در adjust_price_precision: {e}")
        # در صورت خطا، مقادیر اصلی را برگردان
        return open_price_str, close_price_str, high_price_str, low_price_str, False

# ==================== CONFIGURATION ====================
def load_config():
    """بارگذاری تنظیمات از فایل کانفیگ - سازگار با ساختار شما"""
    try:
        # مسیر فایل کانفیگ
        current_dir = os.path.dirname(os.path.abspath(__file__))
        config_file = os.path.join(current_dir, "..", "..", "config", "settings.json")
        config_file = os.path.abspath(config_file)
        
        print(f"📁 مسیر فایل کانفیگ: {config_file}")
        
        if not os.path.exists(config_file):
            return {"success": False, "error": f"فایل کانفیگ یافت نشد: {config_file}"}
        
        # خواندن تنظیمات
        with open(config_file, 'r', encoding='utf-8') as f:
            config_data = json.load(f)
        
        # 1. مسیرها (paths)
        paths = config_data.get('paths', {})
        project_root = paths.get('project_root')
        
        if not project_root:
            return {"success": False, "error": "کلید 'paths.project_root' در تنظیمات یافت نشد"}
        
        # 2. مسیر دیتابیس (database)
        database = config_data.get('database', {})
        database_path = database.get('path')
        
        if not database_path:
            # اگر path نبود، از name بسازیم
            database_name = database.get('name', 'crypto_master.db')
            data_dir = paths.get('data_dir', os.path.join(project_root, 'data'))
            database_path = os.path.join(data_dir, database_name)
        
        # 3. تنظیمات جمع‌آوری (collection)
        collection = config_data.get('collection', {})
        
        # زمان‌فریم‌ها
        timeframe = collection.get('timeframe', '5m')
        timeframes = [timeframe]
        
        candles_per_request = collection.get('candles_per_request', 200)
        api_retry_attempts = collection.get('api_retry_attempts', 3)
        api_retry_delay = collection.get('api_retry_delay', 1)
        
        # 4. تنظیمات API
        api = config_data.get('api', {})
        binance_api = api.get('binance', {})
        
        binance_base_url = binance_api.get('base_url', 'https://api.binance.com/api/v3')
        api_timeout = binance_api.get('request_timeout', 10)
        rate_limit_per_minute = binance_api.get('rate_limit_per_minute', 1200)
        
        # اگر api_retry_attempts در collection نبود، از binance بگیر
        if api_retry_attempts == 3:
            api_retry_attempts = binance_api.get('retry_attempts', 3)
        
        if api_retry_delay == 1:
            api_retry_delay = binance_api.get('retry_delay', 1)
        
        config = {
            # مسیرها
            "project_root": project_root,
            "database_path": database_path,
            "data_dir": paths.get('data_dir'),
            "logs_dir": paths.get('logs_dir'),
            "config_dir": paths.get('config_dir'),
            
            # تنظیمات جمع‌آوری
            "timeframes": timeframes,
            "candles_per_request": candles_per_request,
            "api_retry_attempts": api_retry_attempts,
            "api_retry_delay": api_retry_delay,
            
            # تنظیمات API
            "binance_base_url": binance_base_url,
            "api_timeout": api_timeout,
            "rate_limit_per_minute": rate_limit_per_minute,
            
            # سایر تنظیمات
            "top_coins_limit": collection.get('top_coins_limit', 50),
            "update_interval_seconds": collection.get('update_interval_seconds', 300),
            "max_coins_per_cycle": collection.get('max_coins_per_cycle', 20),
            
            # فایل کانفیگ
            "config_file": config_file,
        }
        
        # تعیین مسیر state_file
        state_dir = os.path.join(project_root, "state")
        config["state_file"] = os.path.join(state_dir, "cycle_state.json")
        
        print(f"✅ تنظیمات از فایل کانفیگ بارگذاری شد")
        print(f"📁 project_root: {project_root}")
        print(f"📁 دیتابیس: {database_path}")
        print(f"📊 تایم‌فریم: {timeframe}")
        print(f"📈 کندل در هر درخواست: {candles_per_request}")
        
        return {"success": True, "config": config}
        
    except json.JSONDecodeError as e:
        return {"success": False, "error": f"خطا در خواندن فایل JSON کانفیگ: {str(e)}"}
    except Exception as e:
        return {"success": False, "error": f"خطا در بارگذاری تنظیمات: {str(e)}"}

# ==================== STATE MANAGEMENT ====================
def load_cycle_state(state_file, target_block=None):
    """بارگذاری وضعیت چرخه - با امکان هدف‌گیری بلوک خاص"""
    try:
        print(f"📁 جستجوی فایل state در: {state_file}")
        
        if not os.path.exists(state_file):
            return {"success": False, "error": f"فایل وضعیت یافت نشد: {state_file}"}
        
        with open(state_file, 'r', encoding='utf-8') as f:
            state_data = json.load(f)
        
        print(f"✅ وضعیت چرخه بارگذاری شد: {state_data.get('cycle_id')}")
        
        # اگر شماره بلوک مشخص شده، آن را تنظیم کن
        if target_block is not None:
            total_blocks = len(state_data.get('blocks', []))
            if 1 <= target_block <= total_blocks:
                state_data['current_block'] = target_block
                print(f"🎯 بلوک هدف: {target_block} تنظیم شد")
            else:
                return {"success": False, "error": f"بلوک {target_block} معتبر نیست (1-{total_blocks})"}
        
        print(f"📊 بلوک فعلی: {state_data.get('current_block')}/{len(state_data.get('blocks', []))}")
        
        return {"success": True, "state_data": state_data, "state_file": state_file}
        
    except json.JSONDecodeError as e:
        return {"success": False, "error": f"خطا در خواندن فایل JSON: {str(e)}"}
    except Exception as e:
        return {"success": False, "error": f"خطا در بارگذاری وضعیت: {str(e)}"}

def save_cycle_state(state_file, state_data):
    """ذخیره وضعیت چرخه"""
    try:
        # اطمینان از وجود پوشه parent
        state_dir = os.path.dirname(state_file)
        if state_dir and not os.path.exists(state_dir):
            os.makedirs(state_dir, exist_ok=True)
            
        with open(state_file, 'w', encoding='utf-8') as f:
            json.dump(state_data, f, indent=2, ensure_ascii=False)
        
        return True
    except Exception as e:
        print(f"❌ خطا در ذخیره وضعیت: {e}")
        return False

# ==================== DATABASE FUNCTIONS ====================
def check_database_connection(db_path):
    """بررسی اتصال و ساختار دیتابیس موجود"""
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # بررسی وجود جدول crypto_coins
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='crypto_coins'")
        if not cursor.fetchone():
            conn.close()
            return {"success": False, "error": "جدول crypto_coins در دیتابیس وجود ندارد"}
        
        # بررسی وجود جدول crypto_klines
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='crypto_klines'")
        if not cursor.fetchone():
            conn.close()
            return {"success": False, "error": "جدول crypto_klines در دیتابیس وجود ندارد"}
        
        # بررسی ساختار جدول crypto_klines
        cursor.execute("PRAGMA table_info(crypto_klines)")
        columns = [col[1] for col in cursor.fetchall()]
        
        # بررسی ستون‌های ضروری
        required_columns = ['coin_id', 'timeframe', 'open_time', 'close_time', 'open_price', 
                           'high_price', 'low_price', 'close_price', 'volume', 'quote_volume']
        
        missing_columns = []
        for col in required_columns:
            if col not in columns:
                missing_columns.append(col)
        
        if missing_columns:
            conn.close()
            return {"success": False, "error": f"ستون‌های ضروری در جدول crypto_klines وجود ندارد: {missing_columns}"}
        
        # دریافت تعداد رکوردهای موجود
        cursor.execute("SELECT COUNT(*) FROM crypto_klines")
        total_candles = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM crypto_coins")
        total_coins = cursor.fetchone()[0]
        
        conn.close()
        
        print(f"   ✅ دیتابیس سالم است")
        print(f"   📊 {total_coins} ارز و {total_candles} کندل موجود")
        
        return {"success": True, "total_coins": total_coins, "total_candles": total_candles}
        
    except sqlite3.Error as e:
        return {"success": False, "error": f"خطای دیتابیس: {str(e)}"}
    except Exception as e:
        return {"success": False, "error": f"خطای ناشناخته در بررسی دیتابیس: {str(e)}"}

def get_coin_id_from_symbol(db_path, symbol):
    """دریافت coin_id از symbol"""
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # تبدیل symbol به فرمت استاندارد
        clean_symbol = symbol.upper()
        if not clean_symbol.endswith('USDT'):
            clean_symbol = f"{clean_symbol}USDT"
        
        cursor.execute("SELECT id FROM crypto_coins WHERE symbol = ?", (clean_symbol,))
        result = cursor.fetchone()
        
        conn.close()
        
        if result:
            return {"success": True, "coin_id": result[0], "symbol": clean_symbol}
        else:
            return {"success": False, "error": f"ارز {clean_symbol} در جدول crypto_coins یافت نشد"}
                
    except Exception as e:
        return {"success": False, "error": f"خطا در دریافت coin_id: {str(e)}"}

def increment_is_active(db_path, symbol, increment_by=1):
    """افزایش مقدار is_active برای یک ارز در صورت خطا"""
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # تبدیل symbol به فرمت استاندارد
        clean_symbol = symbol.upper()
        if not clean_symbol.endswith('USDT'):
            clean_symbol = f"{clean_symbol}USDT"
        
        # ابتدا مقدار فعلی را بگیر
        cursor.execute("SELECT is_active FROM crypto_coins WHERE symbol = ?", (clean_symbol,))
        result = cursor.fetchone()
        
        if not result:
            print(f"   ⚠️ ارز {clean_symbol} در دیتابیس یافت نشد")
            conn.close()
            return False
        
        current_value = result[0] or 0
        new_value = current_value + increment_by
        
        # محدودیت حداکثر مقدار (اختیاری)
        if new_value > 10:
            new_value = 10
            print(f"   ⚠️ is_active {clean_symbol} به حداکثر مقدار (10) رسید")
        
        # بروزرسانی
        cursor.execute(
            "UPDATE crypto_coins SET is_active = ?, last_updated = datetime('now') WHERE symbol = ?",
            (new_value, clean_symbol)
        )
        
        conn.commit()
        conn.close()
        
        print(f"   📈 is_active {clean_symbol}: {current_value} → {new_value}")
        return True
        
    except Exception as e:
        print(f"   ⚠️ خطا در افزایش is_active برای {symbol}: {e}")
        return False

def save_candle_data(db_path, symbol, timeframe, candles):
    """
    ذخیره داده‌های کندل در دیتابیس - با مدیریت دقت برای ارزهای کم‌قیمت
    کاملاً سازگار با ساختار فعلی دیتابیس
    """
    try:
        # ابتدا coin_id را دریافت کن
        coin_result = get_coin_id_from_symbol(db_path, symbol)
        if not coin_result["success"]:
            return {"success": False, "error": coin_result["error"]}
        
        coin_id = coin_result["coin_id"]
        actual_symbol = coin_result["symbol"]
        
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        inserted_count = 0
        duplicate_count = 0
        error_count = 0
        low_price_adjustments = 0
        
        for candle in candles:
            try:
                # دریافت داده‌های خام از API (رشته‌ها)
                open_raw = str(candle[1])
                close_raw = str(candle[4])
                high_raw = str(candle[2])
                low_raw = str(candle[3])
                
                # اعمال تنظیمات دقت برای ارزهای کم‌قیمت
                open_final, close_final, high_final, low_final, was_adjusted = adjust_price_precision(
                    open_raw, close_raw, high_raw, low_raw
                )
                
                if was_adjusted:
                    low_price_adjustments += 1
                    print(f"      🔄 اصلاح دقت: Open={open_raw} → Close={close_final}")
                
                # تبدیل timestamp به فرمت صحیح
                open_timestamp = candle[0]
                close_timestamp = candle[6]
                
                # تبدیل میلی‌ثانیه به ثانیه
                open_time = datetime.fromtimestamp(open_timestamp / 1000).strftime('%Y-%m-%d %H:%M:%S')
                close_time = datetime.fromtimestamp(close_timestamp / 1000).strftime('%Y-%m-%d %H:%M:%S.999000')
                candle_date = datetime.fromtimestamp(open_timestamp / 1000).strftime('%Y-%m-%d')
                
                # داده‌های کندل - ذخیره به صورت REAL (سازگار با دیتابیس موجود)
                open_price = float(open_final)
                close_price = float(close_final)
                high_price = float(high_final)
                low_price = float(low_final)
                volume = float(candle[5])
                quote_volume = float(candle[7])
                number_of_trades = candle[8]
                taker_buy_volume = float(candle[9])
                taker_buy_quote_volume = float(candle[10])
                
                # taker_sell_volume محاسبه شود
                taker_sell_volume = volume - taker_buy_volume if volume > taker_buy_volume else 0.0
                
                # درج داده با ساختار فعلی دیتابیس
                # هیچ فیلد جدیدی اضافه نمی‌کنیم
                cursor.execute('''
                INSERT OR IGNORE INTO crypto_klines 
                (coin_id, timeframe, open_time, close_time, candle_date,
                 open_price, high_price, low_price, close_price, 
                 volume, quote_volume, number_of_trades,
                 taker_buy_volume, taker_sell_volume, taker_buy_quote_volume,
                 created_at, updated_at, source_exchange, is_verified)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 
                        datetime('now'), datetime('now'), 'binance', 1)
                ''', (
                    coin_id, timeframe, open_time, close_time, candle_date,
                    open_price, high_price, low_price, close_price,
                    volume, quote_volume, number_of_trades,
                    taker_buy_volume, taker_sell_volume, taker_buy_quote_volume
                ))
                
                if cursor.rowcount > 0:
                    inserted_count += 1
                else:
                    duplicate_count += 1
                    
            except sqlite3.IntegrityError:
                duplicate_count += 1
            except Exception as e:
                error_count += 1
                print(f"⚠️ خطا در ذخیره کندل برای {actual_symbol}: {e}")
                continue
        
        conn.commit()
        conn.close()
        
        # گزارش اگر تنظیماتی انجام شده
        if low_price_adjustments > 0:
            print(f"   🔄 {low_price_adjustments} کندل اصلاح دقت شدند")
        
        return {
            "success": True, 
            "inserted_count": inserted_count, 
            "duplicate_count": duplicate_count,
            "error_count": error_count,
            "low_price_adjustments": low_price_adjustments,
            "total_candles": len(candles),
            "coin_id": coin_id,
            "symbol": actual_symbol
        }
        
    except sqlite3.Error as e:
        return {"success": False, "error": f"خطای دیتابیس: {str(e)}"}
    except Exception as e:
        return {"success": False, "error": f"خطای ناشناخته: {str(e)}"}

def log_collection(db_path, cycle_id, block_id, symbol, timeframe, candles_count, status, error_message=None):
    """ثبت لاگ جمع‌آوری داده‌ها در جدول collection_logs موجود"""
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # بررسی وجود جدول collection_logs
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='collection_logs'")
        if not cursor.fetchone():
            # اگر جدول وجود ندارد، ایجاد نکن - فقط گزارش بده
            conn.close()
            print(f"⚠️ جدول collection_logs وجود ندارد - لاگ ثبت نمی‌شود")
            return False
        
        cursor.execute('''
        INSERT INTO collection_logs 
        (timestamp, symbol, timeframe, candles_received, candles_saved, candles_duplicate, status, error_msg)
        VALUES (datetime('now'), ?, ?, ?, ?, ?, ?, ?)
        ''', (symbol, timeframe, candles_count.get('total_candles', 0), 
              candles_count.get('inserted_count', 0), candles_count.get('duplicate_count', 0), 
              status, error_message))
        
        conn.commit()
        conn.close()
        
        return True
    except Exception as e:
        print(f"⚠️ خطا در ثبت لاگ: {e}")
        return False

# ==================== BINANCE API FUNCTIONS ====================
def get_binance_klines(base_url, symbol, interval, limit=200, retry_attempts=3, retry_delay=1):
    """دریافت داده‌های کندل از Binance API"""
    for attempt in range(retry_attempts):
        try:
            url = f"{base_url}/klines"
            params = {
                'symbol': symbol.upper().replace('USDT', 'USDT'),
                'interval': interval,
                'limit': limit
            }
            
            response = requests.get(url, params=params, timeout=30)
            
            if response.status_code == 200:
                return {"success": True, "data": response.json()}
            elif response.status_code == 429:  # Rate limit
                wait_time = retry_delay * (attempt + 1)
                print(f"⚠️ Rate limit برای {symbol}. انتظار {wait_time} ثانیه...")
                time.sleep(wait_time)
                continue
            else:
                return {"success": False, "error": f"خطای API: {response.status_code} - {response.text}"}
                
        except requests.exceptions.Timeout:
            print(f"⚠️ Timeout برای {symbol}. تلاش مجدد {attempt + 1}/{retry_attempts}")
            time.sleep(retry_delay)
        except requests.exceptions.ConnectionError:
            print(f"⚠️ خطای اتصال برای {symbol}. تلاش مجدد {attempt + 1}/{retry_attempts}")
            time.sleep(retry_delay)
        except Exception as e:
            return {"success": False, "error": f"خطای ناشناخته: {str(e)}"}
    
    return {"success": False, "error": f"تلاش‌های ناموفق برای {symbol}"}

# ==================== MAIN PROCESSING ====================
def process_current_block(config, state_data, state_file):
    """پردازش بلوک فعلی"""
    try:
        cycle_id = state_data['cycle_id']
        current_block = state_data['current_block']
        
        # پیدا کردن بلوک فعلی
        current_block_data = None
        for block in state_data['blocks']:
            if block['block_id'] == current_block:
                current_block_data = block
                break
        
        if not current_block_data:
            return {"success": False, "error": f"بلوک {current_block} یافت نشد"}
        
        symbols = current_block_data['symbols']
        block_size = len(symbols)
        
        print(f"\n📦 پردازش بلوک {current_block} از {len(state_data['blocks'])}")
        print(f"💰 تعداد ارزها: {block_size}")
        print(f"📊 ارزهای این بلوک: {', '.join(symbols[:5])}{'...' if block_size > 5 else ''}")
        
        total_candles_collected = 0
        total_inserted = 0
        total_duplicates = 0
        total_low_price_adjustments = 0
        successful_symbols = 0
        failed_symbols = 0
        
        start_block_time = time.time()
        
        # پردازش هر ارز در بلوک
        for i, symbol in enumerate(symbols, 1):
            symbol_start_time = time.time()
            print(f"\n[{i}/{block_size}] 📡 دریافت داده‌های {symbol}...")
            
            for timeframe in config['timeframes']:
                print(f"   ⏰ تایم‌فریم: {timeframe}")
                
                # دریافت داده از Binance
                klines_result = get_binance_klines(
                    config['binance_base_url'],
                    symbol,
                    timeframe,
                    limit=config['candles_per_request'],
                    retry_attempts=config['api_retry_attempts'],
                    retry_delay=config['api_retry_delay']
                )
                
                if klines_result['success']:
                    candles = klines_result['data']
                    
                    # ذخیره در دیتابیس با مدیریت دقت
                    save_result = save_candle_data(config['database_path'], symbol, timeframe, candles)
                    
                    if save_result['success']:
                        inserted = save_result['inserted_count']
                        duplicates = save_result['duplicate_count']
                        errors = save_result['error_count']
                        adjustments = save_result['low_price_adjustments']
                        total = save_result['total_candles']
                        
                        total_candles_collected += total
                        total_inserted += inserted
                        total_duplicates += duplicates
                        total_low_price_adjustments += adjustments
                        
                        # ثبت لاگ
                        log_collection(
                            config['database_path'],
                            cycle_id,
                            current_block,
                            save_result['symbol'],
                            timeframe,
                            save_result,
                            'success'
                        )
                        
                        print(f"   ✅ {inserted} جدید, {duplicates} تکراری از {total} کندل")
                        if adjustments > 0:
                            print(f"   🔄 {adjustments} کندل اصلاح دقت شدند")
                        successful_symbols += 1
                    else:
                        print(f"   ❌ خطا در ذخیره داده‌های {symbol}: {save_result['error']}")
                        
                        # افزایش is_active به دلیل خطای ذخیره‌سازی
                        increment_is_active(config['database_path'], symbol)
                        
                        log_collection(
                            config['database_path'],
                            cycle_id,
                            current_block,
                            symbol,
                            timeframe,
                            {"total_candles": 0, "inserted_count": 0, "duplicate_count": 0},
                            'error',
                            save_result['error']
                        )
                        failed_symbols += 1
                else:
                    print(f"   ❌ خطا در دریافت داده‌های {symbol}: {klines_result['error']}")
                    
                    # افزایش is_active به دلیل خطای API
                    increment_is_active(config['database_path'], symbol)
                    
                    log_collection(
                        config['database_path'],
                        cycle_id,
                        current_block,
                        symbol,
                        timeframe,
                        {"total_candles": 0, "inserted_count": 0, "duplicate_count": 0},
                        'error',
                        klines_result['error']
                    )
                    failed_symbols += 1
                
                # رعایت rate limit
                time.sleep(60 / config['rate_limit_per_minute'])
            
            symbol_time = time.time() - symbol_start_time
            print(f"   ⏱️ زمان پردازش {symbol}: {symbol_time:.2f} ثانیه")
        
        # محاسبه زمان کل بلوک
        block_time = time.time() - start_block_time
        
        # به‌روزرسانی وضعیت
        block_index = current_block - 1
        state_data['blocks'][block_index]['processed'] = True
        state_data['blocks'][block_index]['processed_at'] = datetime.now().isoformat()
        state_data['blocks'][block_index]['successful_symbols'] = successful_symbols
        state_data['blocks'][block_index]['failed_symbols'] = failed_symbols
        state_data['blocks'][block_index]['total_candles_collected'] = total_candles_collected
        state_data['blocks'][block_index]['total_inserted'] = total_inserted
        state_data['blocks'][block_index]['total_duplicates'] = total_duplicates
        state_data['blocks'][block_index]['low_price_adjustments'] = total_low_price_adjustments
        
        # اگر همه ارزها پردازش شدند، به بلوک بعدی برو (فقط اگر بلوک هدف مشخص نشده باشد)
        if successful_symbols + failed_symbols == block_size:
            # فقط اگر بلوک هدف مشخص نشده، به بلوک بعدی برو
            if current_block < len(state_data['blocks']) and state_data.get('auto_progress', True):
                state_data['current_block'] = current_block + 1
                state_data['completed_blocks'].append(current_block)
                if current_block in state_data.get('pending_blocks', []):
                    state_data['pending_blocks'].remove(current_block)
            else:
                state_data['status'] = 'completed'
        
        # ذخیره وضعیت به‌روز شده
        if save_cycle_state(state_file, state_data):
            print(f"✅ وضعیت به‌روزرسانی شد")
        else:
            print(f"⚠️ خطا در ذخیره وضعیت به‌روزرسانی شده")
        
        return {
            "success": True,
            "block_id": current_block,
            "total_symbols": block_size,
            "successful_symbols": successful_symbols,
            "failed_symbols": failed_symbols,
            "total_candles_collected": total_candles_collected,
            "total_inserted": total_inserted,
            "total_duplicates": total_duplicates,
            "low_price_adjustments": total_low_price_adjustments,
            "block_time": block_time
        }
        
    except Exception as e:
        return {"success": False, "error": f"خطا در پردازش بلوک: {str(e)}"}

# ==================== MAIN FUNCTION ====================
def run_block_processing(target_block=None):
    """
    تابع اصلی: پردازش بلوک فعلی یا بلوک مشخص شده
    """
    print("=" * 70)
    print("🔄 تکه 02: پردازش بلوک و جمع‌آوری داده‌های کندل")
    print("✨ ورژن 2.1 - حل مشکل Open=Close در ارزهای کم‌قیمت")
    if target_block:
        print(f"🎯 هدف: بلوک {target_block}")
    print("=" * 70)
    
    start_time = time.time()
    
    # 1. بارگذاری تنظیمات از فایل کانفیگ
    print("\n1️⃣ بارگذاری تنظیمات از فایل کانفیگ...")
    config_result = load_config()
    if not config_result["success"]:
        print(f"❌ {config_result['error']}")
        return config_result
    
    config = config_result["config"]
    print(f"   ✅ تنظیمات بارگذاری شد")
    print(f"   📁 دیتابیس: {Path(config['database_path']).name}")
    print(f"   📊 تایم‌فریم: {config['timeframes'][0]}")
    print(f"   📈 کندل در هر درخواست: {config['candles_per_request']}")
    
    # 2. بارگذاری وضعیت چرخه
    print("\n2️⃣ بارگذاری وضعیت چرخه...")
    state_result = load_cycle_state(config["state_file"], target_block)
    if not state_result["success"]:
        print(f"❌ {state_result['error']}")
        return state_result
    
    state_data = state_result["state_data"]
    state_file = state_result["state_file"]
    
    print(f"   ✅ چرخه: {state_data.get('cycle_id')}")
    print(f"   📊 بلوک فعلی: {state_data.get('current_block')}/{state_data['stats']['total_blocks']}")
    
    # 3. بررسی اتصال دیتابیس موجود
    print("\n3️⃣ بررسی اتصال به دیتابیس موجود...")
    db_result = check_database_connection(config["database_path"])
    if not db_result["success"]:
        print(f"❌ {db_result['error']}")
        return db_result
    
    # 4. پردازش بلوک فعلی
    print("\n4️⃣ پردازش بلوک...")
    process_result = process_current_block(config, state_data, state_file)
    
    if not process_result["success"]:
        print(f"❌ {process_result['error']}")
        return process_result
    
    # 5. نتیجه نهایی
    execution_time = time.time() - start_time
    print("\n" + "=" * 70)
    print("📋 نتیجه تکه 02:")
    print("-" * 70)
    print(f"   🆔 چرخه: {state_data['cycle_id']}")
    print(f"   📦 بلوک پردازش شده: {process_result['block_id']}")
    print(f"   ⏱️ زمان کل اجرا: {execution_time:.2f} ثانیه")
    print(f"   ⏱️ زمان پردازش بلوک: {process_result.get('block_time', 0):.2f} ثانیه")
    print(f"\n   📊 آمار پردازش:")
    print(f"      - کل ارزهای بلوک: {process_result['total_symbols']}")
    print(f"      - ارزهای موفق: {process_result['successful_symbols']}")
    print(f"      - ارزهای ناموفق: {process_result['failed_symbols']}")
    print(f"      - کندل‌های دریافت شده: {process_result['total_candles_collected']}")
    print(f"      - کندل‌های جدید ذخیره شده: {process_result['total_inserted']}")
    print(f"      - کندل‌های تکراری: {process_result['total_duplicates']}")
    print(f"      - اصلاحات دقت (Open=Close): {process_result['low_price_adjustments']}")
    
    # نمایش وضعیت بعدی
    next_block = state_data['current_block']
    total_blocks = state_data['stats']['total_blocks']
    
    if next_block <= total_blocks and not target_block:
        print(f"\n🔗 اطلاعات برای تکه بعدی:")
        print(f"   - بلوک بعدی: {next_block}")
        print(f"   - وضعیت: پردازش ادامه دارد")
        print(f"\n💡 دستور بعدی:")
        print(f"   'اجرای مجدد برای پردازش بلوک {next_block}'")
    else:
        print(f"\n🎉 پردازش کامل شد!")
        if target_block:
            print(f"   - بلوک هدف {target_block} پردازش شد")
        else:
            print(f"   - وضعیت: چرخه کامل شد")
        print(f"\n💡 دستور بعدی:")
        print(f"   'برو به تکه 03: تحلیل داده‌ها'")
    
    print("=" * 70)
    
    return {
        "success": True,
        "process_result": process_result,
        "next_block": next_block,
        "total_blocks": total_blocks,
        "message": f"بلوک {process_result['block_id']} پردازش شد. {process_result['successful_symbols']}/{process_result['total_symbols']} ارز موفق."
    }

# ==================== EXECUTION ====================
if __name__ == "__main__":
    # ایجاد پارسر آرگومان
    parser = argparse.ArgumentParser(
        description='پردازش بلوک‌های داده از بایننس',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog='''
مثال‌ها:
  %(prog)s                    # پردازش بلوک فعلی
  %(prog)s --block 5          # پردازش بلوک 5
  %(prog)s -b 3               # پردازش بلوک 3
        '''
    )
    
    parser.add_argument(
        '--block', '-b', 
        type=int, 
        help='شماره بلوک مورد نظر (اختیاری)'
    )
    
    args = parser.parse_args()
    
    result = run_block_processing(args.block)
    
    # خروجی مناسب برای خط فرمان
    if result["success"]:
        print(f"\n✅ {result['message']}")
        next_block = result['next_block']
        total_blocks = result['total_blocks']
        
        if next_block <= total_blocks and not args.block:
            print(f"📌 بلوک بعدی: {next_block} از {total_blocks}")
            print(f"🚀 برای ادامه اجرا کنید: python scripts/cycle/cycle_02_process_block.py")
        elif args.block:
            print(f"🎯 بلوک هدف {args.block} پردازش شد")
        else:
            print(f"🎉 چرخه کامل شد! همه {total_blocks} بلوک پردازش شدند.")
    else:
        print(f"\n❌ خطا: {result.get('error', 'خطای ناشناخته')}")
        sys.exit(1)