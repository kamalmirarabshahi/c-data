#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
trade_executor.py - اجراکننده معاملات و ذخیره‌سازی در دیتابیس
تکه ۵ - فایل ۵ از ۸

ورودی: تصمیم‌های نهایی TradingDecision
خروجی: ذخیره در جدول final_trading_decisions + تأیید
وابستگی: sqlite3, decision_maker, config_manager
"""

import os
import sys
import sqlite3
import logging
import json
from typing import Dict, List, Any, Optional, Tuple
from datetime import datetime

# اضافه کردن مسیر برای import کردن config_manager
current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = os.path.dirname(os.path.dirname(os.path.dirname(current_dir)))
sys.path.insert(0, project_root)

try:
    from config_manager import get_database_path
    DB_PATH = get_database_path()
except ImportError:
    # Fallback path
    DB_PATH = os.path.join(project_root, "data", "crypto_master.db")

class TradeExecutor:
    """
    💾 اجراکننده معاملات و ذخیره‌سازی در دیتابیس
    ذخیره تصمیم‌های نهایی و مدیریت وضعیت معاملات
    """
    
    def __init__(self, db_path: Optional[str] = None):
        """
        مقداردهی اولیه اجراکننده
        
        Args:
            db_path: مسیر دیتابیس (اختیاری)
        """
        self.db_path = db_path or DB_PATH
        self.logger = self._setup_logger()
        
        # اطمینان از وجود جدول
        self._ensure_tables_exist()
        
        self.logger.info(f"✅ TradeExecutor راه‌اندازی شد (DB: {self.db_path})")
    
    def _setup_logger(self) -> logging.Logger:
        """تنظیم لاگر"""
        logger = logging.getLogger("TradeExecutor")
        if not logger.handlers:
            handler = logging.StreamHandler()
            formatter = logging.Formatter(
                '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
                datefmt='%H:%M:%S'
            )
            handler.setFormatter(formatter)
            logger.addHandler(handler)
            logger.setLevel(logging.INFO)
        return logger
    
    def _ensure_tables_exist(self):
        """اطمینان از وجود جداول لازم"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # جدول تصمیم‌های نهایی معاملاتی
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS final_trading_decisions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    decision_id TEXT UNIQUE,
                    timestamp TEXT,
                    
                    -- اطلاعات ارز
                    coin_id INTEGER,
                    symbol TEXT,
                    
                    -- تصمیم
                    decision_type TEXT,  -- EXECUTE_BUY, EXECUTE_SELL, HOLD, REJECT
                    signal_id INTEGER,
                    original_signal_type TEXT,
                    
                    -- پارامترهای اجرا
                    entry_price REAL,
                    stop_loss REAL,
                    take_profit REAL,
                    position_size REAL,
                    leverage INTEGER,
                    
                    -- سرمایه
                    allocated_capital_usd REAL,
                    position_value_usd REAL,
                    margin_required_usd REAL,
                    
                    -- ریسک/بازده
                    risk_amount_usd REAL,
                    expected_profit_usd REAL,
                    expected_loss_usd REAL,
                    risk_reward_ratio REAL,
                    net_risk_reward REAL,
                    
                    -- کارمزدها
                    entry_fee_usd REAL,
                    exit_fee_usd REAL,
                    total_fee_usd REAL,
                    
                    -- امتیازها
                    confidence_score REAL,
                    priority_score REAL,
                    final_score REAL,
                    
                    -- وضعیت
                    status TEXT,  -- PENDING, APPROVED, REJECTED, EXECUTED
                    rejection_reason TEXT,
                    approval_criteria TEXT,  -- JSON array
                    
                    -- متادیتا
                    analysis_summary TEXT,  -- JSON
                    execution_time TEXT,
                    
                    -- زمان‌ها
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    
                    -- کلید خارجی
                    FOREIGN KEY (coin_id) REFERENCES crypto_coins(id),
                    FOREIGN KEY (signal_id) REFERENCES trading_signals(id)
                )
            """)
            
            # ایجاد ایندکس‌ها برای جستجوی سریع
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_decisions_coin ON final_trading_decisions(coin_id)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_decisions_status ON final_trading_decisions(status)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_decisions_time ON final_trading_decisions(timestamp)")
            
            conn.commit()
            conn.close()
            
            self.logger.info("✅ جداول دیتابیس بررسی/ایجاد شدند")
            
        except sqlite3.Error as e:
            self.logger.error(f"❌ خطا در ایجاد جداول دیتابیس: {e}")
    
    def save_decision(self, decision) -> Tuple[bool, int]:
        """
        ذخیره یک تصمیم در دیتابیس
        
        Args:
            decision: شیء TradingDecision
            
        Returns:
            (موفقیت, ID ثبت شده)
        """
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # تبدیل لیست‌ها به JSON
            approval_criteria_json = json.dumps(decision.approval_criteria or [], ensure_ascii=False)
            analysis_summary_json = json.dumps(decision.analysis_summary or {}, ensure_ascii=False)
            
            # درج رکورد
            cursor.execute("""
                INSERT OR REPLACE INTO final_trading_decisions (
                    decision_id, timestamp,
                    coin_id, symbol,
                    decision_type, signal_id, original_signal_type,
                    entry_price, stop_loss, take_profit, position_size, leverage,
                    allocated_capital_usd, position_value_usd, margin_required_usd,
                    risk_amount_usd, expected_profit_usd, expected_loss_usd,
                    risk_reward_ratio, net_risk_reward,
                    entry_fee_usd, exit_fee_usd, total_fee_usd,
                    confidence_score, priority_score, final_score,
                    status, rejection_reason, approval_criteria,
                    analysis_summary, execution_time
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                decision.decision_id,
                decision.timestamp,
                decision.coin_id,
                decision.symbol,
                decision.decision_type,
                decision.signal_id,
                decision.original_signal_type,
                decision.entry_price,
                decision.stop_loss,
                decision.take_profit,
                decision.position_size,
                decision.leverage,
                decision.allocated_capital_usd,
                decision.position_value_usd,
                decision.margin_required_usd,
                decision.risk_amount_usd,
                decision.expected_profit_usd,
                decision.expected_loss_usd,
                decision.risk_reward_ratio,
                decision.net_risk_reward,
                decision.entry_fee_usd,
                decision.exit_fee_usd,
                decision.total_fee_usd,
                decision.confidence_score,
                decision.priority_score,
                decision.final_score,
                decision.status,
                decision.rejection_reason,
                approval_criteria_json,
                analysis_summary_json,
                decision.execution_time
            ))
            
            decision_id = cursor.lastrowid
            conn.commit()
            conn.close()
            
            self.logger.info(f"💾 تصمیم ذخیره شد: {decision.symbol} (ID: {decision_id})")
            self.logger.debug(f"   Decision ID: {decision.decision_id}")
            self.logger.debug(f"   Type: {decision.decision_type}, Status: {decision.status}")
            
            return True, decision_id
            
        except sqlite3.Error as e:
            self.logger.error(f"❌ خطا در ذخیره تصمیم {decision.decision_id}: {e}")
            return False, 0
    
    def save_decisions_batch(self, decisions: List) -> Dict[str, Any]:
        """
        ذخیره دسته‌ای تصمیم‌ها
        
        Args:
            decisions: لیست تصمیم‌ها
            
        Returns:
            آمار ذخیره‌سازی
        """
        if not decisions:
            return {"total": 0, "saved": 0, "failed": 0, "ids": []}
        
        self.logger.info(f"💾 شروع ذخیره دسته‌ای {len(decisions)} تصمیم")
        
        stats = {
            "total": len(decisions),
            "saved": 0,
            "failed": 0,
            "ids": []
        }
        
        for i, decision in enumerate(decisions, 1):
            self.logger.debug(f"   ذخیره تصمیم {i}/{len(decisions)}: {decision.symbol}")
            
            success, decision_id = self.save_decision(decision)
            
            if success:
                stats["saved"] += 1
                stats["ids"].append(decision_id)
            else:
                stats["failed"] += 1
        
        self.logger.info(f"📊 آمار ذخیره‌سازی: {stats['saved']}/{stats['total']} موفق")
        
        if stats["failed"] > 0:
            self.logger.warning(f"⚠️ {stats['failed']} تصمیم ذخیره نشد")
        
        return stats
    
    def update_decision_status(self, decision_id: str, new_status: str, 
                              execution_time: Optional[str] = None) -> bool:
        """
        به‌روزرسانی وضعیت یک تصمیم
        
        Args:
            decision_id: شناسه تصمیم
            new_status: وضعیت جدید
            execution_time: زمان اجرا (اختیاری)
            
        Returns:
            موفقیت عملیات
        """
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            query = """
                UPDATE final_trading_decisions 
                SET status = ?, updated_at = CURRENT_TIMESTAMP
            """
            params = [new_status]
            
            if execution_time:
                query += ", execution_time = ?"
                params.append(execution_time)
            
            query += " WHERE decision_id = ?"
            params.append(decision_id)
            
            cursor.execute(query, params)
            rows_affected = cursor.rowcount
            
            conn.commit()
            conn.close()
            
            if rows_affected > 0:
                self.logger.info(f"🔄 وضعیت تصمیم به‌روزرسانی شد: {decision_id} → {new_status}")
                return True
            else:
                self.logger.warning(f"⚠️ تصمیم یافت نشد: {decision_id}")
                return False
                
        except sqlite3.Error as e:
            self.logger.error(f"❌ خطا در به‌روزرسانی وضعیت: {e}")
            return False
    
    def get_decision_by_id(self, decision_id: str) -> Optional[Dict[str, Any]]:
        """
        دریافت یک تصمیم بر اساس شناسه
        
        Args:
            decision_id: شناسه تصمیم
            
        Returns:
            اطلاعات تصمیم یا None
        """
        try:
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            cursor.execute("""
                SELECT * FROM final_trading_decisions 
                WHERE decision_id = ? 
                ORDER BY id DESC LIMIT 1
            """, (decision_id,))
            
            row = cursor.fetchone()
            conn.close()
            
            if row:
                decision = dict(row)
                
                # تبدیل JSON‌ها به دیکشنری
                if decision.get("approval_criteria"):
                    try:
                        decision["approval_criteria"] = json.loads(decision["approval_criteria"])
                    except:
                        decision["approval_criteria"] = []
                
                if decision.get("analysis_summary"):
                    try:
                        decision["analysis_summary"] = json.loads(decision["analysis_summary"])
                    except:
                        decision["analysis_summary"] = {}
                
                self.logger.debug(f"📖 تصمیم خوانده شد: {decision_id}")
                return decision
            
            return None
            
        except sqlite3.Error as e:
            self.logger.error(f"❌ خطا در خواندن تصمیم: {e}")
            return None
    
    def get_decisions_by_status(self, status: str, limit: int = 100) -> List[Dict[str, Any]]:
        """
        دریافت تصمیم‌ها بر اساس وضعیت
        
        Args:
            status: وضعیت تصمیم
            limit: محدودیت تعداد
            
        Returns:
            لیست تصمیم‌ها
        """
        try:
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            cursor.execute("""
                SELECT * FROM final_trading_decisions 
                WHERE status = ? 
                ORDER BY timestamp DESC 
                LIMIT ?
            """, (status, limit))
            
            rows = cursor.fetchall()
            conn.close()
            
            decisions = []
            for row in rows:
                decision = dict(row)
                
                # تبدیل JSON‌ها
                if decision.get("approval_criteria"):
                    try:
                        decision["approval_criteria"] = json.loads(decision["approval_criteria"])
                    except:
                        decision["approval_criteria"] = []
                
                if decision.get("analysis_summary"):
                    try:
                        decision["analysis_summary"] = json.loads(decision["analysis_summary"])
                    except:
                        decision["analysis_summary"] = {}
                
                decisions.append(decision)
            
            self.logger.debug(f"📖 {len(decisions)} تصمیم با وضعیت '{status}' خوانده شد")
            return decisions
            
        except sqlite3.Error as e:
            self.logger.error(f"❌ خطا در خواندن تصمیم‌ها: {e}")
            return []
    
    def get_decisions_summary(self) -> Dict[str, Any]:
        """
        دریافت خلاصه تصمیم‌های ذخیره شده
        
        Returns:
            خلاصه آمار
        """
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # آمار کلی
            cursor.execute("SELECT COUNT(*) FROM final_trading_decisions")
            total = cursor.fetchone()[0]
            
            # آمار بر اساس وضعیت
            cursor.execute("""
                SELECT status, COUNT(*) 
                FROM final_trading_decisions 
                GROUP BY status
            """)
            status_counts = {row[0]: row[1] for row in cursor.fetchall()}
            
            # آمار بر اساس نوع تصمیم
            cursor.execute("""
                SELECT decision_type, COUNT(*) 
                FROM final_trading_decisions 
                GROUP BY decision_type
            """)
            type_counts = {row[0]: row[1] for row in cursor.fetchall()}
            
            # آخرین تصمیم
            cursor.execute("""
                SELECT symbol, decision_type, status, timestamp 
                FROM final_trading_decisions 
                ORDER BY timestamp DESC 
                LIMIT 1
            """)
            last_decision = cursor.fetchone()
            
            conn.close()
            
            summary = {
                "total_decisions": total,
                "by_status": status_counts,
                "by_type": type_counts,
                "last_decision": {
                    "symbol": last_decision[0] if last_decision else None,
                    "type": last_decision[1] if last_decision else None,
                    "status": last_decision[2] if last_decision else None,
                    "time": last_decision[3] if last_decision else None
                } if last_decision else None
            }
            
            self.logger.info(f"📊 خلاصه تصمیم‌ها: {total} تصمیم در دیتابیس")
            
            return summary
            
        except sqlite3.Error as e:
            self.logger.error(f"❌ خطا در دریافت خلاصه: {e}")
            return {"error": str(e)}
    
    def cleanup_old_decisions(self, days_old: int = 30) -> int:
        """
        پاک‌سازی تصمیم‌های قدیمی
        
        Args:
            days_old: سن مجاز به روز
            
        Returns:
            تعداد رکوردهای حذف شده
        """
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # حذف تصمیم‌های قدیمی‌تر از days_old روز
            cursor.execute("""
                DELETE FROM final_trading_decisions 
                WHERE date(timestamp) < date('now', ?)
            """, (f'-{days_old} days',))
            
            deleted_count = cursor.rowcount
            conn.commit()
            conn.close()
            
            if deleted_count > 0:
                self.logger.info(f"🧹 {deleted_count} تصمیم قدیمی پاک شد (بیشتر از {days_old} روز)")
            
            return deleted_count
            
        except sqlite3.Error as e:
            self.logger.error(f"❌ خطا در پاک‌سازی تصمیم‌های قدیمی: {e}")
            return 0


# ==================== تست ====================
def test_trade_executor():
    """تست TradeExecutor"""
    print("\n🧪 TESTING TRADE EXECUTOR")
    print("=" * 60)
    
    try:
        # کلاس تست TradingDecision
        from dataclasses import dataclass
        from datetime import datetime
        
        @dataclass
        class TestDecision:
            decision_id: str = "DEC_TEST_001"
            timestamp: str = datetime.now().isoformat()
            coin_id: int = 1125
            symbol: str = "BTCUSDT"
            decision_type: str = "EXECUTE_BUY"
            signal_id: int = 1
            original_signal_type: str = "BUY"
            entry_price: float = 49000
            stop_loss: float = 48500
            take_profit: float = 51000
            position_size: float = 0.04
            leverage: int = 3
            allocated_capital_usd: float = 2000
            position_value_usd: float = 1960
            margin_required_usd: float = 653.33
            risk_amount_usd: float = 40
            expected_profit_usd: float = 800
            expected_loss_usd: float = 120
            risk_reward_ratio: float = 2.0
            net_risk_reward: float = 1.8
            entry_fee_usd: float = 1.96
            exit_fee_usd: float = 1.96
            total_fee_usd: float = 3.92
            confidence_score: float = 0.75
            priority_score: float = 85.5
            final_score: float = 76.5
            status: str = "APPROVED"
            rejection_reason: Optional[str] = None
            approval_criteria: List[str] = None
            analysis_summary: Dict[str, Any] = None
            execution_time: Optional[str] = None
        
        print("🔧 ایجاد TradeExecutor...")
        
        # ایجاد اجراکننده
        executor = TradeExecutor()
        
        print(f"✅ TradeExecutor created")
        
        # تست ۱: ذخیره یک تصمیم
        print("\n💾 TEST 1: Saving Single Decision...")
        test_decision = TestDecision()
        test_decision.approval_criteria = ["اعتماد کافی", "ریسک/بازده مناسب"]
        test_decision.analysis_summary = {"score": 76.5, "risk_level": "medium"}
        
        success, decision_id = executor.save_decision(test_decision)
        
        print(f"   Success: {'✅' if success else '❌'}")
        print(f"   Decision ID in DB: {decision_id}")
        
        # تست ۲: خواندن تصمیم
        print("\n📖 TEST 2: Reading Decision...")
        if success:
            retrieved = executor.get_decision_by_id(test_decision.decision_id)
            if retrieved:
                print(f"   ✅ Decision retrieved:")
                print(f"      - Symbol: {retrieved['symbol']}")
                print(f"      - Type: {retrieved['decision_type']}")
                print(f"      - Status: {retrieved['status']}")
                print(f"      - Score: {retrieved['final_score']}")
            else:
                print(f"   ❌ Decision not found")
        
        # تست ۳: ذخیره دسته‌ای
        print("\n📦 TEST 3: Batch Save...")
        decisions = [
            TestDecision(decision_id="DEC_TEST_002", symbol="ETHUSDT"),
            TestDecision(decision_id="DEC_TEST_003", symbol="BNBUSDT"),
            TestDecision(decision_id="DEC_TEST_004", symbol="XRPUSDT", status="REJECTED", 
                        rejection_reason="حجم ناکافی")
        ]
        
        batch_stats = executor.save_decisions_batch(decisions)
        
        print(f"   Batch stats:")
        print(f"      - Total: {batch_stats['total']}")
        print(f"      - Saved: {batch_stats['saved']}")
        print(f"      - Failed: {batch_stats['failed']}")
        
        # تست ۴: دریافت بر اساس وضعیت
        print("\n🔍 TEST 4: Get by Status...")
        approved_decisions = executor.get_decisions_by_status("APPROVED")
        rejected_decisions = executor.get_decisions_by_status("REJECTED")
        
        print(f"   Approved decisions: {len(approved_decisions)}")
        print(f"   Rejected decisions: {len(rejected_decisions)}")
        
        # تست ۵: خلاصه
        print("\n📊 TEST 5: Get Summary...")
        summary = executor.get_decisions_summary()
        
        print(f"   Total decisions: {summary.get('total_decisions', 0)}")
        print(f"   By status: {summary.get('by_status', {})}")
        
        if summary.get('last_decision'):
            last = summary['last_decision']
            print(f"   Last decision: {last.get('symbol')} ({last.get('type')})")
        
        # تست ۶: به‌روزرسانی وضعیت
        print("\n🔄 TEST 6: Update Status...")
        if success:
            updated = executor.update_decision_status(
                test_decision.decision_id, 
                "EXECUTED",
                datetime.now().isoformat()
            )
            print(f"   Status updated: {'✅' if updated else '❌'}")
        
        print("\n" + "=" * 60)
        print("✅ ALL TRADE EXECUTOR TESTS PASSED!")
        
        return True
        
    except Exception as e:
        print(f"❌ Test failed: {e}")
        import traceback
        traceback.print_exc()
        return False


if __name__ == "__main__":
    test_result = test_trade_executor()
    
    if test_result:
        print("\n🚀 TradeExecutor is ready for integration!")
        print("\n📝 Next: Connect with DecisionMaker and real decisions")
    else:
        print("\n❌ Needs debugging before integration")