#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
main_cycle_05.py - سیستم تصمیم‌گیری معاملاتی با config_manager
نسخه اصلاح شده: استفاده از telegram_manager.py
"""

import os
import sys
import json
import sqlite3
import argparse
import time
from datetime import datetime
from typing import List, Dict, Any

# ==================== تنظیم مسیرها ====================
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(SCRIPT_DIR)))
sys.path.insert(0, PROJECT_ROOT)

print("🚀 سیستم تصمیم‌گیری معاملاتی - تکه ۵")
print("=" * 60)

# بارگذاری config_manager
try:
    from scripts.config_manager import get, get_database_path, get_project_root
    
    # استفاده از config_manager برای مسیرها
    PROJECT_ROOT = get_project_root()  # از config_manager می‌گیریم
    DB_PATH = get_database_path()      # مسیر دیتابیس از config_manager
    STATE_PATH = os.path.join(PROJECT_ROOT, "state", "cycle_state.json")
    
    print(f"✅ config_manager بارگذاری شد")
    print(f"📁 مسیر پروژه (از config): {PROJECT_ROOT}")
    print(f"📁 مسیر دیتابیس (از config): {DB_PATH}")
    
except ImportError as e:
    print(f"❌ خطا در بارگذاری config_manager: {e}")
    print("⚠️ استفاده از مسیرهای پیش‌فرض")
    
    # مسیرهای پیش‌فرض
    DB_PATH = os.path.join(PROJECT_ROOT, "data", "crypto_master.db")
    STATE_PATH = os.path.join(PROJECT_ROOT, "state", "cycle_state.json")

print(f"📁 مسیر state: {STATE_PATH}")

# ==================== بارگذاری TelegramManager ====================

def setup_telegram_manager(no_telegram: bool = False):
    """راه‌اندازی مدیر تلگرام"""
    if no_telegram:
        print("ℹ️ تلگرام غیرفعال است (دستور --no-telegram)")
        return None
    
    try:
        # تلاش برای بارگذاری از telegram_manager.py
        from telegram_manager import TelegramManager as SimpleTelegramManager
        
        print("🤖 راه‌اندازی مدیر تلگرام ساده...")
        manager = SimpleTelegramManager()
        
        if not manager.connected:
            print("⚠️ مدیر تلگرام متصل نیست")
            return None
        
        print(f"✅ مدیر تلگرام راه‌اندازی شد")
        
        # تست اتصال
        print("🧪 تست اتصال تلگرام...")
        success = manager.test()
        
        if success:
            print("✅ تلگرام آماده است")
            return manager
        else:
            print("❌ تست تلگرام ناموفق بود")
            return None
            
    except ImportError as e:
        print(f"❌ خطا در بارگذاری telegram_manager.py: {e}")
        print("   تلگرام غیرفعال خواهد بود")
        return None
    except Exception as e:
        print(f"❌ خطا در راه‌اندازی تلگرام: {e}")
        return None

# ==================== توابع اصلی ====================

def get_database_path():
    """دریافت مسیر دیتابیس"""
    try:
        from scripts.config_manager import get_database_path
        return get_database_path()
    except:
        return os.path.join(PROJECT_ROOT, "data", "crypto_master.db")

def get_trading_config():
    """خواندن تنظیمات معاملاتی از config_manager"""
    config = {
        'total_capital': 1000,
        'min_position': 10,
        'min_confidence': 50,
        'max_position_percent': 0.1
    }
    
    try:
        from scripts.config_manager import get
        
        # خواندن از config_manager
        config['total_capital'] = get('trading.total_capital', 1000)
        config['min_position'] = get('trading.min_position', 10)
        config['min_confidence'] = get('trading.min_confidence', 50)
        config['max_position_percent'] = get('trading.max_position_percent', 0.1)
        
        print(f"✅ تنظیمات معاملاتی از config_manager خوانده شد")
        
    except Exception as e:
        print(f"⚠️ استفاده از تنظیمات پیش‌فرض: {e}")
    
    return config

def get_block_coins(block_id: int) -> List[Dict[str, Any]]:
    """دریافت ارزهای یک بلوک"""
    if not os.path.exists(STATE_PATH):
        print(f"❌ فایل state یافت نشد: {STATE_PATH}")
        return []
    
    try:
        with open(STATE_PATH, 'r', encoding='utf-8') as f:
            state = json.load(f)
        
        blocks = state.get('blocks', [])
        print(f"📋 تعداد بلوک‌ها در state: {len(blocks)}")
        
        # پیدا کردن بلوک با block_id
        target_block = None
        for block in blocks:
            if block.get('block_id') == block_id:
                target_block = block
                break
        
        if not target_block:
            print(f"❌ بلوک {block_id} در state یافت نشد")
            available_blocks = [b.get('block_id') for b in blocks]
            print(f"   بلوک‌های موجود: {available_blocks}")
            return []
        
        block_coins = target_block.get('coins', [])
        print(f"📦 بلوک {block_id}: {len(block_coins)} ارز")
        
        # نمایش نمونه
        for i, coin in enumerate(block_coins[:3]):
            print(f"  {i+1}. {coin.get('symbol', 'نامشخص')} (ID: {coin.get('id', '?')})")
        if len(block_coins) > 3:
            print(f"  ... و {len(block_coins)-3} ارز دیگر")
        
        return block_coins
        
    except Exception as e:
        print(f"❌ خطا در خواندن state: {e}")
        return []

def get_signals_for_block(block_id: int) -> List[Dict[str, Any]]:
    """دریافت سیگنال‌های یک بلوک"""
    print(f"\n📊 جستجوی سیگنال‌ها برای بلوک {block_id}...")
    
    block_coins = get_block_coins(block_id)
    if not block_coins:
        print("❌ هیچ ارزی در بلوک یافت نشد")
        return []
    
    coin_ids = [coin.get('id') for coin in block_coins if coin.get('id')]
    print(f"🔍 جستجوی سیگنال‌ها برای {len(coin_ids)} ارز...")
    
    db_path = get_database_path()
    if not os.path.exists(db_path):
        print(f"❌ دیتابیس یافت نشد: {db_path}")
        return []
    
    try:
        conn = sqlite3.connect(db_path)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        
        # دریافت تنظیمات از config_manager
        trading_config = get_trading_config()
        min_confidence = trading_config.get('min_confidence', 50)
        
        placeholders = ','.join('?' * len(coin_ids))
        query = f"""
            SELECT id, coin_id, symbol, signal_type, confidence_score,
                   entry_price, current_price, signal_time, created_at
            FROM trading_signals 
            WHERE coin_id IN ({placeholders})
            AND confidence_score >= ?
            ORDER BY confidence_score DESC
            LIMIT 50
        """
        
        cursor.execute(query, coin_ids + [min_confidence])
        rows = cursor.fetchall()
        conn.close()
        
        signals = [dict(row) for row in rows]
        print(f"✅ {len(signals)} سیگنال برای بلوک {block_id} یافت شد")
        
        # نمایش نمونه
        for i, signal in enumerate(signals[:5]):
            print(f"  {i+1}. {signal['symbol']}: {signal['signal_type']} ({signal['confidence_score']:.1f}%)")
        
        return signals
        
    except Exception as e:
        print(f"❌ خطا در دریافت سیگنال‌ها: {e}")
        return []

def make_trading_decisions(signals: List[Dict[str, Any]], 
                          telegram_manager=None) -> List[Dict[str, Any]]:
    """تصمیم‌گیری معاملاتی (بدون ارسال فوری تلگرام)"""
    trading_config = get_trading_config()
    TOTAL_CAPITAL = trading_config.get('total_capital', 1000)
    MIN_POSITION = trading_config.get('min_position', 10)
    MAX_POSITION_PERCENT = trading_config.get('max_position_percent', 0.1)
    
    decisions = []
    
    print("\n🎯 شروع تصمیم‌گیری:")
    print(f"   سرمایه کل: ${TOTAL_CAPITAL:,}")
    print(f"   حداقل پوزیشن: ${MIN_POSITION}")
    print(f"   حداکثر درصد: {MAX_POSITION_PERCENT*100}%")
    
    for signal in signals:
        try:
            confidence = signal.get('confidence_score', 0)
            symbol = signal.get('symbol', 'UNKNOWN')
            signal_type = signal.get('signal_type', 'NEUTRAL')
            current_price = signal.get('current_price', 0.0)
            
            # تعیین سطح ریسک و تصمیم
            if confidence >= 70:
                decision_type = f"EXECUTE_{signal_type}"
                capital_percent = 0.05
                risk_level = "HIGH"
            elif confidence >= 60:
                decision_type = f"EXECUTE_{signal_type}"
                capital_percent = 0.03
                risk_level = "MEDIUM"
            elif confidence >= 50:
                decision_type = f"EXECUTE_{signal_type}"
                capital_percent = 0.02
                risk_level = "LOW"
            else:
                decision_type = "REJECT"
                capital_percent = 0
                risk_level = "NONE"
            
            position_size = TOTAL_CAPITAL * capital_percent if capital_percent > 0 else 0
            
            if 0 < position_size < MIN_POSITION:
                position_size = MIN_POSITION
            
            MAX_POSITION = TOTAL_CAPITAL * MAX_POSITION_PERCENT
            if position_size > MAX_POSITION:
                position_size = MAX_POSITION
            
            decision_id = f"DEC_{symbol}_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
            
            decision = {
                'decision_id': decision_id,
                'symbol': symbol,
                'signal_type': signal_type,
                'decision_type': decision_type,
                'confidence_score': confidence,
                'current_price': current_price,
                'position_size_usd': round(position_size, 2),
                'risk_level': risk_level,
                'telegram_sent': False,
                'created_at': datetime.now().isoformat()
            }
            
            decisions.append(decision)
            
            status_emoji = "✅" if decision_type.startswith("EXECUTE") else "❌"
            print(f"  {status_emoji} {symbol}: {decision_type} (${position_size:,.2f}) - {risk_level}")
            
        except Exception as e:
            print(f"❌ خطا در پردازش سیگنال {signal.get('symbol', 'UNKNOWN')}: {e}")
    
    return decisions

def save_decisions_to_database(decisions: List[Dict[str, Any]], block_id: int) -> bool:
    """ذخیره تصمیم‌ها در دیتابیس"""
    if not decisions:
        return False
    
    db_path = get_database_path()
    
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # ایجاد جدول اگر وجود ندارد
        cursor.execute('''
        CREATE TABLE IF NOT EXISTS trading_decisions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            decision_id TEXT UNIQUE NOT NULL,
            block_id INTEGER NOT NULL,
            symbol TEXT NOT NULL,
            signal_type TEXT NOT NULL,
            decision_type TEXT NOT NULL,
            confidence_score REAL NOT NULL,
            current_price REAL NOT NULL,
            position_size_usd REAL NOT NULL,
            telegram_sent BOOLEAN DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
        ''')
        
        saved_count = 0
        for decision in decisions:
            try:
                cursor.execute('''
                INSERT OR REPLACE INTO trading_decisions 
                (decision_id, block_id, symbol, signal_type, decision_type,
                 confidence_score, current_price, position_size_usd, 
                 telegram_sent, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ''', (
                    decision['decision_id'],
                    block_id,
                    decision['symbol'],
                    decision['signal_type'],
                    decision['decision_type'],
                    decision['confidence_score'],
                    decision['current_price'],
                    decision['position_size_usd'],
                    decision.get('telegram_sent', False),
                    decision['created_at']
                ))
                saved_count += 1
            except Exception as e:
                print(f"❌ خطا در ذخیره تصمیم {decision['decision_id']}: {e}")
        
        conn.commit()
        conn.close()
        
        print(f"💾 {saved_count} تصمیم در دیتابیس ذخیره شد")
        return True
        
    except Exception as e:
        print(f"❌ خطا در ذخیره تصمیم‌ها: {e}")
        return False

def send_telegram_notifications(decisions: List[Dict[str, Any]], telegram_manager) -> int:
    """ارسال نوتیفیکیشن تلگرام برای تصمیم‌های تأیید شده"""
    if not telegram_manager:
        print("ℹ️ مدیر تلگرام موجود نیست - ارسال نوتیفیکیشن حذف شد")
        return 0
    
    executed_decisions = [d for d in decisions if d['decision_type'].startswith('EXECUTE')]
    
    if not executed_decisions:
        print("ℹ️ هیچ تصمیم تأیید شده‌ای برای ارسال نوتیفیکیشن وجود ندارد")
        return 0
    
    print(f"\n📱 ارسال نوتیفیکیشن تلگرام برای {len(executed_decisions)} تصمیم تأیید شده...")
    
    sent_count = 0
    for decision in executed_decisions:
        try:
            symbol = decision['symbol']
            signal_type = decision['signal_type']
            confidence = decision['confidence_score']
            price = decision['current_price']
            position_size = decision['position_size_usd']
            decision_id = decision['decision_id']
            risk_level = decision['risk_level']
            
            # فرمت پیام تلگرام
            signal_emoji = "🟢" if signal_type == "BUY" else "🔴" if signal_type == "SELL" else "⚪"
            risk_emoji = "🔴" if risk_level == "HIGH" else "🟡" if risk_level == "MEDIUM" else "🟢"
            
            message = f"""
{signal_emoji} *سیگنال معاملاتی - تأیید شده* {signal_emoji}

📊 ارز: *{symbol}*
🎯 سیگنال: *{signal_type}*
{risk_emoji} اعتماد: *{confidence:.1f}%*
{risk_emoji} سطح ریسک: *{risk_level}*
💰 قیمت فعلی: *${price:,.4f}*
💼 سرمایه تخصیص یافته: *${position_size:,.2f}*

🆔 شناسه تصمیم: `{decision_id}`
⏰ زمان: {datetime.now().strftime('%H:%M')}
✅ وضعیت: در دیتابیس ذخیره شد
"""
            
            success = telegram_manager.send_message(message)
            
            if success:
                decision['telegram_sent'] = True
                sent_count += 1
                print(f"  ✅ {symbol}: نوتیفیکیشن ارسال شد")
                time.sleep(1)  # تاخیر برای جلوگیری از rate limit
            else:
                print(f"  ❌ {symbol}: ارسال ناموفق")
                
        except Exception as e:
            print(f"  ❌ خطا در ارسال نوتیفیکیشن برای {decision.get('symbol', 'UNKNOWN')}: {e}")
    
    return sent_count

def update_telegram_status_in_database(decisions: List[Dict[str, Any]], block_id: int):
    """به‌روزرسانی وضعیت تلگرام در دیتابیس"""
    if not decisions:
        return
    
    executed_decisions = [d for d in decisions if d['decision_type'].startswith('EXECUTE')]
    if not executed_decisions:
        return
    
    db_path = get_database_path()
    
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        updated_count = 0
        for decision in executed_decisions:
            if decision.get('telegram_sent', False):
                cursor.execute('''
                UPDATE trading_decisions 
                SET telegram_sent = 1 
                WHERE decision_id = ?
                ''', (decision['decision_id'],))
                updated_count += 1
        
        conn.commit()
        conn.close()
        
        if updated_count > 0:
            print(f"💾 وضعیت تلگرام برای {updated_count} تصمیم در دیتابیس به‌روزرسانی شد")
        
    except Exception as e:
        print(f"⚠️ خطا در به‌روزرسانی وضعیت تلگرام: {e}")

def generate_report(block_id: int, signals: List[Dict[str, Any]], 
                   decisions: List[Dict[str, Any]], telegram_manager=None):
    """تولید گزارش"""
    executed = [d for d in decisions if d['decision_type'].startswith('EXECUTE')]
    rejected = [d for d in decisions if d['decision_type'] == 'REJECT']
    
    # شمارش نوتیفیکیشن‌های ارسال شده
    telegram_sent = sum(1 for d in decisions if d.get('telegram_sent', False))
    
    total_allocated = sum(d['position_size_usd'] for d in executed)
    avg_confidence = sum(s['confidence_score'] for s in signals) / len(signals) if signals else 0
    
    trading_config = get_trading_config()
    TOTAL_CAPITAL = trading_config.get('total_capital', 1000)
    
    print("\n" + "=" * 60)
    print("📊 گزارش نهایی تکه ۵")
    print("=" * 60)
    
    print(f"\n📈 آمار اجرا:")
    print(f"  بلوک: {block_id}")
    print(f"  زمان: {datetime.now().strftime('%H:%M:%S')}")
    
    print(f"\n📊 آمار سیگنال‌ها:")
    print(f"  کل سیگنال‌ها: {len(signals)}")
    print(f"  خرید: {len([s for s in signals if s.get('signal_type') == 'BUY'])}")
    print(f"  فروش: {len([s for s in signals if s.get('signal_type') == 'SELL'])}")
    print(f"  میانگین اعتماد: {avg_confidence:.1f}%")
    
    print(f"\n🎯 آمار تصمیم‌گیری:")
    print(f"  کل تصمیم‌ها: {len(decisions)}")
    print(f"  تأیید شده: {len(executed)}")
    print(f"  رد شده: {len(rejected)}")
    approval_rate = (len(executed)/len(decisions)*100) if decisions else 0
    print(f"  نرخ تأیید: {approval_rate:.1f}%")
    print(f"  نوتیفیکیشن‌های تلگرام: {telegram_sent}")
    
    print(f"\n💰 مدیریت سرمایه:")
    print(f"  سرمایه کل: ${TOTAL_CAPITAL:,}")
    print(f"  سرمایه تخصیص یافته: ${total_allocated:,.2f}")
    utilization_rate = (total_allocated/TOTAL_CAPITAL*100) if TOTAL_CAPITAL > 0 else 0
    print(f"  نرخ استفاده: {utilization_rate:.1f}%")
    print(f"  تعداد پوزیشن‌ها: {len(executed)}")
    
    if executed:
        print(f"\n🏆 برترین تصمیم‌ها:")
        for i, decision in enumerate(sorted(executed, key=lambda x: x['confidence_score'], reverse=True)[:3]):
            risk_emoji = "🔴" if decision.get('risk_level') == 'HIGH' else "🟡" if decision.get('risk_level') == 'MEDIUM' else "🟢"
            telegram_emoji = "📱" if decision.get('telegram_sent') else ""
            print(f"  {i+1}. {decision['symbol']} {risk_emoji}{telegram_emoji}")
            print(f"     - {decision['decision_type']} ({decision['confidence_score']:.1f}%)")
            print(f"     - ${decision['position_size_usd']:,.2f}")
    
    # ارسال گزارش خلاصه به تلگرام
    if telegram_manager and len(executed) > 0:
        try:
            # استفاده از تابع send_message ساده
            summary_message = f"""
📋 *گزارش تکه ۵ - بلوک {block_id}*

📊 آمار اجرا:
├─ کل سیگنال‌ها: {len(signals)}
├─ تصمیم‌های تأیید: {len(executed)}
├─ تصمیم‌های رد: {len(rejected)}
├─ نوتیفیکیشن‌ها ارسال شده: {telegram_sent}
├─ سرمایه تخصیص یافته: *${total_allocated:,.2f}*
└─ میانگین اعتماد: *{avg_confidence:.1f}%*

✅ پردازش بلوک {block_id} تکمیل شد
⏰ {datetime.now().strftime('%H:%M')}
"""
            telegram_manager.send_message(summary_message)
            print(f"📱 گزارش خلاصه بلوک {block_id} به تلگرام ارسال شد")
            
        except Exception as e:
            print(f"⚠️ خطا در ارسال گزارش تلگرام: {e}")
    
    print("\n" + "=" * 60)
    print("✅ تکه ۵ با موفقیت تکمیل شد!")
    print("=" * 60)
    
    # ذخیره گزارش JSON
    report_data = {
        'block_id': block_id,
        'timestamp': datetime.now().isoformat(),
        'total_signals': len(signals),
        'total_decisions': len(decisions),
        'executed_decisions': len(executed),
        'allocated_capital': total_allocated,
        'telegram_notifications': telegram_sent,
        'trading_config': trading_config
    }
    
    reports_dir = os.path.join(PROJECT_ROOT, "reports", "cycle_05")
    os.makedirs(reports_dir, exist_ok=True)
    
    report_file = os.path.join(
        reports_dir, 
        f"block_{block_id:03d}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
    )
    
    with open(report_file, 'w', encoding='utf-8') as f:
        json.dump(report_data, f, indent=2, ensure_ascii=False)
    
    print(f"📄 گزارش ذخیره شد: {report_file}")

def update_system_state(block_id: int):
    """به‌روزرسانی وضعیت سیستم"""
    if not os.path.exists(STATE_PATH):
        return
    
    try:
        with open(STATE_PATH, 'r', encoding='utf-8') as f:
            state = json.load(f)
        
        # به‌روزرسانی بلوک
        for block in state.get('blocks', []):
            if block.get('block_id') == block_id:
                block['cycle_05_processed'] = True
                block['cycle_05_time'] = datetime.now().isoformat()
                block['cycle_05_status'] = 'COMPLETED'
                break
        
        with open(STATE_PATH, 'w', encoding='utf-8') as f:
            json.dump(state, f, indent=2, ensure_ascii=False)
        
        print("💾 وضعیت سیستم به‌روزرسانی شد")
        
    except Exception as e:
        print(f"⚠️ خطا در به‌روزرسانی وضعیت: {e}")

# ==================== تابع اصلی ====================

def main():
    """تابع اصلی"""
    parser = argparse.ArgumentParser(description='سیستم تصمیم‌گیری معاملاتی - تکه ۵')
    parser.add_argument('--block', type=int, default=1, help='شماره بلوک (پیش‌فرض: 1)')
    parser.add_argument('--no-telegram', action='store_true', help='غیرفعال کردن تلگرام')
    
    args = parser.parse_args()
    
    print(f"\n🎯 پردازش بلوک {args.block}")
    print("-" * 40)
    
    # راه‌اندازی تلگرام
    telegram_manager = setup_telegram_manager(args.no_telegram)
    
    # دریافت سیگنال‌ها
    print(f"\n📦 دریافت سیگنال‌های بلوک {args.block}...")
    signals = get_signals_for_block(args.block)
    
    if not signals:
        print(f"❌ هیچ سیگنال معتبری برای بلوک {args.block} یافت نشد")
        return
    
    print(f"✅ {len(signals)} سیگنال دریافت شد")
    
    # تصمیم‌گیری (بدون ارسال فوری تلگرام)
    print("\n🎯 تصمیم‌گیری معاملاتی...")
    decisions = make_trading_decisions(signals, telegram_manager)
    
    if not decisions:
        print("❌ هیچ تصمیمی ایجاد نشد")
        return
    
    executed_count = len([d for d in decisions if d['decision_type'].startswith('EXECUTE')])
    print(f"✅ {len(decisions)} تصمیم ایجاد شد ({executed_count} تأیید)")
    
    # ذخیره در دیتابیس
    print("\n💾 ذخیره در دیتابیس...")
    save_success = save_decisions_to_database(decisions, args.block)
    
    if not save_success:
        print("⚠️ خطا در ذخیره دیتابیس - ادامه بدون تلگرام")
    else:
        # ارسال نوتیفیکیشن‌های تلگرام (پس از ذخیره در دیتابیس)
        if telegram_manager and executed_count > 0:
            print("\n📱 ارسال نوتیفیکیشن‌های تلگرام...")
            sent_count = send_telegram_notifications(decisions, telegram_manager)
            
            if sent_count > 0:
                print(f"✅ {sent_count} نوتیفیکیشن ارسال شد")
                
                # به‌روزرسانی وضعیت تلگرام در دیتابیس
                update_telegram_status_in_database(decisions, args.block)
        else:
            print("ℹ️ نوتیفیکیشن تلگرام ارسال نشد (عدم اتصال یا تصمیم تأیید شده)")
    
    # تولید گزارش
    print("\n📊 تولید گزارش...")
    generate_report(args.block, signals, decisions, telegram_manager)
    
    # به‌روزرسانی وضعیت سیستم
    print("\n🔄 به‌روزرسانی وضعیت سیستم...")
    update_system_state(args.block)
    
    print(f"\n🎉 تکه ۵ برای بلوک {args.block} تکمیل شد!")

if __name__ == "__main__":
    main()