#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
telegram_manager.py - ماژول ساده مدیریت تلگرام
"""

import telebot
import time
from datetime import datetime

# تنظیمات مستقیم
BOT_TOKEN = "8403968068:AAGpfF6pgpXschz4q7M3kkXos1Tra5-YXu8"
CHAT_ID = "108290369"

class TelegramManager:
    """مدیریت ساده تلگرام"""
    
    def __init__(self):
        """راه‌اندازی ربات تلگرام"""
        try:
            self.bot = telebot.TeleBot(BOT_TOKEN)
            self.connected = True
            print("✅ ربات تلگرام راه‌اندازی شد")
        except Exception as e:
            self.bot = None
            self.connected = False
            print(f"❌ خطا در راه‌اندازی تلگرام: {e}")
    
    def send_message(self, message):
        """ارسال پیام ساده"""
        if not self.bot:
            print("❌ ربات راه‌اندازی نشده است")
            return False
        
        try:
            # ارسال پیام
            result = self.bot.send_message(
                chat_id=CHAT_ID,
                text=message,
                parse_mode='Markdown',
                disable_web_page_preview=True
            )
            
            print(f"✅ پیام ارسال شد (ID: {result.message_id})")
            return True
            
        except telebot.apihelper.ApiTelegramException as e:
            if e.error_code == 401:
                print("❌ توکن نامعتبر است")
            elif e.error_code == 403:
                print("❌ ربات به کانال دسترسی ندارد")
            elif e.error_code == 400:
                print("❌ شناسه چت نامعتبر است")
            else:
                print(f"❌ خطای تلگرام: {e}")
            return False
        except Exception as e:
            print(f"❌ خطای غیرمنتظره: {e}")
            return False
    
    def test(self):
        """تست اتصال"""
        print("🧪 تست اتصال تلگرام...")
        
        if not self.bot:
            print("❌ ربات راه‌اندازی نشده است")
            return False
        
        try:
            # تست اتصال
            bot_info = self.bot.get_me()
            print(f"✅ ربات: @{bot_info.username} ({bot_info.first_name})")
            
            # ارسال پیام تست
            message = f"✅ تست سیستم\n⏰ {datetime.now().strftime('%H:%M:%S')}"
            success = self.send_message(message)
            
            if success:
                print("🎉 همه چیز درست است!")
            return success
            
        except Exception as e:
            print(f"❌ خطا در تست: {e}")
            return False

# تست مستقیم
if __name__ == "__main__":
    print("🤖 مدیر تلگرام - نسخه ساده")
    print("=" * 50)
    print(f"توکن: ****{BOT_TOKEN[-8:]}")
    print(f"چت آیدی: {CHAT_ID}")
    
    # ایجاد مدیر
    manager = TelegramManager()
    
    # تست اتصال
    manager.test()