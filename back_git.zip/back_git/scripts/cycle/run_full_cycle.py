﻿"""
فایل: run_auto_fixed.py
مسیر: /scripts/cycle/run_auto_fixed.py
"""

import os
import sys
import json
import time
import subprocess

def find_state_file():
    """یافتن فایل state"""
    # مسیرهای ممکن
    possible_paths = [
        os.path.join(os.path.dirname(__file__), "..", "..", "state", "cycle_state.json"),
        os.path.join(os.path.dirname(__file__), "..", "state", "cycle_state.json"),
        os.path.join(os.path.dirname(os.path.dirname(__file__)), "state", "cycle_state.json"),
        os.path.join(os.getcwd(), "state", "cycle_state.json"),
        os.path.join(os.path.expanduser("~"), "state", "cycle_state.json")
    ]
    
    for path in possible_paths:
        if os.path.exists(path):
            print(f"✅ فایل state یافت شد: {path}")
            return path
    
    print("❌ فایل state یافت نشد")
    return None

def run_script(script_name):
    """اجرای یک اسکریپت"""
    script_path = os.path.join(os.path.dirname(__file__), script_name)
    
    if not os.path.exists(script_path):
        print(f"❌ فایل {script_name} یافت نشد")
        return False
    
    print(f"🔧 اجرای {script_name}...")
    
    try:
        result = subprocess.run(
            [sys.executable, script_path],
            capture_output=True,
            text=True,
            encoding='utf-8'
        )
        
        # نمایش خروجی مهم
        lines = result.stdout.split('\n')
        for line in lines:
            if '✅' in line or '❌' in line or '🎉' in line or 'خطا' in line:
                print(f"   {line}")
        
        return result.returncode == 0
    except Exception as e:
        print(f"   ❌ خطا: {e}")
        return False

def main():
    print("=" * 60)
    print("🚀 اجرای خودکار چرخه کامل (نسخه اصلاح شده)")
    print("=" * 60)
    
    # مرحله 1
    print("\n📊 مرحله 1: فیلتر ارزها")
    if not run_script("cycle_01_coin_filter.py"):
        print("❌ توقف: خطا در مرحله 1")
        return
    
    time.sleep(3)
    
    # یافتن فایل state
    state_file = find_state_file()
    if not state_file:
        return
    
    # خواندن وضعیت
    try:
        with open(state_file, 'r', encoding='utf-8') as f:
            state = json.load(f)
        
        total_blocks = state['stats']['total_blocks']
        print(f"\n📦 اطلاعات چرخه:")
        print(f"   • شناسه: {state['cycle_id']}")
        print(f"   • تعداد بلوک‌ها: {total_blocks}")
        print(f"   • تعداد ارزها: {state['stats']['total_coins_in_blocks']}")
        
    except Exception as e:
        print(f"❌ خطا در خواندن state: {e}")
        return
    
    # مرحله 2: پردازش بلوک‌ها
    print(f"\n🔄 مرحله 2: پردازش {total_blocks} بلوک")
    
    for block_num in range(1, total_blocks + 1):
        print(f"\r📦 بلوک {block_num}/{total_blocks}...", end="")
        
        if run_script("cycle_02_process_block.py"):
            # بررسی پیشرفت
            try:
                with open(state_file, 'r', encoding='utf-8') as f:
                    state = json.load(f)
                
                completed = len(state.get('completed_blocks', []))
                print(f" ({completed}/{total_blocks} تکمیل)")
                
                if state.get('status') == 'completed':
                    print(f"\n🎉 تمام بلوک‌ها پردازش شدند!")
                    break
                    
            except:
                pass
        else:
            print(f"\n⚠️ خطا در بلوک {block_num}")
        
        time.sleep(2)
    
    # مراحل بعدی
    print(f"\n📈 مراحل تکمیلی:")
    
    other_scripts = [
        ("cycle_03_data_analyzer.py", "تحلیل داده"),
        ("cycle_04_report_generator.py", "تولید گزارش"),
        ("cycle_05_cleanup.py", "پاکسازی")
    ]
    
    for script, desc in other_scripts:
        script_path = os.path.join(os.path.dirname(__file__), script)
        if os.path.exists(script_path):
            print(f"   🔄 {desc}...")
            run_script(script)
        else:
            print(f"   ⏭️ {desc} (ندارد)")
        time.sleep(1)
    
    print("\n" + "=" * 60)
    print("🎉 چرخه کامل شد!")
    print("=" * 60)

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n⏹️ اجرا متوقف شد")
    except Exception as e:
        print(f"\n❌ خطای غیرمنتظره: {e}")