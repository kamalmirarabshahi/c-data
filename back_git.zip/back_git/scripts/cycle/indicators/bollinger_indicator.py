"""
اندیکاتور باندهای بولینگر
"""

import math
from typing import List, Optional, Dict, Any, Tuple
from .base_indicator import BaseIndicator


class BollingerBandsIndicator(BaseIndicator):
    """اندیکاتور باندهای بولینگر با محاسسه باند بالا، میانی و پایین"""
    
    def __init__(self, period: int = 20, std_dev: float = 2.0):
        super().__init__(
            name="Bollinger Bands",
            description="Bollinger Bands with standard deviation"
        )
        self.period = period
        self.std_dev = std_dev
        self.minimum_data_points = period
        self.requires_minimum_data = True
    
    def calculate_history(self, prices: List[float], **params) -> Tuple[List[Optional[float]], 
                                                                        List[Optional[float]], 
                                                                        List[Optional[float]]]:
        """محاسبه تاریخچه باندهای بولینگر"""
        period = params.get('period', self.period)
        std_dev = params.get('std_dev', self.std_dev)
        
        if not self.validate_data(prices):
            upper = [None] * len(prices)
            middle = [None] * len(prices)
            lower = [None] * len(prices)
            return upper, middle, lower
        
        n = len(prices)
        upper_band = [None] * n
        middle_band = [None] * n
        lower_band = [None] * n
        
        # محاسبه برای نقاطی که داده کافی دارند
        for i in range(period - 1, n):
            window = prices[i-period+1:i+1]
            
            # میانگین (باند میانی)
            sma = sum(window) / period
            middle_band[i] = sma
            
            # انحراف معیار
            variance = sum((x - sma) ** 2 for x in window) / period
            std = math.sqrt(variance)
            
            # باندهای بالا و پایین
            upper_band[i] = sma + (std_dev * std)
            lower_band[i] = sma - (std_dev * std)
        
        return upper_band, middle_band, lower_band
    
    def get_output_column_name(self) -> str:
        return f"bollinger_{self.period}"
    
    def get_multi_output_columns(self) -> Dict[str, str]:
        """برای اندیکاتورهایی که چند خروجی دارند"""
        return {
            'upper': f"bb_upper_{self.period}",
            'middle': f"bb_middle_{self.period}",
            'lower': f"bb_lower_{self.period}"
        }
    
    def calculate_price_position(self, price: float, upper: float, lower: float) -> Optional[float]:
        """محاسبه موقعیت قیمت در باندها (0 تا 1)"""
        if upper is None or lower is None or upper == lower:
            return None
        return (price - lower) / (upper - lower)
    
    def get_signal(self, price: float, upper: float, lower: float) -> str:
        """دریافت سیگنال بر اساس موقعیت قیمت در باندها"""
        position = self.calculate_price_position(price, upper, lower)
        if position is None:
            return "NEUTRAL"
        
        if position < 0.2:  # نزدیک باند پایین
            return "OVERSOLD"
        elif position > 0.8:  # نزدیک باند بالا
            return "OVERBOUGHT"
        elif position < 0.3:
            return "BUY_SIGNAL"
        elif position > 0.7:
            return "SELL_SIGNAL"
        else:
            return "NEUTRAL"
    
    def get_config_params(self) -> Dict[str, Any]:
        return {
            'period': self.period,
            'std_dev': self.std_dev
        }