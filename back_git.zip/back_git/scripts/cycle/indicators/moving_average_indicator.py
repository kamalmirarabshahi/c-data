"""
اندیکاتورهای میانگین متحرک
"""

from typing import List, Optional, Dict, Any
from .base_indicator import BaseIndicator


class SMAIndicator(BaseIndicator):
    """میانگین متحرک ساده (Simple Moving Average)"""
    
    def __init__(self, period: int = 20):
        super().__init__(
            name=f"SMA-{period}",
            description=f"Simple Moving Average ({period} period)"
        )
        self.period = period
        self.minimum_data_points = period
        self.requires_minimum_data = True
    
    def calculate_history(self, prices: List[float], **params) -> List[Optional[float]]:
        """محاسبه تاریخچه SMA"""
        period = params.get('period', self.period)
        
        if not self.validate_data(prices):
            return [None] * len(prices)
        
        n = len(prices)
        sma_values = [None] * n
        
        for i in range(period - 1, n):
            window = prices[i-period+1:i+1]
            sma_values[i] = sum(window) / period
        
        return sma_values
    
    def get_output_column_name(self) -> str:
        return f"sma_{self.period}"
    
    def get_config_params(self) -> Dict[str, Any]:
        return {'period': self.period}


class EMAIndicator(BaseIndicator):
    """میانگین متحرک نمایی (Exponential Moving Average)"""
    
    def __init__(self, period: int = 12):
        super().__init__(
            name=f"EMA-{period}",
            description=f"Exponential Moving Average ({period} period)"
        )
        self.period = period
        self.minimum_data_points = period
        self.requires_minimum_data = True
        self.multiplier = 2 / (period + 1)
    
    def calculate_history(self, prices: List[float], **params) -> List[Optional[float]]:
        """محاسبه تاریخچه EMA"""
        period = params.get('period', self.period)
        
        if not self.validate_data(prices):
            return [None] * len(prices)
        
        if len(prices) < period:
            return [None] * len(prices)
        
        n = len(prices)
        ema_values = [None] * n
        
        # اولین EMA = SMA
        first_sma = sum(prices[:period]) / period
        ema_values[period-1] = first_sma
        
        # محاسبه EMA برای نقاط بعدی
        for i in range(period, n):
            current_price = prices[i]
            prev_ema = ema_values[i-1]
            
            if prev_ema is None:
                # محاسبه SMA اگر EMA قبلی وجود ندارد
                window = prices[i-period+1:i+1]
                ema_values[i] = sum(window) / period
            else:
                # فرمول استاندارد EMA
                ema_values[i] = (current_price - prev_ema) * self.multiplier + prev_ema
        
        return ema_values
    
    def calculate_single(self, current_price: float, prev_ema: float) -> float:
        """محاسبه EMA برای یک نقطه (برای استفاده real-time)"""
        return (current_price - prev_ema) * self.multiplier + prev_ema
    
    def get_output_column_name(self) -> str:
        return f"ema_{self.period}"
    
    def get_config_params(self) -> Dict[str, Any]:
        return {'period': self.period}