"""
اندیکاتور MACD
"""

from typing import List, Optional, Dict, Any, Tuple
from .base_indicator import BaseIndicator
from .moving_average_indicator import EMAIndicator


class MACDIndicator(BaseIndicator):
    """اندیکاتور MACD با محاسبه خط MACD، خط سیگنال و هیستوگرام"""
    
    def __init__(self, fast_period: int = 12, slow_period: int = 26, signal_period: int = 9):
        super().__init__(
            name="MACD",
            description="Moving Average Convergence Divergence"
        )
        self.fast_period = fast_period
        self.slow_period = slow_period
        self.signal_period = signal_period
        self.minimum_data_points = slow_period + signal_period
        self.ema_fast = EMAIndicator(fast_period)
        self.ema_slow = EMAIndicator(slow_period)
        self.ema_signal = EMAIndicator(signal_period)
    
    def calculate_history(self, prices: List[float], **params) -> Tuple[List[Optional[float]], 
                                                                        List[Optional[float]], 
                                                                        List[Optional[float]]]:
        """محاسبه تاریخچه MACD"""
        fast_period = params.get('fast_period', self.fast_period)
        slow_period = params.get('slow_period', self.slow_period)
        signal_period = params.get('signal_period', self.signal_period)
        
        # محاسبه EMA سریع و کند
        fast_ema = self.ema_fast.calculate_history(prices, period=fast_period)
        slow_ema = self.ema_slow.calculate_history(prices, period=slow_period)
        
        if not fast_ema or not slow_ema:
            macd_line = [None] * len(prices)
            signal_line = [None] * len(prices)
            histogram = [None] * len(prices)
            return macd_line, signal_line, histogram
        
        # محاسبه خط MACD
        macd_line = []
        for i in range(len(prices)):
            if fast_ema[i] is not None and slow_ema[i] is not None:
                macd_line.append(fast_ema[i] - slow_ema[i])
            else:
                macd_line.append(None)
        
        # محاسبه خط سیگنال (EMA از MACD)
        signal_line = self.ema_signal.calculate_history(
            [m if m is not None else 0 for m in macd_line], 
            period=signal_period
        )
        
        # محاسبه هیستوگرام
        histogram = []
        for i in range(len(prices)):
            if (macd_line[i] is not None and 
                signal_line[i] is not None):
                histogram.append(macd_line[i] - signal_line[i])
            else:
                histogram.append(None)
        
        return macd_line, signal_line, histogram
    
    def get_output_column_name(self) -> str:
        return f"macd_{self.fast_period}_{self.slow_period}"
    
    def get_multi_output_columns(self) -> Dict[str, str]:
        """برای اندیکاتورهایی که چند خروجی دارند"""
        return {
            'macd_line': f"macd_{self.fast_period}_{self.slow_period}",
            'macd_signal': f"macd_signal_{self.signal_period}",
            'macd_histogram': f"macd_histogram"
        }
    
    def get_config_params(self) -> Dict[str, Any]:
        return {
            'fast_period': self.fast_period,
            'slow_period': self.slow_period,
            'signal_period': self.signal_period
        }