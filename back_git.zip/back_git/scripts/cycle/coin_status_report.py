"""
coin_status_report_filtered.py
گزارش کامل وضعیت ارزها با فیلتر و سورتینگ پیشرفته
"""

import sqlite3
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from typing import Dict, List, Tuple, Optional, Any
import json
import logging
from pathlib import Path
from dataclasses import dataclass
import warnings
import re

# تنظیمات لاگ‌گیری
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

warnings.filterwarnings('ignore')


@dataclass
class CoinStatusReportConfig:
    """پیکربندی گزارش وضعیت ارزها"""
    database_path: str = "data/crypto_master.db"
    output_dir: str = "reports/coin_status"
    report_formats: List[str] = None
    timeframes: List[str] = None
    exclude_digit_start: bool = True  # حذف ارزهایی که با عدد شروع می‌شوند
    sort_by_missing_candles: bool = True  # سورت بر اساس تأخیر
    descending_order: bool = True  # بیشترین تأخیر اول
    
    def __post_init__(self):
        if self.report_formats is None:
            self.report_formats = ['json', 'html']
        if self.timeframes is None:
            self.timeframes = ['5m', '15m', '1h', '4h']
        
        Path(self.output_dir).mkdir(parents=True, exist_ok=True)


class CoinStatusReporter:
    """گزارش‌گر وضعیت ارزها با فیلتر و سورتینگ"""
    
    def __init__(self, db_path: Optional[str] = None, config: Optional[CoinStatusReportConfig] = None):
        self.config = config or CoinStatusReportConfig()
        if db_path:
            self.config.database_path = db_path
        
        if not Path(self.config.database_path).exists():
            raise FileNotFoundError(f"دیتابیس یافت نشد: {self.config.database_path}")
        
        self.conn = sqlite3.connect(self.config.database_path)
        self.conn.row_factory = sqlite3.Row
        
        logger.info(f"CoinStatusReporter با دیتابیس: {self.config.database_path}")
    
    def __enter__(self):
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
    
    def close(self):
        """بستن اتصال به دیتابیس"""
        if self.conn:
            self.conn.close()
            logger.info("اتصال به دیتابیس بسته شد")
    
    def execute_query(self, query: str, params: tuple = None) -> List[Dict]:
        """اجرای کوئری و بازگشت نتایج"""
        try:
            cursor = self.conn.cursor()
            if params:
                cursor.execute(query, params)
            else:
                cursor.execute(query)
            
            columns = [col[0] for col in cursor.description]
            return [dict(zip(columns, row)) for row in cursor.fetchall()]
        except Exception as e:
            logger.error(f"خطا در اجرای کوئری: {e}")
            raise
    
    def get_dataframe(self, query: str, params: tuple = None) -> pd.DataFrame:
        """دریافت داده به صورت DataFrame"""
        try:
            if params:
                df = pd.read_sql_query(query, self.conn, params=params)
            else:
                df = pd.read_sql_query(query, self.conn)
            return df
        except Exception as e:
            logger.error(f"خطا در دریافت DataFrame: {e}")
            raise
    
    def filter_digit_start_coins(self, df: pd.DataFrame) -> pd.DataFrame:
        """حذف ارزهایی که با عدد شروع می‌شوند"""
        if self.config.exclude_digit_start:
            # بررسی هر ردیف که با عدد شروع نشود
            mask = df['symbol'].apply(lambda x: not bool(re.match(r'^\d', str(x))))
            filtered_df = df[mask].copy()
            logger.info(f"حذف ارزهای با شروع عددی: {len(df) - len(filtered_df)} از {len(df)}")
            return filtered_df
        return df
    
    def sort_by_missing_candles(self, df: pd.DataFrame) -> pd.DataFrame:
        """سورت بر اساس ستون تأخیر"""
        if self.config.sort_by_missing_candles and 'missing_5m_candles' in df.columns:
            order = not self.config.descending_order  # معکوس کردن برای sort_values
            sorted_df = df.sort_values('missing_5m_candles', ascending=order, na_position='last')
            
            # اضافه کردن ستون rank
            sorted_df = sorted_df.reset_index(drop=True)
            sorted_df['delay_rank'] = sorted_df.index + 1
            
            logger.info(f"سورت بر اساس تأخیر انجام شد. بیشترین تأخیر: {sorted_df['missing_5m_candles'].max()}")
            return sorted_df
        return df
    
    def get_all_coins_data(self) -> pd.DataFrame:
        """دریافت تمام اطلاعات ارزها"""
        query = """
        SELECT 
            id as coin_id,
            symbol,
            base_asset,
            coin_name,
            coingecko_id,
            current_price,
            price_change_24h,
            price_change_percent_24h,
            high_24h,
            low_24h,
            volume_24h,
            market_cap,
            market_cap_rank,
            fully_diluted_valuation,
            circulating_supply,
            total_supply,
            max_supply,
            last_updated,
            created_at,
            is_active
        FROM crypto_coins
        WHERE is_active < 5
        ORDER BY symbol
        """
        
        df = self.get_dataframe(query)
        
        # اعمال فیلتر حذف ارزهای با شروع عددی
        df = self.filter_digit_start_coins(df)
        
        return df
    
    def get_timeframe_stats(self, timeframe: str) -> pd.DataFrame:
        """دریافت آمار یک تایم‌فریم خاص"""
        query = f"""
        SELECT 
            coin_id,
            COUNT(*) as candles_count,
            MAX(open_time) as last_candle_time,
            MIN(open_time) as first_candle_time,
            AVG(data_quality) as avg_data_quality,
            SUM(CASE WHEN rsi IS NOT NULL AND macd IS NOT NULL THEN 1 ELSE 0 END) as complete_indicators,
            SUM(CASE WHEN candle_pattern != 'NORMAL' THEN 1 ELSE 0 END) as special_patterns
        FROM crypto_klines
        WHERE timeframe = ?
        GROUP BY coin_id
        """
        
        df = self.get_dataframe(query, (timeframe,))
        if not df.empty:
            rename_dict = {
                'candles_count': f'candles_{timeframe}_count',
                'last_candle_time': f'last_{timeframe}_time',
                'first_candle_time': f'first_{timeframe}_time',
                'avg_data_quality': f'avg_data_quality_{timeframe}',
                'complete_indicators': f'complete_indicators_{timeframe}',
                'special_patterns': f'special_patterns_{timeframe}'
            }
            df = df.rename(columns=rename_dict)
        
        return df
    
    def calculate_missing_candles(self, last_candle_time: pd.Series, timeframe_minutes: int) -> pd.Series:
        """محاسبه تعداد کندل‌های مفقود"""
        if last_candle_time.empty:
            return pd.Series([], dtype=int)
        
        last_candle_dt = pd.to_datetime(last_candle_time, errors='coerce')
        current_time = pd.Timestamp.now()
        
        time_diff = (current_time - last_candle_dt).dt.total_seconds() / 60
        missing_candles = np.floor(time_diff / timeframe_minutes)
        missing_candles = missing_candles.fillna(9999).astype(int)
        
        return missing_candles
    
    def calculate_completeness_percent(self, candle_count: pd.Series, timeframe: str) -> pd.Series:
        """محاسبه درصد کامل بودن داده‌ها"""
        candles_per_day = {
            '5m': 288,   # 24 * 60 / 5
            '15m': 96,   # 24 * 60 / 15
            '1h': 24,    # 24
            '4h': 6      # 24 / 4
        }
        
        if timeframe not in candles_per_day:
            return pd.Series([0] * len(candle_count))
        
        theoretical_candles = candles_per_day[timeframe] * 30
        completeness = (candle_count / theoretical_candles) * 100
        completeness = completeness.clip(0, 100)
        completeness = completeness.round(2)
        
        return completeness
    
    def get_trading_signals_stats(self) -> pd.DataFrame:
        """دریافت آمار سیگنال‌های معاملاتی"""
        query = """
        SELECT 
            coin_id,
            COUNT(*) as total_signals,
            SUM(CASE WHEN status = 'ACTIVE' THEN 1 ELSE 0 END) as active_signals,
            SUM(CASE WHEN status = 'CLOSED' THEN 1 ELSE 0 END) as closed_signals,
            MAX(signal_time) as last_signal_time,
            AVG(confidence_score) as avg_confidence_score
        FROM trading_signals
        GROUP BY coin_id
        """
        
        return self.get_dataframe(query)
    
    def get_technical_indicators_stats(self) -> pd.DataFrame:
        """دریافت آمار اندیکاتورهای تکنیکال"""
        query = """
        SELECT 
            coin_id,
            COUNT(*) as total_indicators,
            MAX(timestamp) as last_indicator_time,
            AVG(signal_score) as avg_signal_score
        FROM technical_indicators
        GROUP BY coin_id
        """
        
        return self.get_dataframe(query)
    
    def generate_complete_report(self) -> Dict[str, Any]:
        """
        تولید گزارش کامل وضعیت تمام ارزها
        
        Returns:
            دیکشنری حاوی گزارش کامل
        """
        logger.info("شروع تولید گزارش کامل وضعیت ارزها...")
        start_time = datetime.now()
        
        # 1. دریافت اطلاعات پایه ارزها
        logger.info("دریافت اطلاعات پایه ارزها...")
        coins_df = self.get_all_coins_data()
        
        if coins_df.empty:
            logger.warning("هیچ ارزی با is_active < 5 یافت نشد!")
            return {"error": "No coins found with is_active < 5"}
        
        # 2. دریافت آمار تایم‌فریم‌ها
        timeframe_stats = {}
        for tf in self.config.timeframes:
            logger.info(f"دریافت آمار تایم‌فریم {tf}...")
            stats_df = self.get_timeframe_stats(tf)
            timeframe_stats[tf] = stats_df
        
        # 3. دریافت آمار سیگنال‌ها و اندیکاتورها
        logger.info("دریافت آمار سیگنال‌های معاملاتی...")
        signals_df = self.get_trading_signals_stats()
        
        logger.info("دریافت آمار اندیکاتورهای تکنیکال...")
        indicators_df = self.get_technical_indicators_stats()
        
        # 4. ترکیب تمام داده‌ها
        logger.info("ترکیب داده‌ها...")
        report_df = coins_df.copy()
        
        # افزودن آمار تایم‌فریم‌ها
        for tf in self.config.timeframes:
            tf_df = timeframe_stats[tf]
            if not tf_df.empty:
                report_df = pd.merge(report_df, tf_df, on='coin_id', how='left')
                
                col_name = f'last_{tf}_time'
                if col_name in report_df.columns:
                    minutes_map = {'5m': 5, '15m': 15, '1h': 60, '4h': 240}
                    missing_col = f'missing_{tf}_candles'
                    report_df[missing_col] = self.calculate_missing_candles(
                        report_df[col_name], 
                        minutes_map[tf]
                    )
                
                count_col = f'candles_{tf}_count'
                if count_col in report_df.columns:
                    complete_col = f'completeness_{tf}_percent'
                    report_df[complete_col] = self.calculate_completeness_percent(
                        report_df[count_col], 
                        tf
                    )
        
        # افزودن آمار سیگنال‌ها
        if not signals_df.empty:
            report_df = pd.merge(report_df, signals_df, on='coin_id', how='left')
        
        # افزودن آمار اندیکاتورها
        if not indicators_df.empty:
            report_df = pd.merge(report_df, indicators_df, on='coin_id', how='left')
        
        # 5. محاسبه ستون‌های محاسباتی
        logger.info("محاسبه ستون‌های محاسباتی...")
        report_df = self.calculate_overall_scores(report_df)
        report_df = self.calculate_status_fields(report_df)
        
        # 6. سورت بر اساس تأخیر
        logger.info("اعمال سورتینگ بر اساس تأخیر...")
        report_df = self.sort_by_missing_candles(report_df)
        
        # 7. آماده‌سازی نتیجه نهایی
        logger.info("آماده‌سازی نتیجه نهایی...")
        coins_data = []
        for _, row in report_df.iterrows():
            coin_dict = {}
            for col in report_df.columns:
                value = row[col]
                
                if isinstance(value, (np.integer, np.floating)):
                    value = float(value) if np.isnan(value) else (
                        int(value) if isinstance(value, np.integer) else float(value)
                    )
                elif isinstance(value, (pd.Timestamp, datetime)):
                    value = value.isoformat() if not pd.isna(value) else None
                elif pd.isna(value):
                    value = None
                
                coin_dict[col] = value
            
            coins_data.append(coin_dict)
        
        # محاسبه آمار کلی
        summary_stats = self.calculate_summary_statistics(report_df)
        
        # آمار فیلترها
        filter_stats = {
            "excluded_digit_start": self.config.exclude_digit_start,
            "sort_by_missing_candles": self.config.sort_by_missing_candles,
            "sort_order": "descending" if self.config.descending_order else "ascending",
            "total_after_filters": len(report_df)
        }
        
        # زمان تولید
        generation_time = (datetime.now() - start_time).total_seconds()
        
        # ساخت گزارش نهایی
        report = {
            "metadata": {
                "report_type": "complete_coin_status_filtered",
                "generated_at": datetime.now().isoformat(),
                "generation_time_seconds": round(generation_time, 2),
                "database_path": self.config.database_path,
                "total_coins": len(report_df),
                "timeframes_analyzed": self.config.timeframes,
                "filters_applied": filter_stats
            },
            "summary_statistics": summary_stats,
            "coins": coins_data,
            "report_config": {
                "timeframes": self.config.timeframes,
                "output_formats": self.config.report_formats,
                "filters": {
                    "exclude_digit_start": self.config.exclude_digit_start,
                    "sort_by_missing_candles": self.config.sort_by_missing_candles,
                    "descending_order": self.config.descending_order
                }
            }
        }
        
        logger.info(f"گزارش کامل تولید شد. تعداد ارزها: {len(report_df)}")
        
        return report
    
    def calculate_overall_scores(self, df: pd.DataFrame) -> pd.DataFrame:
        """محاسبه امتیاز کلی برای هر ارز"""
        
        def calculate_score(row):
            score_components = []
            weights = []
            
            if 'missing_5m_candles' in row and not pd.isna(row['missing_5m_candles']):
                missing = row['missing_5m_candles']
                if missing == 0:
                    score_components.append(100)
                elif missing <= 3:
                    score_components.append(85)
                elif missing <= 12:
                    score_components.append(70)
                elif missing <= 72:
                    score_components.append(40)
                else:
                    score_components.append(20)
                weights.append(0.35)
            
            if 'avg_data_quality_5m' in row and not pd.isna(row['avg_data_quality_5m']):
                quality = row['avg_data_quality_5m']
                score_components.append(quality)
                weights.append(0.25)
            
            if 'completeness_5m_percent' in row and not pd.isna(row['completeness_5m_percent']):
                completeness = min(row['completeness_5m_percent'], 100)
                score_components.append(completeness)
                weights.append(0.20)
            
            if 'candles_5m_count' in row and not pd.isna(row['candles_5m_count']):
                count = row['candles_5m_count']
                if count >= 1000:
                    score_components.append(100)
                elif count >= 500:
                    score_components.append(80)
                elif count >= 100:
                    score_components.append(60)
                elif count >= 50:
                    score_components.append(40)
                else:
                    score_components.append(20)
                weights.append(0.20)
            
            if score_components and weights:
                total_weight = sum(weights)
                if total_weight > 0:
                    weighted_sum = sum(s * w for s, w in zip(score_components, weights))
                    return round(weighted_sum / total_weight, 2)
            
            return 0.0
        
        df['overall_score'] = df.apply(calculate_score, axis=1)
        return df
    
    def calculate_status_fields(self, df: pd.DataFrame) -> pd.DataFrame:
        """محاسبه وضعیت و توصیه‌ها"""
        
        def get_status(row):
            if pd.isna(row.get('candles_5m_count')) or row.get('candles_5m_count', 0) == 0:
                return 'NO_DATA'
            
            missing = row.get('missing_5m_candles', 9999)
            score = row.get('overall_score', 0)
            
            if missing == 0 and score >= 85:
                return 'EXCELLENT'
            elif missing <= 6 and score >= 70:
                return 'GOOD'
            elif missing <= 24 and score >= 50:
                return 'WARNING'
            else:
                return 'CRITICAL'
        
        def get_status_summary(row):
            status = row.get('status', 'NO_DATA')
            missing = row.get('missing_5m_candles', 9999)
            
            if status == 'NO_DATA':
                return 'بدون داده'
            elif status == 'EXCELLENT':
                return 'به‌روز و کامل'
            elif status == 'GOOD':
                return 'وضعیت خوب'
            elif status == 'WARNING':
                return f'تأخیر {missing} کندلی'
            else:
                return f'تأخیر شدید ({missing} کندل)'
        
        def get_recommendation(row):
            status = row.get('status', 'NO_DATA')
            missing = row.get('missing_5m_candles', 9999)
            
            if status == 'NO_DATA':
                return 'نیاز به جمع‌آوری اولیه داده'
            elif status == 'EXCELLENT':
                return 'وضعیت مطلوب - ادامه نظارت'
            elif status == 'GOOD':
                return 'نیاز به بررسی دوره‌ای'
            elif status == 'WARNING':
                return f'نیاز به جمع‌آوری {missing} کندل'
            else:
                return 'نیاز به اقدام فوری'
        
        df['status'] = df.apply(get_status, axis=1)
        df['status_summary'] = df.apply(get_status_summary, axis=1)
        df['recommendation'] = df.apply(get_recommendation, axis=1)
        
        return df
    
    def calculate_summary_statistics(self, df: pd.DataFrame) -> Dict[str, Any]:
        """محاسبه آمار کلی گزارش"""
        
        total_coins = len(df)
        active_coins = df['is_active'].sum() if 'is_active' in df.columns else 0
        
        status_counts = df['status'].value_counts().to_dict() if 'status' in df.columns else {}
        
        coins_with_5m_data = df['candles_5m_count'].notna().sum() if 'candles_5m_count' in df.columns else 0
        coins_without_data = total_coins - coins_with_5m_data
        
        avg_missing_candles = df['missing_5m_candles'].mean() if 'missing_5m_candles' in df.columns else 0
        avg_score = df['overall_score'].mean() if 'overall_score' in df.columns else 0
        avg_quality = df['avg_data_quality_5m'].mean() if 'avg_data_quality_5m' in df.columns else 0
        
        total_5m_candles = df['candles_5m_count'].sum() if 'candles_5m_count' in df.columns else 0
        
        # آمار تأخیر
        if 'missing_5m_candles' in df.columns:
            delay_stats = {
                "max_delay": int(df['missing_5m_candles'].max()),
                "min_delay": int(df['missing_5m_candles'].min()),
                "median_delay": float(df['missing_5m_candles'].median()),
                "coins_with_no_delay": int((df['missing_5m_candles'] == 0).sum()),
                "coins_with_high_delay": int((df['missing_5m_candles'] > 24).sum())
            }
        else:
            delay_stats = {}
        
        return {
            "total_coins": int(total_coins),
            "active_coins": int(active_coins),
            "coins_with_5m_data": int(coins_with_5m_data),
            "coins_without_data": int(coins_without_data),
            "status_distribution": status_counts,
            "average_missing_5m_candles": round(float(avg_missing_candles), 2),
            "average_overall_score": round(float(avg_score), 2),
            "average_data_quality_5m": round(float(avg_quality), 2),
            "total_5m_candles": int(total_5m_candles),
            "percentage_with_data": round((coins_with_5m_data / total_coins * 100), 2) if total_coins > 0 else 0,
            "delay_statistics": delay_stats
        }
    
    def save_report(self, report: Dict[str, Any]):
        """ذخیره گزارش در فایل‌های مختلف"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        base_filename = f"coin_status_report_filtered_{timestamp}"
        
        saved_files = []
        
        for fmt in self.config.report_formats:
            filename = Path(self.config.output_dir) / f"{base_filename}.{fmt}"
            
            if fmt == 'json':
                with open(filename, 'w', encoding='utf-8') as f:
                    json.dump(report, f, ensure_ascii=False, indent=2)
                saved_files.append(str(filename))
                logger.info(f"گزارش JSON ذخیره شد: {filename}")
            
            elif fmt == 'html':
                html_content = self.generate_html_report(report)
                with open(filename, 'w', encoding='utf-8') as f:
                    f.write(html_content)
                saved_files.append(str(filename))
                logger.info(f"گزارش HTML ذخیره شد: {filename}")
            
            elif fmt == 'csv':
                if 'coins' in report:
                    coins_df = pd.DataFrame(report['coins'])
                    csv_file = Path(self.config.output_dir) / f"{base_filename}_data.csv"
                    coins_df.to_csv(csv_file, index=False, encoding='utf-8')
                    saved_files.append(str(csv_file))
                    logger.info(f"داده‌های CSV ذخیره شد: {csv_file}")
        
        return saved_files
    
    def generate_html_report(self, report: Dict[str, Any]) -> str:
        """تولید گزارش HTML"""
        
        summary = report.get('summary_statistics', {})
        total_coins = summary.get('total_coins', 0)
        avg_score = summary.get('average_overall_score', 0)
        status_dist = summary.get('status_distribution', {})
        delay_stats = summary.get('delay_statistics', {})
        
        # اطلاعات فیلترها
        filters = report.get('metadata', {}).get('filters_applied', {})
        
        html = f"""
        <!DOCTYPE html>
        <html dir="rtl" lang="fa">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>گزارش وضعیت ارزها (فیلتر شده) - {datetime.now().strftime('%Y/%m/%d %H:%M')}</title>
            <style>
                * {{ box-sizing: border-box; margin: 0; padding: 0; }}
                body {{ 
                    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                    line-height: 1.6;
                    color: #333;
                    background-color: #f5f5f5;
                    padding: 20px;
                }}
                .container {{ 
                    max-width: 1400px;
                    margin: 0 auto;
                    background: white;
                    border-radius: 10px;
                    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
                    padding: 30px;
                }}
                .header {{ 
                    text-align: center;
                    margin-bottom: 30px;
                    padding-bottom: 20px;
                    border-bottom: 2px solid #eee;
                }}
                .header h1 {{ 
                    color: #2c3e50;
                    margin-bottom: 10px;
                }}
                .filters-info {{ 
                    background: #e8f4f8;
                    padding: 15px;
                    border-radius: 5px;
                    margin: 15px 0;
                    border-right: 4px solid #2196F3;
                }}
                .metadata {{ 
                    background: #f8f9fa;
                    padding: 15px;
                    border-radius: 5px;
                    margin-bottom: 20px;
                    font-size: 0.9em;
                    color: #666;
                }}
                .summary-grid {{ 
                    display: grid;
                    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
                    gap: 20px;
                    margin-bottom: 30px;
                }}
                .summary-card {{ 
                    background: #fff;
                    border: 1px solid #e0e0e0;
                    border-radius: 8px;
                    padding: 20px;
                    text-align: center;
                    transition: transform 0.3s;
                }}
                .summary-card:hover {{ 
                    transform: translateY(-5px);
                    box-shadow: 0 5px 15px rgba(0,0,0,0.1);
                }}
                .summary-card h3 {{ 
                    color: #666;
                    font-size: 0.9em;
                    margin-bottom: 10px;
                }}
                .summary-card .value {{ 
                    font-size: 2em;
                    font-weight: bold;
                    color: #2c3e50;
                }}
                .delay-card {{ 
                    background: #fff8e1;
                    border: 1px solid #ffd54f;
                }}
                .delay-card .value {{ 
                    color: #ff8f00;
                }}
                .status-badge {{ 
                    display: inline-block;
                    padding: 4px 12px;
                    border-radius: 20px;
                    font-size: 0.8em;
                    font-weight: bold;
                    margin: 2px;
                }}
                .status-excellent {{ background: #d4edda; color: #155724; }}
                .status-good {{ background: #d1ecf1; color: #0c5460; }}
                .status-warning {{ background: #fff3cd; color: #856404; }}
                .status-critical {{ background: #f8d7da; color: #721c24; }}
                .status-nodata {{ background: #e2e3e5; color: #383d41; }}
                table {{ 
                    width: 100%;
                    border-collapse: collapse;
                    margin-top: 20px;
                }}
                th, td {{ 
                    padding: 12px 15px;
                    text-align: right;
                    border-bottom: 1px solid #ddd;
                }}
                th {{ 
                    background-color: #f8f9fa;
                    font-weight: bold;
                    color: #495057;
                }}
                .delay-column {{ 
                    background-color: #fff8e1;
                    font-weight: bold;
                }}
                tr:hover {{ background-color: #f5f5f5; }}
                .recommendation {{ 
                    background: #e8f4fd;
                    border-left: 4px solid #2196F3;
                    padding: 10px 15px;
                    margin: 5px 0;
                    font-size: 0.9em;
                }}
                @media (max-width: 768px) {{
                    .summary-grid {{ grid-template-columns: 1fr; }}
                    table {{ font-size: 0.9em; }}
                    th, td {{ padding: 8px 10px; }}
                }}
            </style>
        </head>
        <body>
            <div class="container">
                <div class="header">
                    <h1>📊 گزارش کامل وضعیت ارزها (فیلتر شده)</h1>
                    <p>تولید شده در {datetime.now().strftime('%Y/%m/%d ساعت %H:%M')}</p>
                </div>
                
                <div class="filters-info">
                    <h3>🔧 فیلترهای اعمال شده:</h3>
                    <p>
                        • حذف ارزهای با شروع عددی: {'✅' if filters.get('excluded_digit_start') else '❌'}<br>
                        • سورت بر اساس تأخیر: {'✅' if filters.get('sort_by_missing_candles') else '❌'}<br>
                        • ترتیب سورت: {'نزولی (بیشترین تأخیر اول)' if filters.get('sort_order') == 'descending' else 'صعودی'}
                    </p>
                </div>
                
                <div class="metadata">
                    <p><strong>اطلاعات گزارش:</strong> 
                    تعداد کل ارزها: {total_coins} | 
                    میانگین امتیاز: {avg_score} | 
                    زمان تولید: {report['metadata']['generation_time_seconds']} ثانیه</p>
                </div>
                
                <div class="summary-grid">
                    <div class="summary-card">
                        <h3>تعداد کل ارزها</h3>
                        <div class="value">{summary.get('total_coins', 0)}</div>
                    </div>
                    <div class="summary-card">
                        <h3>میانگین امتیاز</h3>
                        <div class="value">{summary.get('average_overall_score', 0)}</div>
                    </div>
                    <div class="summary-card delay-card">
                        <h3>میانگین تأخیر (کندل)</h3>
                        <div class="value">{summary.get('average_missing_5m_candles', 0)}</div>
                    </div>
                    <div class="summary-card delay-card">
                        <h3>بیشترین تأخیر</h3>
                        <div class="value">{delay_stats.get('max_delay', 0)}</div>
                    </div>
                    <div class="summary-card">
                        <h3>ارزهای با داده</h3>
                        <div class="value">{summary.get('coins_with_5m_data', 0)}</div>
                    </div>
                    <div class="summary-card">
                        <h3>کل کندل‌های 5 دقیقه</h3>
                        <div class="value">{summary.get('total_5m_candles', 0):,}</div>
                    </div>
                </div>
                
                <h2>📈 توزیع وضعیت ارزها</h2>
                <div style="margin: 20px 0;">
        """
        
        status_colors = {
            'EXCELLENT': 'status-excellent',
            'GOOD': 'status-good',
            'WARNING': 'status-warning',
            'CRITICAL': 'status-critical',
            'NO_DATA': 'status-nodata'
        }
        
        for status, count in status_dist.items():
            color_class = status_colors.get(status, 'status-nodata')
            status_fa = {
                'EXCELLENT': 'عالی',
                'GOOD': 'خوب',
                'WARNING': 'هشدار',
                'CRITICAL': 'بحرانی',
                'NO_DATA': 'بدون داده'
            }.get(status, status)
            
            html += f"""
                    <span class="status-badge {color_class}">
                        {status_fa}: {count}
                    </span>
            """
        
        html += """
                </div>
                
                <h2>🏆 ارزهای با بیشترین تأخیر (۱۰ مورد اول)</h2>
                <table>
                    <thead>
                        <tr>
                            <th>رتبه</th>
                            <th>نماد</th>
                            <th>قیمت</th>
                            <th>کندل 5 دقیقه</th>
                            <th class="delay-column">تأخیر (کندل)</th>
                            <th>امتیاز</th>
                            <th>وضعیت</th>
                            <th>توصیه</th>
                        </tr>
                    </thead>
                    <tbody>
        """
        
        coins = report.get('coins', [])
        for coin in coins[:10]:
            symbol = coin.get('symbol', '')
            price = coin.get('current_price', 0)
            candles = coin.get('candles_5m_count', 0)
            missing = coin.get('missing_5m_candles', '')
            score = coin.get('overall_score', 0)
            status = coin.get('status', '')
            recommendation = coin.get('recommendation', '')
            rank = coin.get('delay_rank', '')
            
            status_class = status_colors.get(status, '')
            status_fa = {
                'EXCELLENT': 'عالی',
                'GOOD': 'خوب',
                'WARNING': 'هشدار',
                'CRITICAL': 'بحرانی',
                'NO_DATA': 'بدون داده'
            }.get(status, status)
            
            html += f"""
                        <tr>
                            <td><strong>{rank}</strong></td>
                            <td><strong>{symbol}</strong></td>
                            <td>{price if price else '-'}</td>
                            <td>{candles if candles else 0}</td>
                            <td class="delay-column"><strong>{missing if missing != '' else '-'}</strong></td>
                            <td>{score:.1f}</td>
                            <td><span class="status-badge {status_class}">{status_fa}</span></td>
                            <td                            <td><div class="recommendation">{recommendation}</div></td>
                        </tr>
            """
        
        html += """
                    </tbody>
                </table>
                
                <h2>📋 جزئیات فنی</h2>
                <div style="margin: 20px 0; background: #f8f9fa; padding: 15px; border-radius: 5px;">
        """
        
        # نمایش آمار تأخیر
        if delay_stats:
            html += """
                    <h3>آمار تأخیرها:</h3>
                    <ul>
            """
            
            if 'coins_with_no_delay' in delay_stats:
                html += f"<li>ارزهای بدون تأخیر: {delay_stats['coins_with_no_delay']} مورد</li>"
            if 'coins_with_high_delay' in delay_stats:
                html += f"<li>ارزهای با تأخیر بالا (بیش از 24 کندل): {delay_stats['coins_with_high_delay']} مورد</li>"
            if 'median_delay' in delay_stats:
                html += f"<li>میانه تأخیر: {delay_stats['median_delay']:.1f} کندل</li>"
            
            html += "</ul>"
        
        html += f"""
                    <h3>تنظیمات گزارش:</h3>
                    <ul>
                        <li>تایم‌فریم‌های تحلیل شده: {', '.join(report['report_config']['timeframes'])}</li>
                        <li>دیتابیس: {report['metadata']['database_path']}</li>
                        <li>تعداد ارزهای فیلتر شده: {filters.get('total_after_filters', 0)}</li>
                    </ul>
                </div>
                
                <div style="margin-top: 40px; padding-top: 20px; border-top: 1px solid #eee; text-align: center; color: #666;">
                    <p>گزارش تولید شده توسط سیستم مانیتورینگ ارزهای دیجیتال</p>
                    <p>تاریخ تولید: {datetime.now().strftime('%Y/%m/%d')}</p>
                    <p style="font-size: 0.9em;">این گزارش به‌صورت خودکار تولید شده است.</p>
                </div>
            </div>
            
            <script>
                // اضافه کردن قابلیت‌های تعاملی ساده
                document.addEventListener('DOMContentLoaded', function() {{
                    // رنگ‌آمیزی ردیف‌های جدول بر اساس وضعیت
                    const rows = document.querySelectorAll('tbody tr');
                    rows.forEach(row => {{
                        const statusCell = row.querySelector('.status-badge');
                        if (statusCell) {{
                            if (statusCell.classList.contains('status-critical')) {{
                                row.style.backgroundColor = '#fff5f5';
                            }} else if (statusCell.classList.contains('status-warning')) {{
                                row.style.backgroundColor = '#fff9db';
                            }}
                        }}
                        
                        // اضافه کردن hover effect
                        row.addEventListener('mouseenter', function() {{
                            this.style.transform = 'scale(1.01)';
                            this.style.transition = 'transform 0.2s';
                        }});
                        
                        row.addEventListener('mouseleave', function() {{
                            this.style.transform = 'scale(1)';
                        }});
                    }});
                    
                    // نمایش اطلاعات بیشتر برای تأخیر بالا
                    const delayCells = document.querySelectorAll('.delay-column');
                    delayCells.forEach(cell => {{
                        const delay = parseInt(cell.textContent);
                        if (delay > 72) {{
                            cell.style.backgroundColor = '#ffebee';
                            cell.style.color = '#c62828';
                            cell.title = 'تأخیر شدید - نیاز به اقدام فوری';
                        }} else if (delay > 24) {{
                            cell.style.backgroundColor = '#fff3e0';
                            cell.style.color = '#ef6c00';
                            cell.title = 'تأخیر بالا - نیاز به بررسی';
                        }}
                    }});
                    
                    // اضافه کردن قابلیت مرتب‌سازی
                    const headers = document.querySelectorAll('th');
                    headers.forEach((header, index) => {{
                        if (index > 0) {{ // به جز ستون رتبه
                            header.style.cursor = 'pointer';
                            header.addEventListener('click', () => {{
                                alert('قابلیت مرتب‌سازی در نسخه فعلی فعال نیست. در نسخه‌های بعدی اضافه خواهد شد.');
                            }});
                        }}
                    }});
                }});
            </script>
        </body>
        </html>
        """
        
        return html
    
    def run_full_report(self) -> Dict[str, Any]:
        """اجرای کامل فرآیند گزارش‌گیری"""
        try:
            logger.info("شروع فرآیند گزارش‌گیری کامل...")
            
            # تولید گزارش
            report = self.generate_complete_report()
            
            # ذخیره گزارش
            saved_files = self.save_report(report)
            
            # اضافه کردن اطلاعات فایل‌های ذخیره شده به گزارش
            report['metadata']['saved_files'] = saved_files
            report['metadata']['total_saved_files'] = len(saved_files)
            
            logger.info(f"گزارش‌گیری با موفقیت تکمیل شد. {len(saved_files)} فایل ذخیره شد.")
            
            return report
            
        except Exception as e:
            logger.error(f"خطا در فرآیند گزارش‌گیری: {e}", exc_info=True)
            raise


# توابع کمکی برای استفاده خارجی
def generate_coin_status_report(
    db_path: str = "data/crypto_master.db",
    exclude_digit_start: bool = True,
    sort_by_missing_candles: bool = True,
    descending_order: bool = True,
    output_formats: List[str] = None,
    timeframes: List[str] = None
) -> Dict[str, Any]:
    """
    تابع اصلی برای تولید گزارش وضعیت ارزها
    
    Args:
        db_path: مسیر دیتابیس
        exclude_digit_start: حذف ارزهای با شروع عددی
        sort_by_missing_candles: سورت بر اساس تأخیر
        descending_order: ترتیب نزولی (بیشترین تأخیر اول)
        output_formats: فرمت‌های خروجی
        timeframes: تایم‌فریم‌های تحلیل
    
    Returns:
        گزارش تولید شده
    """
    config = CoinStatusReportConfig(
        database_path=db_path,
        exclude_digit_start=exclude_digit_start,
        sort_by_missing_candles=sort_by_missing_candles,
        descending_order=descending_order
    )
    
    if output_formats:
        config.report_formats = output_formats
    
    if timeframes:
        config.timeframes = timeframes
    
    with CoinStatusReporter(config=config) as reporter:
        report = reporter.run_full_report()
    
    return report


def main():
    """تابع اصلی اجرای مستقیم اسکریپت"""
    import argparse
    
    parser = argparse.ArgumentParser(description='تولید گزارش وضعیت ارزها با فیلتر')
    parser.add_argument('--db', default='data/crypto_master.db', help='مسیر دیتابیس')
    parser.add_argument('--include-digit-start', action='store_true', help='شامل کردن ارزهای با شروع عددی')
    parser.add_argument('--no-sort', action='store_true', help='عدم سورت بر اساس تأخیر')
    parser.add_argument('--ascending', action='store_true', help='ترتیب صعودی (کمترین تأخیر اول)')
    parser.add_argument('--output', default='json,html', help='فرمت‌های خروجی (جدا با کاما)')
    parser.add_argument('--timeframes', default='5m,15m,1h,4h', help='تایم‌فریم‌ها (جدا با کاما)')
    
    args = parser.parse_args()
    
    output_formats = args.output.split(',')
    timeframes = args.timeframes.split(',')
    
    try:
        logger.info("شروع تولید گزارش...")
        
        report = generate_coin_status_report(
            db_path=args.db,
            exclude_digit_start=not args.include_digit_start,
            sort_by_missing_candles=not args.no_sort,
            descending_order=not args.ascending,
            output_formats=output_formats,
            timeframes=timeframes
        )
        
        print("\n" + "="*60)
        print("گزارش با موفقیت تولید شد!")
        print("="*60)
        
        summary = report['metadata']
        print(f"زمان تولید: {summary['generation_time_seconds']} ثانیه")
        print(f"تعداد ارزها: {summary['total_coins']}")
        
        if 'saved_files' in summary:
            print(f"\nفایل‌های ذخیره شده:")
            for file in summary['saved_files']:
                print(f"  📁 {file}")
        
        print(f"\nآمار وضعیت‌ها:")
        for status, count in report['summary_statistics'].get('status_distribution', {}).items():
            status_fa = {
                'EXCELLENT': 'عالی',
                'GOOD': 'خوب',
                'WARNING': 'هشدار',
                'CRITICAL': 'بحرانی',
                'NO_DATA': 'بدون داده'
            }.get(status, status)
            print(f"  {status_fa}: {count}")
        
        print("\n" + "="*60)
        
    except Exception as e:
        logger.error(f"خطا در اجرای اصلی: {e}", exc_info=True)
        print(f"خطا: {e}")
        return 1
    
    return 0


if __name__ == "__main__":
    exit(main())