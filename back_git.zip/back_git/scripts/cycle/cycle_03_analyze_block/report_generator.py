﻿# فایل: scripts/cycle/cycle_03_analyze_block/report_generator.py

import json
import os
import logging
from datetime import datetime

logger = logging.getLogger(__name__)

class ReportGenerator:
    """تولیدکننده گزارش اجرای تکه ۳"""
    
    def __init__(self):
        logger.info("ReportGenerator راه‌اندازی شد")
        
        # ایجاد پوشه گزارش‌ها اگر وجود ندارد
        self.reports_dir = "reports/cycle_03"
        os.makedirs(self.reports_dir, exist_ok=True)
    
    def save_report(self, report_data, block_id):
        """ذخیره گزارش در فایل JSON - این متد وجود نداشت!"""
        try:
            # نام فایل گزارش
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"block_{block_id:03d}_{timestamp}.json"
            filepath = os.path.join(self.reports_dir, filename)
            
            # ذخیره گزارش
            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump(report_data, f, indent=2, ensure_ascii=False)
            
            logger.info(f"✅ گزارش بلوک {block_id} ذخیره شد: {filename}")
            return filepath
            
        except Exception as e:
            logger.error(f"❌ خطا در ذخیره گزارش بلوک {block_id}: {e}")
            return None
    
    def generate_summary_report(self, block_reports):
        """تولید گزارش خلاصه از چندین بلوک"""
        try:
            summary = {
                'generated_at': datetime.now().isoformat(),
                'total_blocks': len(block_reports),
                'blocks': []
            }
            
            total_coins = 0
            total_candles = 0
            total_processed = 0
            
            for report in block_reports:
                if report and 'summary' in report:
                    block_summary = report['summary']
                    block_id = report.get('block_id', 0)
                    
                    summary['blocks'].append({
                        'block_id': block_id,
                        'coins_completed': block_summary.get('coins_completed', 0),
                        'coins_failed': block_summary.get('coins_failed', 0),
                        'total_candles': block_summary.get('total_candles', 0),
                        'processed_candles': block_summary.get('processed_candles', 0),
                        'success_rate': block_summary.get('success_rate', 0),
                        'duration_seconds': report.get('duration_seconds', 0)
                    })
                    
                    total_coins += block_summary.get('coins_completed', 0)
                    total_candles += block_summary.get('total_candles', 0)
                    total_processed += block_summary.get('processed_candles', 0)
            
            # محاسبه آمار کلی
            summary['overall'] = {
                'total_coins_processed': total_coins,
                'total_candles': total_candles,
                'total_processed_candles': total_processed,
                'overall_success_rate': (total_processed / total_candles * 100) if total_candles > 0 else 0,
                'average_duration_per_block': sum(b.get('duration_seconds', 0) for b in summary['blocks']) / len(summary['blocks']) if summary['blocks'] else 0
            }
            
            # ذخیره گزارش خلاصه
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            summary_file = os.path.join(self.reports_dir, f"summary_{timestamp}.json")
            
            with open(summary_file, 'w', encoding='utf-8') as f:
                json.dump(summary, f, indent=2, ensure_ascii=False)
            
            logger.info(f"✅ گزارش خلاصه ذخیره شد: {summary_file}")
            return summary_file
            
        except Exception as e:
            logger.error(f"❌ خطا در تولید گزارش خلاصه: {e}")
            return None
    
    def print_console_report(self, report_data):
        """چاپ گزارش در کنسول"""
        try:
            print("\n" + "=" * 60)
            print("📊 گزارش تکه ۳ - تحلیل کندل‌ها")
            print("=" * 60)
            
            if 'summary' in report_data:
                summary = report_data['summary']
                
                print(f"\n📦 بلوک: {report_data.get('block_id', 'N/A')}")
                print(f"⏱️  زمان اجرا: {report_data.get('duration_seconds', 0):.2f} ثانیه")
                
                print(f"\n📈 آمار کلی:")
                print(f"   • ارزهای پردازش شده: {summary.get('total_coins', 0)}")
                print(f"   • ارزهای موفق: {summary.get('coins_completed', 0)}")
                print(f"   • ارزهای ناموفق: {summary.get('coins_failed', 0)}")
                print(f"   • کل کندل‌ها: {summary.get('total_candles', 0):,}")
                print(f"   • کندل‌های پردازش شده: {summary.get('processed_candles', 0):,}")
                print(f"   • نرخ موفقیت: {summary.get('success_rate', 0):.1f}%")
            
            # نمایش ۵ ارز اول
            if 'coin_results' in report_data and report_data['coin_results']:
                print(f"\n🎯 ۵ ارز اول:")
                for i, coin in enumerate(report_data['coin_results'][:5], 1):
                    symbol = coin.get('symbol', f'Coin_{i}')
                    status = coin.get('status', 'UNKNOWN')
                    processed = coin.get('processed_candles', 0)
                    total = coin.get('total_candles', 0)
                    rate = coin.get('success_rate', 0)
                    
                    status_icon = '✅' if status == 'COMPLETED' else '❌'
                    print(f"   {status_icon} {symbol}: {processed}/{total} ({rate:.1f}%)")
                
                if len(report_data['coin_results']) > 5:
                    print(f"   ... و {len(report_data['coin_results']) - 5} ارز دیگر")
            
            print("\n" + "=" * 60)
            
        except Exception as e:
            logger.error(f"❌ خطا در چاپ گزارش کنسولی: {e}")
            print(f"❌ خطا در تولید گزارش: {e}")