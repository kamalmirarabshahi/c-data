﻿# simple_test.py - تست ساده تکه ۳
import sys
import os
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger('cycle_03_simple')

print("🚀 تکه ۳ ساده - تحلیل بلوک ۴")
print("=" * 60)

# import ماولها
try:
    current_dir = os.path.dirname(os.path.abspath(__file__))
    sys.path.insert(0, current_dir)
    
    import indicator_calculator
    import validator
    import candle_processor
    import database_updater
    import report_generator
    
    # ایجاد instances
    calc = indicator_calculator.IndicatorCalculator()
    valid = validator.validator
    candle_proc = candle_processor.CandleProcessor()
    db_updater = database_updater.DatabaseUpdater()
    report_gen = report_generator.ReportGenerator()
    
    print(f"✅ ۵ ماول لود شدند")
    
    # تست دریافت داده واقعی
    print("\n🧪 تست دریافت داده واقعی...")
    
    test_symbols = ["AAVEUSDT", "CUSDT", "BNTUSDT"]
    
    for symbol in test_symbols:
        print(f"\n📊 {symbol}:")
        
        # دریافت کندلها
        candles = candle_proc.get_candles_for_coin(symbol, limit=10)
        
        if candles:
            print(f"   ✅ {len(candles)} کندل دریافت شد")
            
            # تحلیل یک کندل
            if len(candles) > 25:
                current = candles[-1]
                previous = candles[-26:-1]
                
                indicators = calc.calculate_all_indicators(current, previous)
                print(f"   📈 {len(indicators)} اندیکاتور محاسبه شد")
                
                # اعتبارسنجی
                errors = valid.validate_indicators(indicators)
                print(f"   ✅ اعتبارسنجی: {len(errors)} خطا")
                
                # ذخیره
                success = db_updater.update_candle_indicators(current['id'], indicators)
                print(f"   💾 ذخیره: {'موفق' if success else 'ناموفق'}")
            else:
                print(f"   ⚠️  داده کافی نیست (نیاز: ۲۶ داریم: {len(candles)})")
        else:
            print(f"   ❌ هیچ کندلی دریافت نشد")
    
    print("\n" + "=" * 60)
    print("🎯 تکه ۳ با دادههای واقعی کار میکند!")
    
except Exception as e:
    print(f"\n❌ خطا: {type(e).__name__}: {e}")
    import traceback
    traceback.print_exc()
