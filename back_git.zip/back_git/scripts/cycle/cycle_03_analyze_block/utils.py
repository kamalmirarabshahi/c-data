﻿# utils.py ساده
import logging
logger = logging.getLogger('cycle_03_utils')