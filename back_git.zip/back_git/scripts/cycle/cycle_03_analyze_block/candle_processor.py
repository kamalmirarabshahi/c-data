﻿"""
🕯️ پردازشگر کندل‌ها - دریافت و آماده‌سازی کندل‌های هر ارز
"""

import sqlite3
import logging
from typing import List, Dict, Any

logger = logging.getLogger(__name__)

class CandleProcessor:
    """پردازشگر کندل‌ها - دریافت کندل‌های هر ارز از بانک"""
    
    def __init__(self):
        logger.info("CandleProcessor آماده")
        self.db_path = "data/crypto_master.db"
    
    def get_candles_for_coin(self, coin_symbol: str, limit: int = 200) -> List[Dict[str, Any]]:
        """
        دریافت کندل‌های یک ارز از دیتابیس
        مهم: از JOIN با crypto_coins برای دریافت coin_symbol استفاده می‌کند
        """
        try:
            # اتصال به دیتابیس
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            # کوئری با JOIN برای دریافت coin_symbol
            query = """
                SELECT 
                    k.id,
                    k.coin_id,
                    k.timeframe,
                    k.open_time,
                    k.close_time,
                    k.open_price,
                    k.high_price,
                    k.low_price,
                    k.close_price,
                    k.volume,
                    k.quote_volume,
                    c.symbol as coin_symbol  -- گرفتن symbol از جدول crypto_coins
                FROM crypto_klines k
                JOIN crypto_coins c ON k.coin_id = c.id
                WHERE c.symbol = ? 
                AND k.timeframe = '5m'
                ORDER BY k.open_time ASC
                LIMIT ?
            """
            
            cursor.execute(query, (coin_symbol, limit))
            rows = cursor.fetchall()
            conn.close()
            
            # تبدیل به لیست دیکشنری
            candles = []
            for row in rows:
                candles.append(dict(row))
            
            logger.info(f"📊 {coin_symbol}: {len(candles)} کندل دریافت شد")
            return candles
            
        except sqlite3.Error as e:
            logger.error(f"❌ خطای SQLite در دریافت کندل‌های {coin_symbol}: {e}")
            return []
        except Exception as e:
            logger.error(f"❌ خطا در دریافت کندل‌های {coin_symbol}: {e}")
            return []
    
    def get_available_candle_count(self, coin_symbol: str) -> int:
        """دریافت تعداد کندل‌های موجود برای یک ارز"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            query = """
                SELECT COUNT(*) 
                FROM crypto_klines k
                JOIN crypto_coins c ON k.coin_id = c.id
                WHERE c.symbol = ? 
                AND k.timeframe = '5m'
            """
            
            cursor.execute(query, (coin_symbol,))
            count = cursor.fetchone()[0]
            conn.close()
            
            return count
            
        except Exception as e:
            logger.error(f"❌ خطا در شمارش کندل‌های {coin_symbol}: {e}")
            return 0
    
    def prepare_candles_for_analysis(self, candles: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """آماده‌سازی کندل‌ها برای تحلیل"""
        if not candles:
            return []
        
        # تبدیل قیمت‌ها به float
        for candle in candles:
            candle['open_price'] = float(candle['open_price'])
            candle['high_price'] = float(candle['high_price'])
            candle['low_price'] = float(candle['low_price'])
            candle['close_price'] = float(candle['close_price'])
            candle['volume'] = float(candle['volume'])
        
        return candles
