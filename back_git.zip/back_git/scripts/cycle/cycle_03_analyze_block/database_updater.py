﻿"""
💾 ذخیره‌کننده بانک - بروزرسانی اندیکاتورها در جدول crypto_klines
نسخه بهبود یافته با پشتیبانی کامل از 49 فیلد
"""

from typing import Dict, List, Any, Optional
import sqlite3
from datetime import datetime
import logging
import sys
import os

# تنظیم لاگر
logger = logging.getLogger('database_updater')

# تنظیم مسیر برای import صحیح config_manager
current_file = os.path.abspath(__file__)  # مسیر کامل این فایل
current_dir = os.path.dirname(current_file)  # پوشه cycle_03_analyze_block
cycle_dir = os.path.dirname(current_dir)  # پوشه cycle
scripts_dir = os.path.dirname(cycle_dir)  # پوشه scripts
project_root = os.path.dirname(scripts_dir)  # پوشه اصلی c-data

# اضافه کردن مسیر scripts به sys.path
if scripts_dir not in sys.path:
    sys.path.insert(0, scripts_dir)

# تلاش برای import config_manager
try:
    from config_manager import get_database_path, get
    CONFIG_MANAGER_AVAILABLE = True
    logger.info("✅ config_manager با موفقیت import شد")
except ImportError as e:
    logger.error(f"❌ خطا در import config_manager: {e}")
    logger.error(f"📁 جستجو در مسیر: {scripts_dir}")
    logger.error("📁 استفاده از مسیر پیش‌فرض")
    CONFIG_MANAGER_AVAILABLE = False

class DatabaseUpdater:
    """بروزرسانی دیتابیس - نسخه بهبود یافته با پشتیبانی کامل 49 فیلد"""
    
    def __init__(self):
        logger.info("DatabaseUpdater (نسخه کامل 49 فیلد) راه‌اندازی شد")
        
        # دریافت مسیر دیتابیس
        if CONFIG_MANAGER_AVAILABLE:
            try:
                self.db_path = get_database_path()
                logger.info(f"📁 مسیر دیتابیس (از config_manager): {self.db_path}")
            except Exception as e:
                logger.error(f"❌ خطا در دریافت مسیر از config_manager: {e}")
                self.db_path = os.path.join(project_root, "data", "crypto_master.db")
                logger.info(f"📁 مسیر دیتابیس (پیش‌فرض): {self.db_path}")
        else:
            self.db_path = os.path.join(project_root, "data", "crypto_master.db")
            logger.info(f"📁 مسیر دیتابیس (پیش‌فرض): {self.db_path}")
        
        # لیست کامل 49 فیلد برای crypto_klines
        self.complete_field_mappings = self._get_complete_field_mappings()
    
    def _get_complete_field_mappings(self) -> Dict[str, str]:
        """
        ایجاد نگاشت کامل برای 49 فیلد جدول crypto_klines
        این تابع فقط برای مرجع است و استفاده نمی‌شود
        """
        return {
            # ========== شناسه‌ها و متادیتا ==========
            'id': 'id',
            'coin_id': 'coin_id',
            'timeframe': 'timeframe',
            'aggregation_level': 'aggregation_level',
            
            # ========== زمان‌ها ==========
            'open_time': 'open_time',
            'close_time': 'close_time',
            'candle_date': 'candle_date',
            'created_at': 'created_at',
            'updated_at': 'updated_at',
            
            # ========== قیمت‌های OHLC ==========
            'open_price': 'open_price',
            'high_price': 'high_price',
            'low_price': 'low_price',
            'close_price': 'close_price',
            
            # ========== تغییرات قیمت ==========
            'price_change': 'price_change',
            'price_change_percent': 'price_change_percent',
            
            # ========== حجم‌ها ==========
            'volume': 'volume',
            'quote_volume': 'quote_volume',
            'taker_buy_volume': 'taker_buy_volume',
            'taker_sell_volume': 'taker_sell_volume',
            'taker_buy_quote_volume': 'taker_buy_quote_volume',
            
            # ========== اطلاعات معاملات ==========
            'number_of_trades': 'number_of_trades',
            
            # ========== اندیکاتورهای تکنیکال ==========
            'rsi': 'rsi',
            'macd': 'macd',
            'macd_signal': 'macd_signal',
            'macd_histogram': 'macd_histogram',
            
            # ========== باندهای بولینگر ==========
            'bollinger_upper': 'bollinger_upper',
            'bollinger_middle': 'bollinger_middle',
            'bollinger_lower': 'bollinger_lower',
            
            # ========== میانگین‌های متحرک ==========
            'ma_7': 'ma_7',
            'ma_25': 'ma_25',
            'ma_99': 'ma_99',
            
            # ========== حجم میانگین متحرک ==========
            'volume_ma_20': 'volume_ma_20',
            
            # ========== شاخص‌های نوسان ==========
            'atr': 'atr',
            'volatility': 'volatility',
            
            # ========== شاخص حجم ==========
            'volume_ratio': 'volume_ratio',
            'obv': 'obv',
            
            # ========== الگوهای کندلی ==========
            'candle_pattern': 'candle_pattern',
            'is_doji': 'is_doji',
            'is_hammer': 'is_hammer',
            'is_shooting_star': 'is_shooting_star',
            
            # ========== کیفیت داده ==========
            'data_quality': 'data_quality',
            'is_interpolated': 'is_interpolated',
            'missing_data_points': 'missing_data_points',
            
            # ========== متادیتا ==========
            'source_exchange': 'source_exchange',
            'is_verified': 'is_verified',
            
            # ========== فیلدهای Pattern (جدید) ==========
            'pattern_markers': 'pattern_markers',
            'pattern_confidence': 'pattern_confidence',
            'trend_strength': 'trend_strength',
            'support_resistance_level': 'support_resistance_level'
        }
    
    def _get_connection(self):
        """ایجاد اتصال به دیتابیس"""
        try:
            if not os.path.exists(self.db_path):
                logger.error(f"❌ دیتابیس در مسیر {self.db_path} پیدا نشد")
                return None
            
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row  # برگرداندن نتایج به صورت دیکشنری
            return conn
        except Exception as e:
            logger.error(f"❌ خطا در اتصال به دیتابیس: {e}")
            return None
    
    def _check_table_exists(self, conn, table_name):
        """بررسی وجود جدول در دیتابیس"""
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name=?", (table_name,))
            result = cursor.fetchone()
            exists = result is not None
            
            if not exists:
                logger.error(f"❌ جدول '{table_name}' در دیتابیس وجود ندارد")
            
            return exists
        except Exception as e:
            logger.error(f"❌ خطا در بررسی وجود جدول '{table_name}': {e}")
            return False
    
    def _check_column_exists(self, conn, table_name, column_name):
        """بررسی وجود ستون در جدول"""
        try:
            cursor = conn.cursor()
            cursor.execute(f"PRAGMA table_info({table_name})")
            columns = [col[1] for col in cursor.fetchall()]
            exists = column_name in columns
            
            if not exists:
                logger.debug(f"⚠️ ستون '{column_name}' در جدول '{table_name}' وجود ندارد")
            
            return exists
        except Exception as e:
            logger.debug(f"⚠️ خطا در بررسی وجود ستون '{column_name}' در جدول '{table_name}': {e}")
            return False
    
    def _get_table_columns(self, conn, table_name):
        """دریافت لیست ستون‌های یک جدول"""
        try:
            cursor = conn.cursor()
            cursor.execute(f"PRAGMA table_info({table_name})")
            columns = {}
            for col in cursor.fetchall():
                columns[col[1]] = col[2]  # نام ستون و نوع
            return columns
        except Exception as e:
            logger.error(f"❌ خطا در دریافت ستون‌های جدول '{table_name}': {e}")
            return {}
    
    def update_candle_indicators(self, candle_id: int, indicators: Dict[str, Any]) -> bool:
        """
        آپدیت اندیکاتورهای یک کندل خاص در جدول crypto_klines
        نسخه بهبود یافته با پشتیبانی از فیلدهای جدید
        """
        try:
            if not indicators:
                logger.warning(f"⚠️ هیچ اندیکاتوری برای آپدیت کندل {candle_id} وجود ندارد")
                return False
            
            # اتصال به دیتابیس
            conn = self._get_connection()
            if not conn:
                return False
            
            # بررسی وجود جدول crypto_klines
            if not self._check_table_exists(conn, 'crypto_klines'):
                conn.close()
                return False
            
            # دریافت ستون‌های موجود در جدول
            available_columns = self._get_table_columns(conn, 'crypto_klines')
            if not available_columns:
                logger.error(f"❌ نتوانست ستون‌های جدول crypto_klines را بخواند")
                conn.close()
                return False
            
            # ساخت کوئری UPDATE دینامیک
            set_clauses = []
            params = []
            
            # لیست کامل نگاشت فیلدها (49 فیلد)
            field_mappings = [
                # فیلدهای اصلی
                ('rsi', 'rsi'),
                ('macd', 'macd'),
                ('macd_signal', 'macd_signal'),
                ('macd_histogram', 'macd_histogram'),
                
                # باندهای بولینگر
                ('bollinger_upper', 'bollinger_upper'),
                ('bollinger_middle', 'bollinger_middle'),
                ('bollinger_lower', 'bollinger_lower'),
                
                # میانگین‌های متحرک
                ('ma_7', 'ma_7'),
                ('ma_25', 'ma_25'),
                ('ma_99', 'ma_99'),
                
                # حجم میانگین متحرک
                ('volume_ma_20', 'volume_ma_20'),
                
                # تغییرات قیمت
                ('price_change', 'price_change'),
                ('price_change_percent', 'price_change_percent'),
                
                # اندیکاتورهای نوسان
                ('atr', 'atr'),
                ('volatility', 'volatility'),
                
                # شاخص‌های حجم
                ('volume_ratio', 'volume_ratio'),
                ('obv', 'obv'),
                
                # حجم‌های خاص
                ('quote_volume', 'quote_volume'),
                ('taker_buy_volume', 'taker_buy_volume'),
                ('taker_sell_volume', 'taker_sell_volume'),
                ('taker_buy_quote_volume', 'taker_buy_quote_volume'),
                
                # اطلاعات معاملات
                ('number_of_trades', 'number_of_trades'),
                
                # الگوهای کندلی
                ('candle_pattern', 'candle_pattern'),
                ('is_doji', 'is_doji'),
                ('is_hammer', 'is_hammer'),
                ('is_shooting_star', 'is_shooting_star'),
                
                # کیفیت داده
                ('data_quality', 'data_quality'),
                ('is_interpolated', 'is_interpolated'),
                ('missing_data_points', 'missing_data_points'),
                
                # level تجمیع و تاریخ
                ('aggregation_level', 'aggregation_level'),
                ('candle_date', 'candle_date'),
                
                # فیلدهای Pattern (جدید)
                ('pattern_markers', 'pattern_markers'),
                ('pattern_confidence', 'pattern_confidence'),
                ('trend_strength', 'trend_strength'),
                ('support_resistance_level', 'support_resistance_level'),
            ]
            
            # فقط فیلدهایی که ستون مربوطه وجود دارد و مقدار دارند
            for indicator_name, column_name in field_mappings:
                if column_name in available_columns and indicator_name in indicators:
                    value = indicators[indicator_name]
                    if value is not None:
                        # تبدیل مقادیر بولین به عدد
                        if isinstance(value, bool):
                            set_clauses.append(f"{column_name} = ?")
                            params.append(1 if value else 0)
                        elif isinstance(value, (int, float, str)):
                            # اعتبارسنجی مقادیر عددی
                            if isinstance(value, float):
                                # جلوگیری از مقادیر نامعقول
                                if abs(value) > 1e10:  # عدد خیلی بزرگ
                                    value = 0.0
                                elif abs(value) < 1e-10 and value != 0:  # عدد خیلی کوچک
                                    value = 0.0
                            
                            set_clauses.append(f"{column_name} = ?")
                            params.append(value)
            
            # اگر هیچ فیلدی برای آپدیت نبود
            if not set_clauses:
                logger.warning(f"⚠️ هیچ فیلد معتبری برای آپدیت کندل {candle_id} وجود ندارد")
                logger.debug(f"   ستون‌های موجود: {list(available_columns.keys())[:10]}...")
                logger.debug(f"   اندیکاتورهای دریافتی: {list(indicators.keys())[:10]}...")
                conn.close()
                return False
            
            # اضافه کردن زمان آپدیت اگر ستون وجود دارد
            if 'updated_at' in available_columns:
                set_clauses.append("updated_at = CURRENT_TIMESTAMP")
            
            # اضافه کردن ID کندل به پارامترها
            params.append(candle_id)
            
            # ساخت کوئری کامل
            query = f"""
                UPDATE crypto_klines 
                SET {', '.join(set_clauses)}
                WHERE id = ?
            """
            
            # اجرای کوئری
            cursor = conn.cursor()
            cursor.execute(query, tuple(params))
            conn.commit()
            
            # بررسی تعداد ردیف‌های آپدیت شده
            changes = cursor.rowcount
            conn.close()
            
            if changes > 0:
                logger.debug(f"✅ کندل {candle_id}: {len(set_clauses)} فیلد به‌روزرسانی شد")
                return True
            else:
                logger.warning(f"⚠️ هیچ تغییری در کندل {candle_id} ایجاد نشد (ممکن است وجود نداشته باشد)")
                return False
                
        except sqlite3.Error as e:
            logger.error(f"❌ خطای SQLite در آپدیت کندل {candle_id}: {e}")
            return False
        except Exception as e:
            logger.error(f"❌ خطا در آپدیت اندیکاتورهای کندل {candle_id}: {e}")
            return False
        finally:
            if 'conn' in locals():
                try:
                    conn.close()
                except:
                    pass
    
    # 🔥 تابع جدید: دریافت آمار کامل جدول
    def get_table_stats(self) -> Dict[str, Any]:
        """دریافت آمار کامل جدول crypto_klines"""
        try:
            conn = self._get_connection()
            if not conn:
                return {'error': 'اتصال به دیتابیس ناموفق'}
            
            # بررسی وجود جدول
            if not self._check_table_exists(conn, 'crypto_klines'):
                conn.close()
                return {'error': 'جدول crypto_klines وجود ندارد'}
            
            cursor = conn.cursor()
            
            stats = {}
            
            # ۱. تعداد کل رکوردها
            cursor.execute("SELECT COUNT(*) FROM crypto_klines")
            stats['total_candles'] = cursor.fetchone()[0]
            
            # ۲. تعداد کندل‌های با اندیکاتور (با RSI به عنوان شاخص)
            cursor.execute("SELECT COUNT(*) FROM crypto_klines WHERE rsi IS NOT NULL")
            stats['candles_with_indicators'] = cursor.fetchone()[0]
            
            # ۳. تعداد ارزهای مختلف
            cursor.execute("SELECT COUNT(DISTINCT coin_id) FROM crypto_klines")
            stats['unique_coins'] = cursor.fetchone()[0]
            
            # ۴. جدیدترین و قدیمی‌ترین کندل
            cursor.execute("SELECT MIN(open_time), MAX(open_time) FROM crypto_klines")
            min_max = cursor.fetchone()
            stats['oldest_candle'] = min_max[0]
            stats['newest_candle'] = min_max[1]
            
            # ۵. تعداد تایم‌فریم‌های مختلف
            cursor.execute("SELECT COUNT(DISTINCT timeframe) FROM crypto_klines")
            stats['unique_timeframes'] = cursor.fetchone()[0]
            
            # ۶. درصد کندل‌های پردازش شده
            if stats['total_candles'] > 0:
                stats['processed_percentage'] = (stats['candles_with_indicators'] / stats['total_candles']) * 100
            else:
                stats['processed_percentage'] = 0
            
            # ۷. تعداد کندل‌های با کیفیت داده بالا (>80%)
            if self._check_column_exists(conn, 'crypto_klines', 'data_quality'):
                cursor.execute("SELECT COUNT(*) FROM crypto_klines WHERE data_quality > 80")
                stats['high_quality_candles'] = cursor.fetchone()[0]
            
            # ۸. تعداد کندل‌های با الگوهای تشخیص داده شده
            if self._check_column_exists(conn, 'crypto_klines', 'candle_pattern'):
                cursor.execute("SELECT COUNT(*) FROM crypto_klines WHERE candle_pattern != 'NORMAL' AND candle_pattern IS NOT NULL")
                stats['pattern_candles'] = cursor.fetchone()[0]
            
            conn.close()
            
            logger.info(f"📊 آمار جدول: {stats['total_candles']} کندل, {stats['processed_percentage']:.1f}% پردازش شده")
            
            stats['success'] = True
            return stats
            
        except Exception as e:
            logger.error(f"❌ خطا در دریافت آمار جدول: {e}")
            return {'error': str(e), 'success': False}
        finally:
            if 'conn' in locals():
                try:
                    conn.close()
                except:
                    pass
    
    # 🔥 تابع جدید: بررسی فیلدهای Pattern
    def check_pattern_fields(self) -> Dict[str, bool]:
        """بررسی وجود فیلدهای Pattern در جدول"""
        try:
            conn = self._get_connection()
            if not conn:
                return {}
            
            if not self._check_table_exists(conn, 'crypto_klines'):
                conn.close()
                return {}
            
            pattern_fields = [
                'pattern_markers',
                'pattern_confidence', 
                'trend_strength',
                'support_resistance_level'
            ]
            
            results = {}
            for field in pattern_fields:
                exists = self._check_column_exists(conn, 'crypto_klines', field)
                results[field] = exists
            
            conn.close()
            
            # لاگ نتایج
            existing_fields = [f for f, exists in results.items() if exists]
            missing_fields = [f for f, exists in results.items() if not exists]
            
            if existing_fields:
                logger.info(f"✅ فیلدهای Pattern موجود: {existing_fields}")
            if missing_fields:
                logger.warning(f"⚠️ فیلدهای Pattern مفقود: {missing_fields}")
            
            return results
            
        except Exception as e:
            logger.error(f"❌ خطا در بررسی فیلدهای Pattern: {e}")
            return {}
        finally:
            if 'conn' in locals():
                try:
                    conn.close()
                except:
                    pass
    
    # 🔥 تابع جدید: دریافت تعداد فیلدهای پر شده برای یک کندل
    def get_candle_filled_fields(self, candle_id: int) -> Dict[str, Any]:
        """دریافت تعداد و لیست فیلدهای پر شده برای یک کندل"""
        try:
            conn = self._get_connection()
            if not conn:
                return {'error': 'اتصال به دیتابیس ناموفق'}
            
            if not self._check_table_exists(conn, 'crypto_klines'):
                conn.close()
                return {'error': 'جدول crypto_klines وجود ندارد'}
            
            cursor = conn.cursor()
            cursor.execute(f"SELECT * FROM crypto_klines WHERE id = ?", (candle_id,))
            row = cursor.fetchone()
            
            if not row:
                conn.close()
                return {'error': f'کندل {candle_id} یافت نشد'}
            
            # تبدیل ردیف به دیکشنری
            columns = [description[0] for description in cursor.description]
            candle_data = dict(zip(columns, row))
            
            # شمارش فیلدهای پر شده
            total_fields = len(candle_data)
            filled_fields = 0
            empty_fields = []
            
            for field, value in candle_data.items():
                if value is not None:
                    filled_fields += 1
                else:
                    empty_fields.append(field)
            
            percentage = (filled_fields / total_fields * 100) if total_fields > 0 else 0
            
            conn.close()
            
            return {
                'success': True,
                'candle_id': candle_id,
                'total_fields': total_fields,
                'filled_fields': filled_fields,
                'percentage_filled': percentage,
                'empty_fields': empty_fields[:10],  # فقط ۱۰ تای اول
                'total_empty': len(empty_fields)
            }
            
        except Exception as e:
            logger.error(f"❌ خطا در دریافت اطلاعات فیلدهای کندل {candle_id}: {e}")
            return {'error': str(e), 'success': False}
        finally:
            if 'conn' in locals():
                try:
                    conn.close()
                except:
                    pass

    # 🔥 تابع جدید: به‌روزرسانی چندین فیلد Pattern یکجا
    def update_pattern_fields(self, candle_id: int, pattern_data: Dict[str, Any]) -> bool:
        """به‌روزرسانی فیلدهای Pattern برای یک کندل"""
        try:
            if not pattern_data:
                return False
            
            conn = self._get_connection()
            if not conn:
                return False
            
            if not self._check_table_exists(conn, 'crypto_klines'):
                conn.close()
                return False
            
            # فیلدهای Pattern معتبر
            valid_pattern_fields = {
                'pattern_markers': str,
                'pattern_confidence': float,
                'trend_strength': float,
                'support_resistance_level': float
            }
            
            # ساخت کوئری UPDATE
            set_clauses = []
            params = []
            
            for field, field_type in valid_pattern_fields.items():
                if field in pattern_data and pattern_data[field] is not None:
                    # بررسی وجود ستون
                    if self._check_column_exists(conn, 'crypto_klines', field):
                        value = pattern_data[field]
                        
                        # تبدیل نوع داده
                        try:
                            if field_type == float:
                                value = float(value)
                            elif field_type == str:
                                value = str(value)
                            
                            set_clauses.append(f"{field} = ?")
                            params.append(value)
                        except (ValueError, TypeError):
                            logger.warning(f"⚠️ مقدار نامعتبر برای فیلد {field}: {pattern_data[field]}")
            
            if not set_clauses:
                logger.warning(f"⚠️ هیچ فیلد Pattern معتبری برای کندل {candle_id} یافت نشد")
                conn.close()
                return False
            
            # اضافه کردن updated_at
            if self._check_column_exists(conn, 'crypto_klines', 'updated_at'):
                set_clauses.append("updated_at = CURRENT_TIMESTAMP")
            
            # اضافه کردن candle_id
            params.append(candle_id)
            
            query = f"""
                UPDATE crypto_klines 
                SET {', '.join(set_clauses)}
                WHERE id = ?
            """
            
            cursor = conn.cursor()
            cursor.execute(query, tuple(params))
            conn.commit()
            
            success = cursor.rowcount > 0
            conn.close()
            
            if success:
                logger.debug(f"✅ فیلدهای Pattern کندل {candle_id} به‌روزرسانی شد: {list(pattern_data.keys())}")
            
            return success
            
        except Exception as e:
            logger.error(f"❌ خطا در به‌روزرسانی فیلدهای Pattern کندل {candle_id}: {e}")
            return False
        finally:
            if 'conn' in locals():
                try:
                    conn.close()
                except:
                    pass
    
    # بقیه توابع موجود شما دقیقاً مانند قبل باقی می‌مانند
    # فقط چند تابع بالا اضافه شده است
    
    def batch_update_candles(self, updates: List[Dict[str, Any]]) -> Dict[str, Any]:
        """آپدیت دسته‌ای کندل‌ها - بدون تغییر"""
        # کد قبلی شما دقیقاً همینجا قرار می‌گیرد
        pass
    
    def update_coin_current_price(self, coin_id: int, current_price: float) -> bool:
        """بروزرسانی قیمت فعلی ارز - بدون تغییر"""
        # کد قبلی شما
        pass
    
    def get_candle_last_update_time(self, candle_id: int) -> Optional[datetime]:
        """دریافت زمان آخرین آپدیت - بدون تغییر"""
        # کد قبلی شما
        pass
    
    def check_if_candle_needs_update(self, candle_id: int, max_age_hours: int = 24) -> bool:
        """بررسی نیاز کندل به آپدیت - بدون تغییر"""
        # کد قبلی شما
        pass
    
    def update_candle_data_quality(self, candle_id: int, data_quality: int) -> bool:
        """بروزرسانی کیفیت داده - بدون تغییر"""
        # کد قبلی شما
        pass
    
    def get_unprocessed_candles(self, coin_symbol: str, timeframe: str = '5m') -> List[Dict[str, Any]]:
        """دریافت کندل‌های پردازش نشده - بدون تغییر"""
        # کد قبلی شما
        pass
    
    def get_candle_count_with_indicators(self, coin_symbol: str) -> Dict[str, Any]:
        """دریافت آمار کندل‌های پردازش شده - بدون تغییر"""
        # کد قبلی شما
        pass