﻿"""
🎪 ماژول اصلی تکه ۳ - تحلیل کندل‌ها و محاسبه اندیکاتورها
نویسنده: سیستم تحلیل کریپتو
تاریخ: ۲۰۲۵-۱۲-۲۳
"""

import sys
import os
import json
import sqlite3
import logging
from datetime import datetime
import argparse

# تنظیمات لاگ‌گیری
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('logs/cycle_03.log', encoding='utf-8'),
        logging.StreamHandler()
    ]
)

logger = logging.getLogger(__name__)

def import_modules():
    """وارد کردن ماژول‌های مورد نیاز"""
    try:
        # اضافه کردن مسیر فعلی به sys.path
        current_dir = os.path.dirname(os.path.abspath(__file__))
        sys.path.append(current_dir)
        
        from indicator_calculator import IndicatorCalculator
        from validator import Validator
        from candle_processor import CandleProcessor
        from database_updater import DatabaseUpdater
        from report_generator import ReportGenerator
        
        logger.info("✅ همه ماژول‌ها با موفقیت import شدند")
        return {
            'indicator_calculator': IndicatorCalculator,
            'validator': Validator,
            'candle_processor': CandleProcessor,
            'database_updater': DatabaseUpdater,
            'report_generator': ReportGenerator
        }
    except ImportError as e:
        logger.error(f"❌ خطا در import ماژول‌ها: {e}")
        logger.error("📁 فایل‌های موجود در پوشه:")
        for f in os.listdir(os.path.dirname(__file__)):
            logger.error(f"  - {f}")
        raise

class MainCoordinator:
    """هماهنگ کننده اصلی تکه ۳"""
    
    def __init__(self):
        logger.info("🚀 ایجاد MainCoordinator")
        
        # وارد کردن ماژول‌ها
        modules = import_modules()
        
        # نمونه‌سازی ماژول‌ها
        self.indicator_calculator = modules['indicator_calculator']()
        self.validator = modules['validator']()
        self.candle_processor = modules['candle_processor']()
        self.database_updater = modules['database_updater']()
        self.report_generator = modules['report_generator']()
        
        logger.info("✅ همه ماژول‌ها نمونه‌سازی شدند")
    
    def get_block_coins(self, block_id):
        """دریافت ارزهای یک بلوک از cycle_state.json"""
        try:
            state_path = os.path.join('state', 'cycle_state.json')
            
            if not os.path.exists(state_path):
                logger.error(f"❌ فایل {state_path} پیدا نشد")
                return []
            
            with open(state_path, 'r', encoding='utf-8') as f:
                state = json.load(f)
            
            blocks = state.get('blocks', [])
            
            if block_id < 1 or block_id > len(blocks):
                logger.error(f"❌ بلوک {block_id} معتبر نیست. تعداد کل بلوک‌ها: {len(blocks)}")
                return []
            
            block = blocks[block_id - 1]
            coins = block.get('coins', [])
            
            logger.info(f"📦 بلوک {block_id}: {len(coins)} ارز پیدا شد")
            return coins
            
        except Exception as e:
            logger.error(f"❌ خطا در دریافت ارزهای بلوک {block_id}: {e}")
            return []
    
    def process_single_coin(self, coin_symbol):
        """پردازش کامل یک ارز"""
        try:
            logger.info(f"🔄 شروع پردازش ارز: {coin_symbol}")
            
            # ۱. دریافت کندل‌ها
            candles = self.candle_processor.get_candles_for_coin(coin_symbol)
            
            if not candles:
                logger.warning(f"⚠️ هیچ کندلی برای {coin_symbol} پیدا نشد")
                return {'symbol': coin_symbol, 'status': 'NO_DATA', 'processed': 0}
            
            if len(candles) < 25:
                logger.warning(f"⚠️ کندل کافی برای {coin_symbol} نیست: {len(candles)} کندل")
                return {'symbol': coin_symbol, 'status': 'INSUFFICIENT_DATA', 'processed': 0}
            
            logger.info(f"📊 {coin_symbol}: {len(candles)} کندل دریافت شد")
            
            # ۲. پردازش هر کندل
            processed_count = 0
            total_candles = len(candles)
            
            for i in range(total_candles):
                try:
                    current_candle = candles[i]
                    previous_candles = candles[:i]
                    
                    # محاسبه اندیکاتورها
                    indicators = self.indicator_calculator.calculate_all_indicators(
                        current_candle, 
                        previous_candles
                    )
                    
                    # اعتبارسنجی
                    errors = self.validator.validate_indicators(indicators)
                    if errors:
                        if i > 20:  # فقط برای کندل‌های بعد از ۲۰ام خطا را نمایش بده
                            logger.debug(f"خطا در کندل {i} از {coin_symbol}: {errors[:1]}")
                        continue
                    
                    # محاسبه کیفیت داده
                    quality = self.validator.calculate_data_quality(indicators)
                    indicators['data_quality'] = quality
                    
                    # ذخیره در دیتابیس
                    success = self.database_updater.update_candle_indicators(
                        current_candle['id'], 
                        indicators
                    )
                    
                    if success:
                        processed_count += 1
                    
                    # نمایش پیشرفت
                    if (i + 1) % 50 == 0 or (i + 1) == total_candles:
                        progress = ((i + 1) / total_candles) * 100
                        logger.info(f"📈 {coin_symbol}: {i + 1}/{total_candles} ({progress:.1f}%)")
                        
                except Exception as e:
                    logger.debug(f"خطا در کندل {i} از {coin_symbol}: {str(e)[:100]}")
                    continue
            
            # ۳. نتیجه‌گیری
            success_rate = (processed_count / total_candles) * 100
            
            result = {
                'symbol': coin_symbol,
                'status': 'COMPLETED',
                'total_candles': total_candles,
                'processed_candles': processed_count,
                'success_rate': success_rate,
                'timestamp': datetime.now().isoformat()
            }
            
            logger.info(f"✅ {coin_symbol}: {processed_count}/{total_candles} کندل پردازش شد ({success_rate:.1f}%)")
            return result
            
        except Exception as e:
            logger.error(f"❌ خطا در پردازش {coin_symbol}: {e}")
            return {
                'symbol': coin_symbol,
                'status': 'FAILED',
                'error': str(e),
                'timestamp': datetime.now().isoformat()
            }
    
    def process_block(self, block_id):
        """پردازش کامل یک بلوک"""
        start_time = datetime.now()
        logger.info(f"🚀 شروع پردازش بلوک {block_id}")
        
        # ۱. دریافت ارزهای بلوک
        coins = self.get_block_coins(block_id)
        
        if not coins:
            logger.error(f"❌ هیچ ارزی در بلوک {block_id} پیدا نشد")
            return None
        
        logger.info(f"📊 بلوک {block_id}: {len(coins)} ارز برای پردازش")
        
        # ۲. پردازش هر ارز
        results = []
        for i, coin in enumerate(coins, 1):
            coin_symbol = coin.get('symbol', f'coin_{i}')
            logger.info(f"🔄 [{i}/{len(coins)}] پردازش ارز: {coin_symbol}")
            
            result = self.process_single_coin(coin_symbol)
            results.append(result)
            
            # تاخیر کوتاه برای جلوگیری از overload
            if i < len(coins):
                import time
                time.sleep(0.1)
        
        # ۳. محاسبه آمار
        end_time = datetime.now()
        duration = (end_time - start_time).total_seconds()
        
        completed = sum(1 for r in results if r.get('status') == 'COMPLETED')
        failed = sum(1 for r in results if r.get('status') == 'FAILED')
        no_data = sum(1 for r in results if r.get('status') in ['NO_DATA', 'INSUFFICIENT_DATA'])
        
        total_candles = sum(r.get('total_candles', 0) for r in results)
        processed_candles = sum(r.get('processed_candles', 0) for r in results)
        
        # ۴. تولید گزارش
        report = {
            'block_id': block_id,
            'start_time': start_time.isoformat(),
            'end_time': end_time.isoformat(),
            'duration_seconds': duration,
            'summary': {
                'total_coins': len(coins),
                'coins_completed': completed,
                'coins_failed': failed,
                'coins_no_data': no_data,
                'total_candles': total_candles,
                'processed_candles': processed_candles,
                'success_rate': (processed_candles / total_candles * 100) if total_candles > 0 else 0
            },
            'coin_results': results,
            'status': 'COMPLETED' if failed == 0 else 'PARTIAL'
        }
        
        # ۵. ذخیره گزارش
        self.report_generator.save_report(report, block_id)
        
        # ۶. نمایش نتیجه
        logger.info(f"✅ پردازش بلوک {block_id} کامل شد")
        logger.info(f"⏱️  زمان اجرا: {duration:.2f} ثانیه")
        logger.info(f"📊 نتایج: {completed} موفق، {failed} ناموفق، {no_data} بدون داده")
        logger.info(f"🕯️  کندل‌ها: {processed_candles}/{total_candles} پردازش شد")
        
        return report
    
    def test_modules(self):
        """تست ماژول‌های سیستم"""
        logger.info("🧪 شروع تست ماژول‌ها")
        
        tests_passed = 0
        tests_failed = 0
        
        # تست ۱: اتصال به دیتابیس
        try:
            db_path = os.path.join('data', 'crypto_master.db')
            if os.path.exists(db_path):
                conn = sqlite3.connect(db_path)
                conn.close()
                logger.info("✅ تست ۱: اتصال به دیتابیس - موفق")
                tests_passed += 1
            else:
                logger.error("❌ تست ۱: دیتابیس پیدا نشد")
                tests_failed += 1
        except Exception as e:
            logger.error(f"❌ تست ۱: خطا در اتصال دیتابیس - {e}")
            tests_failed += 1
        
        # تست ۲: فایل وضعیت
        try:
            state_path = os.path.join('state', 'cycle_state.json')
            if os.path.exists(state_path):
                with open(state_path, 'r', encoding='utf-8') as f:
                    json.load(f)
                logger.info("✅ تست ۲: فایل وضعیت - موفق")
                tests_passed += 1
            else:
                logger.error("❌ تست ۲: فایل وضعیت پیدا نشد")
                tests_failed += 1
        except Exception as e:
            logger.error(f"❌ تست ۲: خطا در خواندن وضعیت - {e}")
            tests_failed += 1
        
        # تست ۳: ماژول indicator_calculator
        try:
            # داده‌های نمونه برای تست
            sample_candle = {
                'open_price': 100,
                'high_price': 105,
                'low_price': 95,
                'close_price': 102,
                'volume': 1000
            }
            
            sample_history = [{
                'open_price': 99 + i,
                'high_price': 104 + i,
                'low_price': 94 + i,
                'close_price': 101 + i,
                'volume': 900 + i*10
            } for i in range(20)]
            
            indicators = self.indicator_calculator.calculate_all_indicators(
                sample_candle, 
                sample_history
            )
            
            if indicators:
                logger.info(f"✅ تست ۳: محاسبه اندیکاتورها - موفق ({len(indicators)} اندیکاتور)")
                tests_passed += 1
            else:
                logger.error("❌ تست ۳: هیچ اندیکاتوری محاسبه نشد")
                tests_failed += 1
                
        except Exception as e:
            logger.error(f"❌ تست ۳: خطا در محاسبه اندیکاتورها - {e}")
            tests_failed += 1
        
        # نتیجه تست
        logger.info(f"\n📊 نتیجه تست: {tests_passed} موفق، {tests_failed} ناموفق")
        
        if tests_failed == 0:
            logger.info("🎉 همه تست‌ها موفق بودند!")
            return True
        else:
            logger.warning(f"⚠️ {tests_failed} تست ناموفق بود")
            return False

def main():
    """تابع اصلی اجرا"""
    parser = argparse.ArgumentParser(description='سیستم تحلیل کندل‌ها و اندیکاتورها (تکه ۳)')
    parser.add_argument('--block', type=int, help='شماره بلوک برای تحلیل')
    parser.add_argument('--test', action='store_true', help='اجرای تست ماژول‌ها')
    parser.add_argument('--real', action='store_true', help='اجرای تحلیل واقعی')
    
    args = parser.parse_args()
    
    print("\n" + "=" * 60)
    print("🚀 سیستم تحلیل تکنیکال - تکه ۳")
    print("=" * 60)
    
    try:
        coordinator = MainCoordinator()
        
        if args.test:
            # حالت تست
            print("🧪 حالت تست ماژول‌ها")
            success = coordinator.test_modules()
            if success:
                print("✅ تست‌ها موفق بودند. سیستم آماده اجراست.")
            else:
                print("⚠️ برخی تست‌ها ناموفق بودند. قبل از اجرای واقعی بررسی کنید.")
        
        elif args.block:
            # تحلیل بلوک خاص
            print(f"🎯 تحلیل بلوک {args.block}")
            report = coordinator.process_block(args.block)
            if report:
                print(f"✅ تحلیل بلوک {args.block} با موفقیت کامل شد")
                print(f"📊 نتایج: {report['summary']['coins_completed']} ارز موفق")
            else:
                print(f"❌ تحلیل بلوک {args.block} ناموفق بود")
        
        elif args.real:
            # تحلیل واقعی بلوک ۱ (پیش‌فرض)
            print("🎯 تحلیل واقعی بلوک ۱")
            report = coordinator.process_block(1)
            if report:
                print(f"✅ تحلیل واقعی با موفقیت کامل شد")
                print(f"📊 {report['summary']['processed_candles']} کندل پردازش شد")
            else:
                print("❌ تحلیل واقعی ناموفق بود")
        
        else:
            # حالت پیش‌فرض: تست
            print("🔍 حالت پیش‌فرض: تست ماژول‌ها")
            success = coordinator.test_modules()
            if success:
                print("\n💡 برای تحلیل بلوک ۱ اجرا کنید:")
                print("   python main.py --real")
                print("   یا")
                print("   python main.py --block 1")
    
    except Exception as e:
        print(f"❌ خطای اصلی: {e}")
        import traceback
        traceback.print_exc()
        return 1
    
    print("\n" + "=" * 60)
    print("🏁 پایان اجرا")
    print("=" * 60)
    
    return 0

if __name__ == "__main__":
    sys.exit(main())