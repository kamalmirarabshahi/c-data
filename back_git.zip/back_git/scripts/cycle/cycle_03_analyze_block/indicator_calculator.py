"""
🧮 ماشین حساب اندیکاتورهای تکنیکال - نسخه کامل
پشتیبانی از تمام ۴۹ فیلد جدول crypto_klines
"""

import numpy as np
import pandas as pd
from typing import List, Dict, Any, Optional, Tuple
import logging
from datetime import datetime, timedelta
import math

logger = logging.getLogger(__name__)

class IndicatorCalculator:
    """ماشین حساب کامل اندیکاتورها برای ۴۹ فیلد"""
    
    def __init__(self):
        logger.info("IndicatorCalculator (نسخه کامل) راه‌اندازی شد")
        self.required_periods = {
            'rsi': 14,
            'macd': (12, 26, 9),
            'bollinger': 20,
            'atr': 14,
            'sma_7': 7,
            'sma_25': 25,
            'sma_99': 99,
            'volume_ma': 20
        }
    
    def calculate_all_indicators(self, current_candle: Dict[str, Any], 
                               previous_candles: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        محاسبه کامل تمام اندیکاتورها برای ۴۹ فیلد
        """
        try:
            # ۱. آماده‌سازی داده‌ها
            candles = previous_candles + [current_candle]
            close_prices = [c.get('close_price', 0) for c in candles if c.get('close_price')]
            open_prices = [c.get('open_price', 0) for c in candles if c.get('open_price')]
            high_prices = [c.get('high_price', 0) for c in candles if c.get('high_price')]
            low_prices = [c.get('low_price', 0) for c in candles if c.get('low_price')]
            volumes = [c.get('volume', 0) for c in candles if c.get('volume')]
            
            if len(candles) < 100:  # حداقل داده برای محاسبات
                logger.warning(f"داده کافی نیست: {len(candles)} کندل (نیاز: 100+)")
                return self._get_default_indicators(current_candle)
            
            # ۲. محاسبه تمام اندیکاتورها
            indicators = {}
            
            # قیمت‌های اصلی (OHLC)
            indicators.update(self._calculate_price_indicators(current_candle, candles))
            
            # حجم‌ها
            indicators.update(self._calculate_volume_indicators(current_candle, candles))
            
            # اندیکاتورهای تکنیکال اصلی
            indicators.update(self._calculate_technical_indicators(candles))
            
            # الگوهای کندلی
            indicators.update(self._calculate_candle_patterns(current_candle))
            
            # کیفیت داده
            indicators.update(self._calculate_data_quality(candles))
            
            # فیلدهای Pattern (برای تکه ۴)
            indicators.update(self._calculate_pattern_fields(current_candle, candles))
            
            # متادیتا
            indicators.update(self._calculate_metadata(current_candle))
            
            logger.debug(f"{len(indicators)} اندیکاتور محاسبه شد")
            return indicators
            
        except Exception as e:
            logger.error(f"خطا در محاسبه اندیکاتورها: {e}")
            return self._get_default_indicators(current_candle)
    
    def _calculate_price_indicators(self, current_candle: Dict[str, Any], 
                                   candles: List[Dict[str, Any]]) -> Dict[str, Any]:
        """محاسبه اندیکاتورهای قیمت"""
        indicators = {}
        
        try:
            # استخراج داده‌ها
            close_prices = np.array([c.get('close_price', 0) for c in candles])
            open_prices = np.array([c.get('open_price', 0) for c in candles])
            high_prices = np.array([c.get('high_price', 0) for c in candles])
            low_prices = np.array([c.get('low_price', 0) for c in candles])
            
            # تغییرات قیمت
            if len(close_prices) >= 2:
                prev_close = close_prices[-2]
                curr_close = close_prices[-1]
                indicators['price_change'] = float(curr_close - prev_close)
                indicators['price_change_percent'] = float(((curr_close - prev_close) / prev_close) * 100) if prev_close != 0 else 0.0
            
            # میانگین‌های متحرک
            indicators['ma_7'] = float(self._calculate_sma(close_prices, 7)) if len(close_prices) >= 7 else 0.0
            indicators['ma_25'] = float(self._calculate_sma(close_prices, 25)) if len(close_prices) >= 25 else 0.0
            indicators['ma_99'] = float(self._calculate_sma(close_prices, 99)) if len(close_prices) >= 99 else 0.0
            
            # باندهای بولینگر
            bb_upper, bb_middle, bb_lower = self._calculate_bollinger_bands(close_prices, 20)
            indicators['bollinger_upper'] = float(bb_upper) if bb_upper else 0.0
            indicators['bollinger_middle'] = float(bb_middle) if bb_middle else 0.0
            indicators['bollinger_lower'] = float(bb_lower) if bb_lower else 0.0
            
            # RSI
            indicators['rsi'] = float(self._calculate_rsi(close_prices, 14))
            
            # MACD
            macd, signal, histogram = self._calculate_macd(close_prices)
            indicators['macd'] = float(macd) if macd else 0.0
            indicators['macd_signal'] = float(signal) if signal else 0.0
            indicators['macd_histogram'] = float(histogram) if histogram else 0.0
            
            # ATR (Average True Range)
            indicators['atr'] = float(self._calculate_atr(high_prices, low_prices, close_prices, 14))
            
            # نوسان
            if len(close_prices) >= 20:
                volatility = np.std(close_prices[-20:]) / np.mean(close_prices[-20:]) if np.mean(close_prices[-20:]) != 0 else 0.0
                indicators['volatility'] = float(volatility)
            
            # قدرت روند (برای فیلد pattern)
            if len(close_prices) >= 50:
                short_ma = np.mean(close_prices[-10:])
                long_ma = np.mean(close_prices[-50:])
                if long_ma != 0:
                    trend_strength = abs((short_ma - long_ma) / long_ma) * 100
                    indicators['trend_strength'] = float(trend_strength)
            
        except Exception as e:
            logger.warning(f"خطا در محاسبه اندیکاتورهای قیمت: {e}")
        
        return indicators
    
    def _calculate_volume_indicators(self, current_candle: Dict[str, Any], 
                                   candles: List[Dict[str, Any]]) -> Dict[str, Any]:
        """محاسبه اندیکاتورهای حجم"""
        indicators = {}
        
        try:
            volumes = np.array([c.get('volume', 0) for c in candles])
            close_prices = np.array([c.get('close_price', 0) for c in candles])
            high_prices = np.array([c.get('high_price', 0) for c in candles])
            low_prices = np.array([c.get('low_price', 0) for c in candles])
            
            # میانگین حجم متحرک
            if len(volumes) >= 20:
                indicators['volume_ma_20'] = float(np.mean(volumes[-20:]))
            
            # نسبت حجم
            current_volume = current_candle.get('volume', 0)
            if len(volumes) >= 20 and np.mean(volumes[-20:]) != 0:
                indicators['volume_ratio'] = float(current_volume / np.mean(volumes[-20:]))
            
            # OBV (On-Balance Volume)
            indicators['obv'] = float(self._calculate_obv(close_prices, volumes))
            
            # حجم خریدار/فروشنده (تخمینی)
            if 'taker_buy_volume' in current_candle and 'taker_sell_volume' in current_candle:
                indicators['taker_buy_volume'] = float(current_candle.get('taker_buy_volume', 0))
                indicators['taker_sell_volume'] = float(current_candle.get('taker_sell_volume', 0))
            
            # حجم نقل‌قول (تخمینی)
            if 'quote_volume' in current_candle:
                indicators['quote_volume'] = float(current_candle.get('quote_volume', 0))
            else:
                # محاسبه تخمینی: حجم × قیمت میانگین
                avg_price = (current_candle.get('high_price', 0) + 
                           current_candle.get('low_price', 0) + 
                           current_candle.get('close_price', 0)) / 3
                indicators['quote_volume'] = float(current_candle.get('volume', 0) * avg_price)
            
        except Exception as e:
            logger.warning(f"خطا در محاسبه اندیکاتورهای حجم: {e}")
        
        return indicators
    
    def _calculate_technical_indicators(self, candles: List[Dict[str, Any]]) -> Dict[str, Any]:
        """محاسبه اندیکاتورهای تکنیکال پیچیده"""
        indicators = {}
        
        try:
            close_prices = np.array([c.get('close_price', 0) for c in candles])
            
            # شاخص قدرت نسبی (RSI)
            if len(close_prices) >= 14:
                indicators['rsi'] = float(self._calculate_rsi(close_prices, 14))
            
            # MACD کامل
            if len(close_prices) >= 26:
                macd, signal, histogram = self._calculate_macd(close_prices)
                if macd:
                    indicators['macd'] = float(macd)
                    indicators['macd_signal'] = float(signal)
                    indicators['macd_histogram'] = float(histogram)
            
        except Exception as e:
            logger.warning(f"خطا در محاسبه اندیکاتورهای تکنیکال: {e}")
        
        return indicators
    
    def _calculate_candle_patterns(self, candle: Dict[str, Any]) -> Dict[str, Any]:
        """تشخیص الگوهای کندلی"""
        indicators = {}
        
        try:
            open_price = candle.get('open_price', 0)
            close_price = candle.get('close_price', 0)
            high_price = candle.get('high_price', 0)
            low_price = candle.get('low_price', 0)
            body_size = abs(close_price - open_price)
            total_range = high_price - low_price
            
            # دوجی (Doji)
            is_doji = body_size <= (total_range * 0.1) if total_range > 0 else False
            indicators['is_doji'] = bool(is_doji)
            
            # چکش (Hammer)
            is_hammer = self._is_hammer_candle(candle)
            indicators['is_hammer'] = bool(is_hammer)
            
            # ستاره ثاقب (Shooting Star)
            is_shooting_star = self._is_shooting_star_candle(candle)
            indicators['is_shooting_star'] = bool(is_shooting_star)
            
            # نام الگوی کندلی
            pattern = self._detect_candle_pattern_name(candle)
            indicators['candle_pattern'] = pattern
            
        except Exception as e:
            logger.debug(f"خطا در تشخیص الگوهای کندلی: {e}")
        
        return indicators
    
    def _calculate_data_quality(self, candles: List[Dict[str, Any]]) -> Dict[str, Any]:
        """محاسبه کیفیت داده"""
        indicators = {}
        
        try:
            # شمارش داده‌های مفقود
            missing_count = 0
            total_fields = 0
            
            for candle in candles[-20:]:  # 20 کندل آخر
                for field in ['open_price', 'high_price', 'low_price', 'close_price', 'volume']:
                    total_fields += 1
                    if not candle.get(field):
                        missing_count += 1
            
            missing_percentage = (missing_count / total_fields * 100) if total_fields > 0 else 0
            
            indicators['missing_data_points'] = int(missing_count)
            indicators['data_quality'] = int(100 - missing_percentage)
            indicators['is_interpolated'] = bool(missing_count > 0)
            
        except Exception as e:
            logger.debug(f"خطا در محاسبه کیفیت داده: {e}")
        
        return indicators
    
    def _calculate_pattern_fields(self, current_candle: Dict[str, Any], 
                                 candles: List[Dict[str, Any]]) -> Dict[str, Any]:
        """محاسبه فیلدهای مربوط به Pattern (برای تکه ۴)"""
        indicators = {}
        
        try:
            # این فیلدها توسط PatternDetector در تکه ۴ پر می‌شوند
            # مقادیر پیش‌فرض
            indicators['pattern_markers'] = ''
            indicators['pattern_confidence'] = 0.0
            indicators['trend_strength'] = 0.0
            indicators['support_resistance_level'] = 0.0
            
            # محاسبه اولیه سطح حمایت/مقاومت
            close_prices = [c.get('close_price', 0) for c in candles[-50:]]
            if len(close_prices) >= 20:
                indicators['support_resistance_level'] = float(np.mean(close_prices[-20:]))
            
        except Exception as e:
            logger.debug(f"خطا در محاسبه فیلدهای Pattern: {e}")
        
        return indicators
    
    def _calculate_metadata(self, current_candle: Dict[str, Any]) -> Dict[str, Any]:
        """محاسبه متادیتا"""
        indicators = {}
        
        try:
            # تاریخ کندل (از open_time استخراج)
            open_time = current_candle.get('open_time')
            if open_time:
                try:
                    if isinstance(open_time, str):
                        # استخراج تاریخ
                        date_part = open_time.split(' ')[0] if ' ' in open_time else open_time.split('T')[0]
                        indicators['candle_date'] = date_part
                except:
                    pass
            
            # level تجمیع (پیش‌فرض: 1)
            indicators['aggregation_level'] = 1
            
            # تعداد معاملات (تخمینی)
            volume = current_candle.get('volume', 0)
            avg_trade_size = 1000  # تخمین میانگین سایز معامله
            indicators['number_of_trades'] = int(volume / avg_trade_size) if avg_trade_size > 0 else 0
            
        except Exception as e:
            logger.debug(f"خطا در محاسبه متادیتا: {e}")
        
        return indicators
    
    # ========== توابع کمکی محاسباتی ==========
    
    def _calculate_sma(self, prices: np.ndarray, period: int) -> float:
        """محاسبه میانگین متحرک ساده"""
        if len(prices) < period:
            return 0.0
        return float(np.mean(prices[-period:]))
    
    def _calculate_ema(self, prices: np.ndarray, period: int) -> float:
        """محاسبه میانگین متحرک نمایی"""
        if len(prices) < period:
            return 0.0
        
        try:
            weights = np.exp(np.linspace(-1., 0., period))
            weights /= weights.sum()
            
            ema = np.convolve(prices, weights, mode='valid')[:1]
            return float(ema[0]) if len(ema) > 0 else 0.0
        except:
            return float(np.mean(prices[-period:]))
    
    def _calculate_rsi(self, prices: np.ndarray, period: int = 14) -> float:
        """محاسبه شاخص قدرت نسبی"""
        if len(prices) < period + 1:
            return 50.0  # مقدار خنثی
        
        try:
            deltas = np.diff(prices)
            seed = deltas[:period+1]
            
            up = seed[seed >= 0].sum() / period
            down = -seed[seed < 0].sum() / period
            
            if down == 0:
                return 100.0
            
            rs = up / down
            rsi = 100.0 - (100.0 / (1.0 + rs))
            
            # محدود کردن بین 0 تا 100
            return max(0.0, min(100.0, float(rsi)))
        except:
            return 50.0
    
    def _calculate_macd(self, prices: np.ndarray) -> Tuple[Optional[float], Optional[float], Optional[float]]:
        """محاسبه MACD"""
        if len(prices) < 26:
            return None, None, None
        
        try:
            ema12 = self._calculate_ema(prices, 12)
            ema26 = self._calculate_ema(prices, 26)
            
            macd_line = ema12 - ema26
            
            # سیگنال (EMA 9 از MACD)
            if len(prices) >= 35:  # نیاز به داده بیشتر
                macd_values = []
                for i in range(9):
                    start_idx = max(0, len(prices) - 26 - i)
                    end_idx = len(prices) - i
                    if end_idx - start_idx >= 26:
                        segment = prices[start_idx:end_idx]
                        ema12_seg = self._calculate_ema(segment, 12)
                        ema26_seg = self._calculate_ema(segment, 26)
                        macd_values.append(ema12_seg - ema26_seg)
                
                if len(macd_values) >= 9:
                    signal_line = np.mean(macd_values[-9:])
                    histogram = macd_line - signal_line
                    return macd_line, signal_line, histogram
            
            return macd_line, 0.0, macd_line
        except:
            return None, None, None
    
    def _calculate_bollinger_bands(self, prices: np.ndarray, period: int = 20) -> Tuple[Optional[float], Optional[float], Optional[float]]:
        """محاسبه باندهای بولینگر"""
        if len(prices) < period:
            return None, None, None
        
        try:
            sma = np.mean(prices[-period:])
            std = np.std(prices[-period:])
            
            upper_band = sma + (std * 2)
            middle_band = sma
            lower_band = sma - (std * 2)
            
            return float(upper_band), float(middle_band), float(lower_band)
        except:
            return None, None, None
    
    def _calculate_atr(self, high_prices: np.ndarray, low_prices: np.ndarray, 
                      close_prices: np.ndarray, period: int = 14) -> float:
        """محاسبه Average True Range"""
        if len(high_prices) < period or len(low_prices) < period or len(close_prices) < period:
            return 0.0
        
        try:
            tr_values = []
            for i in range(1, min(len(high_prices), period + 1)):
                high_low = high_prices[-i] - low_prices[-i]
                high_close = abs(high_prices[-i] - close_prices[-i-1]) if i < len(close_prices) else 0
                low_close = abs(low_prices[-i] - close_prices[-i-1]) if i < len(close_prices) else 0
                
                true_range = max(high_low, high_close, low_close)
                tr_values.append(true_range)
            
            return float(np.mean(tr_values)) if tr_values else 0.0
        except:
            return 0.0
    
    def _calculate_obv(self, close_prices: np.ndarray, volumes: np.ndarray) -> float:
        """محاسبه On-Balance Volume"""
        if len(close_prices) < 2 or len(volumes) < 2:
            return 0.0
        
        try:
            obv = 0.0
            for i in range(1, min(len(close_prices), 100)):  # 100 کندل آخر
                if close_prices[-i] > close_prices[-i-1]:
                    obv += volumes[-i]
                elif close_prices[-i] < close_prices[-i-1]:
                    obv -= volumes[-i]
            
            return float(obv)
        except:
            return 0.0
    
    def _is_hammer_candle(self, candle: Dict[str, Any]) -> bool:
        """تشخیص کندل چکش"""
        try:
            open_price = candle.get('open_price', 0)
            close_price = candle.get('close_price', 0)
            high_price = candle.get('high_price', 0)
            low_price = candle.get('low_price', 0)
            
            body_size = abs(close_price - open_price)
            upper_shadow = high_price - max(open_price, close_price)
            lower_shadow = min(open_price, close_price) - low_price
            total_range = high_price - low_price
            
            if total_range == 0:
                return False
            
            # چکش: سایه پایینی حداقل ۲ برابر بدنه، سایه بالایی کوچک
            is_bullish_hammer = (lower_shadow >= body_size * 2 and 
                               upper_shadow <= body_size * 0.3)
            
            return is_bullish_hammer
        except:
            return False
    
    def _is_shooting_star_candle(self, candle: Dict[str, Any]) -> bool:
        """تشخیص کندل ستاره ثاقب"""
        try:
            open_price = candle.get('open_price', 0)
            close_price = candle.get('close_price', 0)
            high_price = candle.get('high_price', 0)
            low_price = candle.get('low_price', 0)
            
            body_size = abs(close_price - open_price)
            upper_shadow = high_price - max(open_price, close_price)
            lower_shadow = min(open_price, close_price) - low_price
            total_range = high_price - low_price
            
            if total_range == 0:
                return False
            
            # ستاره ثاقب: سایه بالایی حداقل ۲ برابر بدنه، سایه پایینی کوچک
            is_shooting_star = (upper_shadow >= body_size * 2 and 
                              lower_shadow <= body_size * 0.3)
            
            return is_shooting_star
        except:
            return False
    
    def _detect_candle_pattern_name(self, candle: Dict[str, Any]) -> str:
        """تشخیص نام الگوی کندلی"""
        try:
            if self._is_hammer_candle(candle):
                return "HAMMER"
            elif self._is_shooting_star_candle(candle):
                return "SHOOTING_STAR"
            elif self._is_doji_candle(candle):
                return "DOJI"
            else:
                return "NORMAL"
        except:
            return "UNKNOWN"
    
    def _is_doji_candle(self, candle: Dict[str, Any]) -> bool:
        """تشخیص کندل دوجی"""
        try:
            open_price = candle.get('open_price', 0)
            close_price = candle.get('close_price', 0)
            high_price = candle.get('high_price', 0)
            low_price = candle.get('low_price', 0)
            
            body_size = abs(close_price - open_price)
            total_range = high_price - low_price
            
            if total_range == 0:
                return False
            
            return body_size <= (total_range * 0.1)
        except:
            return False
    
    def _get_default_indicators(self, current_candle: Dict[str, Any]) -> Dict[str, Any]:
        """مقادیر پیش‌فرض وقتی داده کافی نیست"""
        indicators = {}
        
        # قیمت‌های اصلی
        indicators['price_change'] = 0.0
        indicators['price_change_percent'] = 0.0
        
        # میانگین‌های متحرک
        close_price = current_candle.get('close_price', 0)
        indicators['ma_7'] = float(close_price)
        indicators['ma_25'] = float(close_price)
        indicators['ma_99'] = float(close_price)
        
        # باندهای بولینگر
        indicators['bollinger_upper'] = float(close_price)
        indicators['bollinger_middle'] = float(close_price)
        indicators['bollinger_lower'] = float(close_price)
        
        # RSI خنثی
        indicators['rsi'] = 50.0
        
        # MACD
        indicators['macd'] = 0.0
        indicators['macd_signal'] = 0.0
        indicators['macd_histogram'] = 0.0
        
        # ATR و نوسان
        indicators['atr'] = 0.0
        indicators['volatility'] = 0.0
        
        # حجم
        indicators['volume_ma_20'] = float(current_candle.get('volume', 0))
        indicators['volume_ratio'] = 1.0
        indicators['obv'] = 0.0
        
        # الگوهای کندلی
        indicators['is_doji'] = False
        indicators['is_hammer'] = False
        indicators['is_shooting_star'] = False
        indicators['candle_pattern'] = "NORMAL"
        
        # کیفیت داده
        indicators['data_quality'] = 100
        indicators['is_interpolated'] = False
        indicators['missing_data_points'] = 0
        
        # Pattern fields
        indicators['pattern_markers'] = ''
        indicators['pattern_confidence'] = 0.0
        indicators['trend_strength'] = 0.0
        indicators['support_resistance_level'] = float(close_price)
        
        # متادیتا
        indicators['aggregation_level'] = 1
        indicators['number_of_trades'] = 0
        indicators['candle_date'] = ''
        
        # حجم‌ها
        indicators['quote_volume'] = 0.0
        indicators['taker_buy_volume'] = 0.0
        indicators['taker_sell_volume'] = 0.0
        
        return indicators

# Singleton برای استفاده آسان
calculator = IndicatorCalculator()