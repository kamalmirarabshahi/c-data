"""
complete_candle_indicators_fixed.py
اسکریپت اصلاح شده با مدیریت صحیح connection در threadها
"""

import sqlite3
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from typing import List, Dict, Tuple, Optional, Any
import logging
from pathlib import Path
import warnings
import json
import time
from dataclasses import dataclass
import threading
from queue import Queue
from tqdm import tqdm
import multiprocessing as mp

# تنظیمات لاگ‌گیری
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(f'indicators_log_{datetime.now().strftime("%Y%m%d_%H%M%S")}.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# غیرفعال کردن هشدارهای pandas
warnings.filterwarnings('ignore', category=UserWarning)
warnings.filterwarnings('ignore', message=".*doesn't match format.*")

# Lock برای thread-safe بودن
db_lock = threading.Lock()

@dataclass
class CoinProgress:
    """کلاس برای ذخیره پیشرفت هر ارز"""
    coin_id: int
    symbol: str
    timeframe: str
    total_candles: int = 0
    processed_candles: int = 0
    failed_candles: int = 0
    indicators_calculated: int = 0
    existing_indicators: int = 0
    start_time: datetime = None
    end_time: datetime = None
    status: str = "pending"  # pending, processing, completed, failed
    error_message: str = None
    
    @property
    def duration(self) -> float:
        """محاسبه مدت زمان پردازش"""
        if self.start_time and self.end_time:
            return (self.end_time - self.start_time).total_seconds()
        return 0.0
    
    @property
    def completion_rate(self) -> float:
        """نرخ تکمیل"""
        if self.total_candles == 0:
            return 0.0
        return (self.processed_candles / self.total_candles) * 100
    
    @property
    def success_rate(self) -> float:
        """نرخ موفقیت"""
        if self.processed_candles == 0:
            return 0.0
        return ((self.processed_candles - self.failed_candles) / self.processed_candles) * 100
    
    def to_dict(self) -> Dict[str, Any]:
        """تبدیل به دیکشنری"""
        return {
            'coin_id': self.coin_id,
            'symbol': self.symbol,
            'timeframe': self.timeframe,
            'total_candles': self.total_candles,
            'processed_candles': self.processed_candles,
            'failed_candles': self.failed_candles,
            'indicators_calculated': self.indicators_calculated,
            'existing_indicators': self.existing_indicators,
            'completion_rate': round(self.completion_rate, 2),
            'success_rate': round(self.success_rate, 2),
            'duration_seconds': round(self.duration, 2),
            'status': self.status,
            'error_message': self.error_message
        }


class DatabaseManager:
    """مدیریت اتصال به دیتابیس به صورت thread-safe"""
    
    def __init__(self, db_path: str):
        self.db_path = db_path
        self._local = threading.local()
    
    def get_connection(self):
        """دریافت connection برای thread فعلی"""
        if not hasattr(self._local, 'connection'):
            self._local.connection = sqlite3.connect(self.db_path)
            self._local.connection.row_factory = sqlite3.Row
            # تنظیمات بهینه‌سازی
            self._local.connection.execute("PRAGMA busy_timeout = 5000")
            self._local.connection.execute("PRAGMA journal_mode = WAL")
            self._local.connection.execute("PRAGMA synchronous = NORMAL")
            self._local.connection.execute("PRAGMA cache_size = -2000")  # 2MB cache
        
        return self._local.connection
    
    def close_all_connections(self):
        """بستن تمام connections"""
        if hasattr(self._local, 'connection'):
            self._local.connection.close()
            del self._local.connection


class IndicatorWorker:
    """Worker برای پردازش هر ارز"""
    
    def __init__(self, db_path: str):
        self.db_path = db_path
        self.db_manager = DatabaseManager(db_path)
        self.batch_size = 500
        self.min_candles = 50
    
    def smart_date_parser(self, date_series: pd.Series) -> pd.Series:
        """تبدیل هوشمند تاریخ"""
        if date_series.empty:
            return pd.Series([], dtype='datetime64[ns]')
        
        try:
            # ابتدا سعی کن با format='mixed' تبدیل کن
            return pd.to_datetime(date_series, errors='coerce', format='mixed', dayfirst=False)
        except Exception:
            # اگر نشد، با infer تبدیل کن
            return pd.to_datetime(date_series, errors='coerce')
    
    def get_candles_by_coin_timeframe(self, coin_id: int, timeframe: str) -> pd.DataFrame:
        """دریافت کندل‌های یک ارز"""
        query = """
        SELECT 
            k.*,
            c.symbol,
            c.base_asset
        FROM crypto_klines k
        JOIN crypto_coins c ON k.coin_id = c.id
        WHERE k.coin_id = ? AND k.timeframe = ?
        ORDER BY k.open_time
        """
        
        try:
            conn = self.db_manager.get_connection()
            df = pd.read_sql_query(query, conn, params=(coin_id, timeframe))
            
            if df.empty:
                return df
            
            # تبدیل تاریخ‌ها
            date_columns = ['open_time', 'close_time']
            for col in date_columns:
                if col in df.columns:
                    df[col] = self.smart_date_parser(df[col])
            
            # حذف رکوردهای بدون تاریخ معتبر
            df = df.dropna(subset=['open_time', 'close_time'])
            
            # مرتب‌سازی مجدد
            if not df.empty:
                df = df.sort_values('open_time').reset_index(drop=True)
            
            return df
            
        except Exception as e:
            logger.error(f"خطا در دریافت داده‌های coin_id={coin_id}: {e}")
            return pd.DataFrame()
    
    def calculate_indicators(self, df: pd.DataFrame) -> pd.DataFrame:
        """محاسبه اندیکاتورها"""
        if df.empty or len(df) < 20:
            return df
        
        result = df.copy()
        
        # اطمینان از ترتیب زمانی
        result = result.sort_values('open_time').reset_index(drop=True)
        prices = result['close_price'].astype(float)
        
        # محاسبه تغییرات قیمت
        result['price_change'] = result['close_price'] - result['open_price']
        result['price_change_percent'] = np.where(
            result['open_price'] != 0,
            (result['price_change'] / result['open_price']) * 100,
            0
        )
        
        # محاسبه RSI
        delta = prices.diff()
        gain = (delta.where(delta > 0, 0)).rolling(window=14, min_periods=1).mean()
        loss = (-delta.where(delta < 0, 0)).rolling(window=14, min_periods=1).mean()
        rs = gain / loss
        result['rsi'] = 100 - (100 / (1 + rs))
        
        # محاسبه MACD
        ema_fast = prices.ewm(span=12, adjust=False).mean()
        ema_slow = prices.ewm(span=26, adjust=False).mean()
        result['macd'] = ema_fast - ema_slow
        result['macd_signal'] = result['macd'].ewm(span=9, adjust=False).mean()
        result['macd_histogram'] = result['macd'] - result['macd_signal']
        
        # محاسبه باندهای بولینگر
        window = 20
        sma = prices.rolling(window=window, min_periods=1).mean()
        std = prices.rolling(window=window, min_periods=1).std()
        result['bollinger_upper'] = sma + (std * 2)
        result['bollinger_middle'] = sma
        result['bollinger_lower'] = sma - (std * 2)
        
        # محاسبه میانگین‌های متحرک
        result['ma_7'] = prices.rolling(window=7, min_periods=1).mean()
        result['ma_25'] = prices.rolling(window=25, min_periods=1).mean()
        result['ma_99'] = prices.rolling(window=99, min_periods=1).mean()
        
        # محاسبه میانگین حجم
        result['volume_ma_20'] = result['volume'].rolling(window=20, min_periods=1).mean()
        
        # محاسبه ATR
        high = result['high_price'].astype(float)
        low = result['low_price'].astype(float)
        close = result['close_price'].astype(float)
        
        tr1 = high - low
        tr2 = abs(high - close.shift())
        tr3 = abs(low - close.shift())
        tr = pd.concat([tr1, tr2, tr3], axis=1).max(axis=1)
        result['atr'] = tr.rolling(window=14, min_periods=1).mean()
        
        # محاسبه نوسان
        returns = prices.pct_change()
        result['volatility'] = returns.rolling(window=20, min_periods=1).std() * np.sqrt(252)
        
        # محاسبه نسبت حجم
        result['volume_ratio'] = result['volume'] / result['volume_ma_20'].replace(0, np.nan)
        
        # محاسبه OBV
        price_diff = prices.diff()
        volume = result['volume'].astype(float)
        obv = np.zeros(len(result))
        if len(result) > 0:
            obv[0] = volume.iloc[0]
        
        for i in range(1, len(result)):
            if price_diff.iloc[i] > 0:
                obv[i] = obv[i-1] + volume.iloc[i]
            elif price_diff.iloc[i] < 0:
                obv[i] = obv[i-1] - volume.iloc[i]
            else:
                obv[i] = obv[i-1]
        
        result['obv'] = obv
        
        # تشخیص الگوهای کندلی
        def detect_pattern(row):
            try:
                open_price = float(row['open_price'])
                close = float(row['close_price'])
                high = float(row['high_price'])
                low = float(row['low_price'])
                
                body_size = abs(close - open_price)
                upper_shadow = high - max(open_price, close)
                lower_shadow = min(open_price, close) - low
                total_range = high - low
                
                if total_range == 0:
                    return 'NORMAL'
                
                body_ratio = body_size / total_range
                
                # دوجی
                if body_ratio < 0.1:
                    return 'DOJI'
                
                # چکش / مرد دارآویز
                if lower_shadow > 2 * body_size and upper_shadow < 0.1 * total_range:
                    return 'HAMMER' if close > open_price else 'HANGING_MAN'
                
                # ستاره ثاقب / چکش معکوس
                if upper_shadow > 2 * body_size and lower_shadow < 0.1 * total_range:
                    return 'INVERTED_HAMMER' if close > open_price else 'SHOOTING_STAR'
                
                return 'NORMAL'
            except:
                return 'NORMAL'
        
        result['candle_pattern'] = result.apply(detect_pattern, axis=1)
        result['is_doji'] = (result['candle_pattern'] == 'DOJI').astype(int)
        result['is_hammer'] = result['candle_pattern'].isin(['HAMMER', 'INVERTED_HAMMER']).astype(int)
        result['is_shooting_star'] = result['candle_pattern'].isin(['SHOOTING_STAR', 'HANGING_MAN']).astype(int)
        
        # کیفیت داده
        result['data_quality'] = 100
        
        return result
    
    def batch_update_indicators(self, df: pd.DataFrame, coin_progress: CoinProgress) -> Tuple[int, int]:
        """بروزرسانی دسته‌ای اندیکاتورها"""
        if df.empty:
            return 0, 0
        
        processed = 0
        failed = 0
        
        # تبدیل به لیست برای اجرای دسته‌ای
        update_data = []
        for _, row in df.iterrows():
            try:
                update_data.append((
                    float(row['rsi']) if not pd.isna(row['rsi']) else None,
                    float(row['macd']) if not pd.isna(row['macd']) else None,
                    float(row['macd_signal']) if not pd.isna(row['macd_signal']) else None,
                    float(row['macd_histogram']) if not pd.isna(row['macd_histogram']) else None,
                    float(row['bollinger_upper']) if not pd.isna(row['bollinger_upper']) else None,
                    float(row['bollinger_middle']) if not pd.isna(row['bollinger_middle']) else None,
                    float(row['bollinger_lower']) if not pd.isna(row['bollinger_lower']) else None,
                    float(row['ma_7']) if not pd.isna(row['ma_7']) else None,
                    float(row['ma_25']) if not pd.isna(row['ma_25']) else None,
                    float(row['ma_99']) if not pd.isna(row['ma_99']) else None,
                    float(row['volume_ma_20']) if not pd.isna(row['volume_ma_20']) else None,
                    float(row['price_change']) if not pd.isna(row['price_change']) else None,
                    float(row['price_change_percent']) if not pd.isna(row['price_change_percent']) else None,
                    float(row['atr']) if not pd.isna(row['atr']) else None,
                    float(row['volatility']) if not pd.isna(row['volatility']) else None,
                    float(row['volume_ratio']) if not pd.isna(row['volume_ratio']) else None,
                    float(row['obv']) if not pd.isna(row['obv']) else None,
                    row['candle_pattern'],
                    int(row['is_doji']),
                    int(row['is_hammer']),
                    int(row['is_shooting_star']),
                    int(row['data_quality']),
                    int(row['id'])
                ))
            except Exception as e:
                logger.debug(f"خطا در آماده‌سازی داده‌های row {row.get('id', 'unknown')}: {e}")
                failed += 1
        
        # اجرای دستور UPDATE دسته‌ای
        if update_data:
            update_query = """
            UPDATE crypto_klines
            SET 
                rsi = ?,
                macd = ?,
                macd_signal = ?,
                macd_histogram = ?,
                bollinger_upper = ?,
                bollinger_middle = ?,
                bollinger_lower = ?,
                ma_7 = ?,
                ma_25 = ?,
                ma_99 = ?,
                volume_ma_20 = ?,
                price_change = ?,
                price_change_percent = ?,
                atr = ?,
                volatility = ?,
                volume_ratio = ?,
                obv = ?,
                candle_pattern = ?,
                is_doji = ?,
                is_hammer = ?,
                is_shooting_star = ?,
                data_quality = ?,
                updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
            """
            
            try:
                conn = self.db_manager.get_connection()
                cursor = conn.cursor()
                
                # اجرای دسته‌ای
                cursor.executemany(update_query, update_data)
                conn.commit()
                
                processed = len(update_data)
                
                # آمار اندیکاتورهای محاسبه شده
                indicators_calculated = sum(
                    1 for row in update_data 
                    if any(x is not None for x in row[:17])
                )
                coin_progress.indicators_calculated = indicators_calculated
                
            except Exception as e:
                logger.error(f"خطا در بروزرسانی دسته‌ای: {e}")
                conn.rollback()
                failed += len(update_data)
        
        return processed, failed
    
    def process_coin(self, coin_id: int, symbol: str, timeframe: str) -> CoinProgress:
        """پردازش یک ارز"""
        coin_progress = CoinProgress(
            coin_id=coin_id,
            symbol=symbol,
            timeframe=timeframe,
            start_time=datetime.now(),
            status="processing"
        )
        
        try:
            logger.debug(f"شروع پردازش {symbol} (coin_id={coin_id})")
            
            # دریافت داده‌ها
            df = self.get_candles_by_coin_timeframe(coin_id, timeframe)
            
            if df.empty:
                coin_progress.status = "completed"
                coin_progress.end_time = datetime.now()
                coin_progress.error_message = "هیچ داده‌ای یافت نشد"
                return coin_progress
            
            coin_progress.total_candles = len(df)
            
            # بررسی کندل‌های موجود با اندیکاتور
            if 'rsi' in df.columns and 'macd' in df.columns:
                existing_mask = df['rsi'].notna() & df['macd'].notna()
                coin_progress.existing_indicators = existing_mask.sum()
            
            # اگر تمام کندل‌ها اندیکاتور دارند
            if coin_progress.existing_indicators == coin_progress.total_candles:
                coin_progress.processed_candles = coin_progress.total_candles
                coin_progress.status = "completed"
                coin_progress.end_time = datetime.now()
                logger.debug(f"{symbol}: تمام کندل‌ها از قبل اندیکاتور دارند")
                return coin_progress
            
            # اگر داده کافی نیست
            if coin_progress.total_candles < self.min_candles:
                coin_progress.status = "completed"
                coin_progress.end_time = datetime.now()
                coin_progress.error_message = f"داده کافی نیست ({coin_progress.total_candles})"
                return coin_progress
            
            # محاسبه اندیکاتورها
            df_with_indicators = self.calculate_indicators(df)
            
            # بروزرسانی در دیتابیس
            processed, failed = self.batch_update_indicators(df_with_indicators, coin_progress)
            
            coin_progress.processed_candles = processed
            coin_progress.failed_candles = failed
            coin_progress.status = "completed"
            coin_progress.end_time = datetime.now()
            
            logger.debug(f"{symbol}: پردازش {processed} کندل")
            
        except Exception as e:
            coin_progress.status = "failed"
            coin_progress.end_time = datetime.now()
            coin_progress.error_message = str(e)
            logger.error(f"خطا در پردازش {symbol}: {e}")
        
        return coin_progress


class OptimizedIndicatorCalculator:
    """کلاس اصلی برای محاسبه اندیکاتورها"""
    
    def __init__(self, db_path: str):
        self.db_path = db_path
        self.progress_data: Dict[str, CoinProgress] = {}
        self.db_manager = DatabaseManager(db_path)
    
    def get_coins_to_process(self) -> List[Tuple[int, str, str]]:
        """دریافت لیست ارزهایی که نیاز به محاسبه دارند"""
        query = """
        SELECT DISTINCT 
            k.coin_id, 
            k.timeframe,
            c.symbol,
            COUNT(k.id) as candle_count,
            SUM(CASE WHEN k.rsi IS NULL OR k.macd IS NULL THEN 1 ELSE 0 END) as missing_count
        FROM crypto_klines k
        JOIN crypto_coins c ON k.coin_id = c.id
        WHERE c.is_active = 1
        GROUP BY k.coin_id, k.timeframe
        HAVING missing_count > 0
        ORDER BY candle_count DESC, missing_count DESC
        """
        
        try:
            conn = self.db_manager.get_connection()
            cursor = conn.cursor()
            cursor.execute(query)
            results = cursor.fetchall()
            
            coins_to_process = []
            for coin_id, timeframe, symbol, candle_count, missing_count in results:
                if candle_count >= 50:  # فقط ارزهای با حداقل 50 کندل
                    coins_to_process.append((coin_id, symbol, timeframe))
            
            logger.info(f"تعداد ارزهای نیازمند پردازش: {len(coins_to_process)}")
            return coins_to_process
            
        except Exception as e:
            logger.error(f"خطا در دریافت لیست ارزها: {e}")
            return []
    
    def process_coins_sequential(self):
        """پردازش ترتیبی ارزها (برای اطمینان از صحت)"""
        coins_to_process = self.get_coins_to_process()
        
        if not coins_to_process:
            logger.info("✅ هیچ ارزی نیاز به محاسبه اندیکاتور ندارد!")
            return
        
        logger.info(f"شروع پردازش ترتیبی {len(coins_to_process)} ارز...")
        
        # ایجاد worker
        worker = IndicatorWorker(self.db_path)
        
        # پردازش هر ارز
        for coin_id, symbol, timeframe in tqdm(coins_to_process, desc="پردازش ارزها"):
            progress_key = f"{coin_id}_{timeframe}"
            
            try:
                # پردازش ارز
                coin_progress = worker.process_coin(coin_id, symbol, timeframe)
                self.progress_data[progress_key] = coin_progress
                
                # گزارش هر 10 ارز
                if len(self.progress_data) % 10 == 0:
                    completed = sum(1 for p in self.progress_data.values() if p.status == "completed")
                    logger.info(f"پردازش شده: {completed}/{len(self.progress_data)} ارز")
                    
            except Exception as e:
                logger.error(f"خطا در پردازش {symbol}: {e}")
                self.progress_data[progress_key] = CoinProgress(
                    coin_id=coin_id,
                    symbol=symbol,
                    timeframe=timeframe,
                    status="failed",
                    error_message=str(e)
                )
    
    def generate_detailed_report(self) -> Dict[str, Any]:
        """تولید گزارش جامع"""
        # جمع‌آوری آمار
        total_coins = len(self.progress_data)
        completed_coins = sum(1 for p in self.progress_data.values() if p.status == "completed")
        failed_coins = sum(1 for p in self.progress_data.values() if p.status == "failed")
        
        # آمار کندل‌ها
        total_candles = sum(p.total_candles for p in self.progress_data.values())
        processed_candles = sum(p.processed_candles for p in self.progress_data.values())
        failed_candles = sum(p.failed_candles for p in self.progress_data.values())
        
        # توزیع درصد تکمیل
        completion_groups = {
            "100% (کامل)": 0,
            "80-100%": 0,
            "50-80%": 0,
            "0-50%": 0,
            "بدون داده": 0
        }
        
        for progress in self.progress_data.values():
            if progress.total_candles == 0:
                completion_groups["بدون داده"] += 1
            elif progress.completion_rate >= 99.9:
                completion_groups["100% (کامل)"] += 1
            elif progress.completion_rate >= 80:
                completion_groups["80-100%"] += 1
            elif progress.completion_rate >= 50:
                completion_groups["50-80%"] += 1
            else:
                completion_groups["0-50%"] += 1
        
        # ارزهای کامل
        fully_completed = []
        partially_completed = []
        failed_coins_list = []
        
        for progress in self.progress_data.values():
            coin_info = progress.to_dict()
            if progress.completion_rate >= 99.9:
                fully_completed.append(coin_info)
            elif progress.status == "failed":
                failed_coins_list.append(coin_info)
            else:
                partially_completed.append(coin_info)
        
        # گزارش نهایی
        report = {
            "metadata": {
                "generated_at": datetime.now().isoformat(),
                "total_execution_time": sum(p.duration for p in self.progress_data.values()),
                "database_path": self.db_path
            },
            "summary": {
                "total_coins_processed": total_coins,
                "completed_successfully": completed_coins,
                "failed": failed_coins,
                "total_candles": total_candles,
                "processed_candles": processed_candles,
                "failed_candles": failed_candles,
                "overall_completion_rate": round((processed_candles / total_candles * 100) if total_candles > 0 else 0, 2),
                "overall_success_rate": round(((processed_candles - failed_candles) / processed_candles * 100) if processed_candles > 0 else 0, 2)
            },
            "completion_distribution": completion_groups,
            "fully_completed_coins_count": len(fully_completed),
            "partially_completed_coins_count": len(partially_completed),
            "failed_coins_count": len(failed_coins_list),
            "fully_completed_coins": fully_completed[:50],  # فقط 50 تا اول
            "detailed_progress": [p.to_dict() for p in self.progress_data.values()]
        }
        
        return report
    
    def save_report(self, report: Dict[str, Any]):
        """ذخیره گزارش در فایل"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        
        # گزارش JSON کامل
        json_file = f"indicators_complete_report_{timestamp}.json"
        with open(json_file, 'w', encoding='utf-8') as f:
            json.dump(report, f, ensure_ascii=False, indent=2, default=str)
        
        # گزارش متنی خلاصه
        txt_file = f"indicators_summary_{timestamp}.txt"
        with open(txt_file, 'w', encoding='utf-8') as f:
            f.write("=" * 70 + "\n")
            f.write("گزارش جامع محاسبه اندیکاتورها\n")
            f.write("=" * 70 + "\n\n")
            
            # خلاصه
            f.write("📊 خلاصه اجرا:\n")
            f.write("-" * 40 + "\n")
            f.write(f"تعداد کل ارزهای پردازش شده: {report['summary']['total_coins_processed']}\n")
            f.write(f"ارزهای با موفقیت کامل: {report['summary']['completed_successfully']}\n")
            f.write(f"ارزهای ناموفق: {report['summary']['failed']}\n")
            f.write(f"کل کندل‌ها: {report['summary']['total_candles']:,}\n")
            f.write(f"کندل‌های پردازش شده: {report['summary']['processed_candles']:,}\n")
            f.write(f"کندل‌های ناموفق: {report['summary']['failed_candles']:,}\n")
            f.write(f"نرخ تکمیل کلی: {report['summary']['overall_completion_rate']}%\n")
            f.write(f"نرخ موفقیت کلی: {report['summary']['overall_success_rate']}%\n\n")
            
            # توزیع درصد تکمیل
            f.write("📈 توزیع درصد تکمیل:\n")
            f.write("-" * 40 + "\n")
            for group, count in report['completion_distribution'].items():
                if report['summary']['total_coins_processed'] > 0:
                    percentage = (count / report['summary']['total_coins_processed']) * 100
                    f.write(f"{group}: {count} ارز ({percentage:.1f}%)\n")
                else:
                    f.write(f"{group}: {count} ارز\n")
            f.write("\n")
            
            # ارزهای کامل
            f.write(f"✅ ارزهای با تکمیل 100% ({report['fully_completed_coins_count']} ارز):\n")
            f.write("-" * 40 + "\n")
            if report['fully_completed_coins']:
                for coin in report['fully_completed_coins'][:20]:
                    f.write(f"• {coin['symbol']}: {coin['processed_candles']:,} کندل\n")
                if len(report['fully_completed_coins']) > 20:
                    f.write(f"... و {len(report['fully_completed_coins']) - 20} ارز دیگر\n")
            else:
                f.write("هیچ ارزی 100% تکمیل نیست\n")
            
            f.write("\n" + "=" * 70 + "\n")
            f.write(f"گزارش کامل در فایل JSON ذخیره شد: {json_file}\n")
        
        logger.info(f"گزارش JSON ذخیره شد: {json_file}")
        logger.info(f"گزارش متنی ذخیره شد: {txt_file}")
        
        return json_file, txt_file
    
    def print_summary(self, report: Dict[str, Any]):
        """نمایش خلاصه نتایج در کنسول"""
        print("\n" + "="*70)
        print("📊 خلاصه نتایج محاسبه اندیکاتورها")
        print("="*70)
        
        summary = report['summary']
        distribution = report['completion_distribution']
        
        print(f"\n✅ ارزهای با تکمیل 100%: {distribution['100% (کامل)']} ارز")
        print(f"📈 ارزهای 80-100% تکمیل: {distribution['80-100%']} ارز")
        print(f"⚠️  ارزهای 50-80% تکمیل: {distribution['50-80%']} ارز")
        print(f"❌ ارزهای زیر 50% تکمیل: {distribution['0-50%']} ارز")
        print(f"📭 ارزهای بدون داده: {distribution['بدون داده']} ارز")
        
        print(f"\n📊 آمار کلی:")
        print(f"   • کل ارزها: {summary['total_coins_processed']}")
        print(f"   • کل کندل‌ها: {summary['total_candles']:,}")
        print(f"   • کندل‌های پردازش شده: {summary['processed_candles']:,}")
        print(f"   • نرخ تکمیل: {summary['overall_completion_rate']}%")
        print(f"   • نرخ موفقیت: {summary['overall_success_rate']}%")
        
        # نمایش چند ارز کامل
        if report['fully_completed_coins']:
            print(f"\n🏆 نمونه‌ای از ارزهای کامل:")
            for i, coin in enumerate(report['fully_completed_coins'][:5], 1):
                print(f"   {i}. {coin['symbol']}: {coin['processed_candles']:,} کندل")
        
        print("\n" + "="*70)
    
    def run_calculation(self):
        """اجرای اصلی برنامه"""
        logger.info("شروع محاسبه اندیکاتورها")
        start_time = time.time()
        
        try:
            # پردازش ترتیبی (برای اطمینان از صحت)
            self.process_coins_sequential()
            
            # تولید گزارش
            if self.progress_data:
                report = self.generate_detailed_report()
                json_file, txt_file = self.save_report(report)
                self.print_summary(report)
                
                # زمان اجرا
                execution_time = time.time() - start_time
                logger.info(f"⏱️ زمان کل اجرا: {execution_time:.2f} ثانیه")
                logger.info(f"📁 گزارش‌ها ذخیره شدند:")
                logger.info(f"   • گزارش کامل: {json_file}")
                logger.info(f"   • گزارش خلاصه: {txt_file}")
            else:
                logger.info("هیچ ارزی پردازش نشد!")
            
        except Exception as e:
            logger.error(f"خطای کلی در اجرای برنامه: {e}")
            import traceback
            traceback.print_exc()
        
        finally:
            self.db_manager.close_all_connections()


def main():
    """تابع اصلی اجرا"""
    # مسیر دیتابیس
    db_path = "data/crypto_master.db"
    
    # بررسی وجود فایل دیتابیس
    if not Path(db_path).exists():
        logger.error(f"فایل دیتابیس یافت نشد: {db_path}")
        print(f"❌ فایل دیتابیس یافت نشد: {db_path}")
        return
    
    # نمایش اطلاعات اولیه
    print("\n" + "="*70)
    print("🔧 برنامه محاسبه اندیکاتورها - نسخه اصلاح شده")
    print("="*70)
    
    # ایجاد نمونه کلاس
    calculator = OptimizedIndicatorCalculator(db_path)
    
    # بررسی وضعیت فعلی
    try:
        # ایجاد connection موقت برای بررسی
        temp_conn = sqlite3.connect(db_path)
        cursor = temp_conn.cursor()
        
        # تعداد کل کندل‌ها
        cursor.execute("SELECT COUNT(*) FROM crypto_klines")
        total_candles = cursor.fetchone()[0]
        
        # تعداد کندل‌های فاقد اندیکاتور
        cursor.execute("""
            SELECT COUNT(*) FROM crypto_klines
            WHERE rsi IS NULL OR macd IS NULL
        """)
        missing_indicators = cursor.fetchone()[0]
        
        # تعداد ارزهای فعال
        cursor.execute("SELECT COUNT(*) FROM crypto_coins WHERE is_active = 1")
        active_coins = cursor.fetchone()[0]
        
        temp_conn.close()
        
        print(f"\n📊 وضعیت فعلی دیتابیس:")
        print(f"   • تعداد کل کندل‌ها: {total_candles:,}")
        print(f"   • کندل‌های فاقد اندیکاتور: {missing_indicators:,}")
        print(f"   • ارزهای فعال: {active_coins}")
        
        if missing_indicators == 0:
            print("\n✅ تمام کندل‌ها اندیکاتورهایشان محاسبه شده است!")
            return
        
        completion_rate = ((total_candles - missing_indicators) / total_candles) * 100
        print(f"   • درصد تکمیل فعلی: {completion_rate:.2f}%")
        
    except Exception as e:
        logger.error(f"خطا در بررسی وضعیت: {e}")
    
    # درخواست تأیید
    print("\n" + "-"*40)
    confirm = input("آیا می‌خواهید محاسبه اندیکاتورها را شروع کنید؟ (y/n): ")
    
    if confirm.lower() != 'y':
        print("❌ عملیات لغو شد.")
        return
    
    # شروع پردازش
    print("\n🚀 شروع محاسبه اندیکاتورها...")
    print("این عملیات ممکن است چند دقیقه طول بکشد.")
    print("لطفاً صبر کنید...\n")
    
    # اجرای محاسبات
    calculator.run_calculation()


if __name__ == "__main__":
    main()