"""
فایل: cycle_01_coin_filter.py
مسیر: /cycle/cycle_01_coin_filter.py
عملکرد: دریافت تمام ارزهای فعال، فیلتر و تقسیم به بخش‌های رندوم
تاریخ: 2024-01-15
ورژن: 1.5 (استفاده از project_root از تنظیمات)
"""

import os
import sys
import sqlite3
import random
import json
import time
from datetime import datetime
from pathlib import Path

# ==================== CONFIGURATION ====================
def load_config():
    """بارگذاری تنظیمات از config_manager"""
    try:
        # اضافه کردن مسیرهای لازم به sys.path
        current_dir = os.path.dirname(os.path.abspath(__file__))
        scripts_dir = os.path.dirname(current_dir)
        project_root_default = os.path.dirname(scripts_dir)
        
        # اول scripts_dir را اضافه کنیم
        if scripts_dir not in sys.path:
            sys.path.insert(0, scripts_dir)
        
        # سپس project_root_default را اضافه کنیم
        if project_root_default not in sys.path:
            sys.path.insert(0, project_root_default)
        
        print(f"📁 پوشه اسکریپت: {scripts_dir}")
        print(f"📁 ریشه پروژه پیش‌فرض: {project_root_default}")
        
        # import config_manager
        try:
            from config_manager import get, get_database_path
        except ImportError as e:
            return {"success": False, "error": f"خطا در import config_manager: {str(e)}"}
        
        # خواندن project_root از تنظیمات
        project_root = get('paths.project_root', project_root_default)
        
        # اگر مسیر نسبی است، آن را مطلق کنیم
        if not os.path.isabs(project_root):
            project_root = os.path.abspath(project_root)
        
        # اطمینان از فرمت صحیح مسیر
        project_root = project_root.replace('\\', '/')
        
        config = {
            "database_path": get_database_path(),
            "min_block_size": get('collection.min_block_size', 10),
            "max_block_size": get('collection.max_block_size', 50),
            "min_volume_usd": get('filters.min_volume_usd', 100000),
            "min_price": get('filters.min_price', 0.001),
            "active_days": get('filters.active_days', 30),
            "project_root": project_root
        }
        
        # ایجاد پوشه state در ریشه پروژه (از تنظیمات)
        state_dir = os.path.join(project_root, "state")
        os.makedirs(state_dir, exist_ok=True)
        
        config["state_file"] = os.path.join(state_dir, "cycle_state.json")
        
        print(f"✅ project_root از تنظیمات: {project_root}")
        print(f"📁 پوشه state: {state_dir}")
        print(f"📁 فایل state: {config['state_file']}")
        
        return {"success": True, "config": config}
        
    except Exception as e:
        return {"success": False, "error": f"خطا در بارگذاری تنظیمات: {str(e)}"}

# ==================== DATABASE FUNCTIONS ====================
def get_all_active_coins(db_path):
    """دریافت تمام ارزهای فعال از دیتابیس"""
    try:
        if not os.path.exists(db_path):
            return {"success": False, "error": f"فایل دیتابیس یافت نشد: {db_path}"}
        
        conn = sqlite3.connect(db_path)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        
        # بررسی وجود جدول crypto_coins
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='crypto_coins'")
        if not cursor.fetchone():
            conn.close()
            return {"success": False, "error": "جدول crypto_coins وجود ندارد"}
        
        # دریافت آمار کلی
        cursor.execute("SELECT COUNT(*) as total_coins FROM crypto_coins")
        total_coins = cursor.fetchone()[0]
        
        # دریافت تمام ارزهای فعال (با قیمت مثبت)
        query = """
        SELECT 
            id, symbol, base_asset, coin_name,
            current_price, volume_24h, market_cap,
            price_change_24h, price_change_percent_24h,
            high_24h, low_24h, market_cap_rank,
            last_updated, created_at
        FROM crypto_coins
        WHERE current_price > 0 AND is_active < 5
        ORDER BY last_updated ASC, market_cap_rank, symbol
        """
        
        cursor.execute(query)
        
        all_active_coins = []
        for row in cursor.fetchall():
            coin_dict = dict(row)
            coin_dict['volume_24h'] = coin_dict.get('volume_24h', 0)
            coin_dict['current_price'] = coin_dict.get('current_price', 0)
            coin_dict['name'] = coin_dict.get('coin_name', coin_dict.get('symbol', 'Unknown'))
            coin_dict['is_active'] = 1
            all_active_coins.append(coin_dict)
        
        conn.close()
        
        return {
            "success": True, 
            "all_active_coins": all_active_coins,
            "total_coins_in_db": total_coins,
            "active_coins_count": len(all_active_coins),
            "count": len(all_active_coins)
        }
        
    except sqlite3.Error as e:
        return {"success": False, "error": f"خطای دیتابیس: {str(e)}"}
    except Exception as e:
        return {"success": False, "error": f"خطای ناشناخته: {str(e)}"}

def apply_filters(coins, filters):
    """اعمال فیلترها بر روی لیست ارزها"""
    try:
        filtered_coins = []
        
        for coin in coins:
            volume_ok = coin.get('volume_24h', 0) >= filters["min_volume_usd"]
            price_ok = coin.get('current_price', 0) >= filters["min_price"]
            
            if volume_ok and price_ok:
                filtered_coins.append(coin)
        
        return filtered_coins
        
    except Exception as e:
        print(f"⚠️ خطا در اعمال فیلترها: {e}")
        return coins

# ==================== BLOCK CREATION ====================
def create_random_blocks(coins, min_size, max_size):
    """ایجاد بلوک‌های رندوم از ارزها"""
    try:
        if not coins:
            return {"success": False, "error": "لیست ارزها خالی است"}
        
        total_coins = len(coins)
        blocks = []
        remaining_coins = coins.copy()
        
        random.shuffle(remaining_coins)
        
        print(f"   🔄 ایجاد بلوک‌ها از {total_coins} ارز...")
        
        block_number = 1
        while remaining_coins:
            current_max = min(max_size, len(remaining_coins))
            if current_max < min_size:
                block_size = len(remaining_coins)
            else:
                block_size = random.randint(min_size, current_max)
            
            # ایجاد بلوک
            block_coins = remaining_coins[:block_size]
            remaining_coins = remaining_coins[block_size:]
            
            # محاسبه آمار بلوک
            total_volume = sum(coin.get('volume_24h', 0) for coin in block_coins)
            avg_price = sum(coin.get('current_price', 0) for coin in block_coins) / len(block_coins) if block_coins else 0
            
            blocks.append({
                "block_id": block_number,
                "coins": block_coins,
                "size": len(block_coins),
                "symbols": [coin['symbol'] for coin in block_coins],
                "total_volume": total_volume,
                "avg_price": avg_price,
                "created_at": datetime.now().isoformat()
            })
            
            block_number += 1
        
        return {"success": True, "blocks": blocks, "total_blocks": len(blocks)}
        
    except Exception as e:
        return {"success": False, "error": f"خطا در ایجاد بلوک‌ها: {str(e)}"}

# ==================== STATE MANAGEMENT ====================
def save_cycle_state(state_file, state_data):
    """ذخیره وضعیت چرخه فعلی"""
    try:
        # اطمینان از وجود پوشه parent
        state_dir = os.path.dirname(state_file)
        if state_dir and not os.path.exists(state_dir):
            os.makedirs(state_dir, exist_ok=True)
            
        with open(state_file, 'w', encoding='utf-8') as f:
            json.dump(state_data, f, indent=2, ensure_ascii=False)
        
        print(f"   ✅ وضعیت در {state_file} ذخیره شد")
        return True
    except Exception as e:
        print(f"   ❌ خطا در ذخیره وضعیت: {e}")
        return False

# ==================== MAIN FUNCTION ====================
def run_coin_filter():
    """
    تابع اصلی: دریافت تمام ارزهای فعال، فیلتر و تقسیم به بلوک‌های رندوم
    """
    print("=" * 70)
    print("🔄 تکه 01: سیستم فیلتر و تقسیم ارزها")
    print("=" * 70)
    
    start_time = time.time()
    
    # 1. بارگذاری تنظیمات
    print("\n1️⃣ بارگذاری تنظیمات...")
    config_result = load_config()
    if not config_result["success"]:
        print(f"❌ {config_result['error']}")
        return config_result
    
    config = config_result["config"]
    print(f"   ✅ تنظیمات بارگذاری شد")
    print(f"   📁 دیتابیس: {Path(config['database_path']).name}")
    print(f"   📦 اندازه بلوک‌ها: {config['min_block_size']}-{config['max_block_size']}")
    print(f"   🎯 فیلتر حجم: >= ${config['min_volume_usd']:,}")
    print(f"   💰 فیلتر قیمت: >= ${config['min_price']}")
    
    # 2. دریافت تمام ارزهای فعال
    print("\n2️⃣ دریافت تمام ارزهای فعال از دیتابیس...")
    coins_result = get_all_active_coins(config["database_path"])
    if not coins_result["success"]:
        print(f"❌ {coins_result['error']}")
        return coins_result
    
    all_active_coins = coins_result["all_active_coins"]
    total_coins_in_db = coins_result["total_coins_in_db"]
    active_coins_count = coins_result["active_coins_count"]
    
    print(f"   📊 آمار دیتابیس:")
    print(f"      - کل ارزها در دیتابیس: {total_coins_in_db}")
    print(f"      - ارزهای فعال (با قیمت > 0): {active_coins_count}")
    print(f"      - ارزهای فعال دریافت شده: {len(all_active_coins)}")
    
    if len(all_active_coins) == 0:
        print("❌ هیچ ارز فعالی در دیتابیس وجود ندارد")
        return {"success": False, "error": "هیچ ارز فعالی یافت نشد"}
    
    # نمایش نمونه‌ای از ارزها
    if all_active_coins:
        print(f"\n   📄 نمونه ارزها:")
        for i, coin in enumerate(all_active_coins[:3]):
            print(f"      {i+1}. {coin['symbol']:10s} - قیمت: ${coin.get('current_price', 0):,.2f} - حجم: ${coin.get('volume_24h', 0):,.0f}")
        if len(all_active_coins) > 3:
            print(f"      ... و {len(all_active_coins) - 3} ارز دیگر")
    
    # 3. اعمال فیلترها
    print("\n3️⃣ اعمال فیلترها...")
    filters = {
        "min_volume_usd": config["min_volume_usd"],
        "min_price": config["min_price"]
    }
    
    filtered_coins = apply_filters(all_active_coins, filters)
    
    print(f"   📊 نتیجه فیلتر:")
    print(f"      - ارزهای قبل از فیلتر: {len(all_active_coins)}")
    print(f"      - ارزهای بعد از فیلتر: {len(filtered_coins)}")
    print(f"      - حذف شده: {len(all_active_coins) - len(filtered_coins)}")
    
    # نمایش برخی آمار فیلتر شده‌ها
    if filtered_coins:
        # محاسبه آمار کلی
        total_volume = sum(coin.get('volume_24h', 0) for coin in filtered_coins)
        avg_price = sum(coin.get('current_price', 0) for coin in filtered_coins) / len(filtered_coins)
        
        print(f"   📈 آمار ارزهای فیلتر شده:")
        print(f"      - حجم کل 24h: ${total_volume:,.0f}")
        print(f"      - میانگین قیمت: ${avg_price:.4f}")
        
        # نمایش نمونه‌ای از ارزهای فیلتر شده
        print(f"\n   📄 نمونه ارزهای فیلتر شده:")
        for i, coin in enumerate(filtered_coins[:5]):
            market_rank = coin.get('market_cap_rank', 9999)
            rank_str = f"رتبه {market_rank}" if market_rank != 9999 else "بدون رتبه"
            print(f"      {i+1}. {coin['symbol']:10s} - {rank_str:12s} - قیمت: ${coin.get('current_price', 0):,.2f}")
    
    # 4. ایجاد بلوک‌های رندوم
    print("\n4️⃣ ایجاد بلوک‌های رندوم...")
    blocks_result = create_random_blocks(
        filtered_coins,
        config["min_block_size"],
        config["max_block_size"]
    )
    
    if not blocks_result["success"]:
        print(f"❌ {blocks_result['error']}")
        return blocks_result
    
    blocks = blocks_result["blocks"]
    total_blocks = blocks_result["total_blocks"]
    
    print(f"   ✅ {total_blocks} بلوک ایجاد شد")
    
    # نمایش خلاصه بلوک‌ها
    if blocks:
        print(f"\n   📦 ساختار بلوک‌ها:")
        total_coins_in_blocks = sum(block['size'] for block in blocks)
        print(f"      - کل ارزها در بلوک‌ها: {total_coins_in_blocks}")
        if total_blocks > 0:
            avg_block_size = total_coins_in_blocks // total_blocks
            print(f"      - میانگین اندازه بلوک: {avg_block_size}")
        
        print(f"\n   📊 جزئیات بلوک‌ها:")
        for block in blocks[:5]:
            if block['symbols']:
                first_coin = block['symbols'][0]
                last_coin = block['symbols'][-1]
                volume_str = f"${block['total_volume']:,.0f}" if block['total_volume'] > 0 else "نامشخص"
                print(f"      بلوک {block['block_id']:2d}: {block['size']:3d} ارز - "
                      f"{first_coin:12s} تا {last_coin:12s} - حجم: {volume_str}")
        
        if total_blocks > 5:
            print(f"      ... و {total_blocks - 5} بلوک دیگر")
    
    # 5. ایجاد وضعیت چرخه
    print("\n5️⃣ ایجاد وضعیت چرخه...")
    cycle_id = f"cycle_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
    
    cycle_state = {
        "cycle_id": cycle_id,
        "start_time": datetime.now().isoformat(),
        "stats": {
            "total_coins_in_db": total_coins_in_db,
            "active_coins_before_filter": len(all_active_coins),
            "active_coins_after_filter": len(filtered_coins),
            "removed_by_filters": len(all_active_coins) - len(filtered_coins),
            "total_blocks": total_blocks,
            "total_coins_in_blocks": total_coins_in_blocks
        },
        "filters_applied": filters,
        "current_block": 1,
        "completed_blocks": [],
        "pending_blocks": [block["block_id"] for block in blocks],
        "blocks": blocks,
        "status": "running",
        "config": {
            "project_root": config["project_root"],
            "state_file": config["state_file"],
            "database_path": config["database_path"]
        }
    }
    
    # ذخیره وضعیت
    if save_cycle_state(config["state_file"], cycle_state):
        print(f"   ✅ وضعیت در {config['state_file']} ذخیره شد")
    else:
        print(f"   ⚠️ خطا در ذخیره وضعیت")
    
    # 6. نتیجه نهایی
    execution_time = time.time() - start_time
    print("\n" + "=" * 70)
    print("📋 نتیجه تکه 01:")
    print("-" * 70)
    print(f"   🆔 شناسه چرخه: {cycle_state['cycle_id']}")
    print(f"   🕒 زمان شروع: {cycle_state['start_time'][11:19]}")
    print(f"   ⏱️  زمان اجرا: {execution_time:.2f} ثانیه")
    print(f"\n   📊 آمار ارزها:")
    print(f"      - کل ارزها در دیتابیس: {cycle_state['stats']['total_coins_in_db']}")
    print(f"      - ارزهای فعال (قبل از فیلتر): {cycle_state['stats']['active_coins_before_filter']}")
    print(f"      - ارزهای فعال (بعد از فیلتر): {cycle_state['stats']['active_coins_after_filter']}")
    print(f"      - حذف شده توسط فیلتر: {cycle_state['stats']['removed_by_filters']}")
    print(f"\n   📦 آمار بلوک‌ها:")
    print(f"      - تعداد بلوک‌ها: {cycle_state['stats']['total_blocks']}")
    print(f"      - کل ارزها در بلوک‌ها: {cycle_state['stats']['total_coins_in_blocks']}")
    print(f"      - بلوک فعلی: {cycle_state['current_block']}")
    
    print("\n🔗 اطلاعات برای تکه بعدی:")
    if blocks and blocks[0]['symbols']:
        print(f"   - بلوک فعلی: {cycle_state['current_block']}")
        print(f"   - ارزهای این بلوک: {blocks[0]['size']}")
        print(f"   - اولین ارز بلوک: {blocks[0]['symbols'][0]}")
    
    print("\n💡 دستور بعدی:")
    print("   'python scripts/cycle/cycle_02_process_block.py'")
    print("=" * 70)
    
    return {
        "success": True,
        "cycle_state": cycle_state,
        "message": f"تکه 01 کامل شد. {len(filtered_coins)} ارز در {total_blocks} بلوک سازماندهی شدند."
    }

# ==================== EXECUTION ====================
if __name__ == "__main__":
    result = run_coin_filter()
    
    # خروجی مناسب برای خط فرمان
    if result["success"]:
        print(f"\n✅ {result['message']}")
        if result['cycle_state']['stats']['total_blocks'] > 0:
            print(f"📌 مرحله بعد: پردازش بلوک 1 از {result['cycle_state']['stats']['total_blocks']}")
            print(f"🚀 دستور: python scripts/cycle/cycle_02_process_block.py")
        else:
            print(f"⚠️ هشدار: هیچ بلوکی برای پردازش ایجاد نشد")
    else:
        print(f"\n❌ خطا: {result.get('error', 'خطای ناشناخته')}")
        sys.exit(1)