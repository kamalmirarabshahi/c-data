"""
بررسی وضعیت چرخه جمع‌آوری داده‌ها
"""

import json
import sqlite3
from pathlib import Path
import sys

def get_project_root():
    """دریافت مسیر ریشه پروژه"""
    return Path(__file__).parent.parent.parent

def check_database():
    """بررسی دیتابیس"""
    root = get_project_root()
    db_path = root / "data" / "crypto_master.db"
    
    if not db_path.exists():
        print("❌ دیتابیس پیدا نشد!")
        return False
    
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # بررسی جداول
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
        tables = cursor.fetchall()
        
        print(f"✅ دیتابیس پیدا شد: {db_path}")
        print(f"📊 تعداد جداول: {len(tables)}")
        
        # نمایش تعداد رکوردهای هر جدول
        for table in tables:
            table_name = table[0]
            cursor.execute(f"SELECT COUNT(*) FROM {table_name}")
            count = cursor.fetchone()[0]
            print(f"   - {table_name}: {count:,} رکورد")
        
        conn.close()
        return True
        
    except Exception as e:
        print(f"❌ خطا در بررسی دیتابیس: {e}")
        return False

def check_cycle_state():
    """بررسی وضعیت چرخه"""
    root = get_project_root()
    state_path = root / "state" / "cycle_state.json"
    
    if not state_path.exists():
        print("❌ فایل وضعیت چرخه پیدا نشد!")
        return False
    
    try:
        with open(state_path, 'r', encoding='utf-8') as f:
            state = json.load(f)
        
        print(f"\n📈 وضعیت چرخه:")
        print(f"   وضعیت: {state.get('status', 'نامشخص')}")
        print(f"   بلوک فعلی: {state.get('current_block', 0)} از {state.get('total_blocks', 0)}")
        print(f"   ارزهای پردازش شده: {state.get('total_coins_processed', 0)}")
        print(f"   زمان شروع: {state.get('start_time', 'نامشخص')}")
        
        # نمایش بلوک فعلی
        if 'current_block' in state:
            block_idx = state['current_block'] - 1
            blocks = state.get('blocks', [])
            if blocks and block_idx < len(blocks):
                current_block = blocks[block_idx]
                print(f"\n🎯 بلوک فعلی برای پردازش:")
                print(f"   بلوک #{state['current_block']}")
                print(f"   تعداد ارزها: {len(current_block)}")
                print(f"   اولین ارز: {current_block[0] if current_block else 'هیچ'}")
                print(f"   آخرین ارز: {current_block[-1] if current_block else 'هیچ'}")
        
        return True
        
    except Exception as e:
        print(f"❌ خطا در بررسی وضعیت چرخه: {e}")
        return False

def main():
    """تابع اصلی"""
    print("🔍 بررسی وضعیت پروژه جمع‌آوری داده‌های کریپتو\n")
    
    # بررسی دیتابیس
    db_ok = check_database()
    
    # بررسی وضعیت چرخه
    state_ok = check_cycle_state()
    
    print("\n" + "="*50)
    
    if db_ok and state_ok:
        print("✅ پروژه آماده اجرا است!")
        print("\n📌 دستور بعدی:")
        print("   python scripts/cycle/cycle_02_process_block.py")
    else:
        print("❌ برخی بررسی‌ها ناموفق بودند")
    
    print("="*50)

if __name__ == "__main__":
    main()