"""
فایل: cycle_03_technical_analysis.py
مسیر: /scripts/cycle/cycle_03_technical_analysis.py
عملکرد: تحلیل تکنیکال با استفاده از کلاس‌های اندیکاتور و DatabaseManager
نسخه: 5.0 - کاملاً ماژولار
"""

import os
import sys
import json
import time
from datetime import datetime
from pathlib import Path
from typing import List, Dict, Any, Optional

# ==================== ایمپورت ماژول‌های داخلی ====================
try:
    # اضافه کردن مسیرهای لازم
    current_dir = os.path.dirname(os.path.abspath(__file__))
    scripts_dir = os.path.dirname(current_dir)
    project_root = os.path.dirname(scripts_dir)
    
    if project_root not in sys.path:
        sys.path.insert(0, project_root)
    
    # ایمپورت DatabaseManager
    from database_manager import DatabaseManager
    
    # ایمپورت AnalysisDatabase
    from analysis_database import AnalysisDatabase
    
    # ایمپورت اندیکاتورها
    sys.path.insert(0, os.path.join(scripts_dir, "indicators"))
    from indicators.registry import IndicatorRegistry
    
    print("✅ تمام ماژول‌های مورد نیاز ایمپورت شدند")
    
except ImportError as e:
    print(f"❌ خطا در ایمپورت ماژول‌ها: {e}")
    print(f"📁 مسیر جاری: {current_dir}")
    sys.exit(1)

# ==================== CONFIGURATION ====================
def load_config():
    """بارگذاری تنظیمات از config_manager"""
    try:
        from config_manager import get, reload
        
        # بارگذاری مجدد تنظیمات
        reload()
        
        # دریافت مسیرها
        project_root = get('paths.project_root')
        database_path = get('database.path')
        
        if not database_path:
            data_dir = get('paths.data_dir', os.path.join(project_root, 'data'))
            database_name = get('database.name', 'crypto_master.db')
            database_path = os.path.join(data_dir, database_name)
        
        # دریافت تنظیمات تحلیل
        rsi_period = get('analysis.rsi_period', 14)
        macd_fast = get('analysis.macd_fast', 12)
        macd_slow = get('analysis.macd_slow', 26)
        macd_signal = get('analysis.macd_signal', 9)
        bollinger_period = get('analysis.bollinger_period', 20)
        bollinger_std = get('analysis.bollinger_std', 2)
        ma_periods = get('analysis.ma_periods', [5, 10, 20, 50])
        ema_periods = get('analysis.ema_periods', [12, 26])
        volume_period = get('analysis.volume_period', 20)
        
        # تنظیمات اجرایی
        timeframes = get('analysis.timeframes', ['5m'])
        if isinstance(timeframes, str):
            timeframes = [timeframes]
        
        config = {
            # مسیرها
            "project_root": project_root,
            "database_path": database_path,
            
            # تنظیمات اندیکاتورها
            "rsi_period": rsi_period,
            "macd_fast": macd_fast,
            "macd_slow": macd_slow,
            "macd_signal": macd_signal,
            "bollinger_period": bollinger_period,
            "bollinger_std": bollinger_std,
            "ma_periods": ma_periods,
            "ema_periods": ema_periods,
            "volume_period": volume_period,
            
            # تنظیمات اجرایی
            "timeframes": timeframes,
            "lookback_periods": get('analysis.lookback_periods', 200),
            "min_candles_for_analysis": get('analysis.min_candles_for_analysis', 50),
            "max_coins_per_batch": get('analysis.max_coins_per_batch', 10),
            
            # تنظیمات سیگنال
            "rsi_overbought": get('analysis.rsi_overbought', 70),
            "rsi_oversold": get('analysis.rsi_oversold', 30),
            "macd_threshold": get('analysis.macd_threshold', 0),
            "volume_threshold": get('analysis.volume_threshold', 1.5),
            
            # اطلاعات فایل‌ها
            "config_file": get('paths.config_file', 'config/settings.json')
        }
        
        # مسیر فایل state
        state_dir = get('paths.state_dir', os.path.join(project_root, "state"))
        config["state_file"] = os.path.join(state_dir, "cycle_state.json")
        
        print(f"✅ تنظیمات بارگذاری شد")
        print(f"📁 دیتابیس: {Path(config['database_path']).name}")
        print(f"📊 RSI دوره: {rsi_period}")
        print(f"📈 MACD: {macd_fast}/{macd_slow}/{macd_signal}")
        
        return {"success": True, "config": config}
        
    except Exception as e:
        return {"success": False, "error": f"خطا در بارگذاری تنظیمات: {str(e)}"}


# ==================== TECHNICAL ANALYSIS ENGINE ====================
class TechnicalAnalysisEngine:
    """موتور اصلی تحلیل تکنیکال"""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.db_helper = AnalysisDatabase(config['database_path'])
        self.indicator_registry = IndicatorRegistry(config)
    
    def analyze_coin(self, coin_id: int, symbol: str) -> Dict[str, Any]:
        """تحلیل کامل یک ارز"""
        print(f"\n   🔍 تحلیل {symbol} (ID: {coin_id})...")
        
        all_indicators_data = []
        
        # تحلیل برای هر تایم‌فریم
        for timeframe in self.config['timeframes']:
            # دریافت داده‌های کندل
            candles_result = self.db_helper.get_candles_for_analysis(
                coin_id, 
                timeframe, 
                self.config['lookback_periods']
            )
            
            if not candles_result['success']:
                print(f"      ⚠️ خطا در دریافت داده‌های {timeframe}: {candles_result.get('error')}")
                continue
            
            if candles_result['count'] < self.config['min_candles_for_analysis']:
                print(f"      ⚠️ داده‌های ناکافی برای {timeframe} ({candles_result['count']} کندل)")
                continue
            
            candles = candles_result['candles']
            print(f"      ⏰ {timeframe}: {len(candles)} کندل")
            
            # استخراج داده‌ها
            close_prices = [candle['close'] for candle in candles]
            volumes = [candle['volume'] for candle in candles]
            
            # محاسبه اندیکاتورها برای این تایم‌فریم
            indicators_for_timeframe = self._calculate_indicators_for_timeframe(
                coin_id, timeframe, candles, close_prices, volumes
            )
            
            all_indicators_data.extend(indicators_for_timeframe)
        
        return {
            "success": True,
            "symbol": symbol,
            "coin_id": coin_id,
            "indicators_count": len(all_indicators_data),
            "indicators": all_indicators_data
        }
    
    def _calculate_indicators_for_timeframe(self, coin_id: int, timeframe: str,
                                          candles: List[Dict], 
                                          close_prices: List[float],
                                          volumes: List[float]) -> List[Dict[str, Any]]:
        """محاسبه اندیکاتورها برای یک تایم‌فریم خاص"""
        indicators_data = []
        
        try:
            # دریافت اندیکاتورها از رجیستری
            rsi_indicator = self.indicator_registry.get_indicator('rsi')
            macd_indicator = self.indicator_registry.get_indicator('macd')
            bollinger_indicator = self.indicator_registry.get_indicator('bollinger')
            volume_indicator = self.indicator_registry.get_indicator('volume')
            
            # محاسبه اندیکاتورها
            rsi_values = rsi_indicator.calculate_history(close_prices)
            macd_line, macd_signal, macd_histogram = macd_indicator.calculate_history(close_prices)
            bb_upper, bb_middle, bb_lower = bollinger_indicator.calculate_history(close_prices)
            volume_ma = volume_indicator.calculate_history(volumes)
            
            # محاسبه میانگین‌های متحرک
            sma_indicators = {}
            for period in self.config['ma_periods']:
                indicator_key = f'sma_{period}'
                sma_indicator = self.indicator_registry.get_indicator(indicator_key)
                if sma_indicator:
                    sma_indicators[period] = sma_indicator.calculate_history(close_prices)
            
            ema_indicators = {}
            for period in self.config['ema_periods']:
                indicator_key = f'ema_{period}'
                ema_indicator = self.indicator_registry.get_indicator(indicator_key)
                if ema_indicator:
                    ema_indicators[period] = ema_indicator.calculate_history(close_prices)
            
            # ایجاد رکورد برای هر کندل
            for i, candle in enumerate(candles):
                # محاسبه سیگنال
                signal_score, signal_hint = self._calculate_signal_score(
                    rsi_values[i] if i < len(rsi_values) else None,
                    macd_histogram[i] if i < len(macd_histogram) else None,
                    close_prices[i],
                    bb_upper[i] if i < len(bb_upper) else None,
                    bb_lower[i] if i < len(bb_lower) else None,
                    volume_ma[i] if i < len(volume_ma) else None,
                    volumes[i] if i < len(volumes) else None
                )
                
                # آماده‌سازی داده اندیکاتورها
                indicator_data = {
                    'coin_id': coin_id,
                    'timeframe': timeframe,
                    'timestamp': candle['close_time'],
                    'rsi_14': rsi_values[i] if i < len(rsi_values) else None,
                    'macd': macd_line[i] if i < len(macd_line) else None,
                    'macd_signal': macd_signal[i] if i < len(macd_signal) else None,
                    'macd_histogram': macd_histogram[i] if i < len(macd_histogram) else None,
                    'bollinger_upper': bb_upper[i] if i < len(bb_upper) else None,
                    'bollinger_middle': bb_middle[i] if i < len(bb_middle) else None,
                    'bollinger_lower': bb_lower[i] if i < len(bb_lower) else None,
                    'volume_ma_20': volume_ma[i] if i < len(volume_ma) else None,
                    'signal_score': signal_score,
                    'signal_hint': signal_hint
                }
                
                # اضافه کردن میانگین‌های متحرک
                for period, values in sma_indicators.items():
                    if i < len(values):
                        indicator_data[f'sma_{period}'] = values[i]
                
                for period, values in ema_indicators.items():
                    if i < len(values):
                        indicator_data[f'ema_{period}'] = values[i]
                
                indicators_data.append(indicator_data)
            
            # نمایش نمونه نتایج
            if indicators_data:
                last_result = indicators_data[-1]
                print(f"      📈 نتایج: RSI={last_result.get('rsi_14', 'N/A'):.1f}, "
                      f"MACD Hist={last_result.get('macd_histogram', 'N/A'):.4f}, "
                      f"سیگنال: {last_result.get('signal_hint', 'N/A')}")
            
        except Exception as e:
            print(f"      ❌ خطا در محاسبه اندیکاتورها برای {timeframe}: {e}")
        
        return indicators_data
    
    def _calculate_signal_score(self, rsi: Optional[float], 
                               macd_hist: Optional[float],
                               price: float,
                               bb_upper: Optional[float],
                               bb_lower: Optional[float],
                               volume_ma: Optional[float],
                               current_volume: Optional[float]) -> tuple:
        """محاسبه امتیاز و سیگنال"""
        score = 50  # نمره اولیه (خنثی)
        
        # 1. تحلیل RSI
        if rsi is not None:
            if rsi < self.config['rsi_oversold']:
                score += 25  # اشتباه تایپی اصلاح شد
            elif rsi > self.config['rsi_overbought']:
                score -= 25
            elif rsi < 50:
                score += 10
            elif rsi > 50:
                score -= 10
        
        # 2. تحلیل MACD
        if macd_hist is not None:
            if macd_hist > self.config['macd_threshold']:
                score += 20
            elif macd_hist < -self.config['macd_threshold']:
                score -= 20
        
        # 3. تحلیل باندهای بولینگر
        if bb_upper is not None and bb_lower is not None and bb_upper != bb_lower:
            position = (price - bb_lower) / (bb_upper - bb_lower)
            if position < 0.2:  # نزدیک باند پایین
                score += 20
            elif position > 0.8:  # نزدیک باند بالا
                score -= 20
        
        # 4. تحلیل حجم
        if volume_ma is not None and current_volume is not None and volume_ma > 0:
            volume_ratio = current_volume / volume_ma
            if volume_ratio > self.config['volume_threshold']:
                # اگر حجم بالا همراه با سیگنال مثبت باشد
                if score > 55:
                    score += 10
                elif score < 45:
                    score -= 10
        
        # محدود کردن نمره بین 0 تا 100
        score = max(0, min(100, score))
        
        # تعیین سیگنال
        if score >= 70:
            hint = "STRONG_BUY"
        elif score >= 55:
            hint = "BUY"
        elif score >= 45:
            hint = "NEUTRAL"
        elif score >= 30:
            hint = "SELL"
        else:
            hint = "STRONG_SELL"
        
        return score, hint


# ==================== STATE MANAGEMENT ====================
def load_cycle_state(state_file: str) -> Dict[str, Any]:
    """بارگذاری وضعیت چرخه"""
    try:
        if not os.path.exists(state_file):
            return {"success": False, "error": f"فایل وضعیت یافت نشد: {state_file}"}
        
        with open(state_file, 'r', encoding='utf-8') as f:
            state_data = json.load(f)
        
        print(f"✅ وضعیت چرخه بارگذاری شد: {state_data.get('cycle_id')}")
        return {"success": True, "state_data": state_data, "state_file": state_file}
        
    except Exception as e:
        return {"success": False, "error": f"خطا در بارگذاری وضعیت: {str(e)}"}


def save_cycle_state(state_file: str, state_data: Dict[str, Any]) -> bool:
    """ذخیره وضعیت چرخه"""
    try:
        state_dir = os.path.dirname(state_file)
        if state_dir and not os.path.exists(state_dir):
            os.makedirs(state_dir, exist_ok=True)
            
        with open(state_file, 'w', encoding='utf-8') as f:
            json.dump(state_data, f, indent=2, ensure_ascii=False)
        
        return True
    except Exception as e:
        print(f"❌ خطا در ذخیره وضعیت: {e}")
        return False


# ==================== MAIN PROCESSING ====================
def process_current_block_for_analysis(config: Dict[str, Any], 
                                       state_data: Dict[str, Any], 
                                       state_file: str) -> Dict[str, Any]:
    """پردازش بلوک فعلی برای تحلیل"""
    try:
        cycle_id = state_data['cycle_id']
        current_block = state_data['current_block']
        
        print(f"\n📦 تحلیل بلوک {current_block} از {len(state_data['blocks'])}...")
        
        # یافتن بلوک فعلی
        current_block_data = None
        for block in state_data['blocks']:
            if block['block_id'] == current_block:
                current_block_data = block
                break
        
        if not current_block_data:
            return {"success": False, "error": f"بلوک {current_block} یافت نشد"}
        
        symbols = current_block_data['symbols']
        block_size = len(symbols)
        
        print(f"💰 تعداد ارزها: {block_size}")
        print(f"📊 ارزهای این بلوک: {', '.join(symbols[:5])}{'...' if block_size > 5 else ''}")
        
        # ایجاد موتور تحلیل
        engine = TechnicalAnalysisEngine(config)
        db_helper = AnalysisDatabase(config['database_path'])
        
        # آمار
        total_analyzed = 0
        total_indicators = 0
        successful_coins = 0
        failed_coins = 0
        
        start_block_time = time.time()
        
        # پردازش هر ارز در بلوک
        for i, symbol in enumerate(symbols, 1):
            print(f"\n[{i}/{block_size}] 🔍 تحلیل {symbol}...")
            
            # دریافت شناسه ارز
            coin_result = db_helper.get_coin_id_from_symbol(symbol)
            if not coin_result["success"]:
                print(f"   ❌ ارز {symbol} در دیتابیس یافت نشد: {coin_result.get('error')}")
                failed_coins += 1
                continue
            
            coin_info = {
                'coin_id': coin_result["coin_id"],
                'symbol': coin_result["symbol"]
            }
            
            # تحلیل ارز با موتور
            analysis_result = engine.analyze_coin(coin_info['coin_id'], coin_info['symbol'])
            
            if analysis_result["success"] and analysis_result["indicators"]:
                # ذخیره نتایج در دیتابیس
                save_result = db_helper.save_indicators(analysis_result["indicators"])
                
                if save_result["success"]:
                    indicators_count = analysis_result["indicators_count"]
                    total_indicators += indicators_count
                    successful_coins += 1
                    
                    print(f"   ✅ تحلیل موفق - {indicators_count} اندیکاتور ذخیره شد "
                          f"(جدید: {save_result.get('inserted', 0)}, "
                          f"بروزرسانی: {save_result.get('updated', 0)})")
                else:
                    failed_coins += 1
                    print(f"   ⚠️ تحلیل انجام شد اما ذخیره نشد: {save_result.get('error')}")
            else:
                failed_coins += 1
                error_msg = analysis_result.get('error', 'هیچ داده‌ای تولید نشد')
                print(f"   ❌ تحلیل ناموفق: {error_msg}")
            
            total_analyzed += 1
            
            # تاخیر کوتاه برای جلوگیری از overload
            time.sleep(0.1)
        
        # محاسبه زمان پردازش
        block_time = time.time() - start_block_time
        
        # به‌روزرسانی وضعیت تحلیل
        if 'analysis_stats' not in state_data:
            state_data['analysis_stats'] = {}
        
        state_data['analysis_stats'][f'block_{current_block}'] = {
            'processed_at': datetime.now().isoformat(),
            'successful_coins': successful_coins,
            'failed_coins': failed_coins,
            'total_indicators': total_indicators,
            'processing_time': block_time,
            'avg_indicators_per_coin': total_indicators / successful_coins if successful_coins > 0 else 0
        }
        
        state_data['analysis_status'] = 'IN_PROGRESS'
        state_data['analysis_last_update'] = datetime.now().isoformat()
        
        # بررسی تکمیل بلوک و انتقال به بلوک بعدی
        if successful_coins + failed_coins == block_size:
            if current_block < len(state_data['blocks']):
                state_data['current_block'] = current_block + 1
                if 'analyzed_blocks' not in state_data:
                    state_data['analyzed_blocks'] = []
                state_data['analyzed_blocks'].append(current_block)
            else:
                state_data['analysis_status'] = 'COMPLETED'
                state_data['analysis_completed_at'] = datetime.now().isoformat()
        
        # ذخیره وضعیت به‌روز شده
        if save_cycle_state(state_file, state_data):
            print(f"✅ وضعیت تحلیل به‌روزرسانی شد")
        else:
            print(f"⚠️ خطا در ذخیره وضعیت به‌روزرسانی شده")
        
        return {
            "success": True,
            "block_id": current_block,
            "total_coins": block_size,
            "successful_coins": successful_coins,
            "failed_coins": failed_coins,
            "total_indicators": total_indicators,
            "block_time": block_time
        }
        
    except Exception as e:
        return {"success": False, "error": f"خطا در پردازش بلوک: {str(e)}"}


# ==================== MAIN FUNCTION ====================
def run_technical_analysis():
    """تابع اصلی اجرای تحلیل تکنیکال"""
    print("=" * 70)
    print("🔍 تکه 03: تحلیل تکنیکال (نسخه ماژولار کامل)")
    print("=" * 70)
    
    start_time = time.time()
    
    # 1. بارگذاری تنظیمات
    print("\n1️⃣ بارگذاری تنظیمات از config_manager...")
    config_result = load_config()
    if not config_result["success"]:
        print(f"❌ {config_result['error']}")
        return config_result
    
    config = config_result["config"]
    print(f"   ✅ تنظیمات بارگذاری شد")
    print(f"   📁 دیتابیس: {Path(config['database_path']).name}")
    
    # 2. بارگذاری وضعیت چرخه
    print("\n2️⃣ بارگذاری وضعیت چرخه...")
    state_result = load_cycle_state(config["state_file"])
    if not state_result["success"]:
        print(f"❌ {state_result['error']}")
        return state_result
    
    state_data = state_result["state_data"]
    state_file = state_result["state_file"]
    
    print(f"   ✅ چرخه: {state_data.get('cycle_id')}")
    print(f"   📊 بلوک فعلی: {state_data.get('current_block')}/{state_data['stats']['total_blocks']}")
    
    # 3. پردازش بلوک فعلی
    print("\n3️⃣ شروع تحلیل تکنیکال...")
    process_result = process_current_block_for_analysis(config, state_data, state_file)
    
    if not process_result["success"]:
        print(f"❌ {process_result['error']}")
        return process_result
    
    # 4. نتیجه نهایی
    execution_time = time.time() - start_time
    print("\n" + "=" * 70)
    print("📋 نتیجه تکه 03:")
    print("-" * 70)
    print(f"   🆔 چرخه: {state_data['cycle_id']}")
    print(f"   📦 بلوک تحلیل شده: {process_result['block_id']}")
    print(f"   ⏱️ زمان کل اجرا: {execution_time:.2f} ثانیه")
    print(f"   ⏱️ زمان تحلیل بلوک: {process_result.get('block_time', 0):.2f} ثانیه")
    print(f"\n   📊 آمار تحلیل:")
    print(f"      - کل ارزهای بلوک: {process_result['total_coins']}")
    print(f"      - ارزهای تحلیل موفق: {process_result['successful_coins']}")
    print(f"      - ارزهای تحلیل ناموفق: {process_result['failed_coins']}")
    print(f"      - اندیکاتورهای محاسبه شده: {process_result['total_indicators']}")
    
    # نمایش وضعیت تحلیل
    analysis_status = state_data.get('analysis_status', 'NOT_STARTED')
    analyzed_blocks = state_data.get('analyzed_blocks', [])
    total_blocks = state_data['stats']['total_blocks']
    next_block = state_data['current_block']
    
    print(f"\n   📈 وضعیت کلی تحلیل:")
    print(f"      - وضعیت: {analysis_status}")
    print(f"      - بلوک‌های تحلیل شده: {len(analyzed_blocks)}/{total_blocks}")
    
    # اطلاعات برای تکه بعدی
    print(f"\n🔗 اطلاعات برای تکه بعدی:")
    if analysis_status != 'COMPLETED' and next_block <= total_blocks:
        print(f"   - بلوک بعدی برای تحلیل: {next_block}")
        print(f"   - وضعیت: تحلیل ادامه دارد")
        
        print("\n💡 دستور بعدی:")
        print(f"   'python scripts/cycle/cycle_03_technical_analysis.py'")
    else:
        print(f"   🎉 تحلیل همه بلوک‌ها کامل شد!")
        print(f"   - وضعیت: آماده برای تولید سیگنال")
        
        print("\n💡 دستور بعدی:")
        print(f"   'برو به تکه 04: تولید سیگنال معاملاتی'")
    
    print("=" * 70)
    
    return {
        "success": True,
        "process_result": process_result,
        "next_block": next_block,
        "total_blocks": total_blocks,
        "analysis_status": analysis_status,
        "message": f"تحلیل بلوک {process_result['block_id']} انجام شد. {process_result['total_indicators']} اندیکاتور محاسبه شد."
    }


# ==================== EXECUTION ====================
if __name__ == "__main__":
    result = run_technical_analysis()
    
    if result["success"]:
        print(f"\n✅ {result['message']}")
        
        if result['analysis_status'] != 'COMPLETED' and result['next_block'] <= result['total_blocks']:
            print(f"📌 بلوک بعدی برای تحلیل: {result['next_block']} از {result['total_blocks']}")
            print(f"🚀 برای ادامه اجرا کنید: python scripts/cycle/cycle_03_technical_analysis.py")
        else:
            print(f"🎉 تحلیل تکنیکال کامل شد!")
            print(f"📊 مجموع اندیکاتورهای محاسبه شده: {result['process_result']['total_indicators']}")
            print(f"👉 مرحله بعد: تولید سیگنال معاملاتی")
    else:
        print(f"\n❌ خطا: {result.get('error', 'خطای ناشناخته')}")
        sys.exit(1)