"""
reports_framework.py
چارچوب آماده برای ساخت گزارش‌های متنوع از دیتابیس
"""

import sqlite3
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from typing import Dict, List, Tuple, Optional, Any, Union, Callable
import json
import logging
from abc import ABC, abstractmethod
from dataclasses import dataclass, asdict, field
from pathlib import Path
import warnings
from enum import Enum
import hashlib
import inspect

# ==================== IMPORTS ====================
try:
    from config_manager import get_config, get_database_path
    CONFIG_AVAILABLE = True
except ImportError:
    CONFIG_AVAILABLE = False
    warnings.warn("config_manager not found, using default values")
# =================================================

# ==================== LOGGING ====================
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)
# =================================================

# ==================== ENUMS & DATACLASSES ====================
class ReportType(Enum):
    """انواع گزارش‌های موجود"""
    SYSTEM_SUMMARY = "system_summary"
    MARKET_OVERVIEW = "market_overview"
    COIN_ANALYSIS = "coin_analysis"
    PERFORMANCE = "performance"
    TECHNICAL = "technical"
    FINANCIAL = "financial"
    DATA_QUALITY = "data_quality"
    CUSTOM = "custom"


@dataclass
class ReportConfig:
    """پیکربندی گزارش‌ها"""
    output_dir: str = "reports"
    templates_dir: str = "report_templates"
    charts_dir: str = "charts"
    default_formats: List[str] = field(default_factory=lambda: ['json', 'html'])
    top_n_coins: int = 20
    days_history: int = 30
    default_timeframe: str = "5m"
    database_path: str = None
    cache_enabled: bool = True
    cache_ttl_seconds: int = 300
    
    def __post_init__(self):
        if self.database_path is None and CONFIG_AVAILABLE:
            self.database_path = get_database_path()
        elif self.database_path is None:
            self.database_path = "data/crypto_master.db"
        
        for directory in [self.output_dir, self.templates_dir, self.charts_dir]:
            Path(directory).mkdir(parents=True, exist_ok=True)
# ==============================================================

# ==================== BASE CLASSES ====================
class ReportBase(ABC):
    """کلاس پایه برای تمام گزارش‌ها"""
    
    def __init__(self, reporter: 'DatabaseReporter'):
        self.reporter = reporter
        self.config = reporter.config
        self.logger = logging.getLogger(f"{__name__}.{self.__class__.__name__}")
    
    @abstractmethod
    def generate(self, **kwargs) -> Dict[str, Any]:
        """تولید گزارش - باید توسط کلاس‌های فرزند پیاده‌سازی شود"""
        pass
    
    @abstractmethod
    def get_name(self) -> str:
        """نام گزارش"""
        pass
    
    @abstractmethod
    def get_description(self) -> str:
        """توضیحات گزارش"""
        pass
    
    def validate_parameters(self, **kwargs) -> bool:
        """اعتبارسنجی پارامترهای ورودی"""
        return True
    
    def get_required_parameters(self) -> List[str]:
        """پارامترهای الزامی برای این گزارش"""
        return []
    
    def format_output(self, data: Dict[str, Any], format_type: str = 'json') -> Any:
        """فرمت‌دهی خروجی گزارش"""
        if format_type == 'json':
            return json.dumps(data, ensure_ascii=False, indent=2, default=str)
        elif format_type == 'dict':
            return data
        else:
            return str(data)
# ======================================================

# ==================== MAIN REPORTER CLASS ====================
class DatabaseReporter:
    """کلاس اصلی مدیریت و تولید گزارش‌ها"""
    
    def __init__(self, db_path: Optional[str] = None, config: Optional[ReportConfig] = None):
        self.config = config or ReportConfig()
        if db_path:
            self.config.database_path = db_path
        
        if not Path(self.config.database_path).exists():
            raise FileNotFoundError(f"Database file not found: {self.config.database_path}")
        
        self.conn = self._create_connection()
        self._reports: Dict[str, ReportBase] = {}
        self._cache: Dict[str, Tuple[datetime, Any]] = {}
        
        logger.info(f"DatabaseReporter initialized with database: {self.config.database_path}")
        self._register_builtin_reports()
    
    def _create_connection(self) -> sqlite3.Connection:
        """ایجاد اتصال به دیتابیس"""
        conn = sqlite3.connect(self.config.database_path)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode = WAL")
        conn.execute("PRAGMA synchronous = NORMAL")
        conn.execute("PRAGMA cache_size = -10000")
        return conn
    
    def _register_builtin_reports(self):
        """ثبت گزارش‌های پیش‌فرض"""
        self.register_report_class(SystemSummaryReport)
        self.register_report_class(MarketOverviewReport)
        self.register_report_class(DataQualityReport)
        # گزارش‌های جدید در اینجا اضافه می‌شوند
    
    def register_report(self, report: ReportBase):
        """ثبت یک گزارش جدید"""
        report_name = report.get_name()
        self._reports[report_name] = report
        self.logger.info(f"Report registered: {report_name}")
    
    def register_report_class(self, report_class, *args, **kwargs):
        """ثبت یک کلاس گزارش"""
        report_instance = report_class(self, *args, **kwargs)
        self.register_report(report_instance)
    
    def get_available_reports(self) -> List[Dict[str, str]]:
        """دریافت لیست گزارش‌های موجود"""
        reports_info = []
        for name, report in self._reports.items():
            reports_info.append({
                'name': name,
                'description': report.get_description(),
                'required_params': report.get_required_parameters()
            })
        return reports_info
    
    def generate_report(self, report_name: str, save: bool = True, 
                        formats: List[str] = None, **kwargs) -> Dict[str, Any]:
        """تولید یک گزارش"""
        if report_name not in self._reports:
            raise ValueError(f"Report '{report_name}' not found.")
        
        report = self._reports[report_name]
        cache_key = self._generate_cache_key(report_name, kwargs)
        
        # بررسی کش
        if self.config.cache_enabled and cache_key in self._cache:
            cached_time, cached_data = self._cache[cache_key]
            if (datetime.now() - cached_time).seconds < self.config.cache_ttl_seconds:
                self.logger.info(f"Using cached data for report: {report_name}")
                return cached_data
        
        # تولید گزارش
        self.logger.info(f"Generating report: {report_name}")
        start_time = datetime.now()
        
        try:
            result = report.generate(**kwargs)
            result['metadata'] = {
                'report_name': report_name,
                'generated_at': datetime.now().isoformat(),
                'generation_time_ms': round((datetime.now() - start_time).total_seconds() * 1000, 2),
                'cache_key': cache_key
            }
            
            # ذخیره در کش
            if self.config.cache_enabled:
                self._cache[cache_key] = (datetime.now(), result)
            
            # ذخیره در فایل
            if save:
                self._save_report(result, formats or self.config.default_formats)
            
            return result
            
        except Exception as e:
            self.logger.error(f"Error generating report '{report_name}': {e}")
            raise
    
    def _generate_cache_key(self, report_name: str, params: Dict) -> str:
        """تولید کلید کش"""
        params_str = json.dumps(params, sort_keys=True, default=str)
        key_string = f"{report_name}_{params_str}"
        return hashlib.md5(key_string.encode()).hexdigest()
    
    def _save_report(self, report_data: Dict[str, Any], formats: List[str]):
        """ذخیره گزارش در فایل"""
        report_name = report_data['metadata']['report_name']
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        
        for fmt in formats:
            if fmt == 'json':
                filename = Path(self.config.output_dir) / f"{report_name}_{timestamp}.json"
                with open(filename, 'w', encoding='utf-8') as f:
                    json.dump(report_data, f, ensure_ascii=False, indent=2, default=str)
                self.logger.info(f"Report saved as JSON: {filename}")
            
            elif fmt == 'html':
                filename = Path(self.config.output_dir) / f"{report_name}_{timestamp}.html"
                html_content = self._generate_html_report(report_data)
                with open(filename, 'w', encoding='utf-8') as f:
                    f.write(html_content)
                self.logger.info(f"Report saved as HTML: {filename}")
    
    def _generate_html_report(self, report_data: Dict[str, Any]) -> str:
        """تولید گزارش HTML"""
        # پیاده‌سازی ساده - می‌توانید کامل‌تر کنید
        report_name = report_data['metadata']['report_name']
        html = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <title>Report: {report_name}</title>
            <style>
                body {{ font-family: Arial, sans-serif; margin: 20px; }}
                .metadata {{ background-color: #f5f5f5; padding: 15px; border-radius: 5px; }}
                .section {{ margin: 20px 0; padding: 15px; border: 1px solid #ddd; border-radius: 5px; }}
            </style>
        </head>
        <body>
            <h1>Report: {report_name}</h1>
            <div class="metadata">
                <p><strong>Generated at:</strong> {report_data['metadata']['generated_at']}</p>
                <p><strong>Generation time:</strong> {report_data['metadata']['generation_time_ms']} ms</p>
            </div>
            <pre>{json.dumps(report_data, indent=2, ensure_ascii=False, default=str)}</pre>
        </body>
        </html>
        """
        return html
    
    def execute_query(self, query: str, params: tuple = None, use_cache: bool = False) -> List[Dict]:
        """اجرای کوئری SQL"""
        if use_cache and self.config.cache_enabled:
            cache_key = f"query_{hashlib.md5(query.encode()).hexdigest()}_{params}"
            if cache_key in self._cache:
                cached_time, cached_data = self._cache[cache_key]
                if (datetime.now() - cached_time).seconds < self.config.cache_ttl_seconds:
                    return cached_data
        
        try:
            cursor = self.conn.cursor()
            if params:
                cursor.execute(query, params)
            else:
                cursor.execute(query)
            
            columns = [col[0] for col in cursor.description]
            results = [dict(zip(columns, row)) for row in cursor.fetchall()]
            
            if use_cache and self.config.cache_enabled:
                self._cache[cache_key] = (datetime.now(), results)
            
            return results
            
        except Exception as e:
            self.logger.error(f"Query execution error: {e}")
            raise
    
    def get_dataframe(self, query: str, params: tuple = None) -> pd.DataFrame:
        """دریافت داده به صورت DataFrame"""
        try:
            if params:
                df = pd.read_sql_query(query, self.conn, params=params)
            else:
                df = pd.read_sql_query(query, self.conn)
            return df
        except Exception as e:
            self.logger.error(f"DataFrame error: {e}")
            raise
    
    def clear_cache(self):
        """پاک کردن کش"""
        self._cache.clear()
        self.logger.info("Cache cleared")
    
    def __enter__(self):
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
    
    def close(self):
        """بستن اتصال"""
        if self.conn:
            self.conn.close()
            self.logger.info("Database connection closed")
# ===============================================================

# ==================== BUILT-IN REPORTS ====================
class SystemSummaryReport(ReportBase):
    """گزارش خلاصه سیستم"""
    
    def get_name(self) -> str:
        return "system_summary"
    
    def get_description(self) -> str:
        return "خلاصه وضعیت سیستم و آمار کلی"
    
    def generate(self, **kwargs) -> Dict[str, Any]:
        query = """
        SELECT 
            (SELECT COUNT(*) FROM crypto_coins WHERE is_active = 1) as active_coins,
            (SELECT COUNT(*) FROM crypto_klines) as total_candles,
            (SELECT COUNT(DISTINCT coin_id) FROM crypto_klines) as coins_with_data,
            (SELECT COUNT(*) FROM trading_signals) as total_signals,
            (SELECT COUNT(*) FROM technical_indicators) as total_indicators,
            (SELECT MAX(open_time) FROM crypto_klines) as latest_candle_time
        """
        
        result = self.reporter.execute_query(query)[0]
        
        return {
            "report_type": self.get_name(),
            "data": result,
            "generated_at": datetime.now().isoformat()
        }


class MarketOverviewReport(ReportBase):
    """گزارش کلی بازار"""
    
    def get_name(self) -> str:
        return "market_overview"
    
    def get_description(self) -> str:
        return "بررسی کلی بازار و ارزهای برتر"
    
    def get_required_parameters(self) -> List[str]:
        return ["top_n"]
    
    def validate_parameters(self, **kwargs) -> bool:
        return 'top_n' in kwargs and isinstance(kwargs['top_n'], int)
    
    def generate(self, **kwargs) -> Dict[str, Any]:
        top_n = kwargs.get('top_n', self.config.top_n_coins)
        
        query = """
        SELECT 
            symbol, coin_name, current_price, price_change_percent_24h,
            volume_24h, market_cap, market_cap_rank
        FROM crypto_coins 
        WHERE is_active = 1
        ORDER BY volume_24h DESC
        LIMIT ?
        """
        
        results = self.reporter.execute_query(query, (top_n,))
        
        return {
            "report_type": self.get_name(),
            "top_n": top_n,
            "coins": results,
            "total_coins": len(results)
        }


class DataQualityReport(ReportBase):
    """گزارش کیفیت داده"""
    
    def get_name(self) -> str:
        return "data_quality"
    
    def get_description(self) -> str:
        return "بررسی کیفیت و کامل بودن داده‌ها"
    
    def generate(self, **kwargs) -> Dict[str, Any]:
        query = """
        SELECT 
            COUNT(*) as total_candles,
            SUM(CASE WHEN rsi IS NOT NULL THEN 1 ELSE 0 END) as with_rsi,
            SUM(CASE WHEN macd IS NOT NULL THEN 1 ELSE 0 END) as with_macd,
            SUM(CASE WHEN candle_pattern != 'NORMAL' THEN 1 ELSE 0 END) as special_patterns,
            ROUND(AVG(data_quality), 2) as avg_data_quality
        FROM crypto_klines
        """
        
        result = self.reporter.execute_query(query)[0]
        
        # محاسبه درصدها
        if result['total_candles'] > 0:
            result['rsi_completion_percent'] = round(
                (result['with_rsi'] / result['total_candles']) * 100, 2
            )
            result['macd_completion_percent'] = round(
                (result['with_macd'] / result['total_candles']) * 100, 2
            )
        
        return {
            "report_type": self.get_name(),
            "quality_metrics": result,
            "generated_at": datetime.now().isoformat()
        }
# =========================================================

# ==================== SECTION FOR NEW REPORTS ====================
# ================================================================
#  📝 📝 📝 📝 📝 📝 📝 📝 📝 📝 📝 📝 📝 📝 📝 📝 📝 📝 📝 📝 
#  این بخش برای اضافه کردن گزارش‌های جدید است!
#  گزارش‌های جدید خود را در اینجا کپی کنید
#  📝 📝 📝 📝 📝 📝 📝 📝 📝 📝 📝 📝 📝 📝 📝 📝 📝 📝 📝 📝 
# ================================================================
# 
#  نحوه اضافه کردن گزارش جدید:
#  1. یک کلاس جدید ایجاد کنید که از ReportBase ارث‌بری کند
#  2. متدهای get_name، get_description و generate را پیاده‌سازی کنید
#  3. کلاس را در بخش پایین فایل register کنید
# 
#  مثال:
# 
#  class YourNewReport(ReportBase):
#      def get_name(self):
#          return "your_report_name"
#      
#      def get_description(self):
#          return "توضیحات گزارش شما"
#      
#      def generate(self, **kwargs):
#          # کد گزارش‌گیری شما
#          return {"data": "نتیجه گزارش"}
# 
#  سپس در DatabaseReporter._register_builtin_reports آن را register کنید:
#  self.register_report_class(YourNewReport)
# 
# ================================================================
# 🆕 🆕 🆕 🆕 🆕  گزارش‌های جدید از اینجا شروع می‌شوند 🆕 🆕 🆕 🆕 🆕
# ================================================================

# مثال: گزارش تحلیل تکنیکال
class TechnicalAnalysisReport(ReportBase):
    """گزارش تحلیل تکنیکال"""
    
    def get_name(self) -> str:
        return "technical_analysis"
    
    def get_description(self) -> str:
        return "تحلیل تکنیکال و سیگنال‌های بازار"
    
    def generate(self, **kwargs) -> Dict[str, Any]:
        # نمونه کد - می‌توانید تغییر دهید
        timeframe = kwargs.get('timeframe', self.config.default_timeframe)
        
        query = """
        SELECT 
            c.symbol,
            COUNT(k.id) as candle_count,
            AVG(k.rsi) as avg_rsi,
            AVG(k.volume) as avg_volume,
            SUM(CASE WHEN k.candle_pattern != 'NORMAL' THEN 1 ELSE 0 END) as special_patterns
        FROM crypto_klines k
        JOIN crypto_coins c ON k.coin_id = c.id
        WHERE k.timeframe = ?
        GROUP BY c.symbol
        HAVING candle_count > 100
        ORDER BY avg_volume DESC
        LIMIT 20
        """
        
        results = self.reporter.execute_query(query, (timeframe,))
        
        return {
            "report_type": self.get_name(),
            "timeframe": timeframe,
            "analysis": results,
            "generated_at": datetime.now().isoformat()
        }

# 🆕 گزارش جدید خود را اینجا اضافه کنید
# class YourReportName(ReportBase):
#     ...
# 
# ================================================================
# 🔚 🔚 🔚 🔚 🔚  پایان بخش گزارش‌های جدید 🔚 🔚 🔚 🔚 🔚
# ================================================================

# ==================== UTILITY FUNCTIONS ====================
def create_reporter(db_path: Optional[str] = None) -> DatabaseReporter:
    """تابع کمکی برای ایجاد گزارش‌گیر"""
    return DatabaseReporter(db_path)


def get_all_reports_info() -> List[Dict[str, str]]:
    """دریافت اطلاعات تمام گزارش‌های موجود"""
    with DatabaseReporter() as reporter:
        return reporter.get_available_reports()


def generate_quick_report(report_name: str, **kwargs) -> Dict[str, Any]:
    """تولید سریع یک گزارش"""
    with DatabaseReporter() as reporter:
        return reporter.generate_report(report_name, **kwargs)
# ============================================================

# ==================== MAIN & TEST ====================
if __name__ == "__main__":
    """تست ماژول"""
    
    # تست ساده
    try:
        # ایجاد گزارش‌گیر
        reporter = DatabaseReporter()
        
        # نمایش گزارش‌های موجود
        print("📋 گزارش‌های موجود:")
        for report in reporter.get_available_reports():
            print(f"  • {report['name']}: {report['description']}")
        
        # تولید یک گزارش نمونه
        print("\n🚀 تولید گزارش خلاصه سیستم...")
        summary = reporter.generate_report("system_summary", save=False)
        print(f"✅ گزارش تولید شد: {summary['metadata']['report_name']}")
        print(f"   زمان تولید: {summary['metadata']['generation_time_ms']}ms")
        
        # بستن اتصال
        reporter.close()
        
    except Exception as e:
        print(f"❌ خطا: {e}")
        import traceback
        traceback.print_exc()
# =====================================================