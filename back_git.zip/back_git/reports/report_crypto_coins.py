# report_crypto_coins.py
import sqlite3
import pandas as pd
from pathlib import Path
from datetime import datetime
import sys
import json

def generate_crypto_report(db_path, report_type=1):
    """
    تولید گزارش بر اساس نوع درخواستی
    
    پارامترها:
    ----------
    db_path : str
        مسیر فایل دیتابیس
    report_type : int
        نوع گزارش:
        1 = تمام ارزها
        2 = فقط is_active = 5
        3 = فقط is_active = 1,2,3,4
    
    بازگشت:
    -------
    dict
        دیکشنری حاوی نتایج گزارش
    """
    try:
        # بررسی وجود فایل دیتابیس
        db_file = Path(db_path)
        if not db_file.exists():
            return {
                'success': False,
                'error': f"فایل دیتابیس یافت نشد: {db_path}",
                'report_type': report_type,
                'data': [],
                'count': 0,
                'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            }
        
        # اتصال به دیتابیس
        conn = sqlite3.connect(db_path)
        
        # تعریف query بر اساس نوع گزارش
        if report_type == 1:
            # گزارش نوع 1: تمام ارزها
            query = """
            SELECT 
                id as 'ای دی',
                coin_name as 'نام ارز',
                symbol as 'سیمبل',
                COALESCE(current_price, 0) as 'قیمت',
                is_active as 'is_active'
            FROM crypto_coins
            ORDER BY symbol;
            """
            report_title = "گزارش کامل تمام ارزها"
            
        elif report_type == 2:
            # گزارش نوع 2: فقط is_active = 5
            query = """
            SELECT 
                id as 'ای دی',
                coin_name as 'نام ارز',
                symbol as 'سیمبل',
                COALESCE(current_price, 0) as 'قیمت',
                is_active as 'is_active'
            FROM crypto_coins
            WHERE is_active = 5
            ORDER BY symbol;
            """
            report_title = "گزارش ارزهای با وضعیت is_active = 5"
            
        elif report_type == 3:
            # گزارش نوع 3: فقط is_active = 1,2,3,4
            query = """
            SELECT 
                id as 'ای دی',
                coin_name as 'نام ارز',
                symbol as 'سیمبل',
                COALESCE(current_price, 0) as 'قیمت',
                is_active as 'is_active'
            FROM crypto_coins
            WHERE is_active IN (1, 2, 3, 4)
            ORDER BY symbol;
            """
            report_title = "گزارش ارزهای با وضعیت is_active = 1 تا 4"
            
        else:
            conn.close()
            return {
                'success': False,
                'error': "نوع گزارش نامعتبر است. لطفاً 1، 2 یا 3 وارد کنید.",
                'report_type': report_type,
                'data': [],
                'count': 0,
                'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            }
        
        # اجرای query و دریافت داده‌ها
        df = pd.read_sql_query(query, conn)
        conn.close()
        
        # تبدیل به لیست دیکشنری‌ها برای استفاده در HTML
        data_list = df.to_dict('records')
        
        # تبدیل اعداد اعشاری به float برای جلوگیری از مشکلات JSON
        for item in data_list:
            if 'قیمت' in item:
                try:
                    item['قیمت'] = float(item['قیمت'])
                except:
                    item['قیمت'] = 0.0
        
        result = {
            'success': True,
            'report_type': report_type,
            'report_title': report_title,
            'data': data_list,
            'count': len(data_list),
            'columns': list(df.columns) if not df.empty else [],
            'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'db_path': db_path
        }
        
        return result
        
    except sqlite3.Error as e:
        return {
            'success': False,
            'error': f"خطای SQLite: {str(e)}",
            'report_type': report_type,
            'data': [],
            'count': 0,
            'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        }
    except Exception as e:
        return {
            'success': False,
            'error': f"خطای غیرمنتظره: {str(e)}",
            'report_type': report_type,
            'data': [],
            'count': 0,
            'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        }

def export_report_to_csv(result, filename=None):
    """
    ذخیره گزارش در فایل CSV
    """
    if not result['success'] or len(result['data']) == 0:
        print("❌ خطا: هیچ داده‌ای برای ذخیره وجود ندارد")
        return None
    
    try:
        if filename is None:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"crypto_report_{result['report_type']}_{timestamp}.csv"
        
        df = pd.DataFrame(result['data'])
        df.to_csv(filename, index=False, encoding='utf-8-sig')
        
        print(f"✅ گزارش در فایل ذخیره شد: {filename}")
        return filename
        
    except Exception as e:
        print(f"❌ خطا در ذخیره CSV: {e}")
        return None

def print_report_to_console(result):
    """
    چاپ گزارش در کنسول
    """
    if not result['success']:
        print(f"❌ خطا: {result['error']}")
        return
    
    print("\n" + "="*70)
    print(f"📊 {result['report_title']}")
    print("="*70)
    print(f"📅 تاریخ گزارش: {result['timestamp']}")
    print(f"📊 تعداد رکوردها: {result['count']:,}")
    print(f"💾 مسیر دیتابیس: {result['db_path']}")
    
    if result['count'] > 0:
        print("\n📋 ستون‌ها:")
        print("-" * 40)
        for i, col in enumerate(result['columns'], 1):
            print(f"{i}. {col}")
        
        print("\n📄 نمونه داده‌ها (5 رکورد اول):")
        print("-" * 70)
        
        # نمایش عنوان ستون‌ها
        headers = result['columns']
        header_line = " | ".join(headers)
        print(header_line)
        print("-" * 70)
        
        # نمایش 5 رکورد اول
        for i, row in enumerate(result['data'][:5], 1):
            row_data = []
            for col in headers:
                value = row.get(col, '')
                if col == 'قیمت' and isinstance(value, (int, float)):
                    row_data.append(f"{value:,.2f}")
                else:
                    row_data.append(str(value))
            print(" | ".join(row_data))
        
        print(f"\n📁 برای ذخیره کامل گزارش در فایل CSV، از دستور زیر استفاده کنید:")
        print(f"   python {sys.argv[0]} {sys.argv[1]} --save")
    else:
        print("\n⚠️ هیچ داده‌ای یافت نشد.")

def main():
    """
    تابع اصلی برای اجرا از خط فرمان
    """
    print("🚀 گزارش‌گیر ارزهای دیجیتال")
    print("=" * 70)
    
    # مسیر دیتابیس - استفاده از raw string برای جلوگیری از مشکلات escape
    db_path = r"C:\Users\Kamal\Desktop\py-prg\git\c-data\data\crypto_master.db"
    
    # بررسی آرگومان‌های ورودی
    if len(sys.argv) < 2:
        print("❌ خطا: نوع گزارش را مشخص کنید.")
        print("\n📌 نحوه استفاده:")
        print(f"  {sys.argv[0]} 1        # گزارش کامل تمام ارزها")
        print(f"  {sys.argv[0]} 2        # فقط ارزهای با is_active = 5")
        print(f"  {sys.argv[0]} 3        # فقط ارزهای با is_active = 1 تا 4")
        print(f"  {sys.argv[0]} 1 --save # گزارش کامل و ذخیره در فایل CSV")
        print(f"  {sys.argv[0]} 2 --save # گزارش نوع 2 و ذخیره در فایل CSV")
        print(f"  {sys.argv[0]} 3 --save # گزارش نوع 3 و ذخیره در فایل CSV")
        print("\n📊 خروجی JSON برای استفاده در وب:")
        print(f"  {sys.argv[0]} 1 --json # خروجی JSON")
        return
    
    try:
        report_type = int(sys.argv[1])
        
        if report_type not in [1, 2, 3]:
            print("❌ خطا: نوع گزارش باید 1، 2 یا 3 باشد.")
            return
        
        # تولید گزارش
        result = generate_crypto_report(db_path, report_type)
        
        # بررسی آرگومان‌های اضافی
        save_to_csv = '--save' in sys.argv
        output_json = '--json' in sys.argv
        
        if output_json:
            # خروجی JSON
            print(json.dumps(result, ensure_ascii=False, indent=2))
        
        elif save_to_csv:
            # ذخیره در CSV
            filename = export_report_to_csv(result)
            if filename:
                print_report_to_console(result)
        
        else:
            # فقط نمایش در کنسول
            print_report_to_console(result)
        
        # نمایش وضعیت نهایی
        if result['success']:
            print("\n✅ گزارش با موفقیت تولید شد!")
        else:
            print("\n⚠️ تولید گزارش با مشکل مواجه شد.")
            
    except ValueError:
        print("❌ خطا: نوع گزارش باید یک عدد باشد (1، 2 یا 3).")
    except Exception as e:
        print(f"❌ خطای غیرمنتظره: {e}")

if __name__ == "__main__":
    main()