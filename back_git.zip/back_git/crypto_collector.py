#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
دریافت 500 ارز اصلی - نسخه اصلاح شده
کنترل خودکار افزودن USDT فقط در صورت نیاز
"""

import requests
import sqlite3
import time
from datetime import datetime
import os
import logging

DB_FILE = r"C:\Users\Kamal\Desktop\py-prg\git\c-data\data\crypto_master.db"
API_URL = "https://api.coingecko.com/api/v3/coins/markets"

# تنظیمات لاگ
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(message)s')
logger = logging.getLogger(__name__)

def is_main_coin(coin_data):
    """بررسی آیا این ارز اصلی است یا توکن wrapped"""
    symbol = coin_data['symbol'].upper()
    name = coin_data['name'].lower()
    
    # لیست کلمات کلیدی که نشان‌دهنده توکن wrapped هستند
    wrapped_keywords = [
        'wrapped', 'bridged', 'staked', 'vault', 'tokenized',
        'weth', 'wbtc', 'wbnb', 'wmatic', 'wavax',
        'cb', 'binance', 'coinbase', 'polygon', 'avalanche',
        'wormhole', 'cross-chain', 'bridged', 'peg'
    ]
    
    # بررسی نام
    for keyword in wrapped_keywords:
        if keyword in name:
            return False
    
    # بررسی symbolهای خاص
    wrapped_symbols = [
        'WBTC', 'WETH', 'WBNB', 'WMATIC', 'WAVAX', 
        'CBETH', 'BTCB', 'STETH', 'JITOSOL', 'STSOL',
        'WSTETH', 'WEETH', 'WBETH', 'CBBTC', 'CBETH'
    ]
    
    if symbol in wrapped_symbols:
        return False
    
    # ارزهای اصلی معمولاً نماد کوتاه دارند (1-6 حرف)
    if len(symbol) > 6:
        return False
    
    # حذف ارزهای با کاراکترهای خاص
    if '-' in symbol or '.' in symbol or '_' in symbol:
        return False
    
    return True

def create_binance_symbol(symbol):
    """
    ساخت سمبل مناسب برای Binance API
    - اگر از قبل USDT دارد، تغییر نده
    - اگر USDT دارد اما با حروف کوچک، به بزرگ تبدیل کن
    - اگر USDT ندارد، اضافه کن
    """
    symbol_upper = symbol.upper().strip()
    
    # اگر از قبل USDT دارد (با هر حالتی)
    if symbol_upper.endswith('USDT'):
        return symbol_upper  # بدون تغییر
    
    # اگر USDT دارد اما با حروف کوچک
    if symbol_upper.endswith('USDT'.lower()):
        # تبدیل به حروف بزرگ
        base_symbol = symbol_upper[:-4]
        return f"{base_symbol}USDT"
    
    # اگر USDT ندارد، اضافه کن
    return f"{symbol_upper}USDT"

def fetch_top_coins_by_market_cap(limit=500):
    """دریافت ارزهای برتر (تعداد کمتر برای کیفیت بهتر)"""
    logger.info(f"📊 دریافت {limit} ارز برتر اصلی...")
    
    all_coins = []
    
    # فقط 1 صفحه بگیر (500 ارز برتر)
    params = {
        'vs_currency': 'usd',
        'order': 'market_cap_desc',
        'per_page': min(limit, 500),
        'page': 1,
        'sparkline': False,
        'price_change_percentage': '24h'
    }
    
    try:
        response = requests.get(API_URL, params=params, timeout=30)
        
        if response.status_code == 200:
            coins = response.json()
            
            # فیلتر کردن فقط ارزهای اصلی
            main_coins = [coin for coin in coins if is_main_coin(coin)]
            
            logger.info(f"📄 {len(coins)} ارز دریافت شد ({len(main_coins)} اصلی)")
            
            # اگر ارزهای اصلی کم بودند، بیشتر بگیر
            if len(main_coins) < limit * 0.7:
                logger.info("⚠️  ارزهای اصلی کم بودند، صفحه 2 را می‌گیریم...")
                params['page'] = 2
                time.sleep(2)
                
                response2 = requests.get(API_URL, params=params, timeout=30)
                if response2.status_code == 200:
                    coins2 = response2.json()
                    main_coins2 = [coin for coin in coins2 if is_main_coin(coin)]
                    main_coins.extend(main_coins2)
                    logger.info(f"📄 صفحه 2: {len(main_coins2)} ارز اصلی اضافه شد")
            
            all_coins = main_coins[:limit]
            
        else:
            logger.error(f"❌ خطای API: {response.status_code}")
            return []
            
    except Exception as e:
        logger.error(f"❌ خطای شبکه: {e}")
        return []
    
    return all_coins

def update_existing_coins_only():
    """به‌روزرسانی فقط ارزهای موجود در دیتابیس"""
    
    print("="*70)
    print("🔄 به‌روزرسانی ارزهای موجود")
    print("="*70)
    
    # اتصال به دیتابیس
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    
    # دریافت لیست سمبل‌های موجود در دیتابیس
    cursor.execute("SELECT symbol, base_asset, is_active FROM crypto_coins")
    existing_coins = cursor.fetchall()
    
    if not existing_coins:
        print("❌ هیچ ارزی در دیتابیس وجود ندارد!")
        return
    
    existing_symbols = {}
    for symbol, base_asset, is_active in existing_coins:
        existing_symbols[symbol.upper()] = {
            'base_asset': base_asset,
            'is_active': is_active
        }
    
    print(f"📊 {len(existing_symbols)} ارز در دیتابیس موجود است")
    
    # دریافت ارزهای جدید (500 ارز برتر)
    coins = fetch_top_coins_by_market_cap(500)
    
    if not coins:
        logger.error("❌ هیچ داده‌ای دریافت نشد!")
        return
    
    logger.info(f"📥 {len(coins)} ارز اصلی دریافت شد")
    
    # لیست ارزهای شناخته شده معتبر برای Binance
    known_valid_binance_coins = [
        'BTC', 'ETH', 'BNB', 'XRP', 'USDC', 'SOL', 'TRX', 'DOGE', 'ADA', 
        'BCH', 'LINK', 'XLM', 'LTC', 'AVAX', 'SHIB', 'TON', 'UNI', 'DOT',
        'AAVE', 'XMR', 'ZEC', 'HBAR', 'SUI', 'WLFI', 'USDE', 'USD1'
    ]
    
    # به‌روزرسانی ارزهای موجود
    updated_count = 0
    skipped_count = 0
    not_found_count = 0
    
    for i, coin in enumerate(coins, 1):
        try:
            original_symbol = coin['symbol'].upper()
            
            # ساخت سمبل Binance (کنترل خودکار USDT)
            binance_symbol = create_binance_symbol(original_symbol)
            
            # بررسی آیا این ارز در دیتابیس موجود است
            if binance_symbol not in existing_symbols:
                not_found_count += 1
                if not_found_count <= 5:  # فقط 5 مورد اول را نشان بده
                    logger.debug(f"⚠️  ارز جدید: {binance_symbol} (اضافه نمی‌شود)")
                continue
            
            # ارز پایه (بدون USDT)
            base_asset = binance_symbol.replace('USDT', '')
            
            # بررسی اینکه آیا ارز در Binance معتبر است
            if base_asset not in known_valid_binance_coins:
                # بررسی طول و فرمت
                if len(base_asset) > 6 or len(base_asset) < 2:
                    logger.debug(f"⚠️  رد شد: {binance_symbol} (طول نامناسب)")
                    skipped_count += 1
                    continue
            
            # به‌روزرسانی ارز موجود
            cursor.execute('''
                UPDATE crypto_coins 
                SET coin_name = ?,
                    coingecko_id = ?,
                    current_price = ?,
                    price_change_24h = ?,
                    price_change_percent_24h = ?,
                    high_24h = ?,
                    low_24h = ?,
                    volume_24h = ?,
                    market_cap = ?,
                    market_cap_rank = ?,
                    circulating_supply = ?,
                    total_supply = ?,
                    max_supply = ?,
                    last_updated = ?
                WHERE symbol = ?
            ''', (
                coin['name'],
                coin['id'],
                coin.get('current_price', 0.0) or 0.0,
                coin.get('price_change_24h', 0.0) or 0.0,
                coin.get('price_change_percentage_24h', 0.0) or 0.0,
                coin.get('high_24h', 0.0) or 0.0,
                coin.get('low_24h', 0.0) or 0.0,
                coin.get('total_volume', 0.0) or 0.0,
                coin.get('market_cap', 0.0) or 0.0,
                coin.get('market_cap_rank', 9999) or 9999,
                coin.get('circulating_supply', 0.0) or 0.0,
                coin.get('total_supply', 0.0) or 0.0,
                coin.get('max_supply', 0.0) or 0.0,
                coin.get('last_updated', ''),
                binance_symbol
            ))
            
            if cursor.rowcount > 0:
                updated_count += 1
            
            if i % 20 == 0:
                logger.info(f"📝 {i}/{len(coins)} ارز بررسی شد...")
            
            time.sleep(0.1)  # کمی تاخیر برای رعایت rate limit
                
        except Exception as e:
            logger.warning(f"⚠️ خطا در به‌روزرسانی {coin.get('symbol', 'unknown')}: {e}")
            skipped_count += 1
            continue
    
    conn.commit()
    
    # نمایش 10 ارز برتر به‌روزرسانی شده
    cursor.execute("""
        SELECT symbol, coin_name, market_cap_rank, is_active
        FROM crypto_coins 
        ORDER BY market_cap_rank ASC 
        LIMIT 10
    """)
    top_coins = cursor.fetchall()
    
    # تعداد کل ارزهای active و inactive
    cursor.execute("SELECT COUNT(*) FROM crypto_coins WHERE is_active = 1")
    active_count = cursor.fetchone()[0]
    
    cursor.execute("SELECT COUNT(*) FROM crypto_coins WHERE is_active = 0")
    inactive_count = cursor.fetchone()[0]
    
    conn.close()
    
    print(f"\n" + "="*70)
    print("✅ عملیات تکمیل شد!")
    print("="*70)
    print(f"📊 آمار:")
    print(f"   • ارزهای دریافت شده از API: {len(coins)}")
    print(f"   • ارزهای موجود در دیتابیس: {len(existing_symbols)}")
    print(f"   • به‌روزرسانی شده: {updated_count}")
    print(f"   • رد شده: {skipped_count}")
    print(f"   • ارزهای جدید (اضافه نشدند): {not_found_count}")
    print(f"   • ارزهای active در دیتابیس: {active_count}")
    print(f"   • ارزهای inactive در دیتابیس: {inactive_count}")
    
    if not_found_count > 0:
        print(f"\n💡 {not_found_count} ارز جدید یافت شد که اضافه نشدند.")
        print("   برای اضافه کردن آنها از گزینه بارگذاری جدید استفاده کنید.")
    
    print(f"\n🏆 10 ارز برتر دیتابیس:")
    print("-" * 60)
    print(f"{'رتبه':<6} {'نماد':<12} {'نام':<25} {'وضعیت':<10}")
    print("-" * 60)
    
    for symbol, name, rank, is_active in top_coins:
        name_display = name[:24] if name else symbol
        status = "فعال" if is_active == 1 else "غیرفعال"
        print(f"{rank:<6} {symbol:<12} {name_display:<25} {status:<10}")

def smart_update_existing_coins():
    """آپدیت هوشمند ارزهای موجود"""
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    
    logger.info("🔄 آپدیت هوشمند ارزهای موجود...")
    
    # دریافت ارزهای موجود
    cursor.execute("SELECT id, symbol, is_active FROM crypto_coins")
    coins = cursor.fetchall()
    
    updated_count = 0
    already_correct = 0
    
    for coin_id, symbol, is_active in coins:
        if symbol:
            symbol_str = str(symbol).strip()
            
            # استفاده از تابع create_binance_symbol
            new_symbol = create_binance_symbol(symbol_str)
            
            # اگر تغییر کرده، آپدیت کن (به جز is_active)
            if new_symbol != symbol_str:
                cursor.execute('''
                    UPDATE crypto_coins 
                    SET symbol = ? 
                    WHERE id = ?
                ''', (new_symbol, coin_id))
                
                if cursor.rowcount > 0:
                    updated_count += 1
                    logger.debug(f"آپدیت: {symbol_str} → {new_symbol}")
            else:
                already_correct += 1
    
    conn.commit()
    
    # حذف ارزهای wrapped و نامعتبر
    logger.info("🗑️  حذف ارزهای wrapped و نامعتبر...")
    
    wrapped_keywords = ['WETH', 'WBTC', 'WBNB', 'STETH', 'WSTETH', 'WEETH', 'WBETH']
    
    deleted_count = 0
    for keyword in wrapped_keywords:
        cursor.execute("DELETE FROM crypto_coins WHERE symbol LIKE ?", (f'%{keyword}%',))
        deleted_count += cursor.rowcount
    
    # حذف USDT تکراری
    cursor.execute("DELETE FROM crypto_coins WHERE symbol LIKE '%USDTUSDT%'")
    deleted_count += cursor.rowcount
    
    conn.commit()
    conn.close()
    
    logger.info(f"✅ آپدیت تکمیل شد:")
    logger.info(f"   • آپدیت شده: {updated_count}")
    logger.info(f"   • از قبل صحیح: {already_correct}")
    logger.info(f"   • حذف شده (wrapped): {deleted_count}")

def check_current_status():
    """بررسی وضعیت فعلی ارزها"""
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    
    # تعداد کل ارزها
    cursor.execute("SELECT COUNT(*) FROM crypto_coins")
    total = cursor.fetchone()[0]
    
    # ارزهای active و inactive
    cursor.execute("SELECT COUNT(*) FROM crypto_coins WHERE is_active = 1")
    active = cursor.fetchone()[0]
    
    cursor.execute("SELECT COUNT(*) FROM crypto_coins WHERE is_active = 0")
    inactive = cursor.fetchone()[0]
    
    # ارزهای با فرمت صحیح
    cursor.execute("SELECT COUNT(*) FROM crypto_coins WHERE symbol LIKE '%USDT'")
    usdt_format = cursor.fetchone()[0]
    
    # ارزهای با USDT تکراری
    cursor.execute("SELECT COUNT(*) FROM crypto_coins WHERE symbol LIKE '%USDTUSDT%'")
    double_usdt = cursor.fetchone()[0]
    
    # ارزهای wrapped
    cursor.execute("SELECT COUNT(*) FROM crypto_coins WHERE symbol LIKE 'W%USDT' OR symbol LIKE '%STETH%'")
    wrapped = cursor.fetchone()[0]
    
    print(f"\n📊 وضعیت فعلی دیتابیس:")
    print(f"   • کل ارزها: {total}")
    print(f"   • ارزهای active: {active} ({active/total*100:.1f}%)")
    print(f"   • ارزهای inactive: {inactive} ({inactive/total*100:.1f}%)")
    print(f"   • با فرمت USDT: {usdt_format} ({usdt_format/total*100:.1f}%)")
    print(f"   • USDT تکراری: {double_usdt}")
    print(f"   • Wrapped tokens: {wrapped}")
    
    # نمونه‌ای از ارزهای inactive
    if inactive > 0:
        cursor.execute("SELECT symbol, coin_name FROM crypto_coins WHERE is_active = 0 LIMIT 5")
        inactive_coins = cursor.fetchall()
        print(f"\n📌 نمونه ارزهای inactive:")
        for symbol, name in inactive_coins:
            name_display = name[:20] if name else symbol
            print(f"   • {symbol} ({name_display})")
    
    # نمونه‌ای از مشکلات
    if double_usdt > 0:
        cursor.execute("SELECT symbol FROM crypto_coins WHERE symbol LIKE '%USDTUSDT%' LIMIT 5")
        problems = cursor.fetchall()
        print(f"\n⚠️  نمونه USDT تکراری:")
        for sym, in problems:
            print(f"   • {sym}")
    
    conn.close()

if __name__ == "__main__":
    print("="*70)
    print("🔄 سیستم مدیریت ارزها - نسخه به‌روزرسانی هوشمند")
    print("="*70)
    
    print("\n📋 گزینه‌ها:")
    print("1. به‌روزرسانی ارزهای موجود")
    print("2. آپدیت هوشمند ارزهای موجود (فرمت USDT)")
    print("3. بررسی وضعیت فعلی")
    print("4. خروج")
    
    try:
        choice = input("\n👉 انتخاب کنید (1-4): ").strip()
        
        if choice == '1':
            update_existing_coins_only()
        elif choice == '2':
            smart_update_existing_coins()
        elif choice == '3':
            check_current_status()
        elif choice == '4':
            print("👋 خروج")
        else:
            print("❌ انتخاب نامعتبر!")
            
    except KeyboardInterrupt:
        print("\n\n❌ توسط کاربر لغو شد.")
    except Exception as e:
        print(f"\n❌ خطا: {e}")