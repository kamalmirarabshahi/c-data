// API Configuration
const API_BASE_URL = 'http://127.0.0.1:5000';
let currentSymbol = '';

// DOM Elements
const elements = {
    // Navigation
    sidebar: document.getElementById('sidebar'),
    menuBtn: document.getElementById('menuBtn'),
    closeSidebar: document.getElementById('closeSidebar'),
    navItems: document.querySelectorAll('.nav-item'),
    pageSections: document.querySelectorAll('.page-section'),
    
    // Header
    pageTitle: document.getElementById('pageTitle'),
    refreshBtn: document.getElementById('refreshBtn'),
    searchInput: document.getElementById('searchInput'),
    searchBtn: document.getElementById('searchBtn'),
    
    // Loading & Error
    loadingOverlay: document.getElementById('loadingOverlay'),
    errorAlert: document.getElementById('errorAlert'),
    errorMessage: document.getElementById('errorMessage'),
    
    // Dashboard
    statsGrid: document.querySelector('.stats-grid'),
    topCoinsTable: document.getElementById('topCoinsTable').querySelector('tbody'),
    recentKlinesTable: document.getElementById('recentKlinesTable').querySelector('tbody'),
    recentLogsTable: document.getElementById('recentLogsTable').querySelector('tbody'),
    
    // Coins
    coinsLimit: document.getElementById('coinsLimit'),
    allCoinsTable: document.getElementById('allCoinsTable').querySelector('tbody'),
    
    // Klines
    symbolFilter: document.getElementById('symbolFilter'),
    limitFilter: document.getElementById('limitFilter'),
    applyKlinesFilter: document.getElementById('applyKlinesFilter'),
    klinesTable: document.getElementById('klinesTable').querySelector('tbody'),
    
    // Logs
    logsTable: document.getElementById('logsTable').querySelector('tbody'),
    
    // Health
    dbStatus: document.getElementById('dbStatus'),
    dbDetail: document.getElementById('dbDetail'),
    apiStatus: document.getElementById('apiStatus'),
    apiDetail: document.getElementById('apiDetail'),
    lastUpdate: document.getElementById('lastUpdate'),
    systemInfo: document.getElementById('systemInfo'),
    refreshHealth: document.getElementById('refreshHealth'),
    
    // Footer
    currentTime: document.getElementById('currentTime'),
    footerTime: document.getElementById('footerTime'),
    
    // Modal
    coinModal: document.getElementById('coinModal'),
    modalTitle: document.getElementById('modalTitle'),
    modalBody: document.getElementById('modalBody')
};

// Initialize
document.addEventListener('DOMContentLoaded', function() {
    console.log('🚀 صفحه بارگذاری شد');
    initEventListeners();
    updateTime();
    
    // تست اولیه اتصال API
    testConnection().then(connected => {
        if (connected) {
            console.log('✅ اتصال API موفق');
            loadDashboardData();
        } else {
            console.error('❌ اتصال API ناموفق');
            showError('خطا در اتصال به سرور API');
        }
    });
    
    // Update time every second
    setInterval(updateTime, 1000);
});

// Test API connection
async function testConnection() {
    try {
        console.log('🔗 تست اتصال به API...');
        const response = await fetch(`${API_BASE_URL}/api/health`, {
            method: 'GET',
            headers: {
                'Accept': 'application/json'
            }
        });
        
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}`);
        }
        
        const data = await response.json();
        console.log('📡 پاسخ سلامت API:', data);
        return data.status === 'healthy';
    } catch (error) {
        console.error('❌ خطا در تست اتصال:', error);
        return false;
    }
}

// Event Listeners
function initEventListeners() {
    console.log('🎮 راه‌اندازی Event Listeners');
    
    // Navigation
    elements.menuBtn.addEventListener('click', () => {
        elements.sidebar.classList.add('show');
    });
    
    elements.closeSidebar.addEventListener('click', () => {
        elements.sidebar.classList.remove('show');
    });
    
    elements.navItems.forEach(item => {
        item.addEventListener('click', function(e) {
            e.preventDefault();
            const targetId = this.getAttribute('href').substring(1);
            
            console.log(`📌 تغییر به صفحه: ${targetId}`);
            
            // Update active nav item
            elements.navItems.forEach(nav => nav.classList.remove('active'));
            this.classList.add('active');
            
            // Update page title
            const pageTitles = {
                'dashboard': 'داشبورد',
                'coins': 'ارزها',
                'klines': 'کندل‌ها',
                'logs': 'لاگ‌ها',
                'health': 'سلامت سیستم'
            };
            elements.pageTitle.textContent = pageTitles[targetId];
            
            // Show target section
            elements.pageSections.forEach(section => {
                section.classList.remove('active');
                if (section.id === targetId) {
                    section.classList.add('active');
                    
                    // Load data for section
                    switch(targetId) {
                        case 'dashboard':
                            loadDashboardData();
                            break;
                        case 'coins':
                            loadAllCoins();
                            break;
                        case 'klines':
                            loadKlines();
                            break;
                        case 'logs':
                            loadLogs();
                            break;
                        case 'health':
                            loadHealthData();
                            break;
                    }
                }
            });
            
            // Close sidebar on mobile
            if (window.innerWidth < 992) {
                elements.sidebar.classList.remove('show');
            }
        });
    });
    
    // Refresh button
    elements.refreshBtn.addEventListener('click', () => {
        console.log('🔄 دکمه رفرش کلیک شد');
        const activeSection = document.querySelector('.page-section.active');
        switch(activeSection.id) {
            case 'dashboard':
                loadDashboardData();
                break;
            case 'coins':
                loadAllCoins();
                break;
            case 'klines':
                loadKlines();
                break;
            case 'logs':
                loadLogs();
                break;
            case 'health':
                loadHealthData();
                break;
        }
    });
    
    // Search
    elements.searchBtn.addEventListener('click', () => {
        const symbol = elements.searchInput.value.trim().toUpperCase();
        if (symbol) {
            console.log(`🔍 جستجوی ارز: ${symbol}`);
            searchCoin(symbol);
        }
    });
    
    elements.searchInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            const symbol = elements.searchInput.value.trim().toUpperCase();
            if (symbol) {
                console.log(`🔍 جستجوی ارز (Enter): ${symbol}`);
                searchCoin(symbol);
            }
        }
    });
    
    // Coins limit
    if (elements.coinsLimit) {
        elements.coinsLimit.addEventListener('change', () => {
            console.log(`🔢 تغییر limit به: ${elements.coinsLimit.value}`);
            loadTopCoins();
        });
    }
    
    // Klines filter
    if (elements.applyKlinesFilter) {
        elements.applyKlinesFilter.addEventListener('click', () => {
            console.log('🔍 اعمال فیلتر کندل‌ها');
            loadKlines();
        });
    }
    
    // Health refresh
    if (elements.refreshHealth) {
        elements.refreshHealth.addEventListener('click', () => {
            console.log('🩺 رفرش وضعیت سلامت');
            loadHealthData();
        });
    }
}

// API Functions - نسخه اصلاح شده
async function fetchAPI(endpoint) {
    console.log(`📡 درخواست API به: ${endpoint}`);
    
    // جلوگیری از کش
    const timestamp = new Date().getTime();
    const separator = endpoint.includes('?') ? '&' : '?';
    const url = `${API_BASE_URL}${endpoint}${separator}_t=${timestamp}`;
    
    try {
        showLoading();
        
        const response = await fetch(url, {
            method: 'GET',
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json'
            },
            mode: 'cors',
            cache: 'no-cache'
        });
        
        console.log(`📥 پاسخ API (${endpoint}):`, response.status, response.statusText);
        
        if (!response.ok) {
            const errorText = await response.text();
            console.error(`❌ خطای HTTP: ${response.status}`, errorText);
            throw new Error(`خطای سرور: ${response.status} - ${response.statusText}`);
        }
        
        const data = await response.json();
        console.log(`✅ داده دریافتی از ${endpoint}:`, data);
        
        hideLoading();
        return data;
        
    } catch (error) {
        console.error(`🔥 خطا در fetchAPI (${endpoint}):`, error);
        hideLoading();
        
        // نمایش خطای کاربر پسند
        let userMessage = 'خطا در ارتباط با سرور';
        if (error.message.includes('Failed to fetch')) {
            userMessage = 'سرور API در دسترس نیست. مطمئن شوید که پایتون در حال اجراست.';
        } else if (error.message.includes('خطای سرور')) {
            userMessage = error.message;
        }
        
        showError(userMessage);
        throw error;
    }
}

// Dashboard Functions - نسخه اصلاح شده
async function loadDashboardData() {
    console.log('📊 شروع بارگذاری داده‌های داشبورد');
    
    try {
        // استفاده از Promise.allSettled به جای Promise.all
        const [stats, coins, klines, logs] = await Promise.allSettled([
            fetchAPI('/api/stats'),
            fetchAPI('/api/coins?limit=' + (elements.coinsLimit?.value || 10)),
            fetchAPI('/api/klines?limit=10'),
            fetchAPI('/api/logs?limit=10')
        ]);
        
        console.log('📈 نتایج بارگذاری:', {
            stats: stats.status,
            coins: coins.status,
            klines: klines.status,
            logs: logs.status
        });
        
        // پردازش نتایج
        if (stats.status === 'fulfilled') {
            updateSystemStats(stats.value);
        } else {
            console.error('❌ خطا در دریافت آمار:', stats.reason);
        }
        
        if (coins.status === 'fulfilled') {
            updateTopCoins(coins.value.coins || []);
        } else {
            console.error('❌ خطا در دریافت ارزها:', coins.reason);
            updateTopCoins([]); // نمایش جدول خالی
        }
        
        if (klines.status === 'fulfilled') {
            updateRecentKlines(klines.value.klines || []);
        } else {
            console.error('❌ خطا در دریافت کندل‌ها:', klines.reason);
            updateRecentKlines([]);
        }
        
        if (logs.status === 'fulfilled') {
            updateRecentLogs(logs.value.logs || []);
        } else {
            console.error('❌ خطا در دریافت لاگ‌ها:', logs.reason);
            updateRecentLogs([]);
        }
        
        console.log('✅ بارگذاری داشبورد کامل شد');
        
    } catch (error) {
        console.error('🔥 خطای کلی در بارگذاری داشبورد:', error);
        showError('خطا در بارگذاری داده‌های داشبورد');
    }
}

// بارگذاری جداگانه Top Coins برای event listener
async function loadTopCoins() {
    try {
        console.log('🪙 بارگذاری ارزهای برتر');
        const data = await fetchAPI('/api/coins?limit=' + (elements.coinsLimit?.value || 10));
        updateTopCoins(data.coins || []);
    } catch (error) {
        console.error('❌ خطا در بارگذاری ارزهای برتر:', error);
    }
}

function updateSystemStats(stats) {
    if (!elements.statsGrid) {
        console.error('❌ elements.statsGrid پیدا نشد');
        return;
    }
    
    console.log('📊 به‌روزرسانی آمار سیستم:', stats);
    
    const statsCards = [
        {
            icon: 'fas fa-database',
            title: 'تعداد ارزها',
            value: stats.database?.total_coins || 0,
            detail: 'ارز در دیتابیس'
        },
        {
            icon: 'fas fa-chart-bar',
            title: 'تعداد کندل‌ها',
            value: (stats.database?.total_candles || 0).toLocaleString(),
            detail: 'کندل ذخیره شده'
        },
        {
            icon: 'fas fa-hdd',
            title: 'حجم دیتابیس',
            value: (stats.database?.file_size_mb || 0) + ' MB',
            detail: 'اندازه فایل'
        },
        {
            icon: 'fas fa-bolt',
            title: 'سیگنال‌های فعال',
            value: stats.analysis?.active_signals || 0,
            detail: 'سیگنال امروز: ' + (stats.analysis?.today_signals || 0)
        },
        {
            icon: 'fas fa-history',
            title: 'آخرین جمع‌آوری',
            value: stats.collection?.last_collection ? formatTime(stats.collection.last_collection) : '--:--:--',
            detail: stats.collection?.success_rate ? 'موفقیت: ' + stats.collection.success_rate + '%' : 'بدون اطلاعات'
        },
        {
            icon: 'fas fa-server',
            title: 'وضعیت سیستم',
            value: stats.system?.status === 'RUNNING' ? 'فعال' : 'خطا',
            detail: 'نسخه ' + (stats.system?.version || '--'),
            color: stats.system?.status === 'RUNNING' ? '#4cd964' : '#ff3b30'
        }
    ];
    
    elements.statsGrid.innerHTML = statsCards.map(card => `
        <div class="stat-card">
            <div class="stat-icon">
                <i class="${card.icon}"></i>
            </div>
            <div class="stat-title">${card.title}</div>
            <div class="stat-value" style="${card.color ? `color: ${card.color};` : ''}">
                ${card.value}
            </div>
            <div class="stat-detail">${card.detail}</div>
        </div>
    `).join('');
    
    console.log('✅ آمار سیستم به‌روزرسانی شد');
}

function updateTopCoins(coins) {
    if (!elements.topCoinsTable) {
        console.error('❌ elements.topCoinsTable پیدا نشد');
        return;
    }
    
    console.log(`🪙 به‌روزرسانی ${coins.length} ارز`);
    
    if (coins.length === 0) {
        elements.topCoinsTable.innerHTML = `
            <tr>
                <td colspan="7" style="text-align: center; padding: 20px;">
                    <i class="fas fa-info-circle"></i>
                    هیچ داده‌ای برای نمایش وجود ندارد
                </td>
            </tr>
        `;
        return;
    }
    
    elements.topCoinsTable.innerHTML = coins.map((coin, index) => `
        <tr>
            <td>${index + 1}</td>
            <td><strong>${coin.symbol || '--'}</strong></td>
            <td>${coin.coin_name || '--'}</td>
            <td>${coin.current_price_formatted || formatCurrency(coin.current_price)}</td>
            <td class="${(coin.price_change_percent_24h || 0) > 0 ? 'positive' : 'negative'}">
                ${coin.change_formatted || formatPercent(coin.price_change_percent_24h)}
            </td>
            <td>${coin.volume_formatted || formatVolume(coin.volume_24h)}</td>
            <td>${coin.market_cap_rank || '--'}</td>
        </tr>
    `).join('');
}

function updateRecentKlines(klines) {
    if (!elements.recentKlinesTable) return;
    
    console.log(`📈 به‌روزرسانی ${klines.length} کندل`);
    
    if (klines.length === 0) {
        elements.recentKlinesTable.innerHTML = `
            <tr>
                <td colspan="5" style="text-align: center; padding: 20px;">
                    <i class="fas fa-info-circle"></i>
                    هیچ داده‌ای برای نمایش وجود ندارد
                </td>
            </tr>
        `;
        return;
    }
    
    elements.recentKlinesTable.innerHTML = klines.map(kline => {
        const change = (kline.close_price || 0) - (kline.open_price || 0);
        const changePercent = kline.open_price ? (change / kline.open_price * 100).toFixed(2) : 0;
        
        return `
            <tr>
                <td>${formatTime(kline.open_time)}</td>
                <td><strong>${kline.symbol || '--'}</strong></td>
                <td>${(kline.open_price || 0).toFixed(2)}</td>
                <td>${(kline.close_price || 0).toFixed(2)}</td>
                <td class="${change >= 0 ? 'positive' : 'negative'}">
                    ${change >= 0 ? '+' : ''}${changePercent}%
                </td>
            </tr>
        `;
    }).join('');
}

function updateRecentLogs(logs) {
    if (!elements.recentLogsTable) return;
    
    console.log(`📝 به‌روزرسانی ${logs.length} لاگ`);
    
    if (logs.length === 0) {
        elements.recentLogsTable.innerHTML = `
            <tr>
                <td colspan="4" style="text-align: center; padding: 20px;">
                    <i class="fas fa-info-circle"></i>
                    هیچ داده‌ای برای نمایش وجود ندارد
                </td>
            </tr>
        `;
        return;
    }
    
    elements.recentLogsTable.innerHTML = logs.map(log => {
        const statusClass = log.status === 'SUCCESS' ? 'status-success' : 
                          log.status === 'FAILED' ? 'status-error' : 'status-warning';
        
        return `
            <tr>
                <td>${formatTime(log.timestamp)}</td>
                <td>${log.symbol || '--'}</td>
                <td>
                    <span class="status-badge ${statusClass}">
                        ${log.status || 'UNKNOWN'}
                    </span>
                </td>
                <td>${log.candles_saved || 0}/${log.candles_received || 0}</td>
            </tr>
        `;
    }).join('');
}

// Coins Functions
async function loadAllCoins() {
    try {
        console.log('💰 بارگذاری تمام ارزها');
        const data = await fetchAPI('/api/coins?limit=100');
        updateAllCoinsTable(data.coins || []);
    } catch (error) {
        console.error('❌ خطا در بارگذاری ارزها:', error);
        showError('خطا در بارگذاری لیست ارزها');
    }
}

function updateAllCoinsTable(coins) {
    if (!elements.allCoinsTable) return;
    
    console.log(`💰 به‌روزرسانی جدول ${coins.length} ارز`);
    
    if (coins.length === 0) {
        elements.allCoinsTable.innerHTML = `
            <tr>
                <td colspan="10" style="text-align: center; padding: 20px;">
                    <i class="fas fa-info-circle"></i>
                    هیچ داده‌ای برای نمایش وجود ندارد
                </td>
            </tr>
        `;
        return;
    }
    
    elements.allCoinsTable.innerHTML = coins.map(coin => {
        const changeClass = (coin.price_change_percent_24h || 0) > 0 ? 'positive' : 'negative';
        
        return `
            <tr>
                <td><strong>${coin.symbol || '--'}</strong></td>
                <td>${coin.coin_name || '--'}</td>
                <td>${formatCurrency(coin.current_price)}</td>
                <td class="${changeClass}">
                    ${formatPercent(coin.price_change_percent_24h)}
                </td>
                <td>${formatCurrency(coin.low_24h)}</td>
                <td>${formatCurrency(coin.high_24h)}</td>
                <td>${formatVolume(coin.volume_24h)}</td>
                <td>${formatCurrency(coin.market_cap)}</td>
                <td>${coin.market_cap_rank || '--'}</td>
                <td>
                    <button class="view-btn" onclick="viewCoinDetail('${coin.symbol}')">
                        <i class="fas fa-eye"></i> مشاهده
                    </button>
                </td>
            </tr>
        `;
    }).join('');
}

// Klines Functions
async function loadKlines() {
    try {
        const symbol = elements.symbolFilter?.value || '';
        const limit = elements.limitFilter?.value || 50;
        
        console.log(`📊 بارگذاری کندل‌ها: ${symbol || 'ALL'} (limit: ${limit})`);
        
        let endpoint = `/api/klines?limit=${limit}`;
        if (symbol) {
            endpoint += `&symbol=${symbol.toUpperCase()}`;
        }
        
        const data = await fetchAPI(endpoint);
        updateKlinesTable(data.klines || []);
    } catch (error) {
        console.error('❌ خطا در بارگذاری کندل‌ها:', error);
        showError('خطا در بارگذاری داده‌های کندل');
    }
}

function updateKlinesTable(klines) {
    if (!elements.klinesTable) return;
    
    console.log(`📈 به‌روزرسانی ${klines.length} کندل`);
    
    if (klines.length === 0) {
        elements.klinesTable.innerHTML = `
            <tr>
                <td colspan="9" style="text-align: center; padding: 20px;">
                    <i class="fas fa-info-circle"></i>
                    هیچ داده‌ای برای نمایش وجود ندارد
                </td>
            </tr>
        `;
        return;
    }
    
    elements.klinesTable.innerHTML = klines.map(kline => {
        const change = (kline.close_price || 0) - (kline.open_price || 0);
        const changePercent = kline.open_price ? (change / kline.open_price * 100).toFixed(2) : 0;
        
        return `
            <tr>
                <td>${formatTime(kline.open_time)}</td>
                <td>${formatTime(kline.close_time)}</td>
                <td><strong>${kline.symbol || '--'}</strong></td>
                <td>${(kline.open_price || 0).toFixed(2)}</td>
                <td>${(kline.high_price || 0).toFixed(2)}</td>
                <td>${(kline.low_price || 0).toFixed(2)}</td>
                <td>${(kline.close_price || 0).toFixed(2)}</td>
                <td class="${change >= 0 ? 'positive' : 'negative'}">
                    ${change >= 0 ? '+' : ''}${changePercent}%
                </td>
                <td>${formatVolume(kline.volume)}</td>
            </tr>
        `;
    }).join('');
}

// Logs Functions
async function loadLogs() {
    try {
        console.log('📝 بارگذاری لاگ‌ها');
        const data = await fetchAPI('/api/logs?limit=50');
        updateLogsTable(data.logs || []);
    } catch (error) {
        console.error('❌ خطا در بارگذاری لاگ‌ها:', error);
        showError('خطا در بارگذاری لاگ‌های سیستم');
    }
}

function updateLogsTable(logs) {
    if (!elements.logsTable) return;
    
    console.log(`📝 به‌روزرسانی ${logs.length} لاگ`);
    
    if (logs.length === 0) {
        elements.logsTable.innerHTML = `
            <tr>
                <td colspan="7" style="text-align: center; padding: 20px;">
                    <i class="fas fa-info-circle"></i>
                    هیچ داده‌ای برای نمایش وجود ندارد
                </td>
            </tr>
        `;
        return;
    }
    
    elements.logsTable.innerHTML = logs.map(log => {
        const statusClass = log.status === 'SUCCESS' ? 'status-success' : 
                          log.status === 'FAILED' ? 'status-error' : 'status-warning';
        
        return `
            <tr>
                <td>${formatTime(log.timestamp)}</td>
                <td>${log.symbol || '--'}</td>
                <td>${log.timeframe || '--'}</td>
                <td>${log.candles_received || 0}</td>
                <td>${log.candles_saved || 0}</td>
                <td>
                    <span class="status-badge ${statusClass}">
                        ${log.status || 'UNKNOWN'}
                    </span>
                </td>
                <td class="${log.status === 'FAILED' ? 'negative' : ''}">
                    ${log.error_msg || '--'}
                </td>
            </tr>
        `;
    }).join('');
}

// Health Functions
async function loadHealthData() {
    try {
        console.log('🩺 بارگذاری وضعیت سلامت');
        const [health, stats] = await Promise.allSettled([
            fetchAPI('/api/health'),
            fetchAPI('/api/stats')
        ]);
        
        if (health.status === 'fulfilled') {
            if (stats.status === 'fulfilled') {
                updateHealthStatus(health.value, stats.value);
            } else {
                updateHealthStatus(health.value, {});
            }
        } else {
            console.error('❌ خطا در دریافت وضعیت سلامت:', health.reason);
            showError('خطا در دریافت وضعیت سلامت سیستم');
        }
    } catch (error) {
        console.error('❌ خطا در بارگذاری وضعیت سلامت:', error);
    }
}

function updateHealthStatus(health, stats) {
    console.log('🩺 به‌روزرسانی وضعیت سلامت:', health);
    
    // Database status
    if (health.database?.connected) {
        elements.dbStatus.textContent = 'فعال ✓';
        elements.dbStatus.style.color = '#4cd964';
        elements.dbDetail.textContent = `دیتابیس متصل (${health.database.path || 'نامشخص'})`;
    } else {
        elements.dbStatus.textContent = 'غیرفعال ✗';
        elements.dbStatus.style.color = '#ff3b30';
        elements.dbDetail.textContent = health.database?.exists ? 
            'خطا در اتصال به دیتابیس' : 'فایل دیتابیس یافت نشد';
    }
    
    // API status
    if (health.status === 'healthy') {
        elements.apiStatus.textContent = 'فعال ✓';
        elements.apiStatus.style.color = '#4cd964';
        elements.apiDetail.textContent = 'API در حال پاسخگویی است';
    } else {
        elements.apiStatus.textContent = 'مشکل ✗';
        elements.apiStatus.style.color = '#ff3b30';
        elements.apiDetail.textContent = health.message || 'مشکل در ارتباط با API';
    }
    
    // Last update
    if (stats.database?.last_update) {
        elements.lastUpdate.textContent = formatTime(stats.database.last_update);
    } else {
        elements.lastUpdate.textContent = '--:--:--';
    }
    
    // System info
    if (stats && Object.keys(stats).length > 0) {
        elements.systemInfo.textContent = JSON.stringify(stats, null, 2);
    } else {
        elements.systemInfo.textContent = JSON.stringify(health, null, 2);
    }
}

// Search Functions
async function searchCoin(symbol) {
    try {
        console.log(`🔍 جستجوی ارز: ${symbol}`);
        const data = await fetchAPI(`/api/coin/${symbol}`);
        showCoinModal(data.coin, data.recent_klines || []);
    } catch (error) {
        console.error(`❌ خطا در جستجوی ارز ${symbol}:`, error);
        showError(`ارز "${symbol}" پیدا نشد`);
    }
}

async function viewCoinDetail(symbol) {
    try {
        console.log(`👁️ مشاهده جزئیات ارز: ${symbol}`);
        const data = await fetchAPI(`/api/coin/${symbol}`);
        showCoinModal(data.coin, data.recent_klines || []);
    } catch (error) {
        console.error(`❌ خطا در دریافت اطلاعات ارز ${symbol}:`, error);
        showError(`خطا در دریافت اطلاعات ارز ${symbol}`);
    }
}

function showCoinModal(coin, klines) {
    console.log('📊 نمایش مدال ارز:', coin.symbol);
    
    elements.modalTitle.textContent = `${coin.symbol} - ${coin.coin_name || coin.symbol}`;
    
    const changeClass = (coin.price_change_percent_24h || 0) > 0 ? 'positive' : 'negative';
    
    elements.modalBody.innerHTML = `
        <div class="coin-detail">
            <div class="coin-header">
                <div class="coin-price">
                    <h4>قیمت فعلی</h4>
                    <div class="price-value">${formatCurrency(coin.current_price)}</div>
                    <div class="price-change ${changeClass}">
                        ${(coin.price_change_24h || 0) > 0 ? '+' : ''}${formatCurrency(coin.price_change_24h)} 
                        (${formatPercent(coin.price_change_percent_24h)})
                    </div>
                </div>
                
                <div class="coin-stats">
                    <div class="stat">
                        <span>بیشترین 24h:</span>
                        <strong>${formatCurrency(coin.high_24h)}</strong>
                    </div>
                    <div class="stat">
                        <span>کمترین 24h:</span>
                        <strong>${formatCurrency(coin.low_24h)}</strong>
                    </div>
                    <div class="stat">
                        <span>حجم 24h:</span>
                        <strong>${formatVolume(coin.volume_24h)}</strong>
                    </div>
                    <div class="stat">
                        <span>مارکت‌کپ:</span>
                        <strong>${formatCurrency(coin.market_cap)}</strong>
                    </div>
                    <div class="stat">
                        <span>رتبه:</span>
                        <strong>${coin.market_cap_rank || '--'}</strong>
                    </div>
                    <div class="stat">
                        <span>آخرین بروزرسانی:</span>
                        <strong>${formatTime(coin.last_updated)}</strong>
                    </div>
                </div>
            </div>
            
            <h4>آخرین کندل‌ها (${klines.length})</h4>
            <div class="klines-table">
                <table>
                    <thead>
                        <tr>
                            <th>زمان باز</th>
                            <th>باز</th>
                            <th>بیشترین</th>
                            <th>کمترین</th>
                            <th>بسته</th>
                            <th>حجم</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${klines.length > 0 ? klines.map(kline => {
                            const change = (kline.close_price || 0) - (kline.open_price || 0);
                            const changeClass = change >= 0 ? 'positive' : 'negative';
                            
                            return `
                                <tr>
                                    <td>${formatTime(kline.open_time)}</td>
                                    <td>${(kline.open_price || 0).toFixed(2)}</td>
                                    <td>${(kline.high_price || 0).toFixed(2)}</td>
                                    <td>${(kline.low_price || 0).toFixed(2)}</td>
                                    <td class="${changeClass}">${(kline.close_price || 0).toFixed(2)}</td>
                                    <td>${formatVolume(kline.volume)}</td>
                                </tr>
                            `;
                        }).join('') : `
                            <tr>
                                <td colspan="6" style="text-align: center; padding: 20px;">
                                    <i class="fas fa-info-circle"></i>
                                    هیچ کندلی برای نمایش وجود ندارد
                                </td>
                            </tr>
                        `}
                    </tbody>
                </table>
            </div>
        </div>
    `;
    
    elements.coinModal.style.display = 'flex';
}

function closeModal() {
    console.log('❌ بستن مدال');
    elements.coinModal.style.display = 'none';
}

// Utility Functions
function formatTime(datetimeString) {
    if (!datetimeString) return '--:--:--';
    
    try {
        const date = new Date(datetimeString);
        if (isNaN(date.getTime())) {
            return datetimeString; // اگر تاریخ نامعتبر است، همان رشته را برگردان
        }
        
        const timeString = date.toLocaleTimeString('fa-IR', {
            hour: '2-digit',
            minute: '2-digit'
        });
        
        const dateString = date.toLocaleDateString('fa-IR');
        return `${timeString} ${dateString}`;
    } catch (e) {
        console.error('خطا در فرمت زمان:', datetimeString, e);
        return datetimeString;
    }
}

function formatCurrency(value) {
    if (value === null || value === undefined || value === '') return '$0.00';
    
    const num = parseFloat(value);
    if (isNaN(num)) return '$0.00';
    
    return `$${num.toLocaleString('en-US', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    })}`;
}

function formatPercent(value) {
    if (value === null || value === undefined || value === '') return '0.00%';
    
    const num = parseFloat(value);
    if (isNaN(num)) return '0.00%';
    
    const sign = num >= 0 ? '+' : '';
    return `${sign}${num.toFixed(2)}%`;
}

function formatVolume(value) {
    if (!value && value !== 0) return '$0.00';
    
    const num = parseFloat(value);
    if (isNaN(num)) return '$0.00';
    
    if (num >= 1_000_000_000) {
        return `$${(num / 1_000_000_000).toFixed(2)}B`;
    } else if (num >= 1_000_000) {
        return `$${(num / 1_000_000).toFixed(2)}M`;
    } else if (num >= 1_000) {
        return `$${(num / 1_000).toFixed(2)}K`;
    }
    return `$${num.toFixed(2)}`;
}

function updateTime() {
    const now = new Date();
    const timeString = now.toLocaleTimeString('fa-IR');
    const dateString = now.toLocaleDateString('fa-IR');
    
    if (elements.currentTime) {
        elements.currentTime.textContent = timeString;
    }
    if (elements.footerTime) {
        elements.footerTime.textContent = `${dateString} ${timeString}`;
    }
}

function showLoading() {
    console.log('⏳ نمایش loading...');
    if (elements.loadingOverlay) {
        elements.loadingOverlay.style.display = 'flex';
    }
}

function hideLoading() {
    console.log('✅ مخفی کردن loading');
    if (elements.loadingOverlay) {
        elements.loadingOverlay.style.display = 'none';
    }
}

function showError(message) {
    console.error('🚨 نمایش خطا:', message);
    if (elements.errorAlert && elements.errorMessage) {
        elements.errorMessage.textContent = message;
        elements.errorAlert.style.display = 'flex';
        
        // Auto-hide after 10 seconds
        setTimeout(hideError, 10000);
    }
}

function hideError() {
    console.log('❌ مخفی کردن خطا');
    if (elements.errorAlert) {
        elements.errorAlert.style.display = 'none';
    }
}

// Close modal on ESC key
document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && elements.coinModal.style.display === 'flex') {
        closeModal();
    }
});

// Close modal on outside click
elements.coinModal?.addEventListener('click', (e) => {
    if (e.target === elements.coinModal) {
        closeModal();
    }
});

// Global functions for onclick events
window.viewCoinDetail = viewCoinDetail;
window.closeModal = closeModal;
window.hideError = hideError;
window.searchCoin = searchCoin;