
import sqlite3
import logging
import json
from datetime import datetime

def clean_invalid_candles(db_path: str):
    """پاکسازی کندل‌های معیوب از crypto_klines"""
    
    logging.basicConfig(level=logging.INFO)
    logger = logging.getLogger(__name__)
    
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    try:
        # 1. شمارش کندل‌های معیوب
        logger.info("🔍 شمارش کندل‌های معیوب...")
        
        cursor.execute("SELECT COUNT(*) FROM crypto_klines")
        total = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM crypto_klines WHERE open_price = close_price")
        same_open_close = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM crypto_klines WHERE volume = 0")
        zero_volume = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM crypto_klines WHERE high_price = low_price")
        same_high_low = cursor.fetchone()[0]
        
        logger.info(f"📊 آمار قبل از پاکسازی:")
        logger.info(f"  • کل کندل‌ها: {total:,}")
        logger.info(f"  • open=close: {same_open_close:,} ({same_open_close/total*100:.1f}%)")
        logger.info(f"  • volume=0: {zero_volume:,} ({zero_volume/total*100:.1f}%)")
        logger.info(f"  • high=low: {same_high_low:,} ({same_high_low/total*100:.1f}%)")
        
        # 2. علامت‌گذاری کندل‌های معیوب
        logger.info("🏷️ علامت‌گذاری کندل‌های معیوب...")
        
        cursor.execute("""
            UPDATE crypto_klines 
            SET data_quality = 10,
                pattern_markers = json_set(
                    COALESCE(pattern_markers, '{}'),
                    '$.invalid_reason',
                    CASE 
                        WHEN open_price = close_price THEN 'same_open_close'
                        WHEN volume = 0 THEN 'zero_volume'
                        WHEN high_price = low_price THEN 'same_high_low'
                        ELSE 'unknown'
                    END
                )
            WHERE open_price = close_price 
               OR volume = 0 
               OR high_price = low_price
        """)
        
        affected = cursor.rowcount
        logger.info(f"✅ {affected:,} کندل علامت‌گذاری شدند")
        
        # 3. ایجاد یک view برای داده‌های معتبر
        cursor.execute("DROP VIEW IF EXISTS valid_crypto_klines")
        cursor.execute("""
            CREATE VIEW valid_crypto_klines AS
            SELECT * FROM crypto_klines 
            WHERE open_price != close_price 
              AND volume > 0 
              AND high_price != low_price
              AND data_quality > 50
        """)
        
        cursor.execute("SELECT COUNT(*) FROM valid_crypto_klines")
        valid_count = cursor.fetchone()[0]
        
        logger.info(f"👁️ View ایجاد شد: {valid_count:,} کندل معتبر")
        
        conn.commit()
        
        # 4. خلاصه نهایی
        logger.info("\n🎯 خلاصه پاکسازی:")
        logger.info(f"  • کندل‌های معیوب: {affected:,} ({affected/total*100:.1f}%)")
        logger.info(f"  • کندل‌های باقی‌مانده: {total - affected:,}")
        logger.info(f"  • کندل‌های معتبر (View): {valid_count:,}")
        
        return {
            'success': True,
            'total_candles': total,
            'invalid_marked': affected,
            'valid_in_view': valid_count,
            'invalid_percent': (affected / total * 100) if total > 0 else 0
        }
        
    except Exception as e:
        conn.rollback()
        logger.error(f"❌ خطا در پاکسازی: {e}")
        return {'success': False, 'error': str(e)}
    
    finally:
        conn.close()

if __name__ == "__main__":
    db_path = "data/crypto_master.db"
    print("=" * 60)
    print("🧹 پاکسازی کندل‌های معیوب از دیتابیس")
    print("=" * 60)
    
    result = clean_invalid_candles(db_path)
    
    if result['success']:
        print(f"\n✅ پاکسازی با موفقیت انجام شد!")
        print(f"   {result['invalid_marked']:,} کندل معیوب علامت‌گذاری شدند")
        print(f"   {result['invalid_percent']:.1f}% از کل داده‌ها معیوب بودند")
        print(f"   {result['valid_in_view']:,} کندل معتبر باقی ماند")
    else:
        print(f"\n❌ خطا: {result.get('error')}")
