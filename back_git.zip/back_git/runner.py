import os
import sys
import subprocess
import json
import time
import argparse
from datetime import datetime
from typing import List, Dict, Any, Optional

print("🚀 اجرای کامل پروژه تحلیل کریپتو - مراحل 1 تا 5")
print("=" * 60)

# مسیر ریشه پروژه (همان دایرکتوری که runner.py در آن است)
PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))
print(f"📁 مسیر ریشه پروژه: {PROJECT_ROOT}")

# اضافه کردن مسیر scripts برای import
SCRIPTS_DIR = os.path.join(PROJECT_ROOT, "scripts")
sys.path.insert(0, SCRIPTS_DIR)

# بارگذاری config_manager
try:
    from config_manager import get, get_database_path, get_project_root
    
    # استفاده از config_manager
    DB_PATH = get_database_path()
    CONFIG_PROJECT_ROOT = get_project_root()
    
    print(f"✅ config_manager بارگذاری شد")
    print(f"📁 مسیر دیتابیس: {DB_PATH}")
    
except ImportError as e:
    print(f"❌ خطا در بارگذاری config_manager: {e}")
    print("⚠️ استفاده از مسیرهای پیش‌فرض")
    DB_PATH = os.path.join(PROJECT_ROOT, "data", "crypto_master.db")

# مسیرهای مهم
STATE_PATH = os.path.join(PROJECT_ROOT, "state", "cycle_state.json")
REPORTS_DIR = os.path.join(PROJECT_ROOT, "reports", "runner")
MASTER_LOG = os.path.join(PROJECT_ROOT, "logs", "runner.log")

# ایجاد دایرکتوری‌های لازم
os.makedirs(REPORTS_DIR, exist_ok=True)
os.makedirs(os.path.dirname(MASTER_LOG), exist_ok=True)

def log_message(message: str):
    """ذخیره پیام در لاگ"""
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    log_entry = f"[{timestamp}] {message}"
    
    print(log_entry)
    
    with open(MASTER_LOG, 'a', encoding='utf-8') as f:
        f.write(log_entry + '\n')

def load_state() -> Dict[str, Any]:
    """بارگذاری وضعیت سیستم"""
    if not os.path.exists(STATE_PATH):
        log_message("❌ فایل state یافت نشد")
        return {}
    
    try:
        with open(STATE_PATH, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception as e:
        log_message(f"❌ خطا در خواندن state: {e}")
        return {}

def get_active_blocks() -> List[int]:
    """دریافت لیست بلوک‌های فعال"""
    state = load_state()
    blocks = state.get('blocks', [])
    
    active_blocks = []
    for block in blocks:
        block_id = block.get('block_id')
        if block_id:
            active_blocks.append(block_id)
    
    log_message(f"📋 {len(active_blocks)} بلوک فعال یافت شد")
    return sorted(active_blocks)

def run_cycle_01() -> bool:
    """اجرای تکه 01: فیلتر ارزها"""
    log_message("🔄 شروع تکه 01: فیلتر ارزها")
    
    try:
        script_path = os.path.join(SCRIPTS_DIR, "cycle", "cycle_01_coin_filter.py")
        
        if not os.path.exists(script_path):
            log_message(f"❌ فایل {script_path} یافت نشد")
            return False
        
        result = subprocess.run(
            [sys.executable, script_path],
            cwd=PROJECT_ROOT,
            capture_output=True,
            text=True,
            encoding='utf-8'
        )
        
        if result.returncode == 0:
            log_message("✅ تکه 01 با موفقیت اجرا شد")
            if result.stdout:
                log_message(f"   خروجی: {result.stdout[:200]}")
            return True
        else:
            log_message(f"❌ خطا در اجرای تکه 01")
            if result.stderr:
                log_message(f"   خطا: {result.stderr[:200]}")
            return False
            
    except Exception as e:
        log_message(f"❌ خطا در اجرای تکه 01: {e}")
        return False

def run_cycle_02(block_id: int) -> bool:
    """اجرای تکه 02 برای یک بلوک"""
    log_message(f"🔄 شروع تکه 02: جمع‌آوری داده برای بلوک {block_id}")
    
    try:
        script_path = os.path.join(SCRIPTS_DIR, "cycle", "cycle_02_process_block.py")
        
        if not os.path.exists(script_path):
            log_message(f"❌ فایل {script_path} یافت نشد")
            return False
        
        result = subprocess.run(
            [sys.executable, script_path, '--block', str(block_id)],
            cwd=PROJECT_ROOT,
            capture_output=True,
            text=True,
            encoding='utf-8'
        )
        
        if result.returncode == 0:
            log_message(f"✅ تکه 02 برای بلوک {block_id} اجرا شد")
            return True
        else:
            log_message(f"❌ خطا در اجرای تکه 02 برای بلوک {block_id}")
            if result.stderr:
                log_message(f"   خطا: {result.stderr[:200]}")
            return False
            
    except Exception as e:
        log_message(f"❌ خطا در اجرای تکه 02 برای بلوک {block_id}: {e}")
        return False

def run_cycle_03(block_id: int) -> bool:
    """اجرای تکه 03 برای یک بلوک"""
    log_message(f"🔄 شروع تکه 03: تحلیل تکنیکال برای بلوک {block_id}")
    
    try:
        script_path = os.path.join(SCRIPTS_DIR, "cycle", "cycle_03_analyze_block", "main_cycle_03.py")
        
        if not os.path.exists(script_path):
            log_message(f"❌ فایل {script_path} یافت نشد")
            return False
        
        result = subprocess.run(
            [sys.executable, script_path, '--block', str(block_id)],
            cwd=PROJECT_ROOT,
            capture_output=True,
            text=True,
            encoding='utf-8'
        )
        
        if result.returncode == 0:
            log_message(f"✅ تکه 03 برای بلوک {block_id} اجرا شد")
            return True
        else:
            log_message(f"❌ خطا در اجرای تکه 03 برای بلوک {block_id}")
            if result.stderr:
                log_message(f"   خطا: {result.stderr[:200]}")
            return False
            
    except Exception as e:
        log_message(f"❌ خطا در اجرای تکه 03 برای بلوک {block_id}: {e}")
        return False

def run_cycle_04(block_id: int) -> bool:
    """اجرای تکه 04 برای یک بلوک"""
    log_message(f"🔄 شروع تکه 04: تحلیل پیشرفته برای بلوک {block_id}")
    
    try:
        # تلاش برای پیدا کردن main_cycle_04.py
        script_path = os.path.join(SCRIPTS_DIR, "cycle", "cycle_04_ad_analysis", "main_cycle_04.py")
        
        if not os.path.exists(script_path):
            # تلاش جایگزین
            script_path = os.path.join(SCRIPTS_DIR, "cycle", "cycle_04_ad_analysis", "signal_combiner.py")
            
            if not os.path.exists(script_path):
                log_message(f"⚠️ تکه 04 یافت نشد - رد می‌شود")
                return True  # به عنوان موفق در نظر بگیر چون اجباری نیست
        
        result = subprocess.run(
            [sys.executable, script_path, '--block', str(block_id)],
            cwd=PROJECT_ROOT,
            capture_output=True,
            text=True,
            encoding='utf-8'
        )
        
        if result.returncode == 0:
            log_message(f"✅ تکه 04 برای بلوک {block_id} اجرا شد")
            return True
        else:
            log_message(f"⚠️ هشدار در اجرای تکه 04 برای بلوک {block_id}")
            if result.stderr:
                log_message(f"   خطا: {result.stderr[:200]}")
            return True  # رد می‌شود چون اجباری نیست
            
    except Exception as e:
        log_message(f"⚠️ هشدار در اجرای تکه 04 برای بلوک {block_id}: {e}")
        return True  # رد می‌شود

def run_cycle_05(block_id: int, use_telegram: bool = True) -> bool:
    """اجرای تکه 05 برای یک بلوک"""
    log_message(f"🔄 شروع تکه 05: تصمیم‌گیری برای بلوک {block_id}")
    
    try:
        script_path = os.path.join(SCRIPTS_DIR, "cycle", "cycle_05_decisions", "main_cycle_05.py")
        
        if not os.path.exists(script_path):
            log_message(f"❌ فایل {script_path} یافت نشد")
            return False
        
        cmd = [sys.executable, script_path, '--block', str(block_id)]
        if not use_telegram:
            cmd.append('--no-telegram')
        
        result = subprocess.run(
            cmd,
            cwd=PROJECT_ROOT,
            capture_output=True,
            text=True,
            encoding='utf-8'
        )
        
        if result.returncode == 0:
            log_message(f"✅ تکه 05 برای بلوک {block_id} اجرا شد")
            return True
        else:
            log_message(f"❌ خطا در اجرای تکه 05 برای بلوک {block_id}")
            if result.stderr:
                log_message(f"   خطا: {result.stderr[:200]}")
            return False
            
    except Exception as e:
        log_message(f"❌ خطا در اجرای تکه 05 برای بلوک {block_id}: {e}")
        return False

def process_block(block_id: int, use_telegram: bool = True) -> Dict[str, Any]:
    """پردازش کامل یک بلوک از مرحله 2 تا 5"""
    log_message(f"\n{'='*50}")
    log_message(f"🎯 شروع پردازش بلوک {block_id}")
    log_message(f"{'='*50}")
    
    results = {
        'block_id': block_id,
        'start_time': datetime.now().isoformat(),
        'cycle_02': False,
        'cycle_03': False,
        'cycle_04': False,
        'cycle_05': False
    }
    
    # مرحله 2
    start_time = time.time()
    results['cycle_02'] = run_cycle_02(block_id)
    results['cycle_02_time'] = time.time() - start_time
    
    if not results['cycle_02']:
        log_message(f"❌ تکه 02 برای بلوک {block_id} ناموفق بود - توقف")
        results['status'] = 'failed_at_02'
        return results
    
    # مرحله 3
    start_time = time.time()
    results['cycle_03'] = run_cycle_03(block_id)
    results['cycle_03_time'] = time.time() - start_time
    
    if not results['cycle_03']:
        log_message(f"⚠️ تکه 03 برای بلوک {block_id} ناموفق بود - ادامه با احتیاط")
    
    # مرحله 4
    start_time = time.time()
    results['cycle_04'] = run_cycle_04(block_id)
    results['cycle_04_time'] = time.time() - start_time
    
    # مرحله 5
    start_time = time.time()
    results['cycle_05'] = run_cycle_05(block_id, use_telegram)
    results['cycle_05_time'] = time.time() - start_time
    
    results['end_time'] = datetime.now().isoformat()
    results['total_time'] = sum([
        results.get('cycle_02_time', 0),
        results.get('cycle_03_time', 0),
        results.get('cycle_04_time', 0),
        results.get('cycle_05_time', 0)
    ])
    
    # وضعیت کلی
    results['success'] = results['cycle_02'] and results['cycle_05']
    results['status'] = 'success' if results['success'] else 'partial_success'
    
    log_message(f"📊 نتیجه بلوک {block_id}:")
    log_message(f"  تکه 02: {'✅' if results['cycle_02'] else '❌'} ({results.get('cycle_02_time', 0):.1f}ثانیه)")
    log_message(f"  تکه 03: {'✅' if results['cycle_03'] else '❌'} ({results.get('cycle_03_time', 0):.1f}ثانیه)")
    log_message(f"  تکه 04: {'✅' if results['cycle_04'] else '❌'} ({results.get('cycle_04_time', 0):.1f}ثانیه)")
    log_message(f"  تکه 05: {'✅' if results['cycle_05'] else '❌'} ({results.get('cycle_05_time', 0):.1f}ثانیه)")
    log_message(f"  کل زمان: {results['total_time']:.1f} ثانیه")
    log_message(f"  وضعیت: {'✅ موفق' if results['success'] else '⚠️ موفق نسبی'}")
    
    return results

def parse_block_range(block_range: str) -> List[int]:
    """تبدیل رشته محدوده بلوک به لیست"""
    blocks = []
    
    for part in block_range.split(','):
        part = part.strip()
        if '-' in part:
            start, end = map(int, part.split('-'))
            blocks.extend(range(start, end + 1))
        else:
            blocks.append(int(part))
    
    return sorted(set(blocks))

def generate_final_report(all_results: List[Dict[str, Any]], start_time: datetime, 
                         use_telegram: bool = True):
    """تولید گزارش نهایی"""
    log_message(f"\n{'='*60}")
    log_message("📊 گزارش نهایی اجرای مراحل 1 تا 5")
    log_message(f"{'='*60}")
    
    total_blocks = len(all_results)
    successful_blocks = sum(1 for r in all_results if r.get('success', False))
    failed_blocks = total_blocks - successful_blocks
    
    end_time = datetime.now()
    total_duration = (end_time - start_time).total_seconds()
    
    # آمار زمان‌ها
    total_times = {
        'cycle_02': sum(r.get('cycle_02_time', 0) for r in all_results),
        'cycle_03': sum(r.get('cycle_03_time', 0) for r in all_results),
        'cycle_04': sum(r.get('cycle_04_time', 0) for r in all_results),
        'cycle_05': sum(r.get('cycle_05_time', 0) for r in all_results),
    }
    
    # آمار موفقیت
    success_counts = {
        'cycle_02': sum(1 for r in all_results if r.get('cycle_02', False)),
        'cycle_03': sum(1 for r in all_results if r.get('cycle_03', False)),
        'cycle_04': sum(1 for r in all_results if r.get('cycle_04', False)),
        'cycle_05': sum(1 for r in all_results if r.get('cycle_05', False)),
    }
    
    success_rates = {k: v/total_blocks*100 if total_blocks > 0 else 0 
                    for k, v in success_counts.items()}
    
    log_message(f"\n📈 آمار کلی:")
    log_message(f"  زمان شروع: {start_time.strftime('%Y-%m-%d %H:%M:%S')}")
    log_message(f"  زمان پایان: {end_time.strftime('%Y-%m-%d %H:%M:%S')}")
    log_message(f"  مدت زمان کل: {total_duration:.1f} ثانیه ({total_duration/60:.1f} دقیقه)")
    log_message(f"  تعداد بلوک‌ها: {total_blocks}")
    log_message(f"  بلوک‌های موفق: {successful_blocks}")
    log_message(f"  بلوک‌های ناموفق: {failed_blocks}")
    log_message(f"  نرخ موفقیت: {successful_blocks/total_blocks*100:.1f}%" if total_blocks > 0 else "  نرخ موفقیت: 0%")
    log_message(f"  تلگرام: {'فعال' if use_telegram else 'غیرفعال'}")
    
    log_message(f"\n⏱️ زمان‌های اجرا:")
    for cycle, duration in total_times.items():
        avg_time = duration / total_blocks if total_blocks > 0 else 0
        log_message(f"  {cycle}: {duration:.1f}ثانیه (میانگین: {avg_time:.1f}ثانیه)")
    
    log_message(f"\n📊 نرخ موفقیت مراحل:")
    for cycle, rate in success_rates.items():
        log_message(f"  {cycle}: {rate:.1f}% ({success_counts[cycle]}/{total_blocks})")
    
    log_message(f"\n🎯 بلوک‌های پردازش شده:")
    for result in all_results:
        status = '✅' if result.get('success', False) else '⚠️'
        total_time = result.get('total_time', 0)
        log_message(f"  بلوک {result['block_id']}: {status} ({total_time:.1f}ثانیه)")
    
    # ذخیره گزارش JSON
    report_data = {
        'project_root': PROJECT_ROOT,
        'execution_start': start_time.isoformat(),
        'execution_end': end_time.isoformat(),
        'total_duration_seconds': total_duration,
        'total_blocks': total_blocks,
        'successful_blocks': successful_blocks,
        'failed_blocks': failed_blocks,
        'success_rate_percent': successful_blocks/total_blocks*100 if total_blocks > 0 else 0,
        'telegram_enabled': use_telegram,
        'time_breakdown': total_times,
        'success_counts': success_counts,
        'success_rates': success_rates,
        'block_results': all_results,
        'summary': f"پردازش {total_blocks} بلوک در {total_duration/60:.1f} دقیقه با نرخ موفقیت {successful_blocks/total_blocks*100:.1f}%"
    }
    
    report_file = os.path.join(
        REPORTS_DIR,
        f"runner_report_{start_time.strftime('%Y%m%d_%H%M%S')}.json"
    )
    
    with open(report_file, 'w', encoding='utf-8') as f:
        json.dump(report_data, f, indent=2, ensure_ascii=False)
    
    log_message(f"\n📄 گزارش کامل ذخیره شد: {report_file}")
    log_message(f"{'='*60}")
    log_message("🎉 اجرای کامل مراحل 1 تا 5 به پایان رسید!")
    log_message(f"{'='*60}")
    
    return report_data

def main():
    """تابع اصلی runner"""
    parser = argparse.ArgumentParser(
        description='اجرای کامل مراحل 1 تا 5 پروژه تحلیل کریپتو',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
مثال‌ها:
  python runner.py                    # اجرای کامل برای همه بلوک‌ها
  python runner.py --blocks 1-3       # اجرا برای بلوک‌های 1 تا 3
  python runner.py --blocks 1,3,5     # اجرا برای بلوک‌های 1، 3 و 5
  python runner.py --no-telegram      # اجرا بدون تلگرام
  python runner.py --skip-cycle-01    # رد کردن مرحله فیلتر ارزها
  python runner.py --start-block 2 --end-block 5  # اجرا از بلوک 2 تا 5
        """
    )
    
    parser.add_argument('--blocks', type=str, 
                       help='لیست بلوک‌ها (مثال: 1,3,5 یا 1-5 یا 1-3,5,7-8)')
    
    parser.add_argument('--start-block', type=int, default=1,
                       help='شماره بلوک شروع (پیش‌فرض: 1)')
    
    parser.add_argument('--end-block', type=int, 
                       help='شماره بلوک پایان')
    
    parser.add_argument('--no-telegram', action='store_true',
                       help='غیرفعال کردن تلگرام در مراحل مختلف')
    
    parser.add_argument('--skip-cycle-01', action='store_true',
                       help='رد کردن تکه 01 (فیلتر ارزها)')
    
    parser.add_argument('--delay-between-blocks', type=int, default=5,
                       help='تاخیر بین بلوک‌ها به ثانیه (پیش‌فرض: 5)')
    
    parser.add_argument('--max-blocks', type=int,
                       help='حداکثر تعداد بلوک‌های پردازش شده')
    
    args = parser.parse_args()
    
    # زمان شروع
    start_time = datetime.now()
    
    log_message(f"🚀 شروع اجرای کامل پروژه")
    log_message(f"📅 زمان شروع: {start_time.strftime('%Y-%m-%d %H:%M:%S')}")
    log_message(f"📁 پروژه: {PROJECT_ROOT}")
    log_message(f"⚙️  پارامترها:")
    log_message(f"  - blocks: {args.blocks}")
    log_message(f"  - start-block: {args.start_block}")
    log_message(f"  - end-block: {args.end_block}")
    log_message(f"  - no-telegram: {args.no_telegram}")
    log_message(f"  - skip-cycle-01: {args.skip_cycle_01}")
    log_message(f"  - delay: {args.delay_between_blocks} ثانیه")
    
    # مرحله 1: اجرای تکه 01
    if not args.skip_cycle_01:
        log_message("\n" + "="*50)
        log_message("مرحله 1: اجرای تکه 01 - فیلتر ارزها")
        log_message("="*50)
        cycle_01_success = run_cycle_01()
        
        if not cycle_01_success:
            log_message("⚠️ هشدار: تکه 01 ناموفق بود، ادامه با داده‌های موجود")
        time.sleep(3)  # تاخیر برای به‌روزرسانی state
    else:
        log_message("ℹ️ تکه 01 (فیلتر ارزها) رد شد")
    
    # تعیین بلوک‌های هدف
    if args.blocks:
        # پردازش لیست بلوک‌ها
        target_blocks = parse_block_range(args.blocks)
    else:
        # دریافت بلوک‌های فعال از state
        active_blocks = get_active_blocks()
        
        if not active_blocks:
            log_message("⚠️ هیچ بلوک فعالی یافت نشد - استفاده از بلوک‌های پیش‌فرض 1-16")
            active_blocks = list(range(1, 17))  # پیش‌فرض
        
        # فیلتر کردن بر اساس start-block و end-block
        target_blocks = []
        for block_id in active_blocks:
            if block_id >= args.start_block:
                if args.end_block is None or block_id <= args.end_block:
                    target_blocks.append(block_id)
    
    # محدود کردن تعداد بلوک‌ها اگر max-blocks مشخص شده
    if args.max_blocks and len(target_blocks) > args.max_blocks:
        log_message(f"⚠️ محدود کردن بلوک‌ها از {len(target_blocks)} به {args.max_blocks}")
        target_blocks = target_blocks[:args.max_blocks]
    
    target_blocks = sorted(set(target_blocks))
    log_message(f"🎯 {len(target_blocks)} بلوک برای پردازش: {target_blocks}")
    
    if not target_blocks:
        log_message("❌ هیچ بلوکی برای پردازش یافت نشد")
        return
    
    # پردازش بلوک‌ها
    all_results = []
    
    for i, block_id in enumerate(target_blocks):
        log_message(f"\n{'='*60}")
        log_message(f"پردازش بلوک {block_id} ({i+1}/{len(target_blocks)})")
        log_message(f"{'='*60}")
        
        result = process_block(block_id, not args.no_telegram)
        all_results.append(result)
        
        # تاخیر بین بلوک‌ها (به جز آخرین بلوک)
        if i < len(target_blocks) - 1:
            log_message(f"⏳ تاخیر {args.delay_between_blocks} ثانیه قبل از بلوک بعدی...")
            time.sleep(args.delay_between_blocks)
    
    # تولید گزارش نهایی
    log_message(f"\n{'='*60}")
    log_message("تولید گزارش نهایی...")
    log_message(f"{'='*60}")
    
    report = generate_final_report(all_results, start_time, not args.no_telegram)
    
    # نمایش خلاصه نهایی
    log_message(f"\n✨ خلاصه نهایی:")
    log_message(f"  کل بلوک‌ها: {report['total_blocks']}")
    log_message(f"  موفق: {report['successful_blocks']}")
    log_message(f"  ناموفق: {report['failed_blocks']}")
    log_message(f"  نرخ موفقیت: {report['success_rate_percent']:.1f}%")
    log_message(f"  زمان کل: {report['total_duration_seconds']/60:.1f} دقیقه")
    
    # ذخیره فایل خلاصه
    summary_file = os.path.join(PROJECT_ROOT, "last_run_summary.txt")
    with open(summary_file, 'w', encoding='utf-8') as f:
        f.write(f"آخرین اجرا: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        f.write(f"بلوک‌های پردازش شده: {target_blocks}\n")
        f.write(f"تعداد بلوک‌ها: {report['total_blocks']}\n")
        f.write(f"بلوک‌های موفق: {report['successful_blocks']}\n")
        f.write(f"نرخ موفقیت: {report['success_rate_percent']:.1f}%\n")
        f.write(f"زمان کل: {report['total_duration_seconds']/60:.1f} دقیقه\n")
        f.write(f"تلگرام: {'فعال' if not args.no_telegram else 'غیرفعال'}\n")
        f.write(f"گزارش کامل: {os.path.join(REPORTS_DIR, os.path.basename(report_file))}\n")
    
    log_message(f"📝 خلاصه در: {summary_file}")

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n⏹️ اجرا توسط کاربر متوقف شد")
        log_message("⏹️ اجرا توسط کاربر متوقف شد")
    except Exception as e:
        print(f"\n❌ خطای غیرمنتظره: {e}")
        log_message(f"❌ خطای غیرمنتظره: {e}")