#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
سرور Flask برای نمایش داده‌های ارزها در وب
"""

from flask import Flask, render_template, jsonify, request
import sqlite3
import os
from datetime import datetime
import json

app = Flask(__name__)

# مسیر دیتابیس
DB_FILE = r"C:\Users\Kamal\Desktop\py-prg\git\c-data\data\crypto_master.db"

def get_table_structure():
    """دریافت ساختار جدول"""
    try:
        conn = sqlite3.connect(DB_FILE)
        cursor = conn.cursor()
        
        cursor.execute("PRAGMA table_info(crypto_coins)")
        columns_info = cursor.fetchall()
        column_names = [col[1] for col in columns_info]
        
        conn.close()
        return column_names
    except Exception as e:
        print(f"خطا در دریافت ساختار جدول: {e}")
        return []

def get_coins_data(sort_by=1, limit=500):
    """
    دریافت داده‌های ارزها
    
    پارامترها:
    ----------
    sort_by : int
        1 = سورت بر اساس volume_24h
        2 = سورت بر اساس price_change_percent_24h
    limit : int
        تعداد رکوردها
    """
    
    if not os.path.exists(DB_FILE):
        return {"error": "دیتابیس یافت نشد", "data": []}
    
    try:
        conn = sqlite3.connect(DB_FILE)
        cursor = conn.cursor()
        
        # بررسی ساختار جدول
        table_columns = get_table_structure()
        
        # ستون‌های مورد نیاز
        requested_columns = ['base_asset', 'coin_name', 'current_price', 
                           'price_change_percent_24h', 'volume_24h', 
                           'market_cap_rank']
        
        # انتخاب ستون‌های موجود
        selected_columns = []
        for col in requested_columns:
            if col in table_columns:
                selected_columns.append(col)
        
        if not selected_columns:
            return {"error": "ستون‌های مورد نیاز یافت نشد", "data": []}
        
        # انتخاب ستون سورت
        if sort_by == 1:
            if 'volume_24h' in table_columns:
                sort_column = 'volume_24h'
                sort_name = "حجم معاملات ۲۴ ساعته"
            else:
                sort_column = selected_columns[0]
                sort_name = sort_column
        else:
            if 'price_change_percent_24h' in table_columns:
                sort_column = 'price_change_percent_24h'
                sort_name = "درصد تغییر قیمت ۲۴ ساعته"
            else:
                sort_column = selected_columns[0]
                sort_name = sort_column
        
        sort_direction = 'DESC'
        
        # ساخت کوئری
        query = f"""
        SELECT {', '.join(selected_columns)}
        FROM crypto_coins 
        WHERE {sort_column} IS NOT NULL
        ORDER BY {sort_column} {sort_direction}
        LIMIT {limit}
        """
        
        cursor.execute(query)
        rows = cursor.fetchall()
        
        # تبدیل به لیست دیکشنری
        result = []
        for row in rows:
            item = {}
            for i, col in enumerate(selected_columns):
                item[col] = row[i]
            result.append(item)
        
        conn.close()
        
        return {
            "success": True,
            "sort_name": sort_name,
            "sort_column": sort_column,
            "total": len(result),
            "timestamp": datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            "columns": selected_columns,
            "data": result
        }
        
    except Exception as e:
        return {"error": str(e), "data": []}

@app.route('/')
def index():
    """صفحه اصلی"""
    return render_template('index.html')

@app.route('/api/coins')
def api_coins():
    """API برای دریافت داده‌های ارزها"""
    sort_by = request.args.get('sort_by', 1, type=int)
    limit = request.args.get('limit', 100, type=int)
    
    data = get_coins_data(sort_by, limit)
    return jsonify(data)

@app.route('/api/stats')
def api_stats():
    """API برای دریافت آمار"""
    data = get_coins_data(1, 1000)  # دریافت بیشترین داده برای آمار
    
    if "error" in data:
        return jsonify({"error": data["error"]})
    
    # محاسبه آمار
    stats = {
        "total_coins": len(data["data"]),
        "timestamp": datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    }
    
    if data["data"]:
        # آمار قیمت
        prices = []
        for item in data["data"]:
            if 'current_price' in item and item['current_price']:
                try:
                    prices.append(float(item['current_price']))
                except:
                    pass
        
        if prices:
            stats['avg_price'] = sum(prices) / len(prices)
            stats['max_price'] = max(prices)
            stats['min_price'] = min(prices)
        
        # آمار تغییرات
        changes = []
        for item in data["data"]:
            if 'price_change_percent_24h' in item and item['price_change_percent_24h']:
                try:
                    changes.append(float(item['price_change_percent_24h']))
                except:
                    pass
        
        if changes:
            stats['positive_changes'] = len([c for c in changes if c > 0])
            stats['negative_changes'] = len([c for c in changes if c < 0])
            stats['max_increase'] = max(changes)
            stats['max_decrease'] = min(changes)
            stats['avg_change'] = sum(changes) / len(changes)
    
    return jsonify(stats)

if __name__ == '__main__':
    print("=" * 60)
    print("🌐 سرور Flask در حال راه‌اندازی...")
    print("📊 دیتابیس:", DB_FILE)
    print("🌍 دسترسی به: http://localhost:5000")
    print("=" * 60)
    
    # بررسی وجود دیتابیس
    if not os.path.exists(DB_FILE):
        print(f"⚠️  هشدار: دیتابیس {DB_FILE} یافت نشد!")
    
    app.run(debug=True, host='0.0.0.0', port=5000)