﻿# [file name]: config.py
# [file content begin]
"""
⚙️ فایل تنظیمات پروژه با پشتیبانی از python-dotenv

استفاده:
1. تنظیمات در فایل .env ذخیره می‌شوند
2. با python-dotenv بارگذاری می‌شوند
3. در کلاس Config قابل دسترسی هستند
"""

import os
import json
from pathlib import Path
from datetime import datetime
from dotenv import load_dotenv

# بارگذاری متغیرهای محیطی از فایل .env
load_dotenv()

class Config:
    """کلاس تنظیمات پروژه"""
    
    # ============ مسیرها ============
    BASE_DIR = Path(__file__).parent.parent
    DB_PATH = Path(os.getenv('DB_PATH', BASE_DIR / 'data' / 'crypto_master.db'))
    EXPORT_DIR = BASE_DIR / 'exports'
    LOG_DIR = BASE_DIR / 'logs'
    CACHE_DIR = BASE_DIR / 'cache'
    TEMPLATES_DIR = BASE_DIR / 'templates'
    
    # ============ تنظیمات سرور ============
    HOST = os.getenv('HOST', '0.0.0.0')
    PORT = int(os.getenv('PORT', 5000))
    DEBUG = os.getenv('DEBUG', 'True').lower() == 'true'
    SECRET_KEY = os.getenv('SECRET_KEY', 'dev-secret-key-change-in-production')
    
    # ============ تنظیمات دیتابیس ============
    DB_TIMEOUT = int(os.getenv('DB_TIMEOUT', 30))
    DB_CACHE_SIZE = 10000
    
    # ============ تنظیمات گزارش‌گیری ============
    DEFAULT_PAGE_SIZE = int(os.getenv('DEFAULT_PAGE_SIZE', 50))
    MAX_EXPORT_ROWS = int(os.getenv('MAX_EXPORT_ROWS', 10000))
    CACHE_TIMEOUT = int(os.getenv('CACHE_TIMEOUT', 300))  # 5 دقیقه
    
    # ============ تنظیمات export ============
    ALLOWED_EXPORT_FORMATS = os.getenv('EXPORT_FORMATS', 'csv,json,xlsx').split(',')
    
    # ============ URLs ============
    SERVER_URL = f"http://{HOST}:{PORT}"
    
    # ============ تنظیمات نمایش ============
    SITE_TITLE = os.getenv('SITE_TITLE', 'آخرین پروژه زندگی')
    SITE_DESCRIPTION = os.getenv('SITE_DESCRIPTION', 'سیستم تحلیل ارزهای دیجیتال')
    TIMEZONE = os.getenv('TIMEZONE', 'Asia/Tehran')
    
    # ============ سایر تنظیمات ============
    LOG_LEVEL = os.getenv('LOG_LEVEL', 'INFO')
    ENABLE_CACHE = os.getenv('ENABLE_CACHE', 'True').lower() == 'true'
    API_RATE_LIMIT = int(os.getenv('API_RATE_LIMIT', 100))
    
    # ============ متغیرهای محاسبه‌شده ============
    CURRENT_DATE = datetime.now().strftime('%Y-%m-%d')
    CURRENT_TIME = datetime.now().strftime('%H:%M:%S')
    VERSION = '2.1.0'
    
    # ============ اطلاعات جداول اصلی ============
    MAIN_TABLES = {
        'crypto_coins': 'اطلاعات ارزهای دیجیتال',
        'crypto_klines': 'داده‌های کندل (قیمت)',
        'sqlite_master': 'متادیتای دیتابیس'
    }
    
    # ============ تایم‌فریم‌های پشتیبانی شده ============
    TIMEFRAMES = ['15m', '30m', '1h', '4h', '1d', '1w']
    
    @classmethod
    def init_directories(cls):
        """ایجاد پوشه‌های مورد نیاز"""
        cls.EXPORT_DIR.mkdir(exist_ok=True)
        cls.LOG_DIR.mkdir(exist_ok=True)
        cls.CACHE_DIR.mkdir(exist_ok=True)
        cls.TEMPLATES_DIR.mkdir(exist_ok=True)
        
        # ایجاد فایل لاگ
        log_file = cls.LOG_DIR / f'app_{cls.CURRENT_DATE}.log'
        log_file.touch(exist_ok=True)
    
    @classmethod
    def validate_config(cls):
        """اعتبارسنجی تنظیمات"""
        warnings = []
        
        if not cls.DB_PATH.exists():
            warnings.append(f"فایل دیتابیس یافت نشد: {cls.DB_PATH}")
        
        if cls.DEBUG:
            warnings.append("حالت DEBUG فعال است - در تولید غیرفعال کنید")
        
        if cls.SECRET_KEY == 'dev-secret-key-change-in-production':
            warnings.append("کلید امنیتی پیش‌فرض استفاده می‌شود - در تولید تغییر دهید")
        
        return warnings
    
    @classmethod
    def get_database_connection(cls):
        """ایجاد اتصال به دیتابیس"""
        import sqlite3
        conn = sqlite3.connect(str(cls.DB_PATH), timeout=cls.DB_TIMEOUT)
        conn.row_factory = sqlite3.Row
        return conn
    
    @classmethod
    def to_dict(cls):
        """تبدیل تنظیمات به دیکشنری"""
        return {
            'project_name': cls.SITE_TITLE,
            'version': cls.VERSION,
            'database_path': str(cls.DB_PATH),
            'server_url': cls.SERVER_URL,
            'current_date': cls.CURRENT_DATE,
            'current_time': cls.CURRENT_TIME,
            'debug_mode': cls.DEBUG
        }

# مقداردهی اولیه
Config.init_directories()

if __name__ == '__main__':
    print("📋 تنظیمات پروژه:")
    print(json.dumps(Config.to_dict(), indent=2, ensure_ascii=False))
    
    warnings = Config.validate_config()
    if warnings:
        print("\n⚠️ هشدارها:")
        for warning in warnings:
            print(f"   • {warning}")
