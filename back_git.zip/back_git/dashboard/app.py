﻿"""
🚀 سرور اصلی Flask - نسخه بهینه شده با کانفیگ مرکزی

🔹 هر صفحه HTML یک Backend مخصوص دارد
🔹 استفاده از کانفیگ مرکزی برای تمام تنظیمات
🔹 کد تمیز و قابل نگهداری
🔹 توسعه آسان برای صفحات جدید
🔹 ماژولار شده با ماژول‌های جداگانه
"""

from flask import Flask, render_template, jsonify, request, send_file, abort
import sys
import os
import json
import subprocess
from pathlib import Path
from datetime import datetime

# ============ CONFIGURATION ============

# اضافه کردن مسیرها به sys.path
current_dir = Path(__file__).parent
backend_dir = current_dir / 'backend'
config_dir = current_dir / 'config'

sys.path.insert(0, str(backend_dir))
sys.path.insert(0, str(config_dir))

# import ماژول‌های کانفیگ و backend
try:
    # کانفیگ مرکزی
    from config import Config
    print("✅ کانفیگ مرکزی با موفقیت import شد")
    
    # ماژول‌های backend اصلی
    from reports import get_reports_data
    
    print("✅ ماژول‌های backend با موفقیت import شدند")
    
except ImportError as e:
    print(f"❌ خطا در import ماژول‌ها: {e}")
    print(f"📁 مسیر backend: {backend_dir}")
    print(f"📁 مسیر config: {config_dir}")
    
    # تعریف کلاس Config به صورت fallback
    class Config:
        BASE_DIR = current_dir.parent
        DB_PATH = BASE_DIR / 'data' / 'crypto_master.db'
        HOST = '127.0.0.1'
        PORT = 5000
        DEBUG = True
        SECRET_KEY = 'dev-secret-key-change-in-production'
        DEFAULT_PAGE_SIZE = 50
        MAX_EXPORT_ROWS = 10000
        SITE_TITLE = 'آخرین پروژه زندگی'
        SITE_DESCRIPTION = 'سیستم تحلیل ارزهای دیجیتال'
        EXPORT_DIR = current_dir / 'exports'
    
    # تعریف توابع dummy برای جلوگیری از crash
    def get_reports_data():
        return {'error': 'Backend modules not found'}
    
    def get_database_stats():
        return {
            'active_coins': 0,
            'last_update': '',
            '15m_candles': 0,
            '1h_candles': 0,
            '4h_candles': 0,
            'total_tables': 0,
            'tables_info': []
        }

# ============ FLASK APP INIT ============

app = Flask(__name__, 
            template_folder='templates',
            static_folder='static')

app.config['SECRET_KEY'] = Config.SECRET_KEY
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max upload
app.config['DEBUG'] = Config.DEBUG

# فیلترهای Jinja2
@app.template_filter('intcomma')
def intcomma_filter(value):
    """فرمت‌دهی اعداد با کاما"""
    try:
        return f"{int(value):,}"
    except:
        return value

@app.template_filter('round')
def round_filter(value, decimals=2):
    """گرد کردن اعداد"""
    try:
        return round(float(value), decimals)
    except:
        return value

# ============ HELPER FUNCTIONS ============

def log_request(endpoint, method, status='success'):
    """لاگ درخواست‌های API"""
    timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    print(f"[{timestamp}] {method} {endpoint} - {status}")

def format_db_path_for_display(db_path):
    """فرمت مسیر دیتابیس برای نمایش"""
    try:
        # کوتاه کردن مسیر اگر طولانی است
        str_path = str(db_path)
        if len(str_path) > 50:
            return "..." + str_path[-50:]
        return str_path
    except:
        return str(db_path)

# ============ IMPORT و REGISTER ماژول‌های جدید ============

print("\n" + "="*60)
print("🚀 ثبت ماژول‌های پروژه")
print("="*60)

# ✅ ماژول index
try:
    from backend.index_routes import register_index_routes
    app = register_index_routes(app, Config)
    print("✅ ماژول index routes با موفقیت ثبت شد")
except ImportError as e:
    print(f"⚠️ خطا در ثبت index routes: {e}")

# ✅ ماژول coins
try:
    from backend.coins_routes import register_coins_routes
    app = register_coins_routes(app, Config)
    print("✅ ماژول coins routes با موفقیت ثبت شد")
except ImportError as e:
    print(f"⚠️ خطا در ثبت coins routes: {e}")

# ✅ ماژول tables
try:
    from backend.tables_routes import register_tables_routes
    app = register_tables_routes(app, Config)
    print("✅ ماژول tables routes با موفقیت ثبت شد")
except ImportError as e:
    print(f"⚠️ خطا در ثبت tables routes: {e}")

# ✅ ماژول blocks
try:
    from backend.blocks_routes import register_blocks_routes
    app = register_blocks_routes(app, Config)
    print("✅ ماژول blocks routes با موفقیت ثبت شد")
except ImportError as e:
    print(f"⚠️ خطا در ثبت blocks routes: {e}")

print("="*60 + "\n")

# ============ MAIN ROUTES (قدیمی - فقط reports باقی مانده) ============

@app.route('/reports')
def reports():
    """صفحه گزارشات"""
    log_request('/reports', 'GET')
    try:
        data = get_reports_data()
        # ✅ اصلاح navigation برای اضافه کردن گزارشات
        data['navigation'] = [
            {'name': 'خانه', 'url': '/', 'icon': 'fas fa-home'},
            {'name': 'لیست ارزها', 'url': '/coins', 'icon': 'fas fa-coins'},
            {'name': 'جداول', 'url': '/tables', 'icon': 'fas fa-table'},
            {'name': 'بلوک ارزها', 'url': '/blocks', 'icon': 'fas fa-cubes'},
            {'name': 'گزارشات', 'url': '/reports', 'icon': 'fas fa-chart-bar'}
        ]
        return render_template('reports.html', **data)
    except Exception as e:
        return render_template('reports.html', 
                              status='error',
                              error=str(e),
                              reports=[],
                              stats={},
                              project_name=Config.SITE_TITLE,
                              navigation=[
                                  {'name': 'خانه', 'url': '/', 'icon': 'fas fa-home'},
                                  {'name': 'لیست ارزها', 'url': '/coins', 'icon': 'fas fa-coins'},
                                  {'name': 'جداول', 'url': '/tables', 'icon': 'fas fa-table'},
                                  {'name': 'بلوک ارزها', 'url': '/blocks', 'icon': 'fas fa-cubes'},
                                  {'name': 'گزارشات', 'url': '/reports', 'icon': 'fas fa-chart-bar'}
                              ])

# ============ UTILITY ROUTES ============

@app.route('/api/health')
def health_check():
    """بررسی سلامت سیستم"""
    log_request('/api/health', 'GET')
    
    # بررسی وجود دیتابیس
    db_exists = Config.DB_PATH.exists()
    
    # بررسی وجود فایل‌های backend
    backend_files = [
        'index.py', 'index_routes.py',
        'reports.py', 
        'coins.py', 'coins_routes.py',
        'tables.py', 'tables_routes.py',
        'blocks.py', 'blocks_routes.py'
    ]
    
    backend_status = {}
    for f in backend_files:
        file_path = backend_dir / f
        backend_status[f] = file_path.exists()
    
    # بررسی وجود فایل کانفیگ
    config_status = (config_dir / 'config.py').exists()
    
    # بررسی وجود templates
    templates_dir = current_dir / 'templates'
    template_files = ['index.html', 'reports.html', 'coins.html', 'tables.html', 'blocks.html']
    templates_status = all((templates_dir / f).exists() for f in template_files)
    
    # تست اتصال به دیتابیس
    db_connection = False
    if db_exists:
        try:
            import sqlite3
            conn = sqlite3.connect(str(Config.DB_PATH))
            conn.close()
            db_connection = True
        except:
            db_connection = False
    
    # بررسی ماژول‌های ثبت شده
    registered_modules = {
        'index': 'index_routes' in sys.modules,
        'coins': 'backend.coins_routes' in sys.modules,
        'tables': 'backend.tables_routes' in sys.modules,
        'blocks': 'backend.blocks_routes' in sys.modules
    }
    
    return jsonify({
        'status': 'healthy',
        'app': Config.SITE_TITLE,
        'version': '2.1.0',
        'timestamp': datetime.now().isoformat(),
        'server_url': f"http://{Config.HOST}:{Config.PORT}",
        'checks': {
            'database_file': db_exists,
            'database_connection': db_connection,
            'config_module': config_status,
            'templates': templates_status,
            'flask_server': True
        },
        'modules': registered_modules,
        'backend_files': backend_status,
        'endpoints': {
            'main_pages': ['/', '/reports', '/coins', '/tables', '/blocks'],
            'api_endpoints': [
                '/api/stats',  # از ماژول index
                '/api/health', '/api/info', '/api/config',
                '/api/state/cycle', '/api/run/filter',  # از ماژول blocks
                '/api/coins', '/api/coins/{symbol}', '/api/coins/{symbol}/status',  # از coins
                '/api/reports/all_coins', '/api/reports/active_coins', '/api/reports/inactive_coins',
                '/api/export/{type}',
                '/api/tables', '/api/tables/{table}/structure', '/api/tables/{table}/data',  # از tables
                '/api/database/schema'
            ]
        }
    })

@app.route('/api/info')
def api_info():
    """اطلاعات درباره API"""
    return jsonify({
        'app_name': Config.SITE_TITLE,
        'description': Config.SITE_DESCRIPTION,
        'version': '2.2.0',
        'author': 'Crypto Analysis Team',
        'config': {
            'database_path': str(Config.DB_PATH),
            'server': f"{Config.HOST}:{Config.PORT}",
            'debug_mode': Config.DEBUG,
            'default_page_size': Config.DEFAULT_PAGE_SIZE
        },
        'structure': {
            'backend': 'هر صفحه HTML یک فایل backend جداگانه دارد',
            'templates': 'فایل‌های HTML در پوشه templates/',
            'database': 'داده‌ها از کانفیگ مرکزی خوانده می‌شوند',
            'modules': {
                'index_module': 'ماژول صفحه اصلی',
                'coins_module': 'ماژول مدیریت ارزها',
                'tables_module': 'ماژول مدیریت جداول',
                'blocks_module': 'ماژول مدیریت بلوک‌ها',
                'reports_module': 'ماژول گزارشات'
            }
        },
        'main_endpoints': [
            {'path': '/', 'method': 'GET', 'description': 'صفحه اصلی (شامل داشبورد)'},
            {'path': '/coins', 'method': 'GET', 'description': 'لیست ارزها'},
            {'path': '/tables', 'method': 'GET', 'description': 'مدیریت جداول دیتابیس'},
            {'path': '/blocks', 'method': 'GET', 'description': 'مدیریت بلوک‌های ارزها'},
            {'path': '/reports', 'method': 'GET', 'description': 'صفحه گزارشات'},
            {'path': '/api/stats', 'method': 'GET', 'description': 'آمار کلی پروژه'},
            {'path': '/api/health', 'method': 'GET', 'description': 'بررسی سلامت سیستم'},
            {'path': '/api/info', 'method': 'GET', 'description': 'اطلاعات API'},
            {'path': '/api/config', 'method': 'GET', 'description': 'تنظیمات کانفیگ'}
        ],
        'modules_endpoints': {
            'blocks': [
                {'path': '/api/state/cycle', 'method': 'GET', 'description': 'خواندن وضعیت بلوک‌ها'},
                {'path': '/api/run/filter', 'method': 'POST', 'description': 'اجرای فیلتر و ایجاد بلوک‌ها'}
            ],
            'coins': [
                {'path': '/api/coins', 'method': 'GET', 'description': 'لیست ارزها با فیلتر'},
                {'path': '/api/coins/{symbol}', 'method': 'GET', 'description': 'جزئیات یک ارز'},
                {'path': '/api/coins/{symbol}/status', 'method': 'POST', 'description': 'تغییر وضعیت ارز'},
                {'path': '/api/reports/all_coins', 'method': 'GET', 'description': 'گزارش تمام ارزها'},
                {'path': '/api/reports/active_coins', 'method': 'GET', 'description': 'گزارش ارزهای فعال'},
                {'path': '/api/reports/inactive_coins', 'method': 'GET', 'description': 'گزارش ارزهای غیرفعال'},
                {'path': '/api/export/{type}', 'method': 'GET', 'description': 'دانلود گزارش CSV'}
            ],
            'tables': [
                {'path': '/api/tables', 'method': 'GET', 'description': 'لیست جداول دیتابیس'},
                {'path': '/api/tables/{table}/structure', 'method': 'GET', 'description': 'ساختار جدول'},
                {'path': '/api/tables/{table}/data', 'method': 'GET', 'description': 'داده‌های جدول با صفحه‌بندی'},
                {'path': '/api/database/schema', 'method': 'GET', 'description': 'اسکیمای کامل دیتابیس'}
            ]
        }
    })

@app.route('/api/config')
def api_config():
    """نمایش تنظیمات کانفیگ"""
    log_request('/api/config', 'GET')
    
    try:
        # تبدیل تنظیمات به دیکشنری
        config_dict = {}
        for attr in dir(Config):
            if not attr.startswith('_') and not callable(getattr(Config, attr)):
                value = getattr(Config, attr)
                # تبدیل Path به string برای JSON
                if isinstance(value, Path):
                    value = str(value)
                config_dict[attr] = value
        
        return jsonify({
            'status': 'success',
            'config': config_dict,
            'warnings': Config.validate_config() if hasattr(Config, 'validate_config') else [],
            'timestamp': datetime.now().isoformat()
        })
    except Exception as e:
        return jsonify({
            'status': 'error',
            'error': str(e)
        }), 500

# ============ ERROR HANDLERS ============

@app.errorhandler(404)
def page_not_found(e):
    """مدیریت خطای 404"""
    return render_template('error.html',
                          error_code=404,
                          error_message='صفحه مورد نظر یافت نشد',
                          suggestion='آدرس وارد شده را بررسی کنید یا به صفحه اصلی برگردید',
                          project_name=Config.SITE_TITLE), 404

@app.errorhandler(500)
def internal_server_error(e):
    """مدیریت خطای 500"""
    return render_template('error.html',
                          error_code=500,
                          error_message='خطای داخلی سرور',
                          suggestion='لطفاً بعداً تلاش کنید یا با پشتیبانی تماس بگیرید',
                          project_name=Config.SITE_TITLE), 500

@app.errorhandler(400)
def bad_request(e):
    """مدیریت خطای 400"""
    return render_template('error.html',
                          error_code=400,
                          error_message='درخواست نامعتبر',
                          suggestion='لطفاً پارامترهای درخواست را بررسی کنید',
                          project_name=Config.SITE_TITLE), 400

# ============ STATIC FILE SERVING ============

@app.route('/exports/<filename>')
def download_export(filename):
    """دانلود فایل‌های اکسپورت"""
    log_request(f'/exports/{filename}', 'GET')
    
    try:
        # بررسی وجود پوشه exports
        exports_dir = Config.EXPORT_DIR if hasattr(Config, 'EXPORT_DIR') else current_dir / 'exports'
        exports_dir.mkdir(exist_ok=True)
        
        filepath = exports_dir / filename
        if not filepath.exists():
            abort(404, "فایل یافت نشد")
        
        return send_file(filepath, as_attachment=True)
    except Exception as e:
        abort(500, str(e))

# ============ MAIN EXECUTION ============

if __name__ == '__main__':
    print("=" * 70)
    print(f"🚀 **{Config.SITE_TITLE}** - نسخه ماژولار 🚀")
    print("=" * 70)
    print("📁 ساختار پروژه:")
    print(f"   • Backend Modules: {backend_dir}")
    print(f"   • Config: {config_dir}/config.py")
    print(f"   • Templates: {current_dir / 'templates'}")
    print(f"   • Database: {format_db_path_for_display(Config.DB_PATH)}")
    print(f"   • Database Exists: {'✅' if Config.DB_PATH.exists() else '❌'}")
    
    print("\n✅ ماژول‌های ثبت شده:")
    print("   • index_routes - صفحه اصلی و آمار")
    print("   • coins_routes - مدیریت ارزها")
    print("   • tables_routes - مدیریت جداول")
    print("   • blocks_routes - مدیریت بلوک‌ها")
    print("   • reports - گزارشات (قدیمی)")
    
    print("\n🌐 صفحات اصلی:")
    print(f"   http://{Config.HOST}:{Config.PORT}/              # صفحه اصلی (داشبورد)")
    print(f"   http://{Config.HOST}:{Config.PORT}/coins         # لیست ارزها")
    print(f"   http://{Config.HOST}:{Config.PORT}/tables        # مدیریت جداول")
    print(f"   http://{Config.HOST}:{Config.PORT}/blocks        # بلوک ارزها")
    print(f"   http://{Config.HOST}:{Config.PORT}/reports       # گزارشات")
    
    print("\n🔧 API Endpoints اصلی:")
    print(f"   http://{Config.HOST}:{Config.PORT}/api/health    # وضعیت سلامت")
    print(f"   http://{Config.HOST}:{Config.PORT}/api/info      # اطلاعات API")
    print(f"   http://{Config.HOST}:{Config.PORT}/api/config    # تنظیمات کانفیگ")
    
    print("\n🪙 APIهای Coins:")
    print(f"   • لیست ارزها: /api/coins")
    print(f"   • جزئیات ارز: /api/coins/BTCUSDT")
    print(f"   • تغییر وضعیت: /api/coins/BTCUSDT/status (POST)")
    print(f"   • گزارشات: /api/reports/all_coins, /api/reports/active_coins, /api/reports/inactive_coins")
    print(f"   • اکسپورت: /api/export/all_coins, /api/export/active_coins, /api/export/inactive_coins")
    
    print("\n🏠 APIهای صفحه اصلی:")
    print(f"   • آمار کلی: /api/stats")
    
    print("\n📊 APIهای Tables:")
    print(f"   • لیست جداول: /api/tables")
    print(f"   • ساختار جدول: /api/tables/{{table}}/structure")
    print(f"   • داده‌های جدول: /api/tables/{{table}}/data")
    print(f"   • اسکیما: /api/database/schema")
    
    print("\n⚡ APIهای بلوک‌ها:")
    print(f"   • وضعیت فعلی: /api/state/cycle (GET)")
    print(f"   • اجرای فیلتر: /api/run/filter (POST)")
    
    print("=" * 70)
    
    # ایجاد پوشه‌های مورد نیاز
    for dir_path in ['exports', 'logs', 'cache']:
        dir_full = current_dir / dir_path
        dir_full.mkdir(exist_ok=True)
    
    # اجرای سرور
    app.run(
        host=Config.HOST,
        port=Config.PORT,
        debug=Config.DEBUG,
        threaded=True
    )