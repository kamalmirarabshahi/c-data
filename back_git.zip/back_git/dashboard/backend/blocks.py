# backend/blocks.py

import json
import sqlite3
import subprocess
from pathlib import Path
from datetime import datetime


def get_blocks_data(config):
    """دریافت داده‌های بلوک‌ها برای صفحه HTML"""
    try:
        # اطلاعات پایه
        base_data = {
            'project_name': config.SITE_TITLE,
            'app_name': config.SITE_DESCRIPTION,
            'version': '2.1.0',
            'current_date': datetime.now().strftime('%Y-%m-%d'),
            'current_time': datetime.now().strftime('%H:%M:%S'),
            'server_url': f"http://{config.HOST}:{config.PORT}",
            'database_stats': get_database_stats(config)
        }
        
        return base_data
    except Exception as e:
        raise Exception(f"خطا در دریافت داده‌های بلوک‌ها: {str(e)}")


def get_database_stats(config):
    """آمار دیتابیس"""
    try:
        db_exists = config.DB_PATH.exists()
        if not db_exists:
            return {
                'active_coins': 0,
                'last_update': 'نامشخص',
                'candle_15m': 0,
                'candle_1h': 0,
                'candle_4h': 0,
                'total_tables': 0,
                'db_path': str(config.DB_PATH),
                'db_exists': False
            }
        
        conn = sqlite3.connect(str(config.DB_PATH))
        cursor = conn.cursor()
        
        # تعداد ارزهای فعال
        cursor.execute("SELECT COUNT(*) FROM coins WHERE active = 1")
        active_coins = cursor.fetchone()[0] or 0
        
        # آخرین تاریخ بروزرسانی
        cursor.execute("SELECT MAX(created_at) FROM coins WHERE active = 1")
        last_update_result = cursor.fetchone()
        last_update = last_update_result[0] if last_update_result and last_update_result[0] else 'نامشخص'
        
        # تعداد کندل‌ها
        candle_counts = {}
        for timeframe in ['15m', '1h', '4h']:
            try:
                cursor.execute(f"SELECT COUNT(*) FROM price_history_{timeframe}")
                result = cursor.fetchone()
                candle_counts[f'candle_{timeframe}'] = result[0] if result else 0
            except:
                candle_counts[f'candle_{timeframe}'] = 0
        
        # تعداد جداول
        cursor.execute("SELECT COUNT(*) FROM sqlite_master WHERE type='table'")
        total_tables_result = cursor.fetchone()
        total_tables = total_tables_result[0] if total_tables_result else 0
        
        conn.close()
        
        return {
            'active_coins': active_coins,
            'last_update': last_update,
            'candle_15m': candle_counts.get('candle_15m', 0),
            'candle_1h': candle_counts.get('candle_1h', 0),
            'candle_4h': candle_counts.get('candle_4h', 0),
            'total_tables': total_tables,
            'db_path': str(config.DB_PATH),
            'db_exists': True
        }
        
    except Exception as e:
        return {
            'active_coins': 0,
            'last_update': 'خطا در دریافت',
            'candle_15m': 0,
            'candle_1h': 0,
            'candle_4h': 0,
            'total_tables': 0,
            'db_path': str(config.DB_PATH),
            'db_exists': False,
            'error': str(e)
        }


def get_state_data(config):
    """دریافت داده‌های state از فایل cycle_state.json"""
    try:
        state_file = config.BASE_DIR / "state" / "cycle_state.json"
        
        if not state_file.exists():
            return {
                'success': False,
                'error': 'فایل state یافت نشد',
                'message': 'لطفاً ابتدا اسکریپت فیلتر را اجرا کنید'
            }
        
        with open(state_file, 'r', encoding='utf-8') as f:
            state_data = json.load(f)
        
        return {
            'success': True,
            'state': state_data,
            'message': 'داده‌های state بارگذاری شد',
            'file_path': str(state_file),
            'timestamp': datetime.now().isoformat()
        }
        
    except json.JSONDecodeError as e:
        return {
            'success': False,
            'error': f'خطا در خواندن فایل JSON: {str(e)}',
            'message': 'فایل state معتبر نیست'
        }
    except Exception as e:
        return {
            'success': False,
            'error': str(e),
            'message': 'خطا در خواندن فایل state'
        }


def run_filter_script(config):
    """اجرای اسکریپت فیلتر"""
    try:
        script_path = config.BASE_DIR / "scripts" / "cycle" / "cycle_01_coin_filter.py"
        
        if not script_path.exists():
            return {
                'success': False,
                'error': f'اسکریپت یافت نشد: {script_path}',
                'message': 'مسیر اسکریپت اشتباه است'
            }
        
        # اجرای اسکریپت
        start_time = datetime.now()
        
        try:
            result = subprocess.run(
                ['python', str(script_path)],
                capture_output=True,
                text=True,
                encoding='utf-8',
                cwd=str(config.BASE_DIR)
            )
        except Exception as e:
            return {
                'success': False,
                'error': f'خطا در اجرای اسکریپت: {str(e)}',
                'message': 'اسکریپت قابل اجرا نیست'
            }
        
        execution_time = (datetime.now() - start_time).total_seconds()
        
        if result.returncode == 0:
            # خواندن state جدید پس از اجرا
            state_file = config.BASE_DIR / "state" / "cycle_state.json"
            blocks_count = 0
            cycle_id = 'unknown'
            
            if state_file.exists():
                try:
                    with open(state_file, 'r', encoding='utf-8') as f:
                        state_data = json.load(f)
                        blocks_count = state_data.get('stats', {}).get('total_blocks', 0)
                        cycle_id = state_data.get('cycle_id', 'unknown')
                except:
                    pass
            
            return {
                'success': True,
                'message': 'اسکریپت با موفقیت اجرا شد',
                'execution_time': round(execution_time, 2),
                'blocks_count': blocks_count,
                'cycle_id': cycle_id,
                'output_preview': result.stdout[:500] + "..." if len(result.stdout) > 500 else result.stdout,
                'return_code': result.returncode,
                'timestamp': datetime.now().isoformat()
            }
        else:
            return {
                'success': False,
                'error': f'اسکریپت با کد خطا {result.returncode} خاتمه یافت',
                'stderr': result.stderr[:1000] if result.stderr else 'بدون خطا',
                'stdout': result.stdout[:1000] if result.stdout else 'بدون خروجی',
                'execution_time': round(execution_time, 2),
                'return_code': result.returncode
            }
            
    except Exception as e:
        return {
            'success': False,
            'error': str(e),
            'message': 'خطای سرور در اجرای اسکریپت'
        }