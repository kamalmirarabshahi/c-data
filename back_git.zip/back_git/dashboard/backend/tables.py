# backend/tables.py
"""
📊 ماژول مدیریت جداول دیتابیس - نسخه ماژولار
"""

from config import Config
import sqlite3
import json
from typing import Dict, List, Any
from datetime import datetime
import traceback
from pathlib import Path

class TableManager:
    """مدیریت جداول دیتابیس - کاملاً پویا"""
    
    def __init__(self):
        self.db_path = Config.DB_PATH
    
    def _get_connection(self):
        """ایجاد اتصال به دیتابیس"""
        return sqlite3.connect(str(self.db_path))
    
    def _safe_execute(self, conn, query, params=()):
        """اجرای ایمن کوئری و بازگشت cursor"""
        cursor = conn.cursor()
        try:
            cursor.execute(query, params)
            return cursor
        except Exception as e:
            print(f"⚠️ خطا در اجرای کوئری: {query[:50]}... - {e}")
            raise e
    
    def get_all_tables(self) -> Dict[str, Any]:
        """گرفتن لیست تمام جداول دیتابیس"""
        try:
            conn = self._get_connection()
            
            # دریافت تمام جداول
            cursor = self._safe_execute(conn, """
                SELECT name, type 
                FROM sqlite_master 
                WHERE type IN ('table', 'view')
                AND name NOT LIKE 'sqlite_%'
                ORDER BY type, name
            """)
            
            tables_data = cursor.fetchall()
            tables = []
            total_rows = 0
            last_update = None
            
            for table_name, table_type in tables_data:
                # تعداد رکوردها
                try:
                    count_cursor = self._safe_execute(conn, f"SELECT COUNT(*) FROM `{table_name}`")
                    row_count = count_cursor.fetchone()[0]
                    total_rows += row_count
                except:
                    row_count = 0
                
                # تعداد ستون‌ها
                try:
                    info_cursor = self._safe_execute(conn, f"PRAGMA table_info(`{table_name}`)")
                    columns_info = info_cursor.fetchall()
                    columns_count = len(columns_info)
                except:
                    columns_count = 0
                
                # توضیحات جدول
                description = Config.MAIN_TABLES.get(table_name, 'جدول سیستم')
                
                tables.append({
                    'name': table_name,
                    'type': table_type,
                    'description': description,
                    'row_count': row_count,
                    'columns_count': columns_count,
                    'created_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                })
            
            # پیدا کردن آخرین بروزرسانی
            try:
                update_cursor = self._safe_execute(conn, """
                    SELECT MAX(created_at)
                    FROM crypto_klines 
                    WHERE created_at IS NOT NULL AND created_at != ''
                """)
                last_update_result = update_cursor.fetchone()
                last_update = last_update_result[0] if last_update_result else None
            except:
                pass
            
            conn.close()
            
            return {
                'success': True,
                'total_tables': len(tables),
                'total_rows': total_rows,
                'last_update': last_update if last_update else 'نامشخص',
                'tables': tables,
                'database_info': {
                    'path': str(self.db_path),
                    'exists': self.db_path.exists(),
                    'size_mb': self.db_path.stat().st_size / (1024 * 1024) if self.db_path.exists() else 0
                }
            }
            
        except Exception as e:
            print(f"❌ خطا در get_all_tables: {e}")
            return {
                'success': False,
                'error': str(e),
                'total_tables': 0,
                'total_rows': 0,
                'last_update': 'خطا',
                'tables': [],
                'database_info': {
                    'path': str(self.db_path),
                    'exists': self.db_path.exists(),
                    'size_mb': 0
                }
            }
    
    def get_table_details(self, table_name: str) -> Dict[str, Any]:
        """گرفتن اطلاعات کامل یک جدول"""
        try:
            conn = self._get_connection()
            
            # بررسی وجود جدول
            cursor = self._safe_execute(conn, 
                "SELECT name FROM sqlite_master WHERE type='table' AND name=?", 
                (table_name,)
            )
            
            if not cursor.fetchone():
                conn.close()
                return {
                    'success': False,
                    'error': f'جدول {table_name} یافت نشد',
                    'table_name': table_name
                }
            
            # ساختار جدول
            cursor = self._safe_execute(conn, f"PRAGMA table_info(`{table_name}`)")
            columns_data = cursor.fetchall()
            
            # اطلاعات CREATE TABLE
            cursor = self._safe_execute(conn, 
                f"SELECT sql FROM sqlite_master WHERE type='table' AND name='{table_name}'"
            )
            create_result = cursor.fetchone()
            create_statement = create_result[0] if create_result else None
            
            # آمار جدول
            cursor = self._safe_execute(conn, f"SELECT COUNT(*) FROM `{table_name}`")
            total_rows = cursor.fetchone()[0]
            
            # تبدیل columns_data به لیست دیکشنری
            columns = []
            for col in columns_data:
                columns.append({
                    'id': col[0],
                    'name': col[1],
                    'type': col[2],
                    'nullable': col[3] == 0,
                    'default_value': col[4],
                    'primary_key': col[5] == 1
                })
            
            # نمونه داده‌ها (10 رکورد اول)
            cursor = self._safe_execute(conn, f"SELECT * FROM `{table_name}` LIMIT 10")
            sample_rows = cursor.fetchall()
            column_names = [desc[0] for desc in cursor.description] if cursor.description else []
            
            # تبدیل نمونه داده‌ها به لیست لیست
            sample_data = []
            for row in sample_rows:
                formatted_row = []
                for cell in row:
                    if cell is None:
                        formatted_row.append(None)
                    elif isinstance(cell, (int, float)):
                        formatted_row.append(cell)
                    elif isinstance(cell, bytes):
                        formatted_row.append('[BINARY DATA]')
                    else:
                        formatted_row.append(str(cell))
                sample_data.append(formatted_row)
            
            conn.close()
            
            return {
                'success': True,
                'table_name': table_name,
                'description': Config.MAIN_TABLES.get(table_name, 'جدول سیستم'),
                'total_rows': total_rows,
                'create_statement': create_statement,
                'columns': columns,
                'sample_data': sample_data,
                'column_names': column_names,
                'timestamp': datetime.now().isoformat()
            }
            
        except Exception as e:
            print(f"❌ خطا در get_table_details برای جدول {table_name}: {e}")
            return {
                'success': False,
                'error': str(e),
                'table_name': table_name
            }
    
    def get_table_data(self, table_name: str, page: int = 1, page_size: int = None) -> Dict[str, Any]:
        """گرفتن داده‌های یک جدول با صفحه‌بندی"""
        try:
            if page_size is None:
                page_size = Config.DEFAULT_PAGE_SIZE
            
            offset = (page - 1) * page_size
            
            conn = self._get_connection()
            
            # تعداد کل رکوردها
            cursor = self._safe_execute(conn, f"SELECT COUNT(*) FROM `{table_name}`")
            total_rows = cursor.fetchone()[0]
            
            # محاسبه تعداد صفحات
            total_pages = (total_rows + page_size - 1) // page_size
            
            # دریافت داده‌های صفحه جاری
            cursor = self._safe_execute(conn, 
                f"SELECT * FROM `{table_name}` LIMIT ? OFFSET ?", 
                (page_size, offset)
            )
            rows = cursor.fetchall()
            column_names = [desc[0] for desc in cursor.description] if cursor.description else []
            
            # تبدیل ردیف‌ها به لیست لیست
            data = []
            for row in rows:
                formatted_row = []
                for cell in row:
                    if cell is None:
                        formatted_row.append(None)
                    elif isinstance(cell, (int, float)):
                        formatted_row.append(cell)
                    elif isinstance(cell, bytes):
                        formatted_row.append('[BINARY]')
                    else:
                        # کوتاه کردن متن‌های طولانی
                        cell_str = str(cell)
                        if len(cell_str) > 100:
                            formatted_row.append(cell_str[:100] + '...')
                        else:
                            formatted_row.append(cell_str)
                data.append(formatted_row)
            
            # دریافت ساختار
            cursor = self._safe_execute(conn, f"PRAGMA table_info(`{table_name}`)")
            columns_data = cursor.fetchall()
            
            # تبدیل columns_data به لیست دیکشنری
            columns = []
            for col in columns_data:
                columns.append({
                    'name': col[1],
                    'type': col[2],
                    'nullable': col[3] == 0
                })
            
            conn.close()
            
            return {
                'success': True,
                'table_name': table_name,
                'page': page,
                'page_size': page_size,
                'total_rows': total_rows,
                'total_pages': total_pages,
                'columns': columns,
                'data': data,
                'column_names': column_names
            }
            
        except Exception as e:
            print(f"❌ خطا در get_table_data برای جدول {table_name}: {e}")
            traceback.print_exc()
            return {
                'success': False,
                'error': str(e),
                'table_name': table_name
            }
    
    def get_database_schema(self) -> Dict[str, Any]:
        """گرفتن اسکیمای کامل دیتابیس"""
        try:
            conn = self._get_connection()
            
            # دریافت تمام جداول
            cursor = self._safe_execute(conn, 
                "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name"
            )
            tables_data = cursor.fetchall()
            
            schema = {}
            for table_row in tables_data:
                table_name = table_row[0]
                
                # ساختار جدول
                cursor = self._safe_execute(conn, f"PRAGMA table_info(`{table_name}`)")
                columns_data = cursor.fetchall()
                
                # تبدیل columns_data به لیست دیکشنری
                columns_list = []
                for col in columns_data:
                    columns_list.append({
                        'name': col[1],
                        'type': col[2],
                        'nullable': col[3] == 0,
                        'primary_key': col[5] == 1
                    })
                
                # روابط کلید خارجی
                cursor = self._safe_execute(conn, f"PRAGMA foreign_key_list(`{table_name}`)")
                foreign_keys_data = cursor.fetchall()
                
                # تبدیل foreign_keys_data به لیست دیکشنری
                fk_list = []
                for fk in foreign_keys_data:
                    fk_list.append({
                        'from': fk[3],
                        'to_table': fk[2],
                        'to_column': fk[4]
                    })
                
                # ایندکس‌ها
                cursor = self._safe_execute(conn, f"PRAGMA index_list(`{table_name}`)")
                indexes_data = cursor.fetchall()
                
                # تبدیل indexes_data به لیست دیکشنری
                idx_list = []
                for idx in indexes_data:
                    idx_list.append({
                        'name': idx[1],
                        'unique': idx[2] == 1
                    })
                
                # تعداد رکوردها
                cursor = self._safe_execute(conn, f"SELECT COUNT(*) FROM `{table_name}`")
                row_count = cursor.fetchone()[0]
                
                schema[table_name] = {
                    'columns': columns_list,
                    'foreign_keys': fk_list,
                    'indexes': idx_list,
                    'row_count': row_count
                }
            
            conn.close()
            
            return {
                'success': True,
                'schema': schema,
                'total_tables': len(schema),
                'generated_at': datetime.now().isoformat()
            }
            
        except Exception as e:
            print(f"❌ خطا در get_database_schema: {e}")
            return {
                'success': False,
                'error': str(e)
            }
    
    def export_table(self, table_name: str, format: str = 'csv') -> Dict[str, Any]:
        """اکسپورت جدول به فرمت‌های مختلف"""
        try:
            # دریافت داده‌های جدول
            table_data = self.get_table_data(table_name, page=1, page_size=1000)
            
            if not table_data['success']:
                return table_data
            
            # ایجاد فایل خروجی
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            filename = f"{table_name}_{timestamp}.{format}"
            
            # ساختار دایرکتوری export
            export_dir = Path('exports')
            export_dir.mkdir(exist_ok=True)
            filepath = export_dir / filename
            
            if format == 'json':
                with open(filepath, 'w', encoding='utf-8') as f:
                    json.dump({
                        'table_name': table_name,
                        'export_date': datetime.now().isoformat(),
                        'total_rows': table_data['total_rows'],
                        'columns': table_data['columns'],
                        'data': table_data['data']
                    }, f, indent=2, ensure_ascii=False)
            
            elif format == 'csv':
                import csv
                with open(filepath, 'w', encoding='utf-8', newline='') as f:
                    writer = csv.writer(f)
                    writer.writerow(table_data['column_names'])
                    for row in table_data['data']:
                        writer.writerow(row)
            
            elif format == 'xlsx':
                try:
                    import pandas as pd
                    # تبدیل به DataFrame
                    df = pd.DataFrame(table_data['data'], columns=table_data['column_names'])
                    df.to_excel(filepath, index=False)
                except ImportError:
                    return {
                        'success': False,
                        'error': 'پکیج pandas نصب نیست. برای اکسپورت Excel نیاز به pandas دارید.'
                    }
            
            else:
                return {
                    'success': False,
                    'error': f'فرمت {format} پشتیبانی نمی‌شود'
                }
            
            return {
                'success': True,
                'filename': filename,
                'filepath': str(filepath),
                'format': format,
                'row_count': table_data['total_rows'],
                'download_url': f"/exports/{filename}"
            }
            
        except Exception as e:
            print(f"❌ خطا در export_table: {e}")
            return {
                'success': False,
                'error': str(e)
            }
    
    def search_in_table(self, table_name: str, search_term: str, column: str = None) -> Dict[str, Any]:
        """جستجو در داده‌های یک جدول"""
        try:
            conn = self._get_connection()
            
            # ساخت کوئری جستجو
            if column:
                query = f"SELECT * FROM `{table_name}` WHERE `{column}` LIKE ? LIMIT 50"
                params = (f'%{search_term}%',)
            else:
                # جستجو در همه ستون‌های متنی
                cursor = self._safe_execute(conn, f"PRAGMA table_info(`{table_name}`)")
                columns_data = cursor.fetchall()
                
                text_columns = []
                for col in columns_data:
                    col_type = str(col[2]).upper()
                    if any(text_type in col_type for text_type in ['TEXT', 'CHAR', 'VARCHAR']):
                        text_columns.append(col[1])
                
                if not text_columns:
                    conn.close()
                    return {
                        'success': True,
                        'results': [],
                        'total_results': 0,
                        'message': 'هیچ ستون متنی برای جستجو یافت نشد'
                    }
                
                conditions = " OR ".join([f"`{col}` LIKE ?" for col in text_columns])
                query = f"SELECT * FROM `{table_name}` WHERE {conditions} LIMIT 50"
                params = tuple([f'%{search_term}%'] * len(text_columns))
            
            # اجرای جستجو
            cursor = self._safe_execute(conn, query, params)
            results = cursor.fetchall()
            column_names = [desc[0] for desc in cursor.description] if cursor.description else []
            
            # تبدیل نتایج
            formatted_results = []
            for row in results:
                formatted_row = []
                for cell in row:
                    if cell is None:
                        formatted_row.append(None)
                    elif isinstance(cell, (int, float)):
                        formatted_row.append(cell)
                    elif isinstance(cell, bytes):
                        formatted_row.append('[BINARY]')
                    else:
                        formatted_row.append(str(cell))
                formatted_results.append(formatted_row)
            
            conn.close()
            
            return {
                'success': True,
                'table_name': table_name,
                'search_term': search_term,
                'column': column,
                'results': formatted_results,
                'column_names': column_names,
                'total_results': len(formatted_results)
            }
            
        except Exception as e:
            print(f"❌ خطا در search_in_table: {e}")
            return {
                'success': False,
                'error': str(e)
            }

# نمونه singleton برای استفاده در کل برنامه
table_manager = TableManager()

# ============ توابع کمکی برای ماژولار ============

def get_tables_page_data(config=None):
    """دریافت داده‌های صفحه tables برای ماژولار"""
    from datetime import datetime
    
    table_data = table_manager.get_all_tables()
    
    if not table_data.get('success', False):
        raise Exception(f"خطا در دریافت داده‌های جداول: {table_data.get('error', 'خطای ناشناخته')}")
    
    data = {
        'total_tables': table_data.get('total_tables', 0),
        'total_rows': table_data.get('total_rows', 0),
        'last_update': table_data.get('last_update', 'نامشخص'),
        'database_info': table_data.get('database_info', {}),
        'navigation': [
            {'name': 'خانه', 'url': '/', 'icon': 'fas fa-home'},
            {'name': 'لیست ارزها', 'url': '/coins', 'icon': 'fas fa-coins'},
            {'name': 'جداول', 'url': '/tables', 'icon': 'fas fa-table', 'active': True},
            {'name': 'بلوک ارزها', 'url': '/blocks', 'icon': 'fas fa-cubes'}
        ],
        'current_page': 'tables'
    }
    
    if config:
        data['project_name'] = getattr(config, 'SITE_TITLE', 'پروژه ارز دیجیتال')
        data['version'] = '2.1.0'
    
    data['current_date'] = datetime.now().strftime('%Y-%m-%d')
    data['current_time'] = datetime.now().strftime('%H:%M:%S')
    
    return data

# توابع کمکی برای backward compatibility
def get_all_tables():
    """دریافت لیست تمام جداول (برای سازگاری با کد قدیمی)"""
    return table_manager.get_all_tables()

def get_table_structure(table_name: str):
    """دریافت ساختار جدول (برای سازگاری با کد قدیمی)"""
    return table_manager.get_table_details(table_name)

def get_table_data(table_name: str, page: int = 1):
    """دریافت داده‌های جدول (برای سازگاری با کد قدیمی)"""
    return table_manager.get_table_data(table_name, page)

if __name__ == "__main__":
    # تست ماژول
    print("🧪 تست ماژول tables.py")
    print("=" * 50)
    
    manager = TableManager()
    
    # تست 1: دریافت لیست جداول
    print("📋 تست دریافت لیست جداول...")
    result = manager.get_all_tables()
    if result['success']:
        print(f"✅ تعداد جداول: {result['total_tables']}")
        print(f"✅ مجموع رکوردها: {result['total_rows']}")
        print(f"✅ آخرین بروزرسانی: {result['last_update']}")
        
        if result['tables']:
            print("\n📊 نمونه از جداول:")
            for i, table in enumerate(result['tables'][:3]):
                print(f"  {i+1}. {table['name']} ({table['row_count']} رکورد)")
    else:
        print(f"❌ خطا: {result['error']}")
    
    print("\n" + "=" * 50)
    
    # تست 2: دریافت ساختار یک جدول
    print("\n🏗️ تست دریافت ساختار جدول...")
    if result['success'] and result['tables']:
        test_table = result['tables'][0]['name']
        print(f"🔍 بررسی جدول: {test_table}")
        
        structure = manager.get_table_details(test_table)
        if structure['success']:
            print(f"✅ تعداد ستون‌ها: {len(structure['columns'])}")
            print(f"✅ تعداد رکوردها: {structure['total_rows']}")
            
            if structure['columns']:
                print("\n📋 نمونه از ستون‌ها:")
                for i, col in enumerate(structure['columns'][:3]):
                    print(f"  {i+1}. {col['name']} ({col['type']})")
        else:
            print(f"❌ خطا: {structure['error']}")
    
    print("\n" + "=" * 50)
    print("✅ تست ماژول با موفقیت انجام شد!")