# backend/tables_routes.py
"""
📊 تمام routeهای مربوط به جداول (tables)
"""

from flask import render_template, jsonify, request, send_file
from datetime import datetime
from .tables import table_manager

def log_request(endpoint, method, status='success'):
    """لاگ درخواست‌های API"""
    timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    print(f"[{timestamp}] {method} {endpoint} - {status}")

def format_db_path_for_display(db_path):
    """فرمت مسیر دیتابیس برای نمایش"""
    try:
        str_path = str(db_path)
        if len(str_path) > 50:
            return "..." + str_path[-50:]
        return str_path
    except:
        return str(db_path)

def register_tables_routes(app, config):
    """ثبت تمام routeهای tables"""
    
    # ============ HTML PAGES ============
    @app.route('/tables')
    def tables():
        """صفحه مدیریت جداول"""
        log_request('/tables', 'GET')
        try:
            table_data = table_manager.get_all_tables()
            
            if not table_data.get('success', False):
                raise Exception(f"خطا در دریافت داده‌های جداول: {table_data.get('error', 'خطای ناشناخته')}")
            
            total_tables = table_data.get('total_tables', 0)
            total_rows = table_data.get('total_rows', 0)
            last_update = table_data.get('last_update', 'نامشخص')
            
            database_info = table_data.get('database_info', {
                'path': format_db_path_for_display(config.DB_PATH),
                'exists': config.DB_PATH.exists(),
                'size_mb': config.DB_PATH.stat().st_size / (1024 * 1024) if config.DB_PATH.exists() else 0
            })
            
            data = {
                'project_name': config.SITE_TITLE,
                'version': '2.1.0',
                'current_date': datetime.now().strftime('%Y-%m-%d'),
                'current_time': datetime.now().strftime('%H:%M:%S'),
                'total_tables': total_tables,
                'total_rows': total_rows,
                'last_update': last_update,
                'database_info': database_info,
                'navigation': [
                    {'name': 'خانه', 'url': '/', 'icon': 'fas fa-home'},
                    {'name': 'لیست ارزها', 'url': '/coins', 'icon': 'fas fa-coins'},
                    {'name': 'جداول', 'url': '/tables', 'icon': 'fas fa-table', 'active': True},
                    {'name': 'بلوک ارزها', 'url': '/blocks', 'icon': 'fas fa-cubes'}
                ]
            }
            
            return render_template('tables.html', **data)
            
        except Exception as e:
            error_message = str(e)
            print(f"❌ خطا در بارگذاری صفحه جداول: {error_message}")
            
            return render_template('tables.html',
                project_name=config.SITE_TITLE,
                version='2.1.0',
                current_date=datetime.now().strftime('%Y-%m-%d'),
                current_time=datetime.now().strftime('%H:%M:%S'),
                total_tables=0,
                total_rows=0,
                last_update='خطا در بارگذاری',
                database_info={
                    'path': str(config.DB_PATH),
                    'exists': config.DB_PATH.exists(),
                    'size_mb': 0
                },
                navigation=[
                    {'name': 'خانه', 'url': '/', 'icon': 'fas fa-home'},
                    {'name': 'لیست ارزها', 'url': '/coins', 'icon': 'fas fa-coins'},
                    {'name': 'جداول', 'url': '/tables', 'icon': 'fas fa-table', 'active': True},
                    {'name': 'بلوک ارزها', 'url': '/blocks', 'icon': 'fas fa-cubes'}
                ]
            )
    
    # ============ API ROUTES ============
    @app.route('/api/tables')
    def api_tables():
        """API لیست جدول‌های دیتابیس"""
        log_request('/api/tables', 'GET')
        
        try:
            result = table_manager.get_all_tables()
            
            if not result.get('success', False):
                return jsonify({
                    'success': False,
                    'error': result.get('error', 'خطای ناشناخته'),
                    'total_tables': 0,
                    'total_rows': 0,
                    'last_update': 'خطا',
                    'tables': [],
                    'database_info': {
                        'path': str(config.DB_PATH),
                        'exists': config.DB_PATH.exists(),
                        'size_mb': 0
                    }
                }), 500
            
            # تضمین وجود کلیدهای مورد نیاز
            result.setdefault('total_rows', 0)
            result.setdefault('last_update', 'نامشخص')
            
            if not result['last_update'] or result['last_update'] == 'نامشخص':
                try:
                    import sqlite3
                    conn = sqlite3.connect(str(config.DB_PATH))
                    cursor = conn.cursor()
                    cursor.execute("""
                        SELECT MAX(created_at) 
                        FROM crypto_klines 
                        WHERE created_at IS NOT NULL 
                        AND created_at != ''
                    """)
                    db_last_update = cursor.fetchone()[0]
                    if db_last_update:
                        result['last_update'] = db_last_update
                    conn.close()
                except:
                    result['last_update'] = 'نامشخص'
            
            return jsonify(result)
            
        except Exception as e:
            log_request('/api/tables', 'GET', 'error')
            return jsonify({
                'success': False,
                'error': str(e),
                'total_tables': 0,
                'total_rows': 0,
                'last_update': 'خطا',
                'tables': [],
                'database_info': {
                    'path': str(config.DB_PATH),
                    'exists': config.DB_PATH.exists(),
                    'size_mb': 0
                }
            }), 500
    
    @app.route('/api/tables/list')
    def api_tables_list():
        """API لیست جداول (نام دیگر برای سازگاری)"""
        log_request('/api/tables/list', 'GET')
        return api_tables()  # استفاده از همان تابع
    
    @app.route('/api/tables/<table_name>/structure')
    def api_table_structure(table_name):
        """API ساختار جدول"""
        log_request(f'/api/tables/{table_name}/structure', 'GET')
        
        try:
            result = table_manager.get_table_details(table_name)
            
            if not result.get('success', False):
                return jsonify({
                    'success': False,
                    'error': result.get('error', 'خطای ناشناخته'),
                    'table_name': table_name
                }), 404
                
            return jsonify(result)
            
        except Exception as e:
            return jsonify({
                'success': False,
                'error': str(e),
                'table_name': table_name
            }), 500
    
    @app.route('/api/tables/<table_name>/data')
    def api_table_data(table_name):
        """API داده‌های جدول"""
        log_request(f'/api/tables/{table_name}/data', 'GET')
        
        try:
            page = request.args.get('page', 1, type=int)
            page_size = request.args.get('page_size', config.DEFAULT_PAGE_SIZE, type=int)
            
            result = table_manager.get_table_data(table_name, page, page_size)
            
            if not result.get('success', False):
                return jsonify({
                    'success': False,
                    'error': result.get('error', 'خطای ناشناخته'),
                    'table_name': table_name
                }), 400
                
            return jsonify(result)
            
        except Exception as e:
            return jsonify({
                'success': False,
                'error': str(e),
                'table_name': table_name
            }), 500
    
    @app.route('/api/tables/<table_name>/export')
    def api_table_export(table_name):
        """API اکسپورت جدول"""
        log_request(f'/api/tables/{table_name}/export', 'GET')
        
        try:
            format = request.args.get('format', 'csv')
            result = table_manager.export_table(table_name, format)
            
            if not result.get('success', False):
                return jsonify(result), 400
                
            # ارسال فایل برای دانلود
            from pathlib import Path
            filepath = Path(result['filepath'])
            
            if not filepath.exists():
                return jsonify({
                    'success': False,
                    'error': 'فایل اکسپورت یافت نشد'
                }), 404
            
            return send_file(
                filepath,
                as_attachment=True,
                download_name=result['filename']
            )
            
        except Exception as e:
            return jsonify({
                'success': False,
                'error': str(e)
            }), 500
    
    @app.route('/api/database/schema')
    def api_database_schema():
        """API اسکیمای کامل دیتابیس"""
        log_request('/api/database/schema', 'GET')
        
        try:
            result = table_manager.get_database_schema()
            return jsonify(result)
        except Exception as e:
            return jsonify({
                'success': False,
                'error': str(e)
            }), 500
    
    print("✅ ماژول tables routes با موفقیت ثبت شد")
    return app