# backend/index_routes.py
"""
🏠 تمام routeهای مربوط به صفحه اصلی (index)
"""

from flask import render_template, jsonify
from datetime import datetime
from .index import get_index_data, get_database_stats

def log_request(endpoint, method, status='success'):
    """لاگ درخواست‌های API"""
    timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    print(f"[{timestamp}] {method} {endpoint} - {status}")

def register_index_routes(app, config):
    """ثبت تمام routeهای صفحه اصلی"""
    
    # ============ HTML PAGES ============
    @app.route('/')
    def index():
        """صفحه اصلی (شامل داشبورد)"""
        log_request('/', 'GET')
        try:
            data = get_index_data()
            # ✅ اصلاح navigation برای حذف گزارشات - مشابه app.py
            data['navigation'] = [
                {'name': 'خانه', 'url': '/', 'icon': 'fas fa-home'},
                {'name': 'لیست ارزها', 'url': '/coins', 'icon': 'fas fa-coins'},
                {'name': 'جداول', 'url': '/tables', 'icon': 'fas fa-table'},
                {'name': 'بلوک ارزها', 'url': '/blocks', 'icon': 'fas fa-cubes'}
            ]
            return render_template('index.html', **data)
        except Exception as e:
            print(f"❌ خطا در بارگذاری صفحه اصلی: {e}")
            
            # داده‌های fallback - مشابه app.py
            return render_template('index.html', 
                                  project_name=config.SITE_TITLE,
                                  app_name=config.SITE_DESCRIPTION,
                                  error=str(e),
                                  database_stats={
                                      'active_coins': 0,
                                      'last_update': 'خطا',
                                      'candle_15m': 0,
                                      'candle_1h': 0,
                                      'candle_4h': 0,
                                      'db_exists': False
                                  },
                                  navigation=[
                                      {'name': 'خانه', 'url': '/', 'icon': 'fas fa-home'},
                                      {'name': 'لیست ارزها', 'url': '/coins', 'icon': 'fas fa-coins'},
                                      {'name': 'جداول', 'url': '/tables', 'icon': 'fas fa-table'},
                                      {'name': 'بلوک ارزها', 'url': '/blocks', 'icon': 'fas fa-cubes'}
                                  ])
    
    # ============ API ROUTES ============
    @app.route('/api/stats')
    def api_stats():
        """API آمار کلی پروژه"""
        log_request('/api/stats', 'GET')
        try:
            db_stats = get_database_stats()
            
            return jsonify({
                'status': 'success',
                'timestamp': datetime.now().isoformat(),
                'data': {
                    'project': config.SITE_TITLE,
                    'version': '2.1.0',
                    'database': {
                        'path': str(config.DB_PATH),
                        'exists': config.DB_PATH.exists(),
                        'total_coins': db_stats.get('active_coins', 0),
                        'total_klines': db_stats.get('15m_candles', 0) + 
                                       db_stats.get('1h_candles', 0) + 
                                       db_stats.get('4h_candles', 0),
                        'active_coins': db_stats.get('active_coins', 0),
                        'inactive_coins': 0,
                        'last_update': db_stats.get('last_update', 'نامشخص'),
                        'tables_count': db_stats.get('total_tables', 0)
                    },
                    'system': {
                        'server_url': f"http://{config.HOST}:{config.PORT}",
                        'debug_mode': config.DEBUG,
                        'timezone': 'Asia/Tehran',
                        'current_time': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                    }
                }
            })
        except Exception as e:
            log_request('/api/stats', 'GET', 'error')
            return jsonify({
                'status': 'error',
                'error': str(e),
                'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            }), 500
    
    print("✅ ماژول index routes با موفقیت ثبت شد")
    return app