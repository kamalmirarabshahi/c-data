# backend/blocks_routes.py

from flask import render_template, jsonify, request
from .blocks import get_blocks_data, get_state_data, run_filter_script


def register_blocks_routes(app, config):
    """ثبت routeهای مربوط به blocks"""
    
    @app.route('/blocks')
    def blocks():
        """صفحه مدیریت بلوک‌های ارزها"""
        try:
            base_data = get_blocks_data(config)
            
            # ✅ اصلاح navigation
            base_data['navigation'] = [
                {'name': 'خانه', 'url': '/', 'icon': 'fas fa-home'},
                {'name': 'لیست ارزها', 'url': '/coins', 'icon': 'fas fa-coins'},
                {'name': 'جداول', 'url': '/tables', 'icon': 'fas fa-table'},
                {'name': 'بلوک ارزها', 'url': '/blocks', 'icon': 'fas fa-cubes'},
                {'name': 'گزارشات', 'url': '/reports', 'icon': 'fas fa-chart-bar'}
            ]
            
            return render_template('blocks.html', **base_data)
        except Exception as e:
            return render_template('blocks.html',
                                 project_name=config.SITE_TITLE,
                                 error=str(e),
                                 navigation=[
                                     {'name': 'خانه', 'url': '/', 'icon': 'fas fa-home'},
                                     {'name': 'لیست ارزها', 'url': '/coins', 'icon': 'fas fa-coins'},
                                     {'name': 'جداول', 'url': '/tables', 'icon': 'fas fa-table'},
                                     {'name': 'بلوک ارزها', 'url': '/blocks', 'icon': 'fas fa-cubes'},
                                     {'name': 'گزارشات', 'url': '/reports', 'icon': 'fas fa-chart-bar'}
                                 ])

    @app.route('/api/state/cycle', methods=['GET'])
    def api_state_cycle():
        """API خواندن فایل cycle_state.json"""
        result = get_state_data(config)
        if result.get('success'):
            return jsonify(result)
        else:
            return jsonify(result), 404

    @app.route('/api/run/filter', methods=['POST'])
    def api_run_filter():
        """API اجرای اسکریپت cycle_01_coin_filter.py"""
        result = run_filter_script(config)
        if result.get('success'):
            return jsonify(result)
        else:
            return jsonify(result), 400
    
    return app