# coins.py (اصلاح شده)
"""
🪙 Backend مخصوص صفحه coins.html - نسخه سازگار با ساختار واقعی دیتابیس
"""

import sqlite3
from pathlib import Path
from datetime import datetime
import pandas as pd
from io import BytesIO

def get_db_connection():
    """اتصال به دیتابیس"""
    db_path = Path(__file__).parent.parent.parent / 'data' / 'crypto_master.db'
    
    if not db_path.exists():
        print(f"⚠️ هشدار: فایل دیتابیس یافت نشد: {db_path}")
        return None
    
    try:
        conn = sqlite3.connect(str(db_path))
        conn.row_factory = sqlite3.Row
        return conn
    except sqlite3.Error as e:
        print(f"❌ خطای SQLite: {e}")
        return None

# ============ توابع اصلی (همان قبلی) ============
def get_coins_data(page=1, per_page=50, symbol_filter='', status_filter=''):
    """دریافت داده‌های ارزها با فیلتر و صفحه‌بندی - سازگار با ساختار واقعی"""
    conn = get_db_connection()
    if not conn:
        return get_fallback_coins_data()
    
    try:
        cursor = conn.cursor()
        
        # ساخت WHERE با فیلترها
        where_conditions = []
        params = []
        
        if symbol_filter:
            where_conditions.append("symbol LIKE ?")
            params.append(f'%{symbol_filter.upper()}%')
        
        if status_filter and status_filter != '':
            try:
                status_int = int(status_filter)
                where_conditions.append("is_active = ?")
                params.append(status_int)
            except ValueError:
                pass
        
        # ساخت SQL WHERE
        where_sql = " WHERE " + " AND ".join(where_conditions) if where_conditions else ""
        
        # تعداد کل با فیلتر
        count_query = f"SELECT COUNT(*) FROM crypto_coins {where_sql}"
        cursor.execute(count_query, params)
        total_count = cursor.fetchone()[0]
        
        # محاسبه صفحه‌بندی
        total_pages = max(1, (total_count + per_page - 1) // per_page)
        offset = (page - 1) * per_page
        
        # **کوئری اصلاح شده با ستون‌های واقعی**
        # توجه: updated_at وجود ندارد، پس از created_at استفاده می‌کنیم
        query = f'''
            SELECT 
                id, symbol, coin_name, base_asset,
                is_active, current_price, volume_24h,
                market_cap, created_at
            FROM crypto_coins
            {where_sql}
            ORDER BY 
                CASE 
                    WHEN is_active BETWEEN 1 AND 4 THEN 1
                    WHEN is_active = 0 THEN 2
                    WHEN is_active = 5 THEN 3
                    ELSE 4
                END,
                symbol
            LIMIT ? OFFSET ?
        '''
        
        params.extend([per_page, offset])
        cursor.execute(query, params)
        
        coins = []
        for row in cursor.fetchall():
            coins.append({
                'id': row['id'],
                'symbol': row['symbol'],
                'coin_name': row['coin_name'] or 'نامشخص',
                'base_asset': row['base_asset'] or 'USDT',
                'is_active': row['is_active'],
                'current_price': format_price(row['current_price']),
                'volume_24h': format_number(row['volume_24h']),
                'market_cap': format_number(row['market_cap']),
                'created_at': format_date(row['created_at']),
                # updated_at وجود ندارد، پس از created_at استفاده می‌کنیم
                'updated_at': format_date(row['created_at'])  
            })
        
        conn.close()
        
        return {
            'status': 'success',
            'coins': coins,
            'total': total_count,
            'total_pages': total_pages,
            'current_page': page,
            'per_page': per_page
        }
        
    except Exception as e:
        if conn:
            conn.close()
        return {
            'status': 'error',
            'error': str(e),
            'coins': [],
            'total': 0,
            'total_pages': 1,
            'current_page': 1,
            'per_page': per_page
        }

def update_coin_status(symbol, new_status):
    """بروزرسانی وضعیت is_active یک ارز - سازگار با ساختار واقعی"""
    conn = get_db_connection()
    if not conn:
        return {
            'status': 'error',
            'error': 'خطا در اتصال به دیتابیس'
        }
    
    try:
        cursor = conn.cursor()
        
        # بررسی معتبر بودن وضعیت (0 تا 5)
        if new_status < 0 or new_status > 5:
            return {
                'status': 'error',
                'error': f'وضعیت {new_status} معتبر نیست. باید بین 0 تا 5 باشد.'
            }
        
        # بررسی وجود ارز
        cursor.execute('SELECT symbol FROM crypto_coins WHERE symbol = ?', (symbol.upper(),))
        if not cursor.fetchone():
            conn.close()
            return {
                'status': 'error',
                'error': f'ارز با نماد {symbol} یافت نشد.'
            }
        
        # **بروزرسانی وضعیت ارز - بدون updated_at**
        # در دیتابیس شما ستون updated_at وجود ندارد
        cursor.execute('''
            UPDATE crypto_coins 
            SET is_active = ?
            WHERE symbol = ?
        ''', (new_status, symbol.upper()))
        
        conn.commit()
        
        # دریافت اطلاعات به‌روز شده
        cursor.execute('''
            SELECT symbol, coin_name, is_active, created_at 
            FROM crypto_coins 
            WHERE symbol = ?
        ''', (symbol.upper(),))
        
        coin = cursor.fetchone()
        conn.close()
        
        return {
            'status': 'success',
            'message': f'وضعیت ارز {symbol} به {get_coin_status_name(new_status)} تغییر کرد.',
            'symbol': symbol.upper(),
            'new_status': new_status,
            'coin_name': coin['coin_name'] if coin else 'نامشخص'
        }
        
    except sqlite3.Error as e:
        if conn:
            conn.close()
        return {
            'status': 'error',
            'error': f'خطای دیتابیس: {str(e)}'
        }
    except Exception as e:
        if conn:
            conn.close()
        return {
            'status': 'error',
            'error': f'خطای ناشناخته: {str(e)}'
        }

# ============ توابع کمکی (همان قبلی) ============
def get_coin_status_name(status_id):
    """نام وضعیت ارز"""
    status_map = {
        0: 'جدید',
        1: 'فعال (عالی)',
        2: 'فعال (خوب)',
        3: 'فعال (متوسط)',
        4: 'فعال (ضعیف)',
        5: 'غیرفعال',
        None: 'نامشخص'
    }
    return status_map.get(status_id, f'کد {status_id}')

def format_price(price):
    """فرمت‌دهی قیمت"""
    if price is None or price == 0:
        return 'N/A'
    try:
        price_float = float(price)
        if price_float >= 1000:
            return f"{price_float:,.0f}"
        elif price_float >= 1:
            return f"{price_float:,.2f}"
        else:
            return f"{price_float:.6f}".rstrip('0').rstrip('.')
    except:
        return 'N/A'

def format_number(num):
    """فرمت‌دهی اعداد بزرگ"""
    if num is None or num == 0:
        return 'N/A'
    try:
        num_float = float(num)
        if num_float >= 1_000_000_000:
            return f"{num_float/1_000_000_000:.1f}B"
        elif num_float >= 1_000_000:
            return f"{num_float/1_000_000:.1f}M"
        elif num_float >= 1_000:
            return f"{num_float/1_000:.1f}K"
        else:
            return f"{num_float:,.0f}"
    except:
        return 'N/A'

def format_date(date_str):
    """فرمت‌دهی تاریخ"""
    if not date_str:
        return 'نامشخص'
    try:
        # ممکن است فرمت‌های مختلفی داشته باشد
        if 'T' in date_str:  # ISO format
            dt = datetime.fromisoformat(date_str.replace('Z', '+00:00'))
        else:
            dt = datetime.strptime(date_str, '%Y-%m-%d %H:%M:%S')
        return dt.strftime('%Y/%m/%d %H:%M')
    except:
        return date_str[:16] if date_str else 'نامشخص'

def get_fallback_coins_data():
    """داده‌های پیش‌فرض ارزها"""
    return {
        'status': 'warning',
        'message': 'دیتابیس در دسترس نیست. از داده‌های نمونه استفاده می‌شود.',
        'coins': get_sample_coins(),
        'total': 967,
        'total_pages': 20,
        'current_page': 1,
        'per_page': 50
    }

def get_sample_coins():
    """لیست نمونه ارزها"""
    sample_coins = [
        {'symbol': 'BTCUSDT', 'price': '88,093.00', 'status': 'فعال (عالی)'},
        {'symbol': 'ETHUSDT', 'price': '2,976.38', 'status': 'فعال (عالی)'},
        {'symbol': 'BNBUSDT', 'price': '856.26', 'status': 'فعال (خوب)'},
        {'symbol': 'SOLUSDT', 'price': '105.42', 'status': 'فعال (خوب)'},
        {'symbol': 'XRPUSDT', 'price': '1.90', 'status': 'فعال (متوسط)'},
        {'symbol': 'ADAUSDT', 'price': '0.62', 'status': 'فعال (ضعیف)'},
        {'symbol': 'DOGEUSDT', 'price': '0.15', 'status': 'فعال (متوسط)'},
        {'symbol': 'DOTUSDT', 'price': '7.82', 'status': 'فعال (خوب)'},
        {'symbol': 'AVAXUSDT', 'price': '36.50', 'status': 'فعال (خوب)'},
        {'symbol': 'LINKUSDT', 'price': '14.25', 'status': 'فعال (متوسط)'}
    ]
    
    coins = []
    for i, coin in enumerate(sample_coins, 1):
        coins.append({
            'id': i,
            'symbol': coin['symbol'],
            'coin_name': get_coin_name(coin['symbol']),
            'base_asset': 'USDT',
            'is_active': get_status_code(coin['status']),
            'current_price': coin['price'],
            'volume_24h': f"{i * 100:.1f}M",
            'market_cap': f"{i * 1000:.1f}B",
            'created_at': '2024-01-01 00:00:00',
            'updated_at': '2024-01-15 12:00:00'  # برای نمایش در front-end
        })
    
    return coins

def get_coin_name(symbol):
    """نام ارز بر اساس نماد"""
    names = {
        'BTCUSDT': 'Bitcoin',
        'ETHUSDT': 'Ethereum',
        'BNBUSDT': 'Binance Coin',
        'SOLUSDT': 'Solana',
        'XRPUSDT': 'Ripple',
        'ADAUSDT': 'Cardano',
        'DOGEUSDT': 'Dogecoin',
        'DOTUSDT': 'Polkadot',
        'AVAXUSDT': 'Avalanche',
        'LINKUSDT': 'Chainlink'
    }
    return names.get(symbol, 'Unknown Coin')

def get_status_code(status_name):
    """کد وضعیت بر اساس نام"""
    codes = {
        'فعال (عالی)': 1,
        'فعال (خوب)': 2,
        'فعال (متوسط)': 3,
        'فعال (ضعیف)': 4,
        'غیرفعال': 5,
        'جدید': 0
    }
    return codes.get(status_name, 0)

# ============ توابع جدید برای معماری ماژولار ============

def get_coins_page_data(page=1, per_page=50, symbol_filter='', status_filter='', config=None):
    """
    دریافت تمام داده‌های مورد نیاز برای صفحه coins
    شامل navigation و سایر داده‌های قالب
    """
    # دریافت داده‌های اصلی
    coins_data = get_coins_data(
        page=page,
        per_page=per_page,
        symbol_filter=symbol_filter,
        status_filter=status_filter
    )
    
    # اضافه کردن navigation
    coins_data['navigation'] = get_coins_navigation()
    
    # اضافه کردن اطلاعات صفحه
    coins_data['current_page'] = 'coins'
    coins_data['filters'] = {
        'symbol': symbol_filter,
        'status': status_filter,
        'per_page': per_page
    }
    
    # اضافه کردن اطلاعات پروژه اگر config ارائه شده باشد
    if config:
        coins_data['project_name'] = getattr(config, 'SITE_TITLE', 'پروژه ارز دیجیتال')
        coins_data['app_name'] = getattr(config, 'SITE_DESCRIPTION', 'سیستم تحلیل ارزهای دیجیتال')
        coins_data['version'] = '3.0.0'
    
    # اضافه کردن زمان جاری
    coins_data['current_date'] = datetime.now().strftime('%Y-%m-%d')
    coins_data['current_time'] = datetime.now().strftime('%H:%M:%S')
    
    return coins_data

def get_coins_navigation():
    """Navigation مخصوص صفحه coins"""
    return [
        {'name': 'خانه', 'url': '/', 'icon': 'fas fa-home'},
        {'name': 'لیست ارزها', 'url': '/coins', 'icon': 'fas fa-coins', 'active': True},
        {'name': 'جداول', 'url': '/tables', 'icon': 'fas fa-table'},
        {'name': 'بلوک ارزها', 'url': '/blocks', 'icon': 'fas fa-cubes'}
    ]

def export_coins_report(report_type, config=None):
    """
    ایجاد گزارش اکسپورت برای coins
    report_type: 'all_coins', 'active_coins', 'inactive_coins'
    """
    # تعیین پارامترهای گزارش
    if report_type == 'all_coins':
        data = get_coins_data(per_page=getattr(config, 'MAX_EXPORT_ROWS', 10000))
        filename_prefix = 'all_coins'
    elif report_type == 'active_coins':
        data = get_coins_data(status_filter='1', per_page=getattr(config, 'MAX_EXPORT_ROWS', 10000))
        filename_prefix = 'active_coins'
    elif report_type == 'inactive_coins':
        data = get_coins_data(status_filter='5', per_page=getattr(config, 'MAX_EXPORT_ROWS', 10000))
        filename_prefix = 'inactive_coins'
    else:
        return {
            'status': 'error',
            'error': f'نوع گزارش نامعتبر: {report_type}'
        }
    
    if data.get('status') != 'success':
        return {
            'status': 'error',
            'error': data.get('error', 'خطا در تولید گزارش')
        }
    
    # تبدیل به DataFrame
    df = pd.DataFrame(data['coins'])
    
    # حذف ستون‌های غیرضروری
    columns_to_drop = ['status_name', 'created_at', 'updated_at']
    for col in columns_to_drop:
        if col in df.columns:
            df = df.drop(columns=[col])
    
    # ایجاد فایل CSV در memory
    output = BytesIO()
    df.to_csv(output, index=False, encoding='utf-8-sig')
    output.seek(0)
    
    # نام فایل
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    download_name = f'crypto_{filename_prefix}_{timestamp}.csv'
    
    return {
        'status': 'success',
        'file_data': output,
        'filename': download_name,
        'mimetype': 'text/csv',
        'rows_count': len(df)
    }