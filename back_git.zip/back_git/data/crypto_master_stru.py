import sqlite3
import pandas as pd
import json
import os
from datetime import datetime
import html

class DatabaseStructureAnalyzer:
    def __init__(self, db_path):
        """
        تحلیلگر ساختار کامل دیتابیس SQLite
        
        Args:
            db_path: مسیر فایل دیتابیس
        """
        self.db_path = db_path
        self.connection = None
        self.cursor = None
        self.database_info = {}
        
    def connect(self):
        """اتصال به دیتابیس"""
        try:
            self.connection = sqlite3.connect(self.db_path)
            self.cursor = self.connection.cursor()
            print(f"✅ موفقیت‌آمیز به دیتابیس متصل شد: {self.db_path}")
            return True
        except Exception as e:
            print(f"❌ خطا در اتصال به دیتابیس: {e}")
            return False
    
    def get_database_metadata(self):
        """دریافت متادیتای کامل دیتابیس"""
        metadata = {
            'file_path': self.db_path,
            'file_size': f"{os.path.getsize(self.db_path):,} بایت",
            'file_size_mb': f"{os.path.getsize(self.db_path) / (1024 * 1024):.2f} مگابایت",
            'created_date': datetime.fromtimestamp(os.path.getctime(self.db_path)).strftime('%Y-%m-%d %H:%M:%S'),
            'modified_date': datetime.fromtimestamp(os.path.getmtime(self.db_path)).strftime('%Y-%m-%d %H:%M:%S'),
            'sqlite_version': sqlite3.sqlite_version,
            'connection_time': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        }
        return metadata
    
    def get_all_tables(self):
        """دریافت لیست همه جداول"""
        self.cursor.execute("""
            SELECT 
                name, 
                type,
                sql
            FROM sqlite_master 
            WHERE type IN ('table', 'view')
            ORDER BY type, name
        """)
        return self.cursor.fetchall()
    
    def get_table_structure(self, table_name):
        """دریافت ساختار کامل یک جدول"""
        # اطلاعات ستون‌ها
        self.cursor.execute(f"PRAGMA table_info({table_name})")
        columns = self.cursor.fetchall()
        
        # کلیدهای اصلی
        self.cursor.execute(f"PRAGMA table_info({table_name})")
        pk_columns = [col[1] for col in self.cursor.fetchall() if col[5] == 1]
        
        # کلیدهای خارجی
        self.cursor.execute(f"PRAGMA foreign_key_list({table_name})")
        foreign_keys = self.cursor.fetchall()
        
        # ایندکس‌ها
        self.cursor.execute(f"PRAGMA index_list({table_name})")
        indexes = self.cursor.fetchall()
        
        # اطلاعات ایندکس
        index_details = {}
        for index in indexes:
            index_name = index[1]
            self.cursor.execute(f"PRAGMA index_info({index_name})")
            index_details[index_name] = self.cursor.fetchall()
        
        # تعداد رکوردها
        try:
            self.cursor.execute(f"SELECT COUNT(*) FROM {table_name}")
            row_count = self.cursor.fetchone()[0]
        except:
            row_count = 0
        
        # آخرین تاریخ بروزرسانی (با بررسی ستون‌های تاریخ)
        last_update_date = self.get_last_update_date(table_name)
        
        # نمونه‌ای از داده‌ها
        sample_data = []
        column_names = []
        if row_count > 0:
            try:
                self.cursor.execute(f"SELECT * FROM {table_name} LIMIT 5")
                sample_data = self.cursor.fetchall()
                
                # نام ستون‌ها
                self.cursor.execute(f"SELECT * FROM {table_name} LIMIT 0")
                column_names = [description[0] for description in self.cursor.description]
            except:
                sample_data = []
                column_names = []
        
        return {
            'columns': columns,
            'primary_keys': pk_columns,
            'foreign_keys': foreign_keys,
            'indexes': indexes,
            'index_details': index_details,
            'row_count': row_count,
            'last_update': last_update_date,
            'sample_data': sample_data,
            'column_names': column_names
        }
    
    def get_last_update_date(self, table_name):
        """دریافت آخرین تاریخ بروزرسانی جدول"""
        try:
            # ابتدا ستون‌های تاریخ را پیدا می‌کنیم
            self.cursor.execute(f"PRAGMA table_info({table_name})")
            columns = self.cursor.fetchall()
            
            # ستون‌هایی که نام‌شان شامل date, time, timestamp, created, modified, updated است
            date_columns = []
            for col in columns:
                col_name = col[1].lower()
                if any(keyword in col_name for keyword in ['date', 'time', 'timestamp', 'created', 'modified', 'updated']):
                    date_columns.append(col[1])
            
            if date_columns:
                # از هر ستون تاریخ، جدیدترین مقدار را پیدا می‌کنیم
                max_dates = []
                for date_col in date_columns:
                    try:
                        self.cursor.execute(f"SELECT MAX({date_col}) FROM {table_name}")
                        max_date = self.cursor.fetchone()[0]
                        if max_date:
                            max_dates.append(max_date)
                    except:
                        continue
                
                if max_dates:
                    # بزرگترین تاریخ را برمی‌گردانیم
                    try:
                        valid_dates = []
                        for date_str in max_dates:
                            try:
                                if len(str(date_str)) >= 8:
                                    valid_dates.append(date_str)
                            except:
                                continue
                        
                        if valid_dates:
                            try:
                                valid_dates.sort(reverse=True)
                                return valid_dates[0]
                            except:
                                return valid_dates[0]
                    except:
                        return max_dates[0] if max_dates else None
            
            return "ستون تاریخ یافت نشد"
            
        except Exception as e:
            print(f"خطا در دریافت تاریخ بروزرسانی جدول {table_name}: {e}")
            return "خطا در دریافت تاریخ"
    
    def get_tables_summary(self):
        """دریافت خلاصه اطلاعات همه جداول"""
        tables_summary = []
        
        self.cursor.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name")
        tables = self.cursor.fetchall()
        
        for table, in tables:
            structure = self.get_table_structure(table)
            tables_summary.append({
                'table_name': table,
                'column_count': len(structure['columns']),
                'row_count': structure['row_count'],
                'last_update': structure['last_update'],
                'primary_keys': len(structure['primary_keys']),
                'foreign_keys': len(structure['foreign_keys']),
                'indexes': len(structure['indexes'])
            })
        
        return tables_summary
    
    def get_database_statistics(self):
        """دریافت آمار کامل دیتابیس"""
        tables_summary = self.get_tables_summary()
        
        total_rows = sum(item['row_count'] for item in tables_summary)
        total_columns = sum(item['column_count'] for item in tables_summary)
        tables_with_data = sum(1 for item in tables_summary if item['row_count'] > 0)
        empty_tables = sum(1 for item in tables_summary if item['row_count'] == 0)
        
        # توزیع رکوردها
        row_distribution = {
            'empty': sum(1 for item in tables_summary if item['row_count'] == 0),
            'small': sum(1 for item in tables_summary if 1 <= item['row_count'] <= 1000),
            'medium': sum(1 for item in tables_summary if 1001 <= item['row_count'] <= 10000),
            'large': sum(1 for item in tables_summary if 10001 <= item['row_count'] <= 100000),
            'very_large': sum(1 for item in tables_summary if item['row_count'] > 100000)
        }
        
        # بزرگترین جداول
        largest_tables = sorted(tables_summary, key=lambda x: x['row_count'], reverse=True)[:5]
        
        stats = {
            'total_tables': len(tables_summary),
            'total_rows': total_rows,
            'total_columns': total_columns,
            'tables_with_data': tables_with_data,
            'empty_tables': empty_tables,
            'row_distribution': row_distribution,
            'largest_tables': largest_tables,
            'average_rows_per_table': total_rows / len(tables_summary) if tables_summary else 0,
            'average_columns_per_table': total_columns / len(tables_summary) if tables_summary else 0
        }
        
        return stats
    
    def get_table_relationships(self):
        """دریافت روابط بین جداول"""
        relationships = []
        
        self.cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
        tables = [table[0] for table in self.cursor.fetchall()]
        
        for table in tables:
            self.cursor.execute(f"PRAGMA foreign_key_list({table})")
            fks = self.cursor.fetchall()
            
            for fk in fks:
                relationships.append({
                    'from_table': table,
                    'from_column': fk[3],
                    'to_table': fk[2],
                    'to_column': fk[4],
                    'on_update': fk[5],
                    'on_delete': fk[6]
                })
        
        return relationships
    
    def analyze_data_types_distribution(self):
        """توزیع انواع داده‌ها در جداول"""
        type_distribution = {}
        
        self.cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
        tables = self.cursor.fetchall()
        
        for table, in tables:
            self.cursor.execute(f"PRAGMA table_info({table})")
            columns = self.cursor.fetchall()
            
            for col in columns:
                dtype = col[2].upper()
                if 'INT' in dtype:
                    dtype = 'INTEGER'
                elif 'CHAR' in dtype or 'TEXT' in dtype or 'CLOB' in dtype:
                    dtype = 'TEXT'
                elif 'BLOB' in dtype:
                    dtype = 'BLOB'
                elif 'REAL' in dtype or 'FLOA' in dtype or 'DOUB' in dtype:
                    dtype = 'REAL'
                elif 'NUM' in dtype:
                    dtype = 'NUMERIC'
                elif dtype == '':
                    dtype = 'UNKNOWN'
                
                type_distribution[dtype] = type_distribution.get(dtype, 0) + 1
        
        return type_distribution
    
    def generate_html_report(self, output_file='database_structure_report.html'):
        """ایجاد گزارش HTML کامل"""
        print("\n📊 در حال ایجاد گزارش HTML...")
        
        # جمع‌آوری داده‌ها
        metadata = self.get_database_metadata()
        tables = self.get_all_tables()
        relationships = self.get_table_relationships()
        type_distribution = self.analyze_data_types_distribution()
        tables_summary = self.get_tables_summary()
        stats = self.get_database_statistics()
        
        # محاسبه آمار
        total_rows = stats['total_rows']
        total_columns = stats['total_columns']
        largest_tables = stats['largest_tables']
        
        # HTML Header
        html_content = f"""<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>گزارش کامل ساختار پایگاه داده - {os.path.basename(self.db_path)}</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }}
        
        body {{
            background: #f5f7fa;
            color: #333;
            line-height: 1.6;
            padding: 20px;
        }}
        
        .container {{
            max-width: 1400px;
            margin: 0 auto;
            background: white;
            border-radius: 15px;
            box-shadow: 0 5px 25px rgba(0,0,0,0.1);
            overflow: hidden;
        }}
        
        .header {{
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 40px;
            text-align: center;
            border-bottom: 5px solid #4a6ee0;
        }}
        
        .header h1 {{
            font-size: 2.5rem;
            margin-bottom: 10px;
        }}
        
        .header .subtitle {{
            font-size: 1.2rem;
            opacity: 0.9;
        }}
        
        .metadata {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
            padding: 30px;
            background: #f8f9fa;
            border-bottom: 1px solid #dee2e6;
        }}
        
        .metadata-item {{
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            border-right: 4px solid #4a6ee0;
        }}
        
        .metadata-item h3 {{
            color: #4a6ee0;
            margin-bottom: 10px;
            display: flex;
            align-items: center;
            gap: 10px;
        }}
        
        .summary-cards {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            padding: 30px;
            background: white;
        }}
        
        .card {{
            background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
            color: white;
            padding: 25px;
            border-radius: 10px;
            text-align: center;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            transition: transform 0.3s;
        }}
        
        .card:hover {{
            transform: translateY(-5px);
        }}
        
        .card i {{
            font-size: 2.5rem;
            margin-bottom: 15px;
        }}
        
        .card .number {{
            font-size: 2.5rem;
            font-weight: bold;
            margin-bottom: 5px;
        }}
        
        .card .label {{
            font-size: 1.1rem;
            opacity: 0.9;
        }}
        
        .tables-summary {{
            padding: 30px;
            background: white;
            border-bottom: 1px solid #dee2e6;
        }}
        
        .tables-summary h2 {{
            color: #2c3e50;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }}
        
        .summary-table {{
            width: 100%;
            border-collapse: collapse;
            font-size: 0.95rem;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            border-radius: 10px;
            overflow: hidden;
        }}
        
        .summary-table th {{
            background: #2c3e50;
            color: white;
            padding: 15px;
            text-align: center;
            font-weight: bold;
        }}
        
        .summary-table td {{
            padding: 15px;
            border-bottom: 1px solid #e9ecef;
            text-align: center;
        }}
        
        .summary-table tr:nth-child(even) {{
            background: #f8f9fa;
        }}
        
        .summary-table tr:hover {{
            background: #e9ecef;
            cursor: pointer;
        }}
        
        .table-link {{
            color: #4a6ee0;
            font-weight: bold;
            text-decoration: none;
            cursor: pointer;
        }}
        
        .table-link:hover {{
            text-decoration: underline;
        }}
        
        .row-count {{
            font-weight: bold;
            color: #27ae60;
        }}
        
        .last-update {{
            font-family: monospace;
            background: #fff3cd;
            padding: 5px 10px;
            border-radius: 5px;
            font-size: 0.9rem;
        }}
        
        .tabs {{
            display: flex;
            background: #f8f9fa;
            border-bottom: 1px solid #dee2e6;
            overflow-x: auto;
        }}
        
        .tab {{
            padding: 20px 30px;
            cursor: pointer;
            background: #e9ecef;
            border-right: 1px solid #dee2e6;
            transition: all 0.3s;
            white-space: nowrap;
            font-weight: bold;
            color: #495057;
        }}
        
        .tab:hover {{
            background: #dee2e6;
        }}
        
        .tab.active {{
            background: white;
            color: #4a6ee0;
            border-bottom: 3px solid #4a6ee0;
        }}
        
        .tab-content {{
            padding: 30px;
            display: none;
        }}
        
        .tab-content.active {{
            display: block;
            animation: fadeIn 0.5s;
        }}
        
        @keyframes fadeIn {{
            from {{ opacity: 0; }}
            to {{ opacity: 1; }}
        }}
        
        .table-card {{
            background: white;
            border-radius: 10px;
            padding: 25px;
            margin-bottom: 30px;
            box-shadow: 0 3px 15px rgba(0,0,0,0.08);
            border: 1px solid #e9ecef;
            transition: transform 0.3s;
        }}
        
        .table-card:hover {{
            transform: translateY(-5px);
            border-color: #4a6ee0;
        }}
        
        .table-header {{
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
            padding-bottom: 15px;
            border-bottom: 2px solid #e9ecef;
        }}
        
        .table-title {{
            display: flex;
            align-items: center;
            gap: 15px;
            color: #2c3e50;
            font-size: 1.4rem;
        }}
        
        .table-type {{
            background: #3498db;
            color: white;
            padding: 5px 15px;
            border-radius: 20px;
            font-size: 0.9rem;
            font-weight: bold;
        }}
        
        .table-stats {{
            display: flex;
            gap: 15px;
        }}
        
        .stat {{
            background: #f8f9fa;
            padding: 8px 15px;
            border-radius: 20px;
            font-weight: bold;
            color: #495057;
            border: 1px solid #dee2e6;
        }}
        
        .columns-table {{
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
            font-size: 0.95rem;
        }}
        
        .columns-table th {{
            background: #2c3e50;
            color: white;
            padding: 15px;
            text-align: right;
            font-weight: bold;
        }}
        
        .columns-table td {{
            padding: 15px;
            border-bottom: 1px solid #e9ecef;
            text-align: right;
        }}
        
        .columns-table tr:nth-child(even) {{
            background: #f8f9fa;
        }}
        
        .columns-table tr:hover {{
            background: #e9ecef;
        }}
        
        .column-name {{
            font-weight: bold;
            color: #2c3e50;
        }}
        
        .data-type {{
            display: inline-block;
            padding: 3px 10px;
            border-radius: 5px;
            font-family: monospace;
            font-size: 0.9rem;
        }}
        
        .type-int {{ background: #d4edda; color: #155724; }}
        .type-text {{ background: #d1ecf1; color: #0c5460; }}
        .type-real {{ background: #fff3cd; color: #856404; }}
        .type-blob {{ background: #cce5ff; color: #004085; }}
        .type-numeric {{ background: #f8d7da; color: #721c24; }}
        .type-boolean {{ background: #e8d7ff; color: #4a235a; }}
        
        .primary-key {{
            color: #27ae60;
            font-weight: bold;
        }}
        
        .not-null {{
            color: #e74c3c;
            font-weight: bold;
        }}
        
        .default-value {{
            font-family: monospace;
            background: #f8f9fa;
            padding: 2px 8px;
            border-radius: 4px;
            border: 1px solid #dee2e6;
        }}
        
        .foreign-key {{
            background: #e8f4f8;
            padding: 15px;
            border-radius: 8px;
            margin: 10px 0;
            border-right: 3px solid #3498db;
        }}
        
        .foreign-key-title {{
            font-weight: bold;
            color: #2c3e50;
            margin-bottom: 5px;
        }}
        
        .index {{
            background: #fff3cd;
            padding: 10px 15px;
            border-radius: 8px;
            margin: 10px 0;
            border: 1px dashed #f39c12;
        }}
        
        .sample-data {{
            background: #f8f9fa;
            padding: 20px;
            border-radius: 10px;
            margin-top: 20px;
            border: 1px solid #dee2e6;
        }}
        
        .sample-data h4 {{
            color: #2c3e50;
            margin-bottom: 15px;
            display: flex;
            align-items: center;
            gap: 10px;
        }}
        
        .sample-table {{
            width: 100%;
            border-collapse: collapse;
            font-size: 0.9rem;
        }}
        
        .sample-table th {{
            background: #495057;
            color: white;
            padding: 12px;
            text-align: center;
        }}
        
        .sample-table td {{
            padding: 12px;
            border-bottom: 1px solid #dee2e6;
            text-align: center;
            font-family: monospace;
        }}
        
        .sql-viewer {{
            background: #2c3e50;
            color: #f8f9fa;
            padding: 20px;
            border-radius: 10px;
            font-family: monospace;
            overflow-x: auto;
            white-space: pre-wrap;
            margin: 20px 0;
        }}
        
        .relationship-diagram {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
            gap: 20px;
            padding: 20px;
        }}
        
        .relationship-card {{
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 3px 10px rgba(0,0,0,0.1);
            border: 1px solid #dee2e6;
        }}
        
        .relationship-arrow {{
            text-align: center;
            font-size: 1.5rem;
            color: #3498db;
            padding: 10px;
        }}
        
        .controls {{
            display: flex;
            gap: 15px;
            margin: 30px 0;
            flex-wrap: wrap;
        }}
        
        .btn {{
            padding: 12px 25px;
            border: none;
            border-radius: 8px;
            background: #4a6ee0;
            color: white;
            font-weight: bold;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 10px;
            transition: all 0.3s;
        }}
        
        .btn:hover {{
            background: #3a5ed0;
            transform: translateY(-2px);
        }}
        
        .export-section {{
            background: #f8f9fa;
            padding: 25px;
            border-radius: 10px;
            margin: 30px 0;
            border: 1px solid #dee2e6;
        }}
        
        .stats-grid {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
            margin: 30px 0;
        }}
        
        .stat-box {{
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 3px 10px rgba(0,0,0,0.1);
            border: 1px solid #e9ecef;
        }}
        
        .stat-box h3 {{
            color: #2c3e50;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }}
        
        .progress-bar {{
            background: #e9ecef;
            height: 10px;
            border-radius: 5px;
            margin: 10px 0;
            overflow: hidden;
        }}
        
        .progress-fill {{
            height: 100%;
            background: linear-gradient(90deg, #667eea, #764ba2);
            border-radius: 5px;
        }}
        
        footer {{
            text-align: center;
            padding: 30px;
            background: #2c3e50;
            color: white;
            margin-top: 50px;
        }}
        
        @media (max-width: 768px) {{
            .metadata {{
                grid-template-columns: 1fr;
            }}
            
            .summary-cards {{
                grid-template-columns: 1fr;
            }}
            
            .tabs {{
                flex-direction: column;
            }}
            
            .tab {{
                text-align: center;
            }}
            
            .summary-table,
            .columns-table {{
                font-size: 0.85rem;
            }}
            
            .summary-table th,
            .summary-table td,
            .columns-table th,
            .columns-table td {{
                padding: 10px;
            }}
            
            .table-header {{
                flex-direction: column;
                align-items: flex-start;
                gap: 15px;
            }}
            
            .table-stats {{
                flex-wrap: wrap;
            }}
        }}
    </style>
</head>
<body>
    <div class="container">
        <!-- هدر -->
        <div class="header">
            <h1><i class="fas fa-database"></i> گزارش کامل ساختار پایگاه داده</h1>
            <div class="subtitle">{os.path.basename(self.db_path)}</div>
        </div>
        
        <!-- متادیتا -->
        <div class="metadata">
            <div class="metadata-item">
                <h3><i class="fas fa-info-circle"></i> اطلاعات فایل</h3>
                <p><strong>مسیر:</strong> {metadata['file_path']}</p>
                <p><strong>حجم:</strong> {metadata['file_size']} ({metadata['file_size_mb']})</p>
                <p><strong>تاریخ ایجاد:</strong> {metadata['created_date']}</p>
                <p><strong>تاریخ ویرایش:</strong> {metadata['modified_date']}</p>
            </div>
            <div class="metadata-item">
                <h3><i class="fas fa-cogs"></i> اطلاعات فنی</h3>
                <p><strong>نسخه SQLite:</strong> {metadata['sqlite_version']}</p>
                <p><strong>زمان تحلیل:</strong> {metadata['connection_time']}</p>
                <p><strong>تعداد جداول:</strong> {len([t for t in tables if t[1] == 'table'])}</p>
                <p><strong>تعداد ویوها:</strong> {len([t for t in tables if t[1] == 'view'])}</p>
            </div>
        </div>
        
        <!-- کارت‌های خلاصه -->
        <div class="summary-cards">
            <div class="card">
                <i class="fas fa-table"></i>
                <div class="number">{len([t for t in tables if t[1] == 'table'])}</div>
                <div class="label">تعداد جداول</div>
            </div>
            <div class="card">
                <i class="fas fa-list-ol"></i>
                <div class="number">{total_rows:,}</div>
                <div class="label">تعداد رکوردها</div>
            </div>
            <div class="card">
                <i class="fas fa-columns"></i>
                <div class="number">{total_columns:,}</div>
                <div class="label">تعداد ستون‌ها</div>
            </div>
            <div class="card">
                <i class="fas fa-link"></i>
                <div class="number">{len(relationships)}</div>
                <div class="label">روابط</div>
            </div>
            <div class="card">
                <i class="fas fa-database"></i>
                <div class="number">{metadata['file_size_mb']}</div>
                <div class="label">حجم دیتابیس</div>
            </div>
            <div class="card">
                <i class="fas fa-chart-line"></i>
                <div class="number">{stats['average_rows_per_table']:.0f}</div>
                <div class="label">میانگین رکورد/جدول</div>
            </div>
        </div>
        
        <!-- جدول خلاصه جداول -->
        <div class="tables-summary">
            <h2><i class="fas fa-list-ol"></i> خلاصه جداول پایگاه داده</h2>
            <table class="summary-table">
                <thead>
                    <tr>
                        <th>ردیف</th>
                        <th>نام جدول</th>
                        <th>تعداد ستون‌ها</th>
                        <th>تعداد رکوردها</th>
                        <th>آخرین بروزرسانی</th>
                        <th>کلیدهای اصلی</th>
                        <th>کلیدهای خارجی</th>
                        <th>ایندکس‌ها</th>
                    </tr>
                </thead>
                <tbody>"""
        
        # اضافه کردن ردیف‌های جدول خلاصه
        for i, table_summary in enumerate(tables_summary, 1):
            html_content += f"""
                    <tr onclick="scrollToTable('{table_summary['table_name']}')" style="cursor: pointer;">
                        <td>{i}</td>
                        <td><span class="table-link">{table_summary['table_name']}</span></td>
                        <td>{table_summary['column_count']}</td>
                        <td><span class="row-count">{table_summary['row_count']:,}</span></td>
                        <td><span class="last-update">{table_summary['last_update']}</span></td>
                        <td>{table_summary['primary_keys']}</td>
                        <td>{table_summary['foreign_keys']}</td>
                        <td>{table_summary['indexes']}</td>
                    </tr>"""
        
        html_content += """
                </tbody>
            </table>
        </div>
        
        <!-- تب‌ها -->
        <div class="tabs">
            <div class="tab active" onclick="switchTab('structure')">ساختار کامل جداول</div>
            <div class="tab" onclick="switchTab('stats')">آمار و گزارش</div>
            <div class="tab" onclick="switchTab('relationships')">روابط</div>
            <div class="tab" onclick="switchTab('sql')">اسکریپت‌ها</div>
            <div class="tab" onclick="switchTab('data')">توزیع داده‌ها</div>
            <div class="tab" onclick="switchTab('export')">خروجی‌ها</div>
        </div>
        
        <!-- تب ساختار جداول -->
        <div class="tab-content active" id="structure-tab">"""
        
        # بخش جداول با جزئیات کامل
        for i, (table_name, table_type, table_sql) in enumerate(tables, 1):
            if table_type != 'table':
                continue
                
            structure = self.get_table_structure(table_name)
            
            html_content += f"""
            <div class="table-card" id="table-{table_name}">
                <div class="table-header">
                    <div class="table-title">
                        <i class="fas fa-table"></i>
                        جدول {i}: {table_name}
                        <span class="table-type">{table_type}</span>
                    </div>
                    <div class="table-stats">
                        <span class="stat"><i class="fas fa-columns"></i> {len(structure['columns'])} فیلد</span>
                        <span class="stat"><i class="fas fa-list-ol"></i> {structure['row_count']:,} رکورد</span>
                        <span class="stat"><i class="fas fa-key"></i> {len(structure['primary_keys'])} کلید اصلی</span>
                        <span class="stat"><i class="fas fa-calendar-alt"></i> {structure['last_update']}</span>
                    </div>
                </div>
                
                <h4><i class="fas fa-code"></i> اسکریپت ایجاد جدول:</h4>
                <div class="sql-viewer">{html.escape(table_sql or 'SQL not available')}</div>
                
                <h4><i class="fas fa-list-ul"></i> ساختار ستون‌ها:</h4>
                <table class="columns-table">
                    <thead>
                        <tr>
                            <th>ردیف</th>
                            <th>نام ستون</th>
                            <th>نوع داده</th>
                            <th>Nullable</th>
                            <th>مقدار پیش‌فرض</th>
                            <th>توضیحات</th>
                        </tr>
                    </thead>
                    <tbody>"""
            
            for j, col in enumerate(structure['columns'], 1):
                col_id, name, dtype, notnull, default, pk = col
                
                # تعیین کلاس نوع داده
                dtype_class = 'type-text'
                dtype_upper = dtype.upper()
                if 'INT' in dtype_upper:
                    dtype_class = 'type-int'
                elif 'REAL' in dtype_upper or 'FLOAT' in dtype_upper or 'DOUBLE' in dtype_upper:
                    dtype_class = 'type-real'
                elif 'BLOB' in dtype_upper:
                    dtype_class = 'type-blob'
                elif 'NUM' in dtype_upper:
                    dtype_class = 'type-numeric'
                elif 'BOOL' in dtype_upper:
                    dtype_class = 'type-boolean'
                
                pk_text = ' <span class="primary-key">(PK)</span>' if pk else ''
                null_text = '<span class="not-null">NOT NULL</span>' if notnull else 'NULL'
                default_text = f'<span class="default-value">{default}</span>' if default else 'NULL'
                
                html_content += f"""
                        <tr>
                            <td>{j}</td>
                            <td><span class="column-name">{name}{pk_text}</span></td>
                            <td><span class="data-type {dtype_class}">{dtype}</span></td>
                            <td>{null_text}</td>
                            <td>{default_text}</td>
                            <td></td>
                        </tr>"""
            
            html_content += """
                    </tbody>
                </table>"""
            
            # کلیدهای خارجی
            if structure['foreign_keys']:
                html_content += """
                <h4><i class="fas fa-link"></i> کلیدهای خارجی:</h4>"""
                for fk in structure['foreign_keys']:
                    html_content += f"""
                <div class="foreign-key">
                    <div class="foreign-key-title">{fk[3]} → {fk[2]}.{fk[4]}</div>
                    <div>ON UPDATE: {fk[5]} | ON DELETE: {fk[6]}</div>
                </div>"""
            
            # ایندکس‌ها
            if structure['indexes']:
                html_content += """
                <h4><i class="fas fa-sort-alpha-down"></i> ایندکس‌ها:</h4>"""
                for idx in structure['indexes']:
                    idx_id, idx_name, unique, origin, partial = idx
                    unique_text = "UNIQUE" if unique else "NON-UNIQUE"
                    html_content += f"""
                <div class="index">
                    <strong>{idx_name}</strong> ({unique_text})
                </div>"""
            
            # نمونه داده‌ها
            if structure['sample_data']:
                html_content += f"""
                <div class="sample-data">
                    <h4><i class="fas fa-eye"></i> 5 رکورد نمونه:</h4>
                    <table class="sample-table">
                        <thead>
                            <tr>"""
                for col_name in structure['column_names']:
                    html_content += f"<th>{col_name}</th>"
                
                html_content += """
                            </tr>
                        </thead>
                        <tbody>"""
                
                for row in structure['sample_data']:
                    html_content += "<tr>"
                    for cell in row:
                        cell_text = str(cell)[:50] + ("..." if len(str(cell)) > 50 else "")
                        html_content += f"<td title='{html.escape(str(cell))}'>{html.escape(cell_text)}</td>"
                    html_content += "</tr>"
                
                html_content += """
                        </tbody>
                    </table>
                </div>"""
            
            html_content += """
            </div>"""
        
        html_content += """
        </div>
        
        <!-- تب آمار و گزارش -->
        <div class="tab-content" id="stats-tab">
            <h2><i class="fas fa-chart-bar"></i> آمار و گزارش کامل</h2>
            
            <div class="stats-grid">
                <div class="stat-box">
                    <h3><i class="fas fa-chart-pie"></i> توزیع رکوردها</h3>
                    <p><strong>جداول خالی:</strong> {stats['row_distribution']['empty']} جدول</p>
                    <div class="progress-bar">
                        <div class="progress-fill" style="width: {(stats['row_distribution']['empty']/stats['total_tables']*100) if stats['total_tables'] > 0 else 0}%"></div>
                    </div>
                    
                    <p><strong>جداول کوچک (۱-۱,۰۰۰):</strong> {stats['row_distribution']['small']} جدول</p>
                    <div class="progress-bar">
                        <div class="progress-fill" style="width: {(stats['row_distribution']['small']/stats['total_tables']*100) if stats['total_tables'] > 0 else 0}%"></div>
                    </div>
                    
                    <p><strong>جداول متوسط (۱,۰۰۱-۱۰,۰۰۰):</strong> {stats['row_distribution']['medium']} جدول</p>
                    <div class="progress-bar">
                        <div class="progress-fill" style="width: {(stats['row_distribution']['medium']/stats['total_tables']*100) if stats['total_tables'] > 0 else 0}%"></div>
                    </div>
                    
                    <p><strong>جداول بزرگ (۱۰,۰۰۱-۱۰۰,۰۰۰):</strong> {stats['row_distribution']['large']} جدول</p>
                    <div class="progress-bar">
                        <div class="progress-fill" style="width: {(stats['row_distribution']['large']/stats['total_tables']*100) if stats['total_tables'] > 0 else 0}%"></div>
                    </div>
                    
                    <p><strong>جداول بسیار بزرگ (+۱۰۰,۰۰۰):</strong> {stats['row_distribution']['very_large']} جدول</p>
                    <div class="progress-bar">
                        <div class="progress-fill" style="width: {(stats['row_distribution']['very_large']/stats['total_tables']*100) if stats['total_tables'] > 0 else 0}%"></div>
                    </div>
                </div>
                
                <div class="stat-box">
                    <h3><i class="fas fa-trophy"></i> بزرگترین جداول</h3>"""
        
        for i, table in enumerate(largest_tables, 1):
            percentage = (table['row_count'] / total_rows * 100) if total_rows > 0 else 0
            html_content += f"""
                    <p><strong>{i}. {table['table_name']}:</strong> {table['row_count']:,} رکورد ({percentage:.1f}%)</p>
                    <div class="progress-bar">
                        <div class="progress-fill" style="width: {percentage}%"></div>
                    </div>"""
        
        html_content += f"""
                </div>
                
                <div class="stat-box">
                    <h3><i class="fas fa-info-circle"></i> آمار کلی</h3>
                    <p><strong>تعداد کل جداول:</strong> {stats['total_tables']}</p>
                    <p><strong>تعداد کل رکوردها:</strong> {stats['total_rows']:,}</p>
                    <p><strong>تعداد کل ستون‌ها:</strong> {stats['total_columns']:,}</p>
                    <p><strong>جداول دارای داده:</strong> {stats['tables_with_data']}</p>
                    <p><strong>جداول خالی:</strong> {stats['empty_tables']}</p>
                    <p><strong>میانگین رکورد در هر جدول:</strong> {stats['average_rows_per_table']:.0f}</p>
                    <p><strong>میانگین ستون در هر جدول:</strong> {stats['average_columns_per_table']:.1f}</p>
                </div>
            </div>
        </div>
        
        <!-- تب روابط -->
        <div class="tab-content" id="relationships-tab">
            <h2><i class="fas fa-project-diagram"></i> نمودار روابط جداول</h2>"""
        
        if relationships:
            html_content += """
            <div class="relationship-diagram">"""
            
            for rel in relationships:
                html_content += f"""
                <div class="relationship-card">
                    <div style="text-align: center; font-weight: bold; color: #2c3e50;">
                        {rel['from_table']}
                    </div>
                    <div style="text-align: center; font-size: 0.9rem; color: #495057;">
                        {rel['from_column']}
                    </div>
                    <div class="relationship-arrow">
                        <i class="fas fa-arrow-down"></i>
                    </div>
                    <div style="text-align: center; font-weight: bold; color: #27ae60;">
                        {rel['to_table']}
                    </div>
                    <div style="text-align: center; font-size: 0.9rem; color: #495057;">
                        {rel['to_column']}
                    </div>
                    <div style="text-align: center; margin-top: 10px; font-size: 0.8rem; color: #6c757d;">
                        ON UPDATE: {rel['on_update']} | ON DELETE: {rel['on_delete']}
                    </div>
                </div>"""
            
            html_content += """
            </div>"""
        else:
            html_content += """
            <div style="text-align: center; padding: 50px; color: #6c757d;">
                <i class="fas fa-unlink fa-3x" style="margin-bottom: 20px;"></i>
                <h3>هیچ رابطه‌ای بین جداول وجود ندارد</h3>
            </div>"""
        
        html_content += """
        </div>
        
        <!-- تب اسکریپت‌ها -->
        <div class="tab-content" id="sql-tab">
            <h2><i class="fas fa-code"></i> اسکریپت کامل دیتابیس</h2>"""
        
        for table_name, table_type, table_sql in tables:
            html_content += f"""
            <div style="margin: 20px 0;">
                <h3 style="color: #2c3e50;">{table_type.upper()}: {table_name}</h3>
                <div class="sql-viewer">{html.escape(table_sql or '-- No SQL available')}</div>
            </div>"""
        
        html_content += """
        </div>
        
        <!-- تب توزیع داده‌ها -->
        <div class="tab-content" id="data-tab">
            <h2><i class="fas fa-chart-pie"></i> توزیع انواع داده‌ها</h2>
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 20px; margin: 30px 0;">"""
        
        # توزیع انواع داده‌ها
        html_content += """
                <div style="background: white; padding: 25px; border-radius: 10px; box-shadow: 0 3px 10px rgba(0,0,0,0.1);">
                    <h3 style="color: #2c3e50; margin-bottom: 20px;"><i class="fas fa-chart-bar"></i> توزیع انواع داده‌ها</h3>"""
        
        total_types = sum(type_distribution.values())
        for dtype, count in sorted(type_distribution.items(), key=lambda x: x[1], reverse=True):
            percentage = (count / total_types * 100) if total_types > 0 else 0
            html_content += f"""
                    <div style="margin: 15px 0;">
                        <div style="display: flex; justify-content: space-between; margin-bottom: 5px;">
                            <span>{dtype if dtype else 'UNKNOWN'}</span>
                            <span>{count} ({percentage:.1f}%)</span>
                        </div>
                        <div style="background: #e9ecef; height: 10px; border-radius: 5px; overflow: hidden;">
                            <div style="background: #4a6ee0; width: {percentage}%; height: 100%;"></div>
                        </div>
                    </div>"""
        
        html_content += """
                </div>
            </div>
        </div>
        
        <!-- تب خروجی‌ها -->
        <div class="tab-content" id="export-tab">
            <div class="export-section">
                <h2><i class="fas fa-download"></i> خروجی‌های قابل دانلود</h2>
                <div class="controls">
                    <button class="btn" onclick="exportJSON()">
                        <i class="fas fa-file-code"></i> خروجی JSON
                    </button>
                    <button class="btn" onclick="exportCSV()">
                        <i class="fas fa-file-csv"></i> خروجی CSV
                    </button>
                    <button class="btn" onclick="printReport()">
                        <i class="fas fa-print"></i> چاپ گزارش
                    </button>
                    <button class="btn" onclick="saveHTML()">
                        <i class="fas fa-save"></i> ذخیره HTML
                    </button>
                </div>
            </div>
        </div>
        
        <!-- فوتر -->
        <footer>
            <p>گزارش تولید شده توسط Database Structure Analyzer</p>
            <p>تاریخ تولید: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</p>
        </footer>
    </div>
    
    <script>
        // سیستم تب‌ها
        function switchTab(tabName) {{
            // غیرفعال کردن همه تب‌ها
            document.querySelectorAll('.tab').forEach(tab => {{
                tab.classList.remove('active');
            }});
            
            document.querySelectorAll('.tab-content').forEach(content => {{
                content.classList.remove('active');
            }});
            
            // فعال کردن تب انتخاب شده
            event.target.classList.add('active');
            document.getElementById(tabName + '-tab').classList.add('active');
        }}
        
        // پرش به جدول مشخص شده
        function scrollToTable(tableName) {{
            // فعال کردن تب ساختار جداول
            document.querySelectorAll('.tab').forEach(tab => {{
                tab.classList.remove('active');
            }});
            document.querySelectorAll('.tab-content').forEach(content => {{
                content.classList.remove('active');
            }});
            
            document.querySelector('[onclick="switchTab(\'structure\')"]').classList.add('active');
            document.getElementById('structure-tab').classList.add('active');
            
            // اسکرول به جدول مورد نظر
            const tableElement = document.getElementById('table-' + tableName);
            if (tableElement) {{
                tableElement.scrollIntoView({{
                    behavior: 'smooth',
                    block: 'start'
                }});
                
                // هایلایت کردن جدول
                tableElement.style.boxShadow = '0 0 0 3px #4a6ee0';
                tableElement.style.transition = 'box-shadow 0.3s';
                
                setTimeout(() => {{
                    tableElement.style.boxShadow = '0 3px 15px rgba(0,0,0,0.08)';
                }}, 2000);
            }}
        }}
        
        // توابع خروجی
        function exportJSON() {{
            alert('خروجی JSON آماده دانلود است!');
            window.location.href = 'database_structure.json';
        }}
        
        function exportCSV() {{
            alert('خروجی CSV آماده دانلود است!');
            window.location.href = 'database_structure.xlsx';
        }}
        
        function printReport() {{
            window.print();
        }}
        
        function saveHTML() {{
            const htmlContent = document.documentElement.outerHTML;
            const blob = new Blob([htmlContent], {{ type: 'text/html' }});
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = 'database_structure_report.html';
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
        }}
        
        // جستجو در جداول
        function searchTables() {{
            const searchTerm = document.getElementById('search-input').value.toLowerCase();
            document.querySelectorAll('.table-card').forEach(card => {{
                const cardText = card.textContent.toLowerCase();
                card.style.display = cardText.includes(searchTerm) ? 'block' : 'none';
            }});
        }}
        
        // فعال کردن کلیک روی ردیف‌های جدول
        document.addEventListener('DOMContentLoaded', function() {{
            document.querySelectorAll('.summary-table tr').forEach(row => {{
                row.addEventListener('click', function() {{
                    const tableName = this.querySelector('.table-link').textContent;
                    scrollToTable(tableName);
                }});
            }});
        }});
    </script>
</body>
</html>"""
        
        # ذخیره فایل HTML
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(html_content)
        
        print(f"✅ گزارش HTML در فایل '{output_file}' ذخیره شد.")
        return output_file
    
    def export_json(self, output_file='database_structure.json'):
        """صدور ساختار به JSON"""
        print("\n📊 در حال ایجاد خروجی JSON...")
        
        tables = self.get_all_tables()
        tables_summary = self.get_tables_summary()
        
        data = {
            'metadata': self.get_database_metadata(),
            'statistics': self.get_database_statistics(),
            'tables_summary': tables_summary,
            'relationships': self.get_table_relationships(),
            'type_distribution': self.analyze_data_types_distribution(),
            'tables': []
        }
        
        for table_name, table_type, table_sql in tables:
            if table_type == 'table':
                structure = self.get_table_structure(table_name)
                data['tables'].append({
                    'name': table_name,
                    'type': table_type,
                    'sql': table_sql,
                    'row_count': structure['row_count'],
                    'last_update': structure['last_update'],
                    'structure': {
                        'columns': [
                            {
                                'id': col[0],
                                'name': col[1],
                                'type': col[2],
                                'not_null': bool(col[3]),
                                'default_value': col[4],
                                'primary_key': bool(col[5])
                            }
                            for col in structure['columns']
                        ],
                        'primary_keys': structure['primary_keys'],
                        'foreign_keys': [
                            {
                                'id': fk[0],
                                'seq': fk[1],
                                'table': fk[2],
                                'from_column': fk[3],
                                'to_column': fk[4],
                                'on_update': fk[5],
                                'on_delete': fk[6]
                            }
                            for fk in structure['foreign_keys']
                        ],
                        'indexes': structure['indexes'],
                        'sample_data_count': len(structure['sample_data'])
                    }
                })
        
        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        
        print(f"✅ خروجی JSON در فایل '{output_file}' ذخیره شد.")
        return output_file
    
    def export_excel(self, output_file='database_structure.xlsx'):
        """صدور ساختار به Excel"""
        print("\n📊 در حال ایجاد خروجی Excel...")
        
        tables_summary = self.get_tables_summary()
        stats = self.get_database_statistics()
        
        with pd.ExcelWriter(output_file, engine='openpyxl') as writer:
            # ورق اطلاعات کلی
            metadata_df = pd.DataFrame([self.get_database_metadata()])
            metadata_df.to_excel(writer, sheet_name='Metadata', index=False)
            
            # ورق آمار
            stats_df = pd.DataFrame([stats])
            stats_df.to_excel(writer, sheet_name='Statistics', index=False)
            
            # ورق خلاصه جداول
            summary_df = pd.DataFrame(tables_summary)
            summary_df.to_excel(writer, sheet_name='Tables Summary', index=False)
            
            # ورق توزیع رکوردها
            row_distribution = pd.DataFrame([stats['row_distribution']])
            row_distribution.to_excel(writer, sheet_name='Row Distribution', index=False)
            
            # ورق بزرگترین جداول
            largest_tables = pd.DataFrame(stats['largest_tables'])
            largest_tables.to_excel(writer, sheet_name='Largest Tables', index=False)
            
            # ورق ساختار هر جدول
            tables = self.get_all_tables()
            for table_name, table_type, table_sql in tables:
                if table_type == 'table':
                    structure = self.get_table_structure(table_name)
                    
                    columns_data = []
                    for col in structure['columns']:
                        columns_data.append({
                            'ID': col[0],
                            'Name': col[1],
                            'Type': col[2],
                            'Not Null': 'Yes' if col[3] else 'No',
                            'Default': col[4],
                            'Primary Key': 'Yes' if col[5] else 'No'
                        })
                    
                    if columns_data:
                        columns_df = pd.DataFrame(columns_data)
                        # نام ورق را کوتاه کنیم اگر طولانی بود
                        sheet_name = table_name[:30]
                        columns_df.to_excel(writer, sheet_name=sheet_name, index=False)
        
        print(f"✅ خروجی Excel در فایل '{output_file}' ذخیره شد.")
        return output_file
    
    def close(self):
        """بستن اتصال به دیتابیس"""
        if self.connection:
            self.connection.close()
            print("✅ اتصال به دیتابیس بسته شد.")

def generate_all_reports(db_path):
    """
    تولید همه گزارش‌ها از دیتابیس
    """
    analyzer = DatabaseStructureAnalyzer(db_path)
    
    if not analyzer.connect():
        return
    
    try:
        print(f"\n{'='*70}")
        print("🔍 در حال تحلیل ساختار کامل دیتابیس...")
        print(f"{'='*70}\n")
        
        # دریافت اطلاعات اولیه
        metadata = analyzer.get_database_metadata()
        print("📋 اطلاعات دیتابیس:")
        for key, value in metadata.items():
            print(f"  {key}: {value}")
        
        # دریافت جداول
        tables = analyzer.get_all_tables()
        print(f"\n📊 تعداد جداول: {len([t for t in tables if t[1] == 'table'])}")
        print("📊 تعداد ویوها:", len([t for t in tables if t[1] == 'view']))
        
        # دریافت آمار
        stats = analyzer.get_database_statistics()
        print("\n📊 آمار دیتابیس:")
        print(f"  تعداد کل رکوردها: {stats['total_rows']:,}")
        print(f"  تعداد کل ستون‌ها: {stats['total_columns']:,}")
        print(f"  جداول دارای داده: {stats['tables_with_data']}")
        print(f"  جداول خالی: {stats['empty_tables']}")
        print(f"  میانگین رکورد/جدول: {stats['average_rows_per_table']:.0f}")
        
        # نمایش خلاصه جداول
        tables_summary = analyzer.get_tables_summary()
        print("\n📋 خلاصه جداول:")
        print("-" * 120)
        print(f"{'ردیف':<5} {'نام جدول':<30} {'ستون‌ها':<8} {'رکوردها':<12} {'کلید اصلی':<10} {'کلید خارجی':<10} {'ایندکس':<8} {'آخرین بروزرسانی'}")
        print("-" * 120)
        for i, table_info in enumerate(tables_summary, 1):
            print(f"{i:<5} {table_info['table_name']:<30} {table_info['column_count']:<8} "
                  f"{table_info['row_count']:<12,} {table_info['primary_keys']:<10} "
                  f"{table_info['foreign_keys']:<10} {table_info['indexes']:<8} {str(table_info['last_update'])}")
        print("-" * 120)
        
        # بزرگترین جداول
        print("\n🏆 بزرگترین جداول از نظر تعداد رکورد:")
        largest_tables = sorted(tables_summary, key=lambda x: x['row_count'], reverse=True)[:5]
        for i, table in enumerate(largest_tables, 1):
            print(f"  {i}. {table['table_name']}: {table['row_count']:,} رکورد")
        
        # تولید گزارش‌ها
        print(f"\n{'='*70}")
        print("📤 در حال تولید گزارش‌ها...")
        print(f"{'='*70}")
        
        # 1. گزارش HTML (اصلی)
        html_report = analyzer.generate_html_report('database_structure_report.html')
        
        # 2. گزارش JSON
        json_report = analyzer.export_json('database_structure.json')
        
        # 3. گزارش Excel
        excel_report = analyzer.export_excel('database_structure.xlsx')
        
        print(f"\n{'='*70}")
        print("✅ همه گزارش‌ها با موفقیت تولید شدند!")
        print(f"{'='*70}")
        print("\n📁 فایل‌های تولید شده:")
        print(f"  1. {html_report} (گزارش کامل HTML)")
        print(f"  2. {json_report} (داده‌های ساختاری JSON)")
        print(f"  3. {excel_report} (گزارش Excel)")
        print(f"\n📌 دستور برای باز کردن گزارش HTML در مرورگر:")
        print(f"  start {html_report}")
        
    finally:
        analyzer.close()

if __name__ == "__main__":
    # مسیر دیتابیس شما
    db_path = r"C:\Users\Kamal\Desktop\py-prg\git\c-data\data\crypto_master.db"
    
    # بررسی وجود فایل
    if not os.path.exists(db_path):
        print(f"❌ فایل دیتابیس یافت نشد: {db_path}")
        print("📌 لطفاً مسیر صحیح را وارد کنید.")
    else:
        generate_all_reports(db_path)