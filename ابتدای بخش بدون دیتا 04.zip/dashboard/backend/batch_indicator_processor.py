"""
🔄 پردازش گروهی اندیکاتورها برای دیتابیس تاریخی
این فایل تمام کندل‌های بدون اندیکاتور را پردازش می‌کند
"""

import sqlite3
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import logging
from typing import List, Dict, Any, Tuple
import time
import sys
import os
from tqdm import tqdm  # برای نمایش پیشرفت

# تنظیمات logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('batch_processing.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# اضافه کردن مسیر indicator_calculator
current_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append(current_dir)

from indicator_calculator import IndicatorCalculator

class BatchIndicatorProcessor:
    """پردازش گروهی اندیکاتورها برای دیتابیس تاریخی"""
    
    def __init__(self, db_path: str = None):
        """
        مقداردهی اولیه پردازشگر گروهی
        
        Args:
            db_path: مسیر فایل دیتابیس (اگر None باشد از config_manager می‌گیرد)
        """
        logger.info("🔄 راه‌اندازی BatchIndicatorProcessor")
        
        # تعیین مسیر دیتابیس
        if db_path is None:
            try:
                from config_manager import get_database_path
                self.db_path = get_database_path()
                logger.info(f"📁 مسیر دیتابیس از config_manager: {self.db_path}")
            except ImportError:
                # مسیر پیش‌فرض
                self.db_path = "data/crypto_data.db"
                logger.warning(f"⚠️ config_manager پیدا نشد، استفاده از مسیر پیش‌فرض: {self.db_path}")
        else:
            self.db_path = db_path
        
        # ایجاد ماشین حساب اندیکاتورها
        self.calculator = IndicatorCalculator()
        
        # اتصال به دیتابیس
        self.conn = None
        self._connect_to_database()
        
        # آمار پردازش
        self.stats = {
            'total_processed': 0,
            'successful': 0,
            'failed': 0,
            'skipped': 0,
            'start_time': None,
            'end_time': None,
            'time_per_candle': 0
        }
    
    def _connect_to_database(self):
        """اتصال به دیتابیس"""
        try:
            self.conn = sqlite3.connect(self.db_path)
            self.conn.row_factory = sqlite3.Row  # برای دسترسی به ستون‌ها با نام
            logger.info(f"✅ اتصال به دیتابیس موفق: {self.db_path}")
            
            # بررسی وجود جداول
            cursor = self.conn.cursor()
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
            tables = [row[0] for row in cursor.fetchall()]
            
            logger.info(f"📊 جداول موجود: {tables}")
            
        except Exception as e:
            logger.error(f"❌ خطا در اتصال به دیتابیس: {e}")
            raise
    
    def get_empty_indicator_records(self, symbol: str = None, timeframe: str = None, 
                                   limit: int = None) -> List[Tuple]:
        """
        دریافت کندل‌هایی که اندیکاتورهای آنها خالی است
        
        Args:
            symbol: نماد خاص (اگر None باشد تمام نمادها)
            timeframe: تایم‌فریم خاص (اگر None باشد تمام تایم‌فریم‌ها)
            limit: محدودیت تعداد رکوردها
        
        Returns:
            لیستی از رکوردهای بدون اندیکاتور
        """
        cursor = self.conn.cursor()
        
        # ساخت شرط WHERE پویا
        conditions = ["indicator_calculated = 0"]  # فرض: ستون نشان‌دهنده محاسبه اندیکاتور
        params = []
        
        if symbol:
            conditions.append("symbol = ?")
            params.append(symbol)
        
        if timeframe:
            conditions.append("timeframe = ?")
            params.append(timeframe)
        
        where_clause = " AND ".join(conditions)
        
        # کوئری اصلی
        query = f"""
        SELECT * FROM crypto_klines 
        WHERE {where_clause}
        ORDER BY symbol, timeframe, open_time
        """
        
        if limit:
            query += f" LIMIT {limit}"
        
        logger.info(f"🔍 جستجوی رکوردهای بدون اندیکاتور...")
        cursor.execute(query, params)
        records = cursor.fetchall()
        
        logger.info(f"📊 تعداد رکوردهای بدون اندیکاتور: {len(records)}")
        
        return records
    
    def get_required_history(self, symbol: str, timeframe: str, 
                           current_open_time: str, count: int = 500) -> List[Dict]:
        """
        دریافت تاریخچه مورد نیاز برای محاسبه اندیکاتورها
        
        Args:
            symbol: نماد
            timeframe: تایم‌فریم
            current_open_time: زمان باز شدن کندل فعلی
            count: تعداد کندل‌های تاریخچه مورد نیاز
        
        Returns:
            لیست کندل‌های تاریخچه
        """
        cursor = self.conn.cursor()
        
        query = """
        SELECT * FROM crypto_klines 
        WHERE symbol = ? AND timeframe = ? AND open_time < ?
        ORDER BY open_time DESC
        LIMIT ?
        """
        
        cursor.execute(query, (symbol, timeframe, current_open_time, count))
        history_records = cursor.fetchall()
        
        # تبدیل به لیست دیکشنری و معکوس کردن ترتیب (قدیمی به جدید)
        history = [dict(row) for row in history_records[::-1]]
        
        return history
    
    def calculate_indicators_for_record(self, record: sqlite3.Row) -> Dict[str, Any]:
        """
        محاسبه اندیکاتورها برای یک رکورد خاص
        
        Args:
            record: رکورد دیتابیس
        
        Returns:
            دیکشنری اندیکاتورهای محاسبه شده
        """
        try:
            # تبدیل رکورد به دیکشنری
            current_candle = dict(record)
            
            # دریافت تاریخچه
            symbol = current_candle['symbol']
            timeframe = current_candle['timeframe']
            open_time = current_candle['open_time']
            
            history = self.get_required_history(symbol, timeframe, open_time, 500)
            
            # محاسبه اندیکاتورها
            indicators = self.calculator.calculate_all_indicators(
                current_candle=current_candle,
                previous_candles=history,
                timeframe=timeframe
            )
            
            # اضافه کردن شناسه رکورد
            indicators['record_id'] = current_candle.get('id')
            indicators['symbol'] = symbol
            indicators['timeframe'] = timeframe
            indicators['open_time'] = open_time
            
            return indicators
            
        except Exception as e:
            logger.error(f"❌ خطا در محاسبه اندیکاتورها برای رکورد {record.get('id')}: {e}")
            
            # بازگشت اندیکاتورهای پیش‌فرض
            default_indicators = self.calculator._get_default_indicators(
                dict(record), 
                record.get('timeframe', '5m')
            )
            default_indicators['calculation_status'] = 'FAILED'
            default_indicators['error'] = str(e)
            
            return default_indicators
    
    def update_database_record(self, record_id: int, indicators: Dict[str, Any]) -> bool:
        """
        بروزرسانی رکورد در دیتابیس با اندیکاتورهای محاسبه شده
        
        Args:
            record_id: شناسه رکورد
            indicators: اندیکاتورهای محاسبه شده
        
        Returns:
            موفقیت/شکست
        """
        try:
            cursor = self.conn.cursor()
            
            # تبدیل مقادیر None به NULL برای دیتابیس
            for key, value in indicators.items():
                if value is None:
                    indicators[key] = ''
                elif isinstance(value, (float, np.floating)):
                    indicators[key] = float(value)
            
            # ساخت کوئری UPDATE پویا
            columns = list(indicators.keys())
            
            # اضافه کردن ستون indicator_calculated
            if 'indicator_calculated' not in columns:
                columns.append('indicator_calculated')
                indicators['indicator_calculated'] = 1
            
            # اضافه کردن ستون last_updated
            if 'last_updated' not in columns:
                columns.append('last_updated')
                indicators['last_updated'] = datetime.now().isoformat()
            
            set_clause = ", ".join([f"{col} = ?" for col in columns])
            values = [indicators[col] for col in columns]
            values.append(record_id)  # برای شرط WHERE
            
            query = f"""
            UPDATE crypto_klines 
            SET {set_clause}
            WHERE id = ?
            """
            
            cursor.execute(query, values)
            self.conn.commit()
            
            return cursor.rowcount > 0
            
        except Exception as e:
            logger.error(f"❌ خطا در بروزرسانی رکورد {record_id}: {e}")
            self.conn.rollback()
            return False
    
    def process_batch(self, symbol: str = None, timeframe: str = None, 
                     batch_size: int = 1000, limit: int = None) -> Dict[str, Any]:
        """
        پردازش گروهی رکوردها
        
        Args:
            symbol: نماد خاص (اختیاری)
            timeframe: تایم‌فریم خاص (اختیاری)
            batch_size: اندازه هر بچ
            limit: محدودیت کل رکوردها
        
        Returns:
            آمار پردازش
        """
        self.stats['start_time'] = datetime.now()
        
        # دریافت رکوردهای بدون اندیکاتور
        records = self.get_empty_indicator_records(symbol, timeframe, limit)
        
        if not records:
            logger.info("✅ هیچ رکوردی برای پردازش پیدا نشد")
            return self.stats
        
        total_records = len(records)
        logger.info(f"🚀 شروع پردازش {total_records} رکورد...")
        
        # پردازش با progress bar
        successful = 0
        failed = 0
        skipped = 0
        
        with tqdm(total=total_records, desc="پردازش اندیکاتورها", unit="رکورد") as pbar:
            for i, record in enumerate(records):
                try:
                    # بررسی اینکه آیا کندل اطلاعات کافی دارد
                    required_fields = ['open_price', 'high_price', 'low_price', 'close_price']
                    if not all(record.get(field) for field in required_fields):
                        logger.warning(f"⚠️ رکورد {record['id']} فیلدهای ضروری ندارد - رد شد")
                        skipped += 1
                        pbar.update(1)
                        continue
                    
                    # محاسبه اندیکاتورها
                    start_time = time.time()
                    indicators = self.calculate_indicators_for_record(record)
                    calc_time = time.time() - start_time
                    
                    # بروزرسانی دیتابیس
                    if self.update_database_record(record['id'], indicators):
                        successful += 1
                        self.stats['time_per_candle'] = (self.stats['time_per_candle'] * (successful-1) + calc_time) / successful if successful > 1 else calc_time
                    else:
                        failed += 1
                    
                    # نمایش پیشرفت
                    pbar.update(1)
                    pbar.set_postfix({
                        'موفق': successful,
                        'ناموفق': failed,
                        'رد': skipped,
                        'زمان/رکورد': f"{calc_time:.3f}s"
                    })
                    
                    # ذخیره موقت هر batch_size رکورد
                    if successful % batch_size == 0:
                        logger.info(f"📦 ذخیره موقت پس از {successful} رکورد...")
                        self.conn.commit()
                        
                        # تخمین زمان باقی‌مانده
                        remaining = total_records - (i + 1)
                        time_per_record = self.stats['time_per_candle']
                        eta_seconds = remaining * time_per_record
                        eta_str = str(timedelta(seconds=int(eta_seconds)))
                        
                        logger.info(f"⏱️ تخمین زمان باقی‌مانده: {eta_str}")
                        
                except Exception as e:
                    logger.error(f"❌ خطا در پردازش رکورد {record.get('id')}: {e}")
                    failed += 1
                    pbar.update(1)
        
        # ذخیره نهایی
        self.conn.commit()
        
        # ثبت آمار نهایی
        self.stats['end_time'] = datetime.now()
        self.stats['total_processed'] = total_records
        self.stats['successful'] = successful
        self.stats['failed'] = failed
        self.stats['skipped'] = skipped
        
        # محاسبه زمان کل
        total_time = (self.stats['end_time'] - self.stats['start_time']).total_seconds()
        self.stats['total_time_seconds'] = total_time
        
        return self.stats
    
    def generate_report(self) -> str:
        """تولید گزارش پردازش"""
        if not self.stats['start_time']:
            return "هنوز پردازشی انجام نشده است"
        
        report_lines = [
            "=" * 60,
            "گزارش پردازش گروهی اندیکاتورها",
            "=" * 60,
            f"زمان شروع: {self.stats['start_time'].strftime('%Y-%m-%d %H:%M:%S')}",
            f"زمان پایان: {self.stats['end_time'].strftime('%Y-%m-%d %H:%M:%S')}",
            f"مدت زمان: {self.stats['total_time_seconds']:.2f} ثانیه",
            "-" * 60,
            f"کل رکوردهای پردازش شده: {self.stats['total_processed']}",
            f"موفق: {self.stats['successful']} ({self.stats['successful']/self.stats['total_processed']*100:.1f}%)",
            f"ناموفق: {self.stats['failed']} ({self.stats['failed']/self.stats['total_processed']*100:.1f}%)",
            f"رد شده: {self.stats['skipped']} ({self.stats['skipped']/self.stats['total_processed']*100:.1f}%)",
            "-" * 60,
            f"میانگین زمان هر رکورد: {self.stats['time_per_candle']:.3f} ثانیه",
            f"رکورد در ثانیه: {self.stats['successful']/self.stats['total_time_seconds']:.2f}" if self.stats['total_time_seconds'] > 0 else "N/A",
            "=" * 60
        ]
        
        return "\n".join(report_lines)
    
    def save_report_to_file(self, filename: str = "batch_processing_report.txt"):
        """ذخیره گزارش در فایل"""
        report = self.generate_report()
        
        with open(filename, 'w', encoding='utf-8') as f:
            f.write(report)
        
        logger.info(f"📄 گزارش در {filename} ذخیره شد")
        
        # نمایش گزارش در کنسول
        print(report)
    
    def close(self):
        """بستن اتصالات"""
        if self.conn:
            self.conn.close()
            logger.info("🔌 اتصال دیتابیس بسته شد")

def main():
    """تابع اصلی اجرا"""
    import argparse
    
    parser = argparse.ArgumentParser(description='پردازش گروهی اندیکاتورها')
    parser.add_argument('--symbol', type=str, help='نماد خاص (مثلاً BTCUSDT)')
    parser.add_argument('--timeframe', type=str, help='تایم‌فریم (مثلاً 5m, 1h, 1d)')
    parser.add_argument('--limit', type=int, help='محدودیت تعداد رکوردها')
    parser.add_argument('--batch-size', type=int, default=1000, help='اندازه بچ برای ذخیره موقت')
    parser.add_argument('--db-path', type=str, help='مسیر دیتابیس')
    
    args = parser.parse_args()
    
    # ایجاد پردازشگر
    processor = None
    
    try:
        processor = BatchIndicatorProcessor(db_path=args.db_path)
        
        # پردازش رکوردها
        stats = processor.process_batch(
            symbol=args.symbol,
            timeframe=args.timeframe,
            batch_size=args.batch_size,
            limit=args.limit
        )
        
        # تولید و ذخیره گزارش
        processor.save_report_to_file()
        
    except Exception as e:
        logger.error(f"❌ خطای اصلی: {e}")
        
    finally:
        if processor:
            processor.close()

if __name__ == "__main__":
    main()