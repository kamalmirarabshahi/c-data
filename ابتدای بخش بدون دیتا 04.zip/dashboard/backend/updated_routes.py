# backend/updated_routes.py - نسخه کامل با اصلاح ثبت تکراری
"""
Routeهای صفحه بروزرسانی - نسخه کامل
"""

from flask import render_template, jsonify, request, Flask  # Flask را هم import کردیم
from datetime import datetime
from .updated import get_updated_data, get_update_summary, get_coins_update_status

def register_updated_routes(app, config):
    """ثبت routeهای مربوط به updated - پارامتر app دریافت می‌شود"""
    
    print(f"🚀 ثبت routeهای updated شروع شد")
    
    # بررسی اینکه آیا routeها قبلاً ثبت شده‌اند
    existing_endpoints = set(app.view_functions.keys())
    
    @app.route('/updated')
    def updated_page():
        """صفحه اصلی بروزرسانی"""
        print(f"📥 درخواست GET به /updated")
        
        try:
            # دریافت داده‌ها
            data = get_updated_data(config)
            print(f"✅ داده‌ها دریافت شد. تعداد ارزها: {len(data.get('coins', []))}")
            
            # منوی navigation
            try:
                from config import Navigation
                data['navigation'] = Navigation.get_navigation_with_active('بروز رسان')
            except Exception as nav_error:
                print(f"⚠️ Navigation خطا: {nav_error}")
                # منوی پیش‌فرض
                data['navigation'] = [
                    {'name': 'خانه', 'url': '/', 'icon': 'fas fa-home'},
                    {'name': 'لیست ارزها', 'url': '/coins', 'icon': 'fas fa-coins'},
                    {'name': 'جداول', 'url': '/tables', 'icon': 'fas fa-table'},
                    {'name': 'بلوک ارزها', 'url': '/blocks', 'icon': 'fas fa-cubes'},
                    {'name': 'گزارشات', 'url': '/reports', 'icon': 'fas fa-chart-bar'},
                    {'name': 'بروز رسان', 'url': '/updated', 'icon': 'fas fa-history'}
                ]
            
            return render_template('updated.html', **data)
            
        except Exception as e:
            print(f"❌ خطا در updated_page: {e}")
            import traceback
            traceback.print_exc()
            
            # داده‌های fallback
            fallback_data = {
                'project_name': getattr(config, 'SITE_TITLE', 'پروژه تحلیل ارزهای دیجیتال'),
                'error': f"خطا: {str(e)}",
                'database_stats': {
                    'db_exists': False,
                    'db_path': str(getattr(config, 'DB_PATH', 'نامشخص')),
                    'active_coins': 0,
                    'total_coins': 0
                },
                'has_data': False,
                'navigation': [
                    {'name': 'خانه', 'url': '/', 'icon': 'fas fa-home'},
                    {'name': 'بروز رسان', 'url': '/updated', 'icon': 'fas fa-history', 'active': True}
                ],
                'coins': []
            }
            
            return render_template('updated.html', **fallback_data)
    
    # API Routes - فقط اگر قبلاً ثبت نشده باشند
    if 'api_update_summary' not in existing_endpoints:
        @app.route('/api/update/summary', methods=['GET'])
        def api_update_summary():
            """API دریافت خلاصه وضعیت بروزرسانی"""
            try:
                summary = get_update_summary(config)
                return jsonify({'success': True, 'summary': summary})
            except Exception as e:
                return jsonify({'success': False, 'error': str(e)}), 500
    else:
        print(f"⚠️ api_update_summary قبلاً ثبت شده است")
    
    if 'api_coins_status' not in existing_endpoints:
        @app.route('/api/update/coins-status', methods=['GET'])
        def api_coins_status():
            """API دریافت وضعیت بروزرسانی ارزها"""
            try:
                limit = request.args.get('limit', default=100, type=int)
                coins_data = get_coins_update_status(config, limit)
                return jsonify({'success': True, 'coins': coins_data})
            except Exception as e:
                return jsonify({'success': False, 'error': str(e)}), 500
    else:
        print(f"⚠️ api_coins_status قبلاً ثبت شده است")
    
    if 'api_run_candle_update' not in existing_endpoints:
        @app.route('/api/update/run-candle-update', methods=['POST'])
        def api_run_candle_update():
            """API اجرای بروزرسانی کندل‌ها"""
            try:
                data = request.get_json() or {}
                timeframe = data.get('timeframe', 'all')
                
                # در اینجا باید اسکریپت بروزرسانی کندل‌ها فراخوانی شود
                # فعلاً فقط پیام بازگشتی
                
                return jsonify({
                    'success': True,
                    'message': f'بروزرسانی کندل‌های {timeframe} با موفقیت آغاز شد',
                    'timeframe': timeframe,
                    'timestamp': datetime.now().isoformat()
                })
            except Exception as e:
                return jsonify({'success': False, 'error': str(e)}), 500
    else:
        print(f"⚠️ api_run_candle_update قبلاً ثبت شده است")
    
    if 'api_run_coin_update' not in existing_endpoints:
        @app.route('/api/update/run-coin-update', methods=['POST'])
        def api_run_coin_update():
            """API اجرای بروزرسانی ارزها"""
            try:
                # در اینجا باید اسکریپت بروزرسانی ارزها فراخوانی شود
                # فعلاً فقط پیام بازگشتی
                
                return jsonify({
                    'success': True,
                    'message': 'بروزرسانی اطلاعات ارزها با موفقیت آغاز شد',
                    'timestamp': datetime.now().isoformat()
                })
            except Exception as e:
                return jsonify({'success': False, 'error': str(e)}), 500
    else:
        print(f"⚠️ api_run_coin_update قبلاً ثبت شده است")
    
    if 'api_update_single_coin' not in existing_endpoints:
        @app.route('/api/update/single-coin/<symbol>', methods=['POST'])
        def api_update_single_coin(symbol):
            """API بروزرسانی یک ارز خاص - نسخه ساده"""
            try:
                data = request.get_json() or {}
                timeframe = data.get('timeframe', 'all')
                
                import subprocess
                import os
                
                # مسیر قطعی
                script_path = r"C:\Users\Kamal\Desktop\py-prg\git\c-data\scripts\cycle\cycle_02_process_3time_1Coin.py"
                
                # فقط چک کنیم فایل وجود دارد
                if not os.path.exists(script_path):
                    return jsonify({
                        'success': False,
                        'error': f'فایل {script_path} وجود ندارد!',
                        'help': 'لطفاً این دستور را در ترمینال اجرا کنید:',
                        'test_command': f'python "{script_path}" {symbol}'
                    }), 404
                
                # اجرای ساده
                try:
                    # استفاده از os.system برای اطمینان
                    command = f'python "{script_path}" {symbol}'
                    print(f"🎯 اجرای دستور: {command}")
                    
                    # روش 1: os.system (ساده ترین)
                    return_code = os.system(command)
                    
                    if return_code == 0:
                        return jsonify({
                            'success': True,
                            'message': f'بروزرسانی {symbol} با موفقیت انجام شد',
                            'return_code': return_code
                        })
                    else:
                        return jsonify({
                            'success': False,
                            'error': f'اسکریپت با کد خطای {return_code} خاتمه یافت',
                            'return_code': return_code,
                            'command': command
                        }), 500
                        
                except Exception as e:
                    return jsonify({
                        'success': False,
                        'error': f'خطا: {str(e)}',
                        'script_path': script_path,
                        'symbol': symbol
                    }), 500
                    
            except Exception as e:
                return jsonify({'success': False, 'error': str(e)}), 500
    else:
        print(f"⚠️ api_update_single_coin قبلاً ثبت شده است")
    
    print(f"✅ routeهای updated با موفقیت ثبت شدند")
    return app