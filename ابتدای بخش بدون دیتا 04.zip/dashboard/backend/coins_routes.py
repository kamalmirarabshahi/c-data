# backend/coins_routes.py (فایل جدید)
"""
🌐 تمام routeهای مربوط به coins در یک فایل
"""

from flask import render_template, jsonify, request, send_file
from datetime import datetime
from .coins import (
    get_coins_data, 
    update_coin_status, 
    get_coins_page_data,
    export_coins_report,
    get_coin_status_name
)

def log_request(endpoint, method, status='success'):
    """لاگ درخواست‌های API"""
    timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    print(f"[{timestamp}] {method} {endpoint} - {status}")

def register_coins_routes(app, config):
    """
    ثبت تمام routeهای مربوط به coins در Flask app
    
    Args:
        app: Flask application instance
        config: Config object containing settings
    
    Returns:
        Flask app با routeهای ثبت شده
    """
    
    # ============ HTML PAGES ============
    
    @app.route('/coins')
    def coins_page():
        """صفحه HTML لیست ارزها"""
        log_request('/coins', 'GET')
        
        try:
            # دریافت پارامترهای فیلتر از URL
            page = request.args.get('page', 1, type=int)
            per_page = request.args.get('per_page', getattr(config, 'DEFAULT_PAGE_SIZE', 50), type=int)
            symbol = request.args.get('symbol', '')
            status = request.args.get('status', '')
            
            # دریافت تمام داده‌های مورد نیاز برای صفحه
            data = get_coins_page_data(
                page=page,
                per_page=per_page,
                symbol_filter=symbol,
                status_filter=status,
                config=config
            )
            
            return render_template('coins.html', **data)
            
        except Exception as e:
            log_request('/coins', 'GET', 'error')
            print(f"❌ خطا در صفحه coins: {e}")
            
            # بازگرداندن صفحه با داده‌های پیش‌فرض در صورت خطا
            return render_template('coins.html',
                status='error',
                error=str(e),
                coins=[],
                total=0,
                total_pages=1,
                current_page=1,
                per_page=getattr(config, 'DEFAULT_PAGE_SIZE', 50),
                project_name=getattr(config, 'SITE_TITLE', 'پروژه ارز دیجیتال'),
                navigation=[
                    {'name': 'خانه', 'url': '/', 'icon': 'fas fa-home'},
                    {'name': 'لیست ارزها', 'url': '/coins', 'icon': 'fas fa-coins', 'active': True},
                    {'name': 'جداول', 'url': '/tables', 'icon': 'fas fa-table'},
                    {'name': 'بلوک ارزها', 'url': '/blocks', 'icon': 'fas fa-cubes'},
                    {'name': 'بروز رسان', 'url': '/updated', 'icon': 'fas fa-history'}
                ]
            )
    
    # ============ API ROUTES ============
    
    @app.route('/api/coins')
    def api_coins():
        """API لیست ارزها با فیلتر و صفحه‌بندی"""
        log_request('/api/coins', 'GET')
        
        try:
            # دریافت پارامترها
            page = request.args.get('page', 1, type=int)
            per_page = request.args.get('per_page', getattr(config, 'DEFAULT_PAGE_SIZE', 50), type=int)
            symbol = request.args.get('symbol', '')
            status = request.args.get('status', '')
            
            # دریافت داده‌ها
            data = get_coins_data(
                page=page,
                per_page=per_page,
                symbol_filter=symbol,
                status_filter=status
            )
            
            return jsonify(data)
            
        except Exception as e:
            log_request('/api/coins', 'GET', 'error')
            return jsonify({
                'status': 'error',
                'error': str(e),
                'coins': [],
                'total': 0,
                'total_pages': 1,
                'current_page': 1,
                'per_page': getattr(config, 'DEFAULT_PAGE_SIZE', 50)
            }), 500
    
    @app.route('/api/coins/<symbol>')
    def api_coin_detail(symbol):
        """API جزئیات یک ارز خاص"""
        log_request(f'/api/coins/{symbol}', 'GET')
        
        try:
            data = get_coins_data(symbol_filter=symbol, per_page=1)
            
            if data.get('status') == 'success' and data.get('coins'):
                return jsonify({
                    'status': 'success',
                    'coin': data['coins'][0]
                })
            else:
                return jsonify({
                    'status': 'error',
                    'error': f'ارز {symbol} یافت نشد'
                }), 404
                
        except Exception as e:
            log_request(f'/api/coins/{symbol}', 'GET', 'error')
            return jsonify({
                'status': 'error',
                'error': str(e)
            }), 500
    
    @app.route('/api/coins/<symbol>/status', methods=['POST'])
    def api_update_coin_status(symbol):
        """API تغییر وضعیت is_active یک ارز"""
        log_request(f'/api/coins/{symbol}/status', 'POST')
        
        try:
            # دریافت داده‌های JSON
            data = request.json
            
            if not data:
                return jsonify({
                    'status': 'error',
                    'error': 'بدنه درخواست خالی است'
                }), 400
            
            # بررسی وجود پارامتر status
            if 'status' not in data:
                return jsonify({
                    'status': 'error',
                    'error': 'پارامتر status ارسال نشده است'
                }), 400
            
            new_status = data['status']
            
            # بررسی معتبر بودن وضعیت
            try:
                new_status_int = int(new_status)
                if new_status_int < 0 or new_status_int > 5:
                    return jsonify({
                        'status': 'error',
                        'error': f'وضعیت {new_status} معتبر نیست. باید بین 0 تا 5 باشد.'
                    }), 400
            except ValueError:
                return jsonify({
                    'status': 'error',
                    'error': 'وضعیت باید یک عدد باشد.'
                }), 400
            
            # فراخوانی تابع بک‌اند برای بروزرسانی
            result = update_coin_status(symbol.upper(), new_status_int)
            
            if result['status'] == 'success':
                return jsonify(result)
            else:
                return jsonify(result), 400
                
        except Exception as e:
            log_request(f'/api/coins/{symbol}/status', 'POST', 'error')
            return jsonify({
                'status': 'error',
                'error': f'خطای سرور: {str(e)}'
            }), 500
    
    # ============ REPORT API ROUTES ============
    
    @app.route('/api/reports/all_coins')
    def api_report_all_coins():
        """API گزارش تمام ارزها"""
        log_request('/api/reports/all_coins', 'GET')
        
        try:
            data = get_coins_data(per_page=getattr(config, 'MAX_EXPORT_ROWS', 10000))
            return jsonify(data)
        except Exception as e:
            return jsonify({
                'status': 'error',
                'error': str(e)
            }), 500
    
    @app.route('/api/reports/active_coins')
    def api_report_active_coins():
        """API گزارش ارزهای فعال"""
        log_request('/api/reports/active_coins', 'GET')
        
        try:
            data = get_coins_data(status_filter='1', per_page=getattr(config, 'MAX_EXPORT_ROWS', 10000))
            return jsonify(data)
        except Exception as e:
            return jsonify({
                'status': 'error',
                'error': str(e)
            }), 500
    
    @app.route('/api/reports/inactive_coins')
    def api_report_inactive_coins():
        """API گزارش ارزهای غیرفعال"""
        log_request('/api/reports/inactive_coins', 'GET')
        
        try:
            data = get_coins_data(status_filter='5', per_page=getattr(config, 'MAX_EXPORT_ROWS', 10000))
            return jsonify(data)
        except Exception as e:
            return jsonify({
                'status': 'error',
                'error': str(e)
            }), 500
    
    # ============ EXPORT ROUTES ============
    
    @app.route('/api/export/<report_type>')
    def export_coins(report_type):
        """دانلود گزارش به صورت CSV"""
        log_request(f'/api/export/{report_type}', 'GET')
        
        try:
            # بررسی نوع گزارش
            valid_reports = ['all_coins', 'active_coins', 'inactive_coins']
            if report_type not in valid_reports:
                return jsonify({
                    'status': 'error',
                    'error': f'نوع گزارش نامعتبر. گزینه‌های معتبر: {", ".join(valid_reports)}'
                }), 400
            
            # ایجاد گزارش
            export_result = export_coins_report(report_type, config)
            
            if export_result['status'] != 'success':
                return jsonify(export_result), 500
            
            # ارسال فایل
            return send_file(
                export_result['file_data'],
                as_attachment=True,
                download_name=export_result['filename'],
                mimetype=export_result['mimetype']
            )
            
        except Exception as e:
            log_request(f'/api/export/{report_type}', 'GET', 'error')
            return jsonify({
                'status': 'error',
                'error': str(e)
            }), 500
    
    # ============ UTILITY ROUTES ============
    
    @app.route('/api/coins/status_names')
    def api_coin_status_names():
        """API دریافت نام‌های وضعیت ارزها"""
        log_request('/api/coins/status_names', 'GET')
        
        status_names = {}
        for status_id in range(0, 6):  # 0 تا 5
            status_names[str(status_id)] = get_coin_status_name(status_id)
        
        return jsonify({
            'status': 'success',
            'status_names': status_names
        })
    
    print("✅ ماژول coins routes با موفقیت ثبت شد")
    return app