# backend/updated.py - نسخه نهایی با دیباگ
"""
ماژول مدیریت بروزرسانی - نسخه نهایی با JOIN جداول
"""

import sqlite3
from pathlib import Path
from datetime import datetime, timedelta

def get_updated_data(config):
    """دریافت داده‌های کامل بروزرسانی"""
    print(f"🔧 دریافت داده‌های بروزرسانی...")
    
    try:
        # بررسی وجود دیتابیس
        db_path = getattr(config, 'DB_PATH', Path('data/crypto_master.db'))
        db_exists = db_path.exists() if db_path else False
        
        # آمار پایه دیتابیس
        database_stats = {
            'db_exists': db_exists,
            'db_path': str(db_path) if db_path else 'نامشخص',
            'active_coins': 0,
            'total_coins': 0,
            'last_update': 'نامشخص',
            'error': None
        }
        
        # اگر دیتابیس وجود دارد، اطلاعات واقعی را بگیر
        if db_exists:
            try:
                conn = sqlite3.connect(str(db_path))
                cursor = conn.cursor()
                
                # تعداد کل ارزها (is_active < 5)
                cursor.execute("SELECT COUNT(*) FROM crypto_coins WHERE is_active < 5")
                total_coins = cursor.fetchone()[0] or 0
                
                # تعداد ارزهای فعال (is_active < 5)
                cursor.execute("SELECT COUNT(*) FROM crypto_coins WHERE is_active < 5")
                active_coins = cursor.fetchone()[0] or 0
                
                # آخرین بروزرسانی
                cursor.execute("SELECT MAX(last_updated) FROM crypto_coins WHERE is_active < 5")
                last_update = cursor.fetchone()[0]
                
                database_stats.update({
                    'active_coins': active_coins,
                    'total_coins': total_coins,
                    'last_update': last_update or 'نامشخص'
                })
                
                conn.close()
                
            except Exception as db_error:
                database_stats['error'] = str(db_error)
                print(f"⚠️ خطا در خواندن دیتابیس: {db_error}")
                import traceback
                traceback.print_exc()
        
        # دریافت خلاصه بروزرسانی
        update_summary = get_update_summary(config)
        
        # دریافت وضعیت ارزها
        coins_status = get_coins_update_status(config)
        
        # داده‌های نهایی
        base_data = {
            'project_name': getattr(config, 'SITE_TITLE', 'سیستم تحلیل ارزهای دیجیتال'),
            'app_name': getattr(config, 'SITE_DESCRIPTION', 'پروژه تحلیل'),
            'version': getattr(config, 'VERSION', '2.2.0'),
            'current_date': datetime.now().strftime('%Y-%m-%d'),
            'current_time': datetime.now().strftime('%H:%M:%S'),
            'server_url': f"http://{getattr(config, 'HOST', '127.0.0.1')}:{getattr(config, 'PORT', 5000)}",
            'database_stats': database_stats,
            'coins': coins_status
        }
        
        # اضافه کردن خلاصه بروزرسانی
        base_data.update(update_summary)
        
        print(f"✅ داده‌های بروزرسانی آماده شد. تعداد ارزها: {len(coins_status)}")
        return base_data
        
    except Exception as e:
        print(f"❌ خطا در get_updated_data: {e}")
        import traceback
        traceback.print_exc()
        raise

def get_update_summary(config):
    """دریافت خلاصه وضعیت بروزرسانی"""
    try:
        db_path = getattr(config, 'DB_PATH', None)
        if not db_path or not db_path.exists():
            return {
                'has_data': False,
                'last_candle_update': 'نامشخص',
                'last_coin_update': 'نامشخص',
                'update_time_ago': 'نامشخص',
                'total_active_coins': 0,
                'total_coins': 0,
                'update_status': {}
            }
        
        conn = sqlite3.connect(str(db_path))
        cursor = conn.cursor()
        
        summary = {
            'has_data': True,
            'last_candle_update': 'نامشخص',
            'last_coin_update': 'نامشخص',
            'update_time_ago': 'نامشخص',
            'total_active_coins': 0,
            'total_coins': 0,
            'update_status': {}
        }
        
        # تابع کمکی برای فرمت‌دهی تاریخ
        def format_datetime(dt_str):
            """تبدیل هر فرمت تاریخ به فرمت استاندارد YYYY-MM-DD HH:MM:SS"""
            if not dt_str:
                return 'نامشخص'
            
            try:
                dt_str = str(dt_str)
                
                # حذف میکروثانیه‌ها
                if '.' in dt_str:
                    dt_str = dt_str.split('.')[0]
                
                # تبدیل T به فاصله (فرمت ISO)
                dt_str = dt_str.replace('T', ' ')
                
                # حذف Z
                dt_str = dt_str.replace('Z', '')
                
                # فقط 19 کاراکتر اول (YYYY-MM-DD HH:MM:SS)
                return dt_str[:19]
            except:
                return dt_str[:19] if dt_str else 'نامشخص'
        
        # آخرین بروزرسانی ارزها
        try:
            cursor.execute("SELECT MAX(last_updated) FROM crypto_coins WHERE is_active < 5")
            last_coin = cursor.fetchone()[0]
            if last_coin:
                # ذخیره دو نسخه: فرمت خام و فرمت شده
                summary['last_coin_update_raw'] = last_coin
                summary['last_coin_update'] = format_datetime(last_coin)
                
                # محاسبه زمان گذشته
                try:
                    # آماده‌سازی رشته تاریخ برای تبدیل
                    last_coin_str = str(last_coin)
                    if 'T' in last_coin_str:
                        # فرمت ISO: 2025-12-28T02:17:06.510510
                        last_dt = datetime.fromisoformat(last_coin_str.replace('Z', '+00:00'))
                    else:
                        # فرمت استاندارد: 2025-12-28 02:17:06
                        last_dt = datetime.strptime(last_coin_str[:19], '%Y-%m-%d %H:%M:%S')
                    
                    diff = datetime.now() - last_dt
                    
                    days = diff.days
                    hours = diff.seconds // 3600
                    minutes = (diff.seconds % 3600) // 60
                    
                    parts = []
                    if days > 0:
                        parts.append(f"{days} روز")
                    if hours > 0:
                        parts.append(f"{hours} ساعت")
                    if minutes > 0:
                        parts.append(f"{minutes} دقیقه")
                    
                    summary['update_time_ago'] = ' و '.join(parts) if parts else 'همین لحظه'
                except Exception as dt_error:
                    print(f"⚠️ خطا در تبدیل تاریخ ارزها: {dt_error}")
                    summary['update_time_ago'] = 'نامشخص'
        except Exception as e:
            print(f"⚠️ خطا در دریافت آخرین بروزرسانی ارزها: {e}")
        
        # تعداد ارزها (is_active < 5)
        try:
            cursor.execute("SELECT COUNT(*) FROM crypto_coins WHERE is_active < 5")
            summary['total_coins'] = cursor.fetchone()[0] or 0
            
            cursor.execute("SELECT COUNT(*) FROM crypto_coins WHERE is_active < 5")
            summary['total_active_coins'] = cursor.fetchone()[0] or 0
        except Exception as e:
            print(f"⚠️ خطا در شمارش ارزها: {e}")
        
        # آخرین بروزرسانی کندل‌ها
        try:
            cursor.execute("""
                SELECT MAX(k.created_at) 
                FROM crypto_klines k
                JOIN crypto_coins c ON k.coin_id = c.id
                WHERE c.is_active < 5
            """)
            last_candle = cursor.fetchone()[0]
            if last_candle:
                # ذخیره دو نسخه: فرمت خام و فرمت شده
                summary['last_candle_update_raw'] = last_candle
                summary['last_candle_update'] = format_datetime(last_candle)
        except Exception as e:
            print(f"⚠️ خطا در دریافت آخرین بروزرسانی کندل‌ها: {e}")
        
        # آمار تایم‌فریم‌ها
        update_status = {}
        for timeframe in ['15m', '1h', '4h']:
            try:
                # تعداد ارزهای دارای داده در این تایم‌فریم
                cursor.execute("""
                    SELECT COUNT(DISTINCT c.symbol) 
                    FROM crypto_klines k
                    JOIN crypto_coins c ON k.coin_id = c.id
                    WHERE c.is_active < 5 AND k.timeframe = ?
                """, (timeframe,))
                coins_count = cursor.fetchone()[0] or 0
                
                # تعداد کل کندل‌ها
                cursor.execute("""
                    SELECT COUNT(*) 
                    FROM crypto_klines k
                    JOIN crypto_coins c ON k.coin_id = c.id
                    WHERE c.is_active < 5 AND k.timeframe = ?
                """, (timeframe,))
                total_candles = cursor.fetchone()[0] or 0
                
                # آخرین کندل
                cursor.execute("""
                    SELECT MAX(k.created_at) 
                    FROM crypto_klines k
                    JOIN crypto_coins c ON k.coin_id = c.id
                    WHERE c.is_active < 5 AND k.timeframe = ?
                """, (timeframe,))
                last_candle = cursor.fetchone()[0]
                
                # میانگین تعداد کندل‌ها به ازای هر ارز
                avg_candles = total_candles // coins_count if coins_count > 0 else 0
                
                update_status[timeframe] = {
                    'coins_count': coins_count,
                    'total_candles': total_candles,
                    'avg_candles_per_coin': avg_candles,
                    'last_candle': format_datetime(last_candle) if last_candle else None,
                    'status': 'active' if coins_count > 0 else 'inactive'
                }
                
                print(f"📊 تایم‌فریم {timeframe}: {coins_count} ارز، {total_candles} کندل")
                
            except Exception as e:
                print(f"⚠️ خطا در دریافت آمار {timeframe}: {e}")
                update_status[timeframe] = {
                    'coins_count': 0,
                    'total_candles': 0,
                    'avg_candles_per_coin': 0,
                    'last_candle': None,
                    'status': 'error'
                }
        
        summary['update_status'] = update_status
        conn.close()
        
        # دیباگ: چاپ تاریخ‌های فرمت شده
        print(f"📅 تاریخ ارزها (فرمت شده): {summary.get('last_coin_update')}")
        print(f"📅 تاریخ کندل‌ها (فرمت شده): {summary.get('last_candle_update')}")
        
        return summary
        
    except Exception as e:
        print(f"⚠️ خطا در get_update_summary: {e}")
        import traceback
        traceback.print_exc()
        return {
            'has_data': False,
            'last_candle_update': 'خطا',
            'last_coin_update': 'خطا',
            'update_time_ago': 'نامشخص',
            'total_active_coins': 0,
            'total_coins': 0,
            'update_status': {}
        }

def get_coins_update_status(config, limit=300):
    """دریافت وضعیت بروزرسانی ارزها با JOIN جداول"""
    try:
        db_path = getattr(config, 'DB_PATH', None)
        if not db_path or not db_path.exists():
            print(f"❌ دیتابیس وجود ندارد: {db_path}")
            return []
        
        conn = sqlite3.connect(str(db_path))
        cursor = conn.cursor()
        
        # تابع داخلی برای فرمت‌دهی تاریخ
        def format_datetime(dt_str):
            """تبدیل هر فرمت تاریخ به فرمت استاندارد YYYY-MM-DD HH:MM:SS"""
            try:
                if not dt_str or dt_str == 'نامشخص':
                    return 'نامشخص'
                
                dt_str = str(dt_str)
                
                # حذف میکروثانیه‌ها
                if '.' in dt_str:
                    dt_str = dt_str.split('.')[0]
                
                # تبدیل T به فاصله (فرمت ISO)
                if 'T' in dt_str:
                    dt_str = dt_str.replace('T', ' ')
                
                # حذف Z
                dt_str = dt_str.replace('Z', '')
                
                # حذف +00:00
                if '+00:00' in dt_str:
                    dt_str = dt_str.replace('+00:00', '')
                
                # فقط 19 کاراکتر اول (YYYY-MM-DD HH:MM:SS)
                result = dt_str[:19]
                return result if result.strip() else 'نامشخص'
                
            except Exception as e:
                print(f"⚠️ خطا در فرمت‌دهی تاریخ '{dt_str}': {e}")
                return str(dt_str)[:19] if dt_str else 'نامشخص'
        
        # دریافت ارزهای فعال (is_active < 5)
        cursor.execute("""
            SELECT 
                c.id,
                c.symbol, 
                c.coin_name, 
                c.current_price, 
                c.last_updated, 
                c.market_cap, 
                c.volume_24h,
                c.is_active
            FROM crypto_coins c 
            WHERE c.is_active < 5
            ORDER BY c.is_active ASC, c.market_cap DESC            
        """)
        
        coins_data = []
        rows = cursor.fetchall()
        print(f"📊 تعداد ارزهای is_active < 5: {len(rows)}")
        
        # محدود کردن تعداد اگر لازم باشد
        if limit > 0 and len(rows) > limit:
            rows = rows[:limit]
            print(f"📋 محدود شده به {limit} ارز اول")
        
        for row in rows:
            coin_id = row[0]
            symbol = row[1]
            coin_name = row[2] or symbol
            current_price = row[3] or 0
            last_updated = row[4]
            market_cap = row[5] or 0
            volume_24h = row[6] or 0
            is_active = row[7] or 0
            
            # فرمت‌دهی تاریخ بروزرسانی
            updated_at_formatted = format_datetime(last_updated)
            
            # دیباگ برای چند ارز اول
            if len(coins_data) < 3:
                print(f"  نمونه ارز {symbol}: updated_at خام='{last_updated}', فرمت شده='{updated_at_formatted}'")
            
            # وضعیت کندل‌ها با حداقل 200 کندل
            candle_status = {}
            sufficient_timeframes = 0
            total_timeframes = 0
            
            for timeframe in ['15m', '1h', '4h']:
                total_timeframes += 1
                
                try:
                    # تعداد کندل‌های موجود برای این coin_id و تایم‌فریم
                    cursor.execute("""
                        SELECT COUNT(*) 
                        FROM crypto_klines 
                        WHERE coin_id = ? AND timeframe = ?
                    """, (coin_id, timeframe))
                    
                    result = cursor.fetchone()
                    candle_count = result[0] if result else 0
                    
                    # آخرین کندل
                    cursor.execute("""
                        SELECT MAX(created_at) 
                        FROM crypto_klines 
                        WHERE coin_id = ? AND timeframe = ?
                    """, (coin_id, timeframe))
                    
                    last_candle_result = cursor.fetchone()
                    last_candle = last_candle_result[0] if last_candle_result else None
                    
                    # فرمت‌دهی تاریخ آخرین کندل
                    last_candle_formatted = format_datetime(last_candle) if last_candle else None
                    
                    # تعیین وضعیت بر اساس تعداد کندل‌ها
                    if candle_count >= 200:
                        missing_count = 0
                        status = 'updated'
                        display_count = f"✓ {candle_count}"
                        candle_sufficient = True
                        sufficient_timeframes += 1
                    elif candle_count > 0:
                        missing_count = 200 - candle_count
                        status = 'insufficient'
                        display_count = f"{candle_count} ({missing_count}+)"
                        candle_sufficient = False
                    else:
                        missing_count = 200
                        status = 'no_data'
                        display_count = "ندارد"
                        candle_sufficient = False
                    
                    candle_status[timeframe] = {
                        'candle_count': candle_count,
                        'required_count': 200,
                        'missing_count': missing_count,
                        'last_candle': last_candle_formatted,
                        'last_candle_raw': last_candle,
                        'status': status,
                        'display': display_count,
                        'candle_sufficient': candle_sufficient
                    }
                    
                except Exception as e:
                    print(f"⚠️ خطا در بررسی کندل‌های {symbol}-{timeframe}: {e}")
                    candle_status[timeframe] = {
                        'candle_count': 0,
                        'required_count': 200,
                        'missing_count': 200,
                        'last_candle': None,
                        'last_candle_raw': None,
                        'status': 'error',
                        'display': 'خطا',
                        'candle_sufficient': False
                    }
            
            # منطق جدید: اگر 2 از 3 تایم‌فریم داده کافی داشته باشد، کافی است
            has_sufficient_data = sufficient_timeframes >= 2
            
            coins_data.append({
                'coin_id': coin_id,
                'symbol': symbol,
                'name': coin_name,
                'current_price': current_price,
                'market_cap': market_cap,
                'volume_24h': volume_24h,
                'updated_at': updated_at_formatted,  # نسخه فرمت شده
                'updated_at_raw': last_updated,      # نسخه خام (برای دیباگ)
                'active_status': is_active,
                'candle_status': candle_status,
                'has_sufficient_data': has_sufficient_data,
                'sufficient_timeframes': sufficient_timeframes,
                'total_timeframes': total_timeframes
            })
        
        conn.close()
        
        print(f"✅ داده‌های {len(coins_data)} ارز آماده شد")
        
        # آمار کلی
        updated_count = sum(1 for coin in coins_data if coin['has_sufficient_data'])
        insufficient_count = len(coins_data) - updated_count
        
        print(f"📈 آمار: {updated_count} ارز داده کامل، {insufficient_count} ارز داده ناکافی")
        
        # مرتب‌سازی: اول ارزهای با مشکل داده، سپس active کمتر، سپس مارکت‌کپ بیشتر
        coins_data.sort(key=lambda x: (
            not x['has_sufficient_data'],  # False (0) اول، True (1) بعد (مشکل‌دارها اول)
            x['active_status'],            # active کمتر اول
            -x['market_cap']               # مارکت‌کپ بیشتر اول
        ))
        
        return coins_data
        
    except sqlite3.Error as e:
        print(f"❌ خطای دیتابیس در get_coins_update_status: {e}")
        import traceback
        traceback.print_exc()
        return []
    except Exception as e:
        print(f"❌ خطای ناشناخته در get_coins_update_status: {e}")
        import traceback
        traceback.print_exc()
        return []

def check_candle_sufficiency(cursor, coin_id, timeframe):
    """بررسی کفایت تعداد کندل‌ها برای یک ارز و تایم‌فریم"""
    try:
        cursor.execute("""
            SELECT COUNT(*) 
            FROM crypto_klines 
            WHERE coin_id = ? AND timeframe = ?
        """, (coin_id, timeframe))
        
        count = cursor.fetchone()[0] or 0
        return count >= 200, count
    except:
        return False, 0