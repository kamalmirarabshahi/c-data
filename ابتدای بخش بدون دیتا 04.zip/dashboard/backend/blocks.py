# backend/blocks.py

import json
import sqlite3
import subprocess
from pathlib import Path
from datetime import datetime
import traceback


def get_blocks_data(config):
    """دریافت داده‌های بلوک‌ها برای صفحه HTML"""
    try:
        # اطلاعات پایه
        base_data = {
            'project_name': config.SITE_TITLE,
            'app_name': config.SITE_DESCRIPTION,
            'version': '2.1.0',
            'current_date': datetime.now().strftime('%Y-%m-%d'),
            'current_time': datetime.now().strftime('%H:%M:%S'),
            'server_url': f"http://{config.HOST}:{config.PORT}",
            'database_stats': get_database_stats(config),
            'state_data': get_state_data(config)
        }
        
        return base_data
    except Exception as e:
        print(f"خطا در get_blocks_data: {traceback.format_exc()}")
        raise Exception(f"خطا در دریافت داده‌های بلوک‌ها: {str(e)}")


def convert_to_jalali(dt):
    """تبدیل تاریخ میلادی به شمسی"""
    try:
        import jdatetime
        jalali_dt = jdatetime.datetime.fromgregorian(
            datetime=dt,
            locale='fa_IR'
        )
        return {
            'jalali_full': jalali_dt.strftime('%Y/%m/%d %H:%M:%S'),
            'jalali_date': jalali_dt.strftime('%Y/%m/%d'),
            'jalali_time': jalali_dt.strftime('%H:%M:%S'),
            'jalali_year': jalali_dt.year,
            'jalali_month': jalali_dt.month,
            'jalali_day': jalali_dt.day
        }
    except ImportError:
        print("⚠️ کتابخانه jdatetime نصب نیست. تاریخ شمسی نمایش داده نمی‌شود.")
        return {
            'jalali_full': dt.strftime('%Y-%m-%d %H:%M:%S'),
            'jalali_date': dt.strftime('%Y-%m-%d'),
            'jalali_time': dt.strftime('%H:%M:%S'),
            'error': 'jdatetime not installed'
        }
    except Exception as e:
        print(f"خطا در تبدیل به تاریخ شمسی: {str(e)}")
        return {
            'jalali_full': f"خطا: {str(e)[:50]}",
            'jalali_date': dt.strftime('%Y-%m-%d'),
            'jalali_time': dt.strftime('%H:%M:%S'),
            'error': str(e)
        }


def safe_convert_timestamp(timestamp_value):
    """تبدیل امن timestamp به تاریخ"""
    try:
        if timestamp_value is None:
            return None, None, "timestamp is None"
            
        if isinstance(timestamp_value, str):
            # اگر رشته است، سعی کن به عدد تبدیل کن
            try:
                timestamp_value = float(timestamp_value)
            except:
                return None, None, f"cannot convert string to number: {timestamp_value}"
        
        if not isinstance(timestamp_value, (int, float)):
            return None, None, f"invalid timestamp type: {type(timestamp_value)}"
        
        # تشخیص فرمت timestamp
        dt = None
        timestamp_type = "unknown"
        
        if timestamp_value > 1000000000000:  # میلی‌ثانیه (بعد از سال 2001)
            dt = datetime.fromtimestamp(timestamp_value / 1000)
            timestamp_type = "milliseconds"
        elif timestamp_value > 1000000000:  # ثانیه (بعد از سال 2001)
            dt = datetime.fromtimestamp(timestamp_value)
            timestamp_type = "seconds"
        elif timestamp_value > 0:  # روز از epoch (1970-01-01)
            dt = datetime.fromtimestamp(timestamp_value * 86400)
            timestamp_type = "days"
        else:
            return None, None, f"invalid timestamp value: {timestamp_value}"
        
        # تبدیل به تاریخ شمسی
        jalali_info = convert_to_jalali(dt)
        
        return {
            'gregorian': dt.strftime('%Y-%m-%d %H:%M:%S'),
            'jalali': jalali_info['jalali_full'],
            'jalali_info': jalali_info,
            'timestamp': timestamp_value,
            'timestamp_type': timestamp_type,
            'datetime_obj': dt
        }, dt, timestamp_type
        
    except Exception as e:
        print(f"خطا در safe_convert_timestamp برای مقدار {timestamp_value}: {str(e)}")
        return None, None, str(e)


def parse_readable_date(date_str):
    """تبدیل رشته تاریخ قابل خواندن به datetime object"""
    try:
        if not date_str:
            return None
        
        # فرمت‌های مختلفی که ممکن است در last_updated_readable وجود داشته باشد
        formats = [
            '%Y-%m-%d %H:%M:%S',
            '%Y/%m/%d %H:%M:%S',
            '%d-%m-%Y %H:%M:%S',
            '%d/%m/%Y %H:%M:%S',
            '%Y-%m-%dT%H:%M:%S',
            '%Y-%m-%d %H:%M',
            '%d-%m-%Y %H:%M',
            '%d/%m/%Y %H:%M'
        ]
        
        for fmt in formats:
            try:
                return datetime.strptime(date_str, fmt)
            except ValueError:
                continue
        
        # اگر هیچ فرمتی جواب نداد
        print(f"⚠️ فرمت تاریخ قابل خواندن نیست: {date_str}")
        return None
    except Exception as e:
        print(f"خطا در parse_readable_date: {str(e)}")
        return None


def get_database_stats(config):
    """آمار دیتابیس"""
    try:
        # بررسی وجود فایل دیتابیس
        db_path = Path(config.DB_PATH)
        
        # چک کردن مسیرهای مختلف
        if not db_path.exists():
            # اگر مسیر کامل وجود ندارد، شاید مسیر نسبی است
            if hasattr(config, 'BASE_DIR'):
                db_path = config.BASE_DIR / "data" / "crypto_master.db"
            if not db_path.exists():
                return {
                    'success': False,
                    'active_coins': 0,
                    'last_update': 'نامشخص',
                    'last_update_jalali': 'نامشخص',
                    'candle_15m': 0,
                    'candle_1h': 0,
                    'candle_4h': 0,
                    'total_tables': 0,
                    'db_path': str(db_path),
                    'db_exists': False,
                    'error': 'فایل دیتابیس یافت نشد'
                }
        
        print(f"📊 در حال اتصال به دیتابیس: {db_path}")
        
        conn = sqlite3.connect(str(db_path))
        cursor = conn.cursor()
        
        # تعداد ارزهای فعال
        cursor.execute("SELECT COUNT(*) FROM coins WHERE active = 1")
        active_coins = cursor.fetchone()[0] or 0
        
        # آخرین تاریخ بروزرسانی
        cursor.execute("SELECT MAX(last_updated_ts) FROM coins WHERE active = 1")
        last_update_result = cursor.fetchone()
        last_update_ts = last_update_result[0] if last_update_result and last_update_result[0] else None
        
        last_update_info = {
            'gregorian': 'نامشخص',
            'jalali': 'نامشخص',
            'timestamp': last_update_ts,
            'timestamp_type': 'none'
        }
        
        if last_update_ts:
            try:
                result, dt, ts_type = safe_convert_timestamp(last_update_ts)
                if result:
                    last_update_info = result
                    print(f"✅ آخرین بروزرسانی: {result['gregorian']} -> {result['jalali']} (نوع: {ts_type})")
                else:
                    print(f"⚠️ تبدیل timestamp ناموفق: {last_update_ts}")
            except Exception as e:
                print(f"❌ خطا در تبدیل timestamp: {e}")
                last_update_info['error'] = str(e)
        else:
            print("⚠️ آخرین timestamp یافت نشد")
        
        # تعداد کندل‌ها
        candle_counts = {}
        for timeframe in ['15m', '1h', '4h']:
            try:
                table_name = f"price_history_{timeframe}"
                cursor.execute(f"SELECT COUNT(*) FROM {table_name}")
                result = cursor.fetchone()
                candle_counts[f'candle_{timeframe}'] = result[0] if result else 0
                print(f"📈 کندل‌های {timeframe}: {candle_counts[f'candle_{timeframe}']}")
            except Exception as e:
                print(f"⚠️ خطا در شمارش کندل‌های {timeframe}: {e}")
                candle_counts[f'candle_{timeframe}'] = 0
        
        # تعداد جداول
        cursor.execute("SELECT COUNT(*) FROM sqlite_master WHERE type='table'")
        total_tables_result = cursor.fetchone()
        total_tables = total_tables_result[0] if total_tables_result else 0
        
        # بررسی ساختار جدول coins
        try:
            cursor.execute("PRAGMA table_info(coins)")
            columns = cursor.fetchall()
            coin_columns = [col[1] for col in columns]
            print(f"📋 ستون‌های جدول coins: {coin_columns}")
        except Exception as e:
            print(f"⚠️ خطا در بررسی ساختار جدول: {e}")
        
        conn.close()
        
        return {
            'success': True,
            'active_coins': active_coins,
            'last_update': last_update_info.get('gregorian', 'نامشخص'),
            'last_update_jalali': last_update_info.get('jalali', 'نامشخص'),
            'last_update_info': last_update_info,
            'candle_15m': candle_counts.get('candle_15m', 0),
            'candle_1h': candle_counts.get('candle_1h', 0),
            'candle_4h': candle_counts.get('candle_4h', 0),
            'total_tables': total_tables,
            'db_path': str(db_path),
            'db_exists': True,
            'db_tested': True
        }
        
    except Exception as e:
        print(f"❌ خطا در get_database_stats: {str(e)}")
        print(traceback.format_exc())
        return {
            'success': False,
            'active_coins': 0,
            'last_update': f'خطا: {str(e)[:50]}',
            'last_update_jalali': f'خطا: {str(e)[:50]}',
            'candle_15m': 0,
            'candle_1h': 0,
            'candle_4h': 0,
            'total_tables': 0,
            'db_path': str(config.DB_PATH),
            'db_exists': False,
            'error': str(e),
            'traceback': traceback.format_exc()
        }


def get_state_data(config):
    """دریافت داده‌های state از فایل cycle_state.json"""
    try:
        # یافتن فایل state
        possible_paths = [
            config.BASE_DIR / "state" / "cycle_state.json",
            config.BASE_DIR / "cycle_state.json",
            Path("state") / "cycle_state.json",
            Path("cycle_state.json")
        ]
        
        state_file = None
        for path in possible_paths:
            if path.exists():
                state_file = path
                break
        
        if not state_file:
            return {
                'success': False,
                'error': 'فایل state یافت نشد',
                'message': 'لطفاً ابتدا اسکریپت فیلتر را اجرا کنید',
                'searched_paths': [str(p) for p in possible_paths]
            }
        
        print(f"📂 بارگذاری state از: {state_file}")
        
        with open(state_file, 'r', encoding='utf-8') as f:
            state_data = json.load(f)
        
        # بررسی و تبدیل timestampها در بلوک‌ها
        blocks_with_timestamps = []
        total_coins_converted = 0
        conversion_errors = 0
        
        if 'blocks' in state_data:
            for block_index, block in enumerate(state_data['blocks']):
                block_info = {
                    'block_id': block.get('block_id'),
                    'size': block.get('size', 0),
                    'symbols': block.get('symbols', []),
                    'coins': []
                }
                
                if 'coins' in block:
                    for coin_index, coin in enumerate(block['coins']):
                        coin_with_timestamp = dict(coin)  # کپی سکه
                        
                        # اولویت با فیلد last_updated_readable است
                        last_updated_readable = coin.get('last_updated_readable')
                        timestamp_value = None
                        timestamp_field_used = None
                        readable_date_obj = None
                        
                        if last_updated_readable:
                            # اگر فیلد readable وجود دارد، از آن استفاده می‌کنیم
                            timestamp_value = last_updated_readable
                            timestamp_field_used = 'last_updated_readable'
                            readable_date_obj = parse_readable_date(last_updated_readable)
                            
                            # نمایش دیباگ برای 5 سکه اول
                            if block_index == 0 and coin_index < 5:
                                print(f"🔹 سکه {coin.get('symbol', 'unknown')}: last_updated_readable = {last_updated_readable}")
                                if readable_date_obj:
                                    print(f"   -> Parsed datetime: {readable_date_obj}")
                        else:
                            # در غیر این صورت به سراغ timestampها می‌رویم
                            timestamp_fields = ['last_updated_ts', 'last_updated', 'updated_at', 'timestamp', 'created_at']
                            for field in timestamp_fields:
                                if field in coin and coin[field]:
                                    timestamp_value = coin[field]
                                    timestamp_field_used = field
                                    break
                        
                        coin_with_timestamp['timestamp_field'] = timestamp_field_used
                        
                        if timestamp_value:
                            try:
                                # اگر فیلد readable است
                                if timestamp_field_used == 'last_updated_readable':
                                    if readable_date_obj:
                                        # تبدیل به تاریخ شمسی
                                        jalali_info = convert_to_jalali(readable_date_obj)
                                        coin_with_timestamp.update({
                                            'gregorian_date': readable_date_obj.strftime('%Y-%m-%d %H:%M:%S'),
                                            'jalali_date': jalali_info['jalali_full'],
                                            'last_updated_readable': last_updated_readable,
                                            'readable_date_obj': readable_date_obj.isoformat(),
                                            'timestamp_info': {
                                                'gregorian': readable_date_obj.strftime('%Y-%m-%d %H:%M:%S'),
                                                'jalali': jalali_info['jalali_full'],
                                                'readable_format': True,
                                                'datetime_obj': readable_date_obj.isoformat()
                                            },
                                            'conversion_success': True
                                        })
                                    else:
                                        # اگر نتوانستیم پارس کنیم، همان رشته را نمایش می‌دهیم
                                        coin_with_timestamp.update({
                                            'gregorian_date': last_updated_readable,
                                            'jalali_date': last_updated_readable,
                                            'last_updated_readable': last_updated_readable,
                                            'readable_date_obj': None,
                                            'timestamp_info': {
                                                'gregorian': last_updated_readable,
                                                'jalali': last_updated_readable,
                                                'readable_format': True,
                                                'raw_string': last_updated_readable
                                            },
                                            'conversion_success': True
                                        })
                                    total_coins_converted += 1
                                else:
                                    # برای timestampهای عددی
                                    result, dt, ts_type = safe_convert_timestamp(timestamp_value)
                                    if result:
                                        coin_with_timestamp.update({
                                            'gregorian_date': result['gregorian'],
                                            'jalali_date': result['jalali'],
                                            'timestamp_info': result,
                                            'conversion_success': True
                                        })
                                        total_coins_converted += 1
                                    else:
                                        coin_with_timestamp.update({
                                            'gregorian_date': 'خطا در تبدیل',
                                            'jalali_date': 'خطا در تبدیل',
                                            'conversion_success': False,
                                            'conversion_error': ts_type  # در اینجا ts_type حاوی خطا است
                                        })
                                        conversion_errors += 1
                            except Exception as e:
                                coin_with_timestamp.update({
                                    'gregorian_date': 'خطا',
                                    'jalali_date': 'خطا',
                                    'conversion_success': False,
                                    'conversion_error': str(e)
                                })
                                conversion_errors += 1
                        else:
                            coin_with_timestamp.update({
                                'gregorian_date': 'بدون timestamp',
                                'jalali_date': 'بدون timestamp',
                                'conversion_success': False
                            })
                        
                        block_info['coins'].append(coin_with_timestamp)
                
                blocks_with_timestamps.append(block_info)
        
        # آمار کلی timestampها از state
        timestamp_stats = {
            'oldest_last_updated_ts': state_data.get('stats', {}).get('oldest_last_updated_ts'),
            'newest_last_updated_ts': state_data.get('stats', {}).get('newest_last_updated_ts'),
            'total_coins_with_ts': state_data.get('stats', {}).get('coins_with_last_updated_ts', 0),
            'total_blocks': state_data.get('stats', {}).get('total_blocks', 0),
            'coins_converted': total_coins_converted,
            'conversion_errors': conversion_errors
        }
        
        # تبدیل timestampهای اصلی در stats
        stats_with_dates = {}
        if 'stats' in state_data:
            stats_with_dates = state_data['stats'].copy()
            # تبدیل oldest_last_updated_ts
            if 'oldest_last_updated_ts' in state_data['stats']:
                result, dt, ts_type = safe_convert_timestamp(state_data['stats']['oldest_last_updated_ts'])
                if result:
                    stats_with_dates['oldest_last_updated_ts_formatted'] = result['gregorian']
                    stats_with_dates['oldest_last_updated_ts_jalali'] = result['jalali']
                    stats_with_dates['oldest_last_updated_ts_info'] = result
            
            # تبدیل newest_last_updated_ts
            if 'newest_last_updated_ts' in state_data['stats']:
                result, dt, ts_type = safe_convert_timestamp(state_data['stats']['newest_last_updated_ts'])
                if result:
                    stats_with_dates['newest_last_updated_ts_formatted'] = result['gregorian']
                    stats_with_dates['newest_last_updated_ts_jalali'] = result['jalali']
                    stats_with_dates['newest_last_updated_ts_info'] = result
        
        print(f"✅ تبدیل timestampها کامل شد: {total_coins_converted} موفق، {conversion_errors} خطا")
        print(f"📊 فیلد last_updated_readable در سکه‌های بلوک اول: {len([c for c in blocks_with_timestamps[0]['coins'] if 'last_updated_readable' in c]) if blocks_with_timestamps else 0}")
        
        return {
            'success': True,
            'state': state_data,
            'blocks_with_timestamps': blocks_with_timestamps,
            'stats_with_dates': stats_with_dates,
            'timestamp_stats': timestamp_stats,
            'message': 'داده‌های state بارگذاری و timestampها تبدیل شدند',
            'file_path': str(state_file),
            'file_size': state_file.stat().st_size if state_file.exists() else 0,
            'timestamp': datetime.now().isoformat(),
            'conversion_summary': {
                'total': total_coins_converted + conversion_errors,
                'successful': total_coins_converted,
                'errors': conversion_errors,
                'success_rate': (total_coins_converted / (total_coins_converted + conversion_errors) * 100) if (total_coins_converted + conversion_errors) > 0 else 0
            }
        }
        
    except json.JSONDecodeError as e:
        print(f"❌ خطا در خواندن JSON: {e}")
        return {
            'success': False,
            'error': f'خطا در خواندن فایل JSON: {str(e)}',
            'message': 'فایل state معتبر نیست'
        }
    except Exception as e:
        print(f"❌ خطای کلی در get_state_data: {e}")
        print(traceback.format_exc())
        return {
            'success': False,
            'error': str(e),
            'message': 'خطا در خواندن فایل state',
            'traceback': traceback.format_exc()
        }


def run_filter_script(config):
    """اجرای اسکریپت فیلتر"""
    try:
        # جستجوی اسکریپت در مسیرهای مختلف
        possible_paths = [
            config.BASE_DIR / "scripts" / "cycle" / "cycle_01_coin_filter.py",
            config.BASE_DIR / "cycle_01_coin_filter.py",
            Path("scripts/cycle/cycle_01_coin_filter.py"),
            Path("cycle_01_coin_filter.py")
        ]
        
        script_path = None
        for path in possible_paths:
            if path.exists():
                script_path = path
                break
        
        if not script_path:
            return {
                'success': False,
                'error': f'اسکریپت یافت نشد',
                'message': 'مسیر اسکریپت اشتباه است',
                'searched_paths': [str(p) for p in possible_paths]
            }
        
        print(f"🚀 اجرای اسکریپت از: {script_path}")
        
        # اجرای اسکریپت
        start_time = datetime.now()
        
        try:
            result = subprocess.run(
                ['python', str(script_path)],
                capture_output=True,
                text=True,
                encoding='utf-8',
                cwd=str(config.BASE_DIR),
                timeout=300  # 5 دقیقه تایم‌اوت
            )
        except subprocess.TimeoutExpired:
            return {
                'success': False,
                'error': 'تایم‌اوت اسکریپت',
                'message': 'اسکریپت پس از 5 دقیقه کامل نشد'
            }
        except Exception as e:
            return {
                'success': False,
                'error': f'خطا در اجرای اسکریپت: {str(e)}',
                'message': 'اسکریپت قابل اجرا نیست'
            }
        
        execution_time = (datetime.now() - start_time).total_seconds()
        
        if result.returncode == 0:
            # خواندن state جدید پس از اجرا
            state_file = config.BASE_DIR / "state" / "cycle_state.json"
            blocks_count = 0
            cycle_id = 'unknown'
            
            if state_file.exists():
                try:
                    with open(state_file, 'r', encoding='utf-8') as f:
                        state_data = json.load(f)
                        blocks_count = state_data.get('stats', {}).get('total_blocks', 0)
                        cycle_id = state_data.get('cycle_id', 'unknown')
                except:
                    pass
            
            return {
                'success': True,
                'message': 'اسکریپت با موفقیت اجرا شد',
                'execution_time': round(execution_time, 2),
                'blocks_count': blocks_count,
                'cycle_id': cycle_id,
                'output_preview': result.stdout[:500] + "..." if len(result.stdout) > 500 else result.stdout,
                'return_code': result.returncode,
                'timestamp': datetime.now().isoformat(),
                'timestamp_jalali': convert_to_jalali(datetime.now())['jalali_full']
            }
        else:
            print(f"❌ خطا در اجرای اسکریپت: {result.stderr}")
            return {
                'success': False,
                'error': f'اسکریپت با کد خطا {result.returncode} خاتمه یافت',
                'stderr': result.stderr[:1000] if result.stderr else 'بدون خطا',
                'stdout': result.stdout[:1000] if result.stdout else 'بدون خروجی',
                'execution_time': round(execution_time, 2),
                'return_code': result.returncode,
                'timestamp': datetime.now().isoformat()
            }
            
    except Exception as e:
        print(f"❌ خطا در run_filter_script: {e}")
        print(traceback.format_exc())
        return {
            'success': False,
            'error': str(e),
            'message': 'خطای سرور در اجرای اسکریپت',
            'traceback': traceback.format_exc()
        }