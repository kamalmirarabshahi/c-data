# backend/indicator.py - گزارش جامع وضعیت اندیکاتورها

import sqlite3
from pathlib import Path
from datetime import datetime, timedelta
import math

def get_indicator_report(config, coin_symbol: str = None):
    """
    دریافت گزارش واقعی اندیکاتورها از دیتابیس
    
    Args:
        config: تنظیمات پروژه
        coin_symbol: (اختیاری) برای گزارش یک ارز خاص
    
    Returns:
        dict: گزارش کامل وضعیت اندیکاتورها
    """
    print(f"📊 دریافت گزارش وضعیت اندیکاتورها از دیتابیس...")
    
    try:
        db_path = getattr(config, 'DB_PATH', Path('data/crypto_master.db'))
        
        if not db_path or not db_path.exists():
            print(f"❌ دیتابیس یافت نشد: {db_path}")
            return {
                'success': False,
                'error': f'دیتابیس یافت نشد: {db_path}',
                'db_exists': False
            }
        
        conn = sqlite3.connect(str(db_path))
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        
        print(f"✅ اتصال به دیتابیس برقرار شد: {db_path}")
        
        # گزارش کلی
        if not coin_symbol:
            report = get_comprehensive_report(cursor)
        else:
            # اگر نماد ارز داده شده، گزارش تک ارز تولید کن
            report = get_coin_report(cursor, coin_symbol)
        
        conn.close()
        
        # اضافه کردن متادیتا
        report.update({
            'success': True,
            'generated_at': datetime.now().isoformat(),
            'coin_filter': coin_symbol,
            'report_type': 'single_coin' if coin_symbol else 'comprehensive',
            'db_path': str(db_path)
        })
        
        print(f"✅ گزارش اندیکاتورها آماده شد")
        return report
        
    except Exception as e:
        print(f"❌ خطا در get_indicator_report: {e}")
        import traceback
        traceback.print_exc()
        return {
            'success': False,
            'error': str(e),
            'generated_at': datetime.now().isoformat()
        }

def get_comprehensive_report(cursor):
    """
    گزارش جامع برای تمام ارزهای فعال
    """
    print("🔍 در حال تحلیل داده‌های واقعی از دیتابیس...")
    
    # 1. آمار کلی ارزها
    cursor.execute("""
        SELECT 
            COUNT(*) as total_coins,
            SUM(CASE WHEN is_active < 5 THEN 1 ELSE 0 END) as active_coins,
            SUM(CASE WHEN is_active >= 5 THEN 1 ELSE 0 END) as inactive_coins
        FROM crypto_coins
    """)
    coins_stats = cursor.fetchone()
    
    # 2. ارزهای دارای داده کندل
    cursor.execute("""
        SELECT COUNT(DISTINCT c.id) as coins_with_candle_data
        FROM crypto_coins c
        JOIN crypto_klines k ON c.id = k.coin_id
        WHERE c.is_active < 5
    """)
    coins_with_data = cursor.fetchone()
    
    # 3. تحلیل اندیکاتورهای کل
    indicator_analysis = analyze_all_indicators(cursor)
    
    # 4. تحلیل تایم‌فریم‌ها
    timeframe_analysis = analyze_timeframes(cursor)
    
    # 5. تحلیل ارزهای برتر
    top_coins = analyze_top_coins(cursor)
    
    # 6. محاسبه نمره کلی سیستم
    system_score = calculate_system_score(indicator_analysis, timeframe_analysis)
    
    # 7. تحلیل کیفیت داده
    data_quality = analyze_data_quality(cursor)
    
    # 8. تحلیل وضعیت بروزرسانی
    update_status = analyze_update_status(cursor)
    
    return {
        'overall_stats': {
            'total_coins': coins_stats['total_coins'] if coins_stats else 0,
            'active_coins': coins_stats['active_coins'] if coins_stats else 0,
            'inactive_coins': coins_stats['inactive_coins'] if coins_stats else 0,
            'coins_with_candle_data': coins_with_data['coins_with_candle_data'] if coins_with_data else 0,
            'coins_analyzed': len(top_coins) if top_coins else 0
        },
        'aggregate_stats': {
            'avg_overall_score': system_score,
            'ready_for_signal': calculate_ready_coins(cursor),
            'ready_percentage': calculate_ready_percentage(cursor),
            'status_distribution': calculate_status_distribution(cursor),
            'top_coins': top_coins[:10] if top_coins else []
        },
        'indicator_analysis': indicator_analysis,
        'timeframe_analysis': timeframe_analysis,
        'data_quality': data_quality,
        'update_status': update_status
    }

def get_coin_report(cursor, coin_symbol: str):
    """
    گزارش برای یک ارز خاص
    """
    print(f"🔍 در حال تحلیل ارز {coin_symbol}...")
    
    # پیدا کردن coin_id
    cursor.execute("""
        SELECT id, symbol, coin_name, market_cap_rank, is_active
        FROM crypto_coins 
        WHERE symbol = ? AND is_active < 5
    """, (coin_symbol.upper(),))
    
    coin = cursor.fetchone()
    
    if not coin:
        return {
            'success': False,
            'error': f'ارز {coin_symbol} یافت نشد یا غیرفعال است'
        }
    
    coin_id = coin['id']
    
    # تحلیل ارز
    coin_analysis = analyze_single_coin(cursor, coin_id, coin_symbol)
    
    return {
        'coin_info': {
            'id': coin_id,
            'symbol': coin['symbol'],
            'name': coin['coin_name'],
            'market_cap_rank': coin['market_cap_rank'],
            'is_active': coin['is_active']
        },
        'coin_analysis': coin_analysis,
        'success': True
    }

def analyze_single_coin(cursor, coin_id: int, symbol: str):
    """
    تحلیل کامل یک ارز خاص
    """
    print(f"📊 تحلیل ارز {symbol} (ID: {coin_id})")
    
    # 1. اطلاعات پایه
    cursor.execute("""
        SELECT 
            COUNT(*) as total_candles,
            COUNT(DISTINCT timeframe) as timeframe_count,
            MIN(close_time) as first_candle,
            MAX(close_time) as last_candle
        FROM crypto_klines 
        WHERE coin_id = ?
    """, (coin_id,))
    
    basic_info = cursor.fetchone()
    
    # 2. تحلیل تایم‌فریم‌ها
    timeframe_analysis = {}
    cursor.execute("""
        SELECT timeframe, COUNT(*) as candle_count,
               MIN(close_time) as first_candle,
               MAX(close_time) as last_candle
        FROM crypto_klines 
        WHERE coin_id = ?
        GROUP BY timeframe
        ORDER BY CASE timeframe
            WHEN '15m' THEN 1
            WHEN '1h' THEN 2
            WHEN '4h' THEN 3
            WHEN '1d' THEN 4
            WHEN '1w' THEN 5
            ELSE 6
        END
    """, (coin_id,))
    
    for row in cursor.fetchall():
        timeframe_analysis[row['timeframe']] = {
            'candle_count': row['candle_count'],
            'first_candle': row['first_candle'],
            'last_candle': row['last_candle'],
            'has_sufficient_data': row['candle_count'] >= 200,
            'missing_candles': max(0, 200 - row['candle_count'])
        }
    
    # 3. تحلیل اندیکاتورها
    indicator_coverage = analyze_coin_indicators_detailed(cursor, coin_id)
    
    # 4. کیفیت داده
    data_quality = analyze_coin_data_quality(cursor, coin_id)
    
    # 5. محاسبه نمره کلی
    overall_score = calculate_coin_overall_score(timeframe_analysis, indicator_coverage, data_quality)
    
    # 6. وضعیت آمادگی برای سیگنال
    signal_readiness = check_coin_signal_readiness(timeframe_analysis, indicator_coverage)
    
    return {
        'basic_info': {
            'total_candles': basic_info['total_candles'] if basic_info else 0,
            'timeframe_count': basic_info['timeframe_count'] if basic_info else 0,
            'first_candle': basic_info['first_candle'] if basic_info else None,
            'last_candle': basic_info['last_candle'] if basic_info else None
        },
        'timeframe_analysis': timeframe_analysis,
        'indicator_coverage': indicator_coverage,
        'data_quality': data_quality,
        'overall_score': overall_score,
        'signal_readiness': signal_readiness,
        'recommendations': generate_coin_recommendations(timeframe_analysis, indicator_coverage, data_quality)
    }

def analyze_coin_indicators_detailed(cursor, coin_id: int):
    """
    تحلیل دقیق اندیکاتورهای یک ارز
    """
    indicators = [
        'rsi', 'macd', 'macd_signal', 'macd_histogram',
        'ma_7', 'ma_25', 'ma_99', 
        'bollinger_upper', 'bollinger_middle', 'bollinger_lower',
        'obv', 'volume_ma_20', 'volume_ratio',
        'atr', 'volatility',
        'price_change', 'price_change_percent'
    ]
    
    results = {}
    timeframes = ['15m', '1h', '4h']
    
    for indicator in indicators:
        coverage_by_timeframe = {}
        
        for tf in timeframes:
            cursor.execute(f"""
                SELECT 
                    COUNT(*) as total,
                    SUM(CASE WHEN {indicator} IS NOT NULL THEN 1 ELSE 0 END) as populated
                FROM crypto_klines 
                WHERE coin_id = ? AND timeframe = ?
                ORDER BY close_time DESC 
                LIMIT 200
            """, (coin_id, tf))
            
            result = cursor.fetchone()
            total = result['total'] if result else 0
            populated = result['populated'] if result else 0
            
            percentage = round((populated / total * 100), 1) if total > 0 else 0
            
            coverage_by_timeframe[tf] = {
                'total': total,
                'populated': populated,
                'percentage': percentage
            }
        
        # میانگین بین تایم‌فریم‌ها
        percentages = [data['percentage'] for data in coverage_by_timeframe.values() if data['total'] > 0]
        avg_percentage = round(sum(percentages) / len(percentages), 1) if percentages else 0
        
        results[indicator] = {
            'by_timeframe': coverage_by_timeframe,
            'avg_percentage': avg_percentage,
            'status': get_indicator_status(avg_percentage)
        }
    
    return results

def analyze_coin_data_quality(cursor, coin_id: int):
    """
    تحلیل کیفیت داده یک ارز
    """
    cursor.execute("""
        SELECT 
            AVG(data_quality) as avg_data_quality,
            COUNT(CASE WHEN is_interpolated = 1 THEN 1 END) as interpolated_count,
            COUNT(CASE WHEN missing_data_points > 0 THEN 1 END) as missing_data_count,
            COUNT(*) as total_candles
        FROM crypto_klines 
        WHERE coin_id = ?
    """, (coin_id,))
    
    result = cursor.fetchone()
    
    if not result or result['total_candles'] == 0:
        return {
            'avg_data_quality': 0,
            'interpolated_percentage': 0,
            'missing_data_percentage': 0,
            'quality_level': 'نامشخص'
        }
    
    avg_quality = result['avg_data_quality'] or 0
    interpolated_pct = (result['interpolated_count'] / result['total_candles'] * 100) if result['total_candles'] > 0 else 0
    missing_pct = (result['missing_data_count'] / result['total_candles'] * 100) if result['total_candles'] > 0 else 0
    
    # سطح کیفیت
    if avg_quality >= 90:
        quality_level = 'عالی'
        quality_color = 'success'
    elif avg_quality >= 75:
        quality_level = 'خوب'
        quality_color = 'info'
    elif avg_quality >= 60:
        quality_level = 'متوسط'
        quality_color = 'warning'
    else:
        quality_level = 'ضعیف'
        quality_color = 'danger'
    
    return {
        'avg_data_quality': round(avg_quality, 1),
        'interpolated_percentage': round(interpolated_pct, 1),
        'missing_data_percentage': round(missing_pct, 1),
        'quality_level': quality_level,
        'quality_color': quality_color
    }

def calculate_coin_overall_score(timeframe_analysis, indicator_coverage, data_quality):
    """
    محاسبه نمره کلی یک ارز
    """
    # نمره تعداد کندل‌ها (40%)
    candle_scores = []
    for tf, data in timeframe_analysis.items():
        candle_count = data['candle_count']
        score = min(100, (candle_count / 200) * 100)  # نمره بر اساس 200 کندل ایده‌آل
        candle_scores.append(score)
    
    candle_score = sum(candle_scores) / len(candle_scores) if candle_scores else 0
    
    # نمره پوشش اندیکاتورها (40%)
    indicator_percentages = [data['avg_percentage'] for data in indicator_coverage.values()]
    indicator_score = sum(indicator_percentages) / len(indicator_percentages) if indicator_percentages else 0
    
    # نمره کیفیت داده (20%)
    quality_score = data_quality['avg_data_quality']
    
    # محاسبه نمره نهایی
    overall_score = round((candle_score * 0.4) + (indicator_score * 0.4) + (quality_score * 0.2), 1)
    
    # تعیین سطح
    if overall_score >= 85:
        level = 'عالی'
        color = 'success'
    elif overall_score >= 70:
        level = 'خوب'
        color = 'info'
    elif overall_score >= 50:
        level = 'متوسط'
        color = 'warning'
    else:
        level = 'ضعیف'
        color = 'danger'
    
    return {
        'score': overall_score,
        'level': level,
        'color': color,
        'components': {
            'candle_score': round(candle_score, 1),
            'indicator_score': round(indicator_score, 1),
            'quality_score': round(quality_score, 1)
        }
    }

def check_coin_signal_readiness(timeframe_analysis, indicator_coverage):
    """
    بررسی آمادگی ارز برای تولید سیگنال
    """
    # حداقل 2 تایم‌فریم با داده کافی
    sufficient_timeframes = sum(1 for data in timeframe_analysis.values() 
                               if data.get('has_sufficient_data', False))
    
    # اندیکاتورهای حیاتی
    vital_indicators = ['rsi', 'macd', 'ma_7', 'bollinger_upper', 'bollinger_lower', 'obv']
    vital_coverage = []
    
    for indicator in vital_indicators:
        if indicator in indicator_coverage:
            coverage = indicator_coverage[indicator]
            vital_coverage.append(coverage['avg_percentage'])
    
    avg_vital_coverage = sum(vital_coverage) / len(vital_coverage) if vital_coverage else 0
    
    # شرایط آمادگی
    is_ready = (sufficient_timeframes >= 2 and avg_vital_coverage >= 80)
    
    missing_requirements = []
    if sufficient_timeframes < 2:
        missing_requirements.append(f'نیاز به {2 - sufficient_timeframes} تایم‌فریم دیگر با داده کافی')
    if avg_vital_coverage < 80:
        missing_requirements.append(f'پوشش اندیکاتورهای حیاتی {avg_vital_coverage:.1f}% (حداقل 80% مورد نیاز)')
    
    return {
        'ready': is_ready,
        'sufficient_timeframes': sufficient_timeframes,
        'vital_coverage': round(avg_vital_coverage, 1),
        'missing_requirements': missing_requirements,
        'recommendation': 'آماده برای تولید سیگنال' if is_ready else 'نیاز به بهبود داده‌ها'
    }

def generate_coin_recommendations(timeframe_analysis, indicator_coverage, data_quality):
    """
    تولید توصیه‌ها برای بهبود یک ارز
    """
    recommendations = []
    
    # بررسی تایم‌فریم‌ها
    for tf, data in timeframe_analysis.items():
        if data['candle_count'] < 200:
            missing = 200 - data['candle_count']
            recommendations.append(f"⏳ تایم‌فریم {tf}: {missing} کندل دیگر نیاز دارید (فعلاً {data['candle_count']} کندل)")
    
    # بررسی اندیکاتورها
    for indicator, data in indicator_coverage.items():
        if data['avg_percentage'] < 70:
            recommendations.append(f"📊 اندیکاتور {indicator}: فقط {data['avg_percentage']}% پوشش دارد")
    
    # بررسی کیفیت داده
    if data_quality['avg_data_quality'] < 80:
        recommendations.append(f"🧪 کیفیت داده: {data_quality['avg_data_quality']}% (حداقل 80% توصیه می‌شود)")
    
    if data_quality['interpolated_percentage'] > 10:
        recommendations.append(f"⚠️ {data_quality['interpolated_percentage']}% داده درون‌یابی شده (حداکثر 10% قابل قبول)")
    
    if not recommendations:
        recommendations.append("✅ داده‌ها در وضعیت مطلوب هستند. می‌توانید تحلیل سیگنال را آغاز کنید.")
    
    return recommendations

# بقیه توابع (که قبلاً تعریف شده بودند)...
def analyze_all_indicators(cursor):
    """
    تحلیل واقعی اندیکاتورها از دیتابیس
    """
    print("📈 تحلیل اندیکاتورهای واقعی...")
    
    indicators = [
        'rsi', 'macd', 'macd_signal', 'macd_histogram',
        'ma_7', 'ma_25', 'ma_99', 
        'bollinger_upper', 'bollinger_middle', 'bollinger_lower',
        'obv', 'volume_ma_20', 'volume_ratio',
        'atr', 'volatility',
        'price_change', 'price_change_percent'
    ]
    
    results = {}
    
    for indicator in indicators:
        try:
            cursor.execute(f"""
                SELECT COUNT(*) as total_candles
                FROM crypto_klines 
                WHERE timeframe IN ('15m', '1h', '4h')
            """)
            total = cursor.fetchone()['total_candles']
            
            cursor.execute(f"""
                SELECT COUNT(*) as populated_candles
                FROM crypto_klines 
                WHERE timeframe IN ('15m', '1h', '4h')
                AND {indicator} IS NOT NULL
            """)
            populated = cursor.fetchone()['populated_candles']
            
            percentage = round((populated / total * 100), 1) if total > 0 else 0
            
            results[indicator] = {
                'total': total,
                'populated': populated,
                'percentage': percentage,
                'status': get_indicator_status(percentage)
            }
            
            print(f"  {indicator}: {populated}/{total} ({percentage}%)")
            
        except Exception as e:
            print(f"⚠️ خطا در تحلیل {indicator}: {e}")
            results[indicator] = {
                'total': 0,
                'populated': 0,
                'percentage': 0,
                'status': 'error'
            }
    
    return results

def get_indicator_status(percentage):
    if percentage >= 90:
        return 'excellent'
    elif percentage >= 70:
        return 'good'
    elif percentage >= 50:
        return 'average'
    else:
        return 'poor'

def analyze_timeframes(cursor):
    timeframes = ['15m', '1h', '4h', '1d', '1w']
    results = {}
    
    for timeframe in timeframes:
        try:
            cursor.execute("""
                SELECT COUNT(DISTINCT coin_id) as coins_count
                FROM crypto_klines 
                WHERE timeframe = ?
            """, (timeframe,))
            coins_count = cursor.fetchone()['coins_count']
            
            cursor.execute("""
                SELECT COUNT(*) as total_candles
                FROM crypto_klines 
                WHERE timeframe = ?
            """, (timeframe,))
            total_candles = cursor.fetchone()['total_candles']
            
            cursor.execute("""
                SELECT AVG(
                    CASE WHEN rsi IS NOT NULL THEN 1 ELSE 0 END +
                    CASE WHEN macd IS NOT NULL THEN 1 ELSE 0 END +
                    CASE WHEN ma_7 IS NOT NULL THEN 1 ELSE 0 END
                ) / 3 * 100 as avg_coverage
                FROM crypto_klines 
                WHERE timeframe = ?
            """, (timeframe,))
            avg_coverage_result = cursor.fetchone()
            avg_coverage = round(avg_coverage_result['avg_coverage'], 1) if avg_coverage_result['avg_coverage'] else 0
            
            results[timeframe] = {
                'coins_count': coins_count,
                'total_candles': total_candles,
                'avg_indicator_coverage': avg_coverage,
                'status': 'active' if coins_count > 0 else 'inactive'
            }
            
            print(f"  تایم‌فریم {timeframe}: {coins_count} ارز، {total_candles} کندل، پوشش: {avg_coverage}%")
            
        except Exception as e:
            print(f"⚠️ خطا در تحلیل تایم‌فریم {timeframe}: {e}")
            results[timeframe] = {
                'coins_count': 0,
                'total_candles': 0,
                'avg_indicator_coverage': 0,
                'status': 'error'
            }
    
    return results

def analyze_top_coins(cursor, limit=20):
    try:
        cursor.execute("""
            SELECT c.id, c.symbol, c.coin_name, c.market_cap_rank,
                   COUNT(k.id) as candle_count,
                   MAX(k.close_time) as last_candle_time
            FROM crypto_coins c
            LEFT JOIN crypto_klines k ON c.id = k.coin_id AND k.timeframe = '4h'
            WHERE c.is_active < 5
            GROUP BY c.id, c.symbol, c.coin_name, c.market_cap_rank
            HAVING candle_count >= 100
            ORDER BY candle_count DESC, c.market_cap_rank
            LIMIT ?
        """, (limit,))
        
        coins = cursor.fetchall()
        
        top_coins = []
        for coin in coins:
            coin_id = coin['id']
            symbol = coin['symbol']
            
            # تحلیل ساده برای تست
            candle_count = coin['candle_count']
            indicator_score = 80 if candle_count > 150 else 60
            quality_score = 85
            
            overall_score = round((candle_count / 200 * 100 * 0.4) + (indicator_score * 0.4) + (quality_score * 0.2), 1)
            
            if overall_score >= 85:
                level = 'عالی'
            elif overall_score >= 70:
                level = 'خوب'
            elif overall_score >= 50:
                level = 'متوسط'
            else:
                level = 'ضعیف'
            
            signal_ready = overall_score >= 70 and candle_count >= 150
            
            top_coins.append({
                'symbol': symbol,
                'name': coin['coin_name'] or symbol,
                'market_cap_rank': coin['market_cap_rank'] or 9999,
                'candle_count': candle_count,
                'last_candle_time': coin['last_candle_time'],
                'overall_score': {
                    'score': overall_score,
                    'level': level
                },
                'signal_readiness': {
                    'ready': signal_ready,
                    'reason': 'کیفیت داده مناسب' if signal_ready else 'نیاز به بهبود داده'
                },
                'quality_score': quality_score,
                'indicator_score': indicator_score
            })
        
        print(f"✅ {len(top_coins)} ارز برتر تحلیل شدند")
        return top_coins
        
    except Exception as e:
        print(f"❌ خطا در تحلیل ارزهای برتر: {e}")
        return []

def calculate_system_score(indicator_analysis, timeframe_analysis):
    try:
        indicator_percentages = [data['percentage'] for data in indicator_analysis.values()]
        avg_indicator_coverage = sum(indicator_percentages) / len(indicator_percentages) if indicator_percentages else 0
        
        timeframe_percentages = [data['avg_indicator_coverage'] for data in timeframe_analysis.values()]
        avg_timeframe_coverage = sum(timeframe_percentages) / len(timeframe_percentages) if timeframe_percentages else 0
        
        system_score = (avg_indicator_coverage * 0.6 + avg_timeframe_coverage * 0.4)
        
        return round(system_score, 1)
        
    except:
        return 0

def calculate_ready_coins(cursor):
    try:
        cursor.execute("""
            SELECT COUNT(DISTINCT coin_id) as ready_coins
            FROM crypto_klines 
            WHERE timeframe = '4h'
            AND rsi IS NOT NULL 
            AND macd IS NOT NULL 
            AND ma_7 IS NOT NULL
            AND (
                SELECT COUNT(*) 
                FROM crypto_klines k2 
                WHERE k2.coin_id = crypto_klines.coin_id 
                AND k2.timeframe = '4h'
            ) >= 150
        """)
        
        result = cursor.fetchone()
        return result['ready_coins'] if result else 0
        
    except:
        return 0

def calculate_ready_percentage(cursor):
    try:
        cursor.execute("SELECT COUNT(*) as total FROM crypto_coins WHERE is_active < 5")
        total_coins = cursor.fetchone()['total']
        
        ready_coins = calculate_ready_coins(cursor)
        
        percentage = (ready_coins / total_coins * 100) if total_coins > 0 else 0
        
        return round(percentage, 1)
        
    except:
        return 0

def calculate_status_distribution(cursor):
    try:
        cursor.execute("""
            SELECT 
                COUNT(CASE WHEN candle_count >= 200 THEN 1 END) as excellent,
                COUNT(CASE WHEN candle_count >= 150 AND candle_count < 200 THEN 1 END) as good,
                COUNT(CASE WHEN candle_count >= 100 AND candle_count < 150 THEN 1 END) as average,
                COUNT(CASE WHEN candle_count < 100 THEN 1 END) as poor
            FROM (
                SELECT c.id, COUNT(k.id) as candle_count
                FROM crypto_coins c
                LEFT JOIN crypto_klines k ON c.id = k.coin_id AND k.timeframe = '4h'
                WHERE c.is_active < 5
                GROUP BY c.id
            ) as coin_stats
        """)
        
        result = cursor.fetchone()
        
        return {
            'excellent': result['excellent'] if result else 0,
            'good': result['good'] if result else 0,
            'average': result['average'] if result else 0,
            'poor': result['poor'] if result else 0
        }
        
    except:
        return {'excellent': 0, 'good': 0, 'average': 0, 'poor': 0}

def analyze_data_quality(cursor):
    try:
        cursor.execute("""
            SELECT 
                AVG(data_quality) as avg_data_quality,
                COUNT(CASE WHEN is_interpolated = 1 THEN 1 END) as interpolated_count,
                COUNT(CASE WHEN missing_data_points > 0 THEN 1 END) as missing_data_count,
                COUNT(*) as total_candles
            FROM crypto_klines
        """)
        
        result = cursor.fetchone()
        
        if not result:
            return {'avg_data_quality': 0, 'interpolated_percentage': 0, 'missing_data_percentage': 0}
        
        avg_quality = result['avg_data_quality'] or 0
        interpolated_pct = (result['interpolated_count'] / result['total_candles'] * 100) if result['total_candles'] > 0 else 0
        missing_pct = (result['missing_data_count'] / result['total_candles'] * 100) if result['total_candles'] > 0 else 0
        
        if avg_quality >= 90:
            quality_level = 'عالی'
        elif avg_quality >= 75:
            quality_level = 'خوب'
        elif avg_quality >= 60:
            quality_level = 'متوسط'
        else:
            quality_level = 'ضعیف'
        
        return {
            'avg_data_quality': round(avg_quality, 1),
            'interpolated_percentage': round(interpolated_pct, 1),
            'missing_data_percentage': round(missing_pct, 1),
            'quality_level': quality_level
        }
        
    except:
        return {'avg_data_quality': 0, 'interpolated_percentage': 0, 'missing_data_percentage': 0, 'quality_level': 'نامشخص'}

def analyze_update_status(cursor):
    try:
        cursor.execute("""
            SELECT 
                MAX(close_time) as last_update,
                COUNT(CASE WHEN datetime(close_time) >= datetime('now', '-1 hour') THEN 1 END) as updated_last_hour,
                COUNT(CASE WHEN datetime(close_time) < datetime('now', '-24 hours') THEN 1 END) as outdated_24h
            FROM crypto_klines
        """)
        
        result = cursor.fetchone()
        
        return {
            'last_update': result['last_update'] if result else None,
            'updated_last_hour': result['updated_last_hour'] if result else 0,
            'outdated_24h': result['outdated_24h'] if result else 0,
            'update_status': 'به‌روز' if result and result['updated_last_hour'] > 0 else 'نیاز به بروزرسانی'
        }
        
    except:
        return {'last_update': None, 'update_status': 'نامشخص'}