# backend/index.py
"""
🏠 Backend مخصوص صفحه index.html - نسخه ماژولار
"""

from config import Config, Navigation  # ✅ اضافه کردن import Navigation
import sqlite3
from datetime import datetime

def get_database_stats():
    """گرفتن آمار از دیتابیس با استفاده از تنظیمات مرکزی"""
    stats = {
        'active_coins': 0,
        'last_update': '',
        '15m_candles': 0,
        '1h_candles': 0,
        '4h_candles': 0,
        'total_tables': 0,
        'tables_info': []
    }
    
    try:
        if Config.DB_PATH.exists():
            conn = Config.get_database_connection()
            cursor = conn.cursor()
            
            # تعداد ارزهای فعال
            cursor.execute("SELECT COUNT(*) FROM crypto_coins WHERE is_active = 1")
            stats['active_coins'] = cursor.fetchone()[0]
            
            # آخرین تاریخ بروزرسانی
            cursor.execute("""
                SELECT MAX(updated_at) FROM crypto_klines 
                UNION ALL
                SELECT MAX(updated_at) FROM crypto_coins
                ORDER BY 1 DESC LIMIT 1
            """)
            last_update = cursor.fetchone()[0]
            stats['last_update'] = last_update if last_update else 'نامشخص'
            
            # تعداد کندل‌ها بر اساس تایم‌فریم
            timeframes = ['15m', '1h', '4h']
            for tf in timeframes:
                cursor.execute(f"SELECT COUNT(*) FROM crypto_klines WHERE timeframe = '{tf}'")
                stats[f'{tf}_candles'] = cursor.fetchone()[0]
            
            # اطلاعات جداول
            cursor.execute("""
                SELECT name FROM sqlite_master 
                WHERE type='table' AND name NOT LIKE 'sqlite_%'
                ORDER BY name
            """)
            tables = cursor.fetchall()
            stats['total_tables'] = len(tables)
            
            for table in tables:
                table_name = table[0]
                # تعداد رکوردها
                cursor.execute(f"SELECT COUNT(*) FROM {table_name}")
                row_count = cursor.fetchone()[0]
                
                # ساختار جدول
                cursor.execute(f"PRAGMA table_info({table_name})")
                columns = cursor.fetchall()
                
                # داده‌های نمونه (5 رکورد اول)
                cursor.execute(f"SELECT * FROM {table_name} LIMIT 5")
                sample_data = cursor.fetchall()
                column_names = [desc[0] for desc in cursor.description] if cursor.description else []
                
                stats['tables_info'].append({
                    'name': table_name,
                    'description': Config.MAIN_TABLES.get(table_name, 'جدول سیستم') if hasattr(Config, 'MAIN_TABLES') else 'جدول سیستم',
                    'row_count': row_count,
                    'columns': [{'name': col[1], 'type': col[2], 'nullable': col[3]} for col in columns],
                    'sample_data': sample_data,
                    'column_names': column_names
                })
            
            conn.close()
    
    except Exception as e:
        print(f"خطا در خواندن دیتابیس: {e}")
    
    return stats

def get_index_data():
    """داده‌های صفحه اصلی با استفاده از کانفیگ"""
    db_stats = get_database_stats()
    
    return {
        'project_name': Config.SITE_TITLE,
        'app_name': Config.SITE_DESCRIPTION,
        'version': getattr(Config, 'VERSION', '2.1.0'),
        'current_date': datetime.now().strftime('%Y-%m-%d'),
        'current_time': datetime.now().strftime('%H:%M:%S'),
        'server_url': f"http://{Config.HOST}:{Config.PORT}",
        
        # آمار دیتابیس
        'database_stats': {
            'active_coins': db_stats['active_coins'],
            'last_update': db_stats['last_update'],
            'candle_15m': db_stats['15m_candles'],
            'candle_1h': db_stats['1h_candles'],
            'candle_4h': db_stats['4h_candles'],
            'total_tables': db_stats['total_tables'],
            'db_path': str(Config.DB_PATH),
            'db_exists': Config.DB_PATH.exists()
        },
        
        # اطلاعات جداول برای نمایش
        'tables_info': db_stats['tables_info'],
        
        # ویژگی‌های سیستم
        'features': [
            '📊 جمع‌آوری داده‌های Real-time از صرافی‌ها',
            '📈 تحلیل تکنیکال با 50+ اندیکاتور',
            '🔔 سیستم سیگنال‌دهی هوشمند',
            '📋 گزارش‌گیری جامع و قابل دانلود',
            '👤 مدیریت کاربران و دسترسی‌ها',
            '💾 پشتیبان‌گیری خودکار از داده‌ها'
        ],
        
        # اطلاعات سیستم
        'system_info': {
            'debug_mode': Config.DEBUG,
            'cache_enabled': getattr(Config, 'ENABLE_CACHE', True),
            'export_formats': getattr(Config, 'ALLOWED_EXPORT_FORMATS', ['csv', 'json', 'xlsx']),
            'timezone': getattr(Config, 'TIMEZONE', 'Asia/Tehran')
        },
        
        # ✅ اضافه کردن navigation به داده‌های صفحه (اختیاری)
        'navigation': Navigation.get_main_navigation()
    }

# ============ توابع کمکی برای ماژولار ============

def get_index_page_data(config=None):
    """دریافت داده‌های صفحه index به صورت ماژولار"""
    data = get_index_data()
    
    if config:
        # اضافه کردن تنظیمات از config اگر ارسال شده
        data['project_name'] = getattr(config, 'SITE_TITLE', data['project_name'])
        data['app_name'] = getattr(config, 'SITE_DESCRIPTION', data['app_name'])
        data['server_url'] = f"http://{config.HOST}:{config.PORT}"
    
    return data