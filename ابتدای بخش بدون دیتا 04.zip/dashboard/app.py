﻿
from flask import Flask, render_template, jsonify, send_file, abort
import sys
from pathlib import Path
from datetime import datetime

# ============ CONFIGURATION ============

# اضافه کردن مسیرها به sys.path
current_dir = Path(__file__).parent
backend_dir = current_dir / 'backend'
config_dir = current_dir / 'config'

sys.path.insert(0, str(backend_dir))
sys.path.insert(0, str(config_dir))

# import ماژول‌های کانفیگ و backend
try:
    # کانفیگ مرکزی (با Navigation)
    from config import Config, Navigation
    print("✅ کانفیگ مرکزی با موفقیت import شد")
    
    # ماژول‌های backend اصلی
    from reports import get_reports_data
    
    print("✅ ماژول‌های backend با موفقیت import شدند")
    
except ImportError as e:
    print(f"❌ خطا در import ماژول‌ها: {e}")
    
    # تعریف fallback برای Config و Navigation
    class Config:
        BASE_DIR = current_dir.parent
        DB_PATH = BASE_DIR / 'data' / 'crypto_master.db'
        HOST = '127.0.0.1'
        PORT = 5000
        DEBUG = True
        SECRET_KEY = 'dev-secret-key-change-in-production'
        DEFAULT_PAGE_SIZE = 50
        MAX_EXPORT_ROWS = 10000
        SITE_TITLE = 'آخرین پروژه زندگی'
        SITE_DESCRIPTION = 'سیستم تحلیل ارزهای دیجیتال'
        EXPORT_DIR = current_dir / 'exports'
    
    class Navigation:
        MAIN_MENU = [
            {'name': 'خانه', 'url': '/', 'icon': 'fas fa-home'},
            {'name': 'لیست ارزها', 'url': '/coins', 'icon': 'fas fa-coins'},
            {'name': 'جداول', 'url': '/tables', 'icon': 'fas fa-table'},
            {'name': 'بلوک ارزها', 'url': '/blocks', 'icon': 'fas fa-cubes'},
            {'name': 'گزارشات', 'url': '/reports', 'icon': 'fas fa-chart-bar'},
            {'name': 'اندیکاتورها', 'url': '/indicator', 'icon': 'fas fa-chart-line'},
            {'name': 'بروز رسان', 'url': '/updated', 'icon': 'fas fa-history'}
        ]
        
        @classmethod
        def get_main_navigation(cls):
            return cls.MAIN_MENU
        
        @classmethod
        def get_navigation_with_active(cls, active_page=None):
            menu = cls.MAIN_MENU.copy()
            if active_page:
                for item in menu:
                    item['active'] = (item['name'] == active_page)
            return menu
    
    # تعریف توابع dummy برای جلوگیری از crash
    def get_reports_data():
        return {'error': 'Backend modules not found'}

# ============ FLASK APP INIT ============

app = Flask(__name__, 
            template_folder='templates',
            static_folder='static')

app.config['SECRET_KEY'] = Config.SECRET_KEY
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024
app.config['DEBUG'] = Config.DEBUG

# فیلترهای Jinja2
@app.template_filter('intcomma')
def intcomma_filter(value):
    try:
        return f"{int(value):,}"
    except:
        return value

@app.template_filter('round')
def round_filter(value, decimals=2):
    try:
        return round(float(value), decimals)
    except:
        return value

@app.template_filter('number_format')
def number_format_filter(value):
    """فیلتر جدید برای فرمت اعداد"""
    try:
        return f"{int(value):,}"
    except:
        try:
            return f"{float(value):,.2f}"
        except:
            return value

# ============ HELPER FUNCTIONS ============

def log_request(endpoint, method, status='success'):
    timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    print(f"[{timestamp}] {method} {endpoint} - {status}")

def format_db_path_for_display(db_path):
    try:
        str_path = str(db_path)
        if len(str_path) > 50:
            return "..." + str_path[-50:]
        return str_path
    except:
        return str(db_path)

# ============ IMPORT و REGISTER ماژول‌های جدید ============

print("\n" + "="*60)
print("🚀 ثبت ماژول‌های پروژه")
print("="*60)

# ماژول indicator - اضافه شده
try:
    from backend.indicator_routes import register_indicator_routes
    app = register_indicator_routes(app, Config)
    print("✅ ماژول indicator routes با موفقیت ثبت شد")
except ImportError as e:
    print(f"⚠️ خطا در ثبت indicator routes: {e}")

# ماژول updated
try:
    from backend.updated_routes import register_updated_routes
    app = register_updated_routes(app, Config)
    print("✅ ماژول updated routes با موفقیت ثبت شد")
except ImportError as e:
    print(f"⚠️ خطا در ثبت updated routes: {e}")

# ماژول index
try:
    from backend.index_routes import register_index_routes
    app = register_index_routes(app, Config)
    print("✅ ماژول index routes با موفقیت ثبت شد")
except ImportError as e:
    print(f"⚠️ خطا در ثبت index routes: {e}")

# ماژول coins
try:
    from backend.coins_routes import register_coins_routes
    app = register_coins_routes(app, Config)
    print("✅ ماژول coins routes با موفقیت ثبت شد")
except ImportError as e:
    print(f"⚠️ خطا در ثبت coins routes: {e}")

# ماژول tables
try:
    from backend.tables_routes import register_tables_routes
    app = register_tables_routes(app, Config)
    print("✅ ماژول tables routes با موفقیت ثبت شد")
except ImportError as e:
    print(f"⚠️ خطا در ثبت tables routes: {e}")

# ماژول blocks
try:
    from backend.blocks_routes import register_blocks_routes
    app = register_blocks_routes(app, Config)
    print("✅ ماژول blocks routes با موفقیت ثبت شد")
except ImportError as e:
    print(f"⚠️ خطا در ثبت blocks routes: {e}")

print("="*60 + "\n")

# ============ MAIN ROUTES ============

@app.route('/reports')
def reports():
    """صفحه گزارشات"""
    log_request('/reports', 'GET')
    try:
        data = get_reports_data()
        # استفاده از Navigation متمرکز
        data['navigation'] = Navigation.get_navigation_with_active('گزارشات')
        return render_template('reports.html', **data)
    except Exception as e:
        # استفاده از Navigation در حالت خطا
        return render_template('reports.html', 
                              status='error',
                              error=str(e),
                              reports=[],
                              stats={},
                              project_name=Config.SITE_TITLE,
                              navigation=Navigation.get_main_navigation())

# ============ UTILITY ROUTES ============

@app.route('/api/health')
def health_check():
    """بررسی سلامت سیستم"""
    log_request('/api/health', 'GET')
    
    db_exists = Config.DB_PATH.exists()
    
    backend_files = [
        'indicator.py', 'indicator_routes.py',  # اضافه شده
        'index.py', 'index_routes.py',
        'reports.py', 
        'coins.py', 'coins_routes.py',
        'tables.py', 'tables_routes.py',
        'blocks.py', 'blocks_routes.py',
        'updated.py', 'updated_routes.py'
    ]
    
    backend_status = {}
    for f in backend_files:
        file_path = backend_dir / f
        backend_status[f] = file_path.exists()
    
    config_status = (config_dir / 'config.py').exists()
    
    templates_dir = current_dir / 'templates'
    template_files = ['indicator.html', 'indicator_coin.html', 'index.html', 'reports.html', 'coins.html', 'tables.html', 'blocks.html', 'updated.html']
    templates_status = all((templates_dir / f).exists() for f in template_files)
    
    db_connection = False
    if db_exists:
        try:
            import sqlite3
            conn = sqlite3.connect(str(Config.DB_PATH))
            conn.close()
            db_connection = True
        except:
            db_connection = False
    
    registered_modules = {
        'indicator': 'backend.indicator_routes' in sys.modules,  # اضافه شده
        'index': 'index_routes' in sys.modules,
        'coins': 'backend.coins_routes' in sys.modules,
        'tables': 'backend.tables_routes' in sys.modules,
        'blocks': 'backend.blocks_routes' in sys.modules,
        'updated': 'backend.updated_routes' in sys.modules
    }
    
    nav_config_exists = hasattr(Navigation, 'get_main_navigation')
    
    return jsonify({
        'status': 'healthy',
        'app': Config.SITE_TITLE,
        'version': '2.2.0',
        'timestamp': datetime.now().isoformat(),
        'server_url': f"http://{Config.HOST}:{Config.PORT}",
        'checks': {
            'database_file': db_exists,
            'database_connection': db_connection,
            'config_module': config_status,
            'navigation_config': nav_config_exists,
            'templates': templates_status,
            'flask_server': True
        },
        'modules': registered_modules,
        'backend_files': backend_status,
        'navigation': Navigation.get_main_navigation() if nav_config_exists else [],
        'endpoints': {
            'main_pages': ['/', '/indicator', '/reports', '/coins', '/tables', '/blocks', '/updated'],
            'api_endpoints': [
                '/api/stats',
                '/api/update/summary', '/api/update/coins-status',
                '/api/update/run-candle-update', '/api/update/run-coin-update', '/api/update/single-coin/{symbol}',
                '/api/health', '/api/info', '/api/config',
                '/api/state/cycle', '/api/run/filter',
                '/api/coins', '/api/coins/{symbol}', '/api/coins/{symbol}/status',
                '/api/reports/all_coins', '/api/reports/active_coins', '/api/reports/inactive_coins',
                '/api/indicator/report', '/api/indicator/status', '/api/indicator/coins-list', '/api/indicator/refresh',  # اضافه شده
                '/api/export/{type}',
                '/api/tables', '/api/tables/{table}/structure', '/api/tables/{table}/data',
                '/api/database/schema'
            ]
        }
    })

@app.route('/api/info')
def api_info():
    """اطلاعات درباره API"""
    return jsonify({
        'app_name': Config.SITE_TITLE,
        'description': Config.SITE_DESCRIPTION,
        'version': '2.2.0',
        'author': 'Crypto Analysis Team',
        'navigation': Navigation.get_main_navigation(),
        'main_endpoints': [
            {'path': '/', 'method': 'GET', 'description': 'صفحه اصلی (شامل داشبورد)'},
            {'path': '/indicator', 'method': 'GET', 'description': 'گزارش اندیکاتورها'},  # اضافه شده
            {'path': '/coins', 'method': 'GET', 'description': 'لیست ارزها'},
            {'path': '/tables', 'method': 'GET', 'description': 'مدیریت جداول دیتابیس'},
            {'path': '/blocks', 'method': 'GET', 'description': 'مدیریت بلوک‌های ارزها'},
            {'path': '/reports', 'method': 'GET', 'description': 'صفحه گزارشات'},
            {'path': '/updated', 'method': 'GET', 'description': 'صفحه بروزرسانی'}
        ]
    })

@app.route('/api/config')
def api_config():
    """نمایش تنظیمات کانفیگ"""
    log_request('/api/config', 'GET')
    
    try:
        config_dict = {}
        for attr in dir(Config):
            if not attr.startswith('_') and not callable(getattr(Config, attr)):
                value = getattr(Config, attr)
                if isinstance(value, Path):
                    value = str(value)
                config_dict[attr] = value
        
        return jsonify({
            'status': 'success',
            'config': config_dict,
            'navigation': Navigation.get_main_navigation(),
            'warnings': Config.validate_config() if hasattr(Config, 'validate_config') else [],
            'timestamp': datetime.now().isoformat()
        })
    except Exception as e:
        return jsonify({
            'status': 'error',
            'error': str(e)
        }), 500

# ============ ERROR HANDLERS ============

@app.errorhandler(404)
def page_not_found(e):
    return render_template('error.html',
                          error_code=404,
                          error_message='صفحه مورد نظر یافت نشد',
                          suggestion='آدرس وارد شده را بررسی کنید یا به صفحه اصلی برگردید',
                          project_name=Config.SITE_TITLE,
                          navigation=Navigation.get_main_navigation()), 404

@app.errorhandler(500)
def internal_server_error(e):
    return render_template('error.html',
                          error_code=500,
                          error_message='خطای داخلی سرور',
                          suggestion='لطفاً بعداً تلاش کنید یا با پشتیبانی تماس بگیرید',
                          project_name=Config.SITE_TITLE,
                          navigation=Navigation.get_main_navigation()), 500

@app.errorhandler(400)
def bad_request(e):
    return render_template('error.html',
                          error_code=400,
                          error_message='درخواست نامعتبر',
                          suggestion='لطفاً پارامترهای درخواست را بررسی کنید',
                          project_name=Config.SITE_TITLE,
                          navigation=Navigation.get_main_navigation()), 400

# ============ STATIC FILE SERVING ============

@app.route('/exports/<filename>')
def download_export(filename):
    log_request(f'/exports/{filename}', 'GET')
    
    try:
        exports_dir = Config.EXPORT_DIR if hasattr(Config, 'EXPORT_DIR') else current_dir / 'exports'
        exports_dir.mkdir(exist_ok=True)
        
        filepath = exports_dir / filename
        if not filepath.exists():
            abort(404, "فایل یافت نشد")
        
        return send_file(filepath, as_attachment=True)
    except Exception as e:
        abort(500, str(e))

# ============ MAIN EXECUTION ============

if __name__ == '__main__':
    print("=" * 70)
    print(f"🚀 **{Config.SITE_TITLE}** - نسخه ماژولار 🚀")
    print("=" * 70)
    print("📁 ساختار پروژه:")
    print(f"   • Backend Modules: {backend_dir}")
    print(f"   • Config: {config_dir}/config.py")
    print(f"   • Templates: {current_dir / 'templates'}")
    print(f"   • Database: {format_db_path_for_display(Config.DB_PATH)}")
    print(f"   • Database Exists: {'✅' if Config.DB_PATH.exists() else '❌'}")
    print(f"   • Navigation Config: {'✅' if hasattr(Navigation, 'get_main_navigation') else '❌'}")
    
    print("\n✅ ماژول‌های ثبت شده:")
    print("   • indicator_routes - گزارش اندیکاتورها")
    print("   • index_routes - صفحه اصلی و آمار")
    print("   • coins_routes - مدیریت ارزها")
    print("   • tables_routes - مدیریت جداول")
    print("   • blocks_routes - مدیریت بلوک‌ها")
    print("   • updated_routes - صفحه بروزرسانی")
    
    print("\n🌐 صفحات اصلی:")
    print(f"   http://{Config.HOST}:{Config.PORT}/              # صفحه اصلی (داشبورد)")
    print(f"   http://{Config.HOST}:{Config.PORT}/indicator     # گزارش اندیکاتورها")
    print(f"   http://{Config.HOST}:{Config.PORT}/coins         # لیست ارزها")
    print(f"   http://{Config.HOST}:{Config.PORT}/tables        # مدیریت جداول")
    print(f"   http://{Config.HOST}:{Config.PORT}/blocks        # بلوک ارزها")
    print(f"   http://{Config.HOST}:{Config.PORT}/updated       # بروزرسانی")
    print(f"   http://{Config.HOST}:{Config.PORT}/reports       # گزارشات")
    
    print("\n🔧 API Endpoints اصلی:")
    print(f"   http://{Config.HOST}:{Config.PORT}/api/health    # وضعیت سلامت")
    print(f"   http://{Config.HOST}:{Config.PORT}/api/info      # اطلاعات API")
    print(f"   http://{Config.HOST}:{Config.PORT}/api/config    # تنظیمات کانفیگ")
    print(f"   http://{Config.HOST}:{Config.PORT}/api/indicator/report  # گزارش اندیکاتورها")
    
    print("\n📍 Navigation Menu:")
    try:
        for item in Navigation.get_main_navigation():
            print(f"   • {item['name']} - {item['url']}")
    except Exception as e:
        print(f"   ❌ خطا در نمایش Navigation: {e}")
    
    print("=" * 70)
    
    # ایجاد پوشه‌های مورد نیاز
    for dir_path in ['exports', 'logs', 'cache']:
        dir_full = current_dir / dir_path
        dir_full.mkdir(exist_ok=True)
    
    # اجرای سرور
    app.run(
        host=Config.HOST,
        port=Config.PORT,
        debug=Config.DEBUG,
        threaded=True
    )