﻿# [file name]: config.py
"""
⚙️ فایل تنظیمات پروژه با پشتیبانی از python-dotenv
"""

import os
import json
from pathlib import Path
from datetime import datetime
from dotenv import load_dotenv

# بارگذاری متغیرهای محیطی از فایل .env
load_dotenv()

# ============ تعیین مسیرهای اصلی ============
# ریشه پروژه (پوشه dashboard)
PROJECT_ROOT = Path(r"C:\Users\Kamal\Desktop\py-prg\git\c-data\dashboard")

# ریشه دیتابیس (پوشه data در سطح بالاتر)
DATA_ROOT = Path(r"C:\Users\Kamal\Desktop\py-prg\git\c-data\data")

print(f"📁 ریشه پروژه: {PROJECT_ROOT}")
print(f"📁 پوشه دیتابیس: {DATA_ROOT}")
print(f"✅ پروژه وجود دارد: {PROJECT_ROOT.exists()}")
print(f"✅ پوشه دیتابیس وجود دارد: {DATA_ROOT.exists()}")

class Config:
    """کلاس تنظیمات پروژه"""
    
    # ============ مسیرها ============
    BASE_DIR = PROJECT_ROOT
    DB_PATH = DATA_ROOT / 'crypto_master.db'
    EXPORT_DIR = BASE_DIR / 'exports'
    LOG_DIR = BASE_DIR / 'logs'
    CACHE_DIR = BASE_DIR / 'cache'
    TEMPLATES_DIR = BASE_DIR / 'templates'
    
    # ============ تنظیمات سرور ============
    HOST = os.getenv('HOST', '0.0.0.0')
    PORT = int(os.getenv('PORT', 5000))
    DEBUG = os.getenv('DEBUG', 'True').lower() == 'true'
    SECRET_KEY = os.getenv('SECRET_KEY', 'dev-secret-key-change-in-production')
    
    # ============ تنظیمات دیتابیس ============
    DB_TIMEOUT = int(os.getenv('DB_TIMEOUT', 30))
    DB_CACHE_SIZE = 10000
    
    # ============ تنظیمات گزارش‌گیری ============
    DEFAULT_PAGE_SIZE = int(os.getenv('DEFAULT_PAGE_SIZE', 50))
    MAX_EXPORT_ROWS = int(os.getenv('MAX_EXPORT_ROWS', 10000))
    CACHE_TIMEOUT = int(os.getenv('CACHE_TIMEOUT', 300))  # 5 دقیقه
    
    # ============ تنظیمات export ============
    ALLOWED_EXPORT_FORMATS = os.getenv('EXPORT_FORMATS', 'csv,json,xlsx').split(',')
    
    # ============ URLs ============
    SERVER_URL = f"http://{HOST}:{PORT}"
    
    # ============ تنظیمات نمایش ============
    SITE_TITLE = os.getenv('SITE_TITLE', 'آخرین پروژه زندگی')
    SITE_DESCRIPTION = os.getenv('SITE_DESCRIPTION', 'سیستم تحلیل ارزهای دیجیتال')
    TIMEZONE = os.getenv('TIMEZONE', 'Asia/Tehran')
    
    # ============ سایر تنظیمات ============
    LOG_LEVEL = os.getenv('LOG_LEVEL', 'INFO')
    ENABLE_CACHE = os.getenv('ENABLE_CACHE', 'True').lower() == 'true'
    API_RATE_LIMIT = int(os.getenv('API_RATE_LIMIT', 100))
    
    # ============ متغیرهای محاسبه‌شده ============
    CURRENT_DATE = datetime.now().strftime('%Y-%m-%d')
    CURRENT_TIME = datetime.now().strftime('%H:%M:%S')
    VERSION = '2.1.0'
    
    # ============ اطلاعات جداول اصلی ============
    MAIN_TABLES = {
        'crypto_coins': 'اطلاعات ارزهای دیجیتال',
        'crypto_klines': 'داده‌های کندل (قیمت)',
        'sqlite_master': 'متادیتای دیتابیس'
    }
    
    # ============ تایم‌فریم‌های پشتیبانی شده ============
    TIMEFRAMES = ['15m', '30m', '1h', '4h', '1d', '1w']
    
    @classmethod
    def init_directories(cls):
        """ایجاد پوشه‌های مورد نیاز"""
        # ایجاد پوشه‌ها
        cls.EXPORT_DIR.mkdir(exist_ok=True)
        cls.LOG_DIR.mkdir(exist_ok=True)
        cls.CACHE_DIR.mkdir(exist_ok=True)
        cls.TEMPLATES_DIR.mkdir(exist_ok=True)
        
        # ایجاد پوشه data اگر وجود ندارد
        cls.DB_PATH.parent.mkdir(exist_ok=True)
        
        # نمایش اطلاعات
        print(f"\n📁 مسیرهای پروژه:")
        print(f"   • ریشه پروژه: {cls.BASE_DIR}")
        print(f"   • دیتابیس: {cls.DB_PATH}")
        print(f"   • دیتابیس وجود دارد: {'✅' if cls.DB_PATH.exists() else '❌'}")
        print(f"   • صادرات: {cls.EXPORT_DIR}")
        print(f"   • لاگ‌ها: {cls.LOG_DIR}")
        print(f"   • کش: {cls.CACHE_DIR}")
        print(f"   • تمپلیت‌ها: {cls.TEMPLATES_DIR}")
        
        # اگر دیتابیس وجود ندارد، ایجادش کن
        if not cls.DB_PATH.exists():
            print(f"\n⚠️ فایل دیتابیس وجود ندارد!")
            print(f"📝 ایجاد فایل دیتابیس جدید...")
            try:
                # ایجاد فایل دیتابیس خالی
                import sqlite3
                conn = sqlite3.connect(str(cls.DB_PATH))
                conn.close()
                print(f"✅ فایل دیتابیس ایجاد شد: {cls.DB_PATH}")
            except Exception as e:
                print(f"❌ خطا در ایجاد دیتابیس: {e}")
    
    @classmethod
    def validate_config(cls):
        """اعتبارسنجی تنظیمات"""
        warnings = []
        
        if not cls.DB_PATH.exists():
            warnings.append(f"فایل دیتابیس یافت نشد: {cls.DB_PATH}")
        
        if cls.DEBUG:
            warnings.append("حالت DEBUG فعال است - در تولید غیرفعال کنید")
        
        if cls.SECRET_KEY == 'dev-secret-key-change-in-production':
            warnings.append("کلید امنیتی پیش‌فرض استفاده می‌شود - در تولید تغییر دهید")
        
        return warnings
    
    @classmethod
    def get_database_connection(cls):
        """ایجاد اتصال به دیتابیس"""
        import sqlite3
        
        # مطمئن شویم پوشه وجود دارد
        cls.DB_PATH.parent.mkdir(exist_ok=True)
        
        conn = sqlite3.connect(str(cls.DB_PATH), timeout=cls.DB_TIMEOUT)
        conn.row_factory = sqlite3.Row
        return conn
    
    @classmethod
    def to_dict(cls):
        """تبدیل تنظیمات به دیکشنری"""
        return {
            'project_name': cls.SITE_TITLE,
            'version': cls.VERSION,
            'database_path': str(cls.DB_PATH),
            'database_exists': cls.DB_PATH.exists(),
            'server_url': cls.SERVER_URL,
            'current_date': cls.CURRENT_DATE,
            'current_time': cls.CURRENT_TIME,
            'debug_mode': cls.DEBUG
        }

# ============ کلاس Navigation ============
class Navigation:
    """کلاس مدیریت نویگیشن متمرکز"""
    
    MAIN_MENU = [
        {'name': 'خانه', 'url': '/', 'icon': 'fas fa-home'},
        {'name': 'لیست ارزها', 'url': '/coins', 'icon': 'fas fa-coins'},
        {'name': 'جداول', 'url': '/tables', 'icon': 'fas fa-table'},
        {'name': 'بلوک ارزها', 'url': '/blocks', 'icon': 'fas fa-cubes'},
        {'name': 'گزارشات', 'url': '/reports', 'icon': 'fas fa-chart-bar'},
        {'name': 'اندیکاتور', 'url': '/indicator', 'icon': 'fas fa-chart-bar'},
        {'name': 'بروز رسان', 'url': '/updated', 'icon': 'fas fa-history'}
    ]
    
    @classmethod
    def get_main_navigation(cls):
        """دریافت منوی اصلی"""
        return cls.MAIN_MENU
    
    @classmethod
    def get_navigation_with_active(cls, active_page=None):
        """دریافت منو با مشخص کردن صفحه فعال"""
        menu = cls.MAIN_MENU.copy()
        if active_page:
            for item in menu:
                item['active'] = (item['name'] == active_page)
        return menu

# مقداردهی اولیه
Config.init_directories()

if __name__ == '__main__':
    print("\n📋 تنظیمات پروژه:")
    print(json.dumps(Config.to_dict(), indent=2, ensure_ascii=False))
    
    warnings = Config.validate_config()
    if warnings:
        print("\n⚠️ هشدارها:")
        for warning in warnings:
            print(f"   • {warning}")
    
    print("\n📍 منوی نویگیشن:")
    for item in Navigation.get_main_navigation():
        print(f"   • {item['name']}: {item['url']}")