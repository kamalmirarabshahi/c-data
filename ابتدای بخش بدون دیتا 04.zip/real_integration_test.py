﻿"""
real_integration_test.py - تست یکپارچه واقعی تکه ۵
"""

import sys
import os
import sqlite3
import json
from datetime import datetime

print("🚀 تست یکپارچه واقعی تکه ۵")
print("=" * 60)

# مسیرها
db_path = r"C:\Users\Kamal\Desktop\py-prg\git\c-data\data\crypto_master.db"
scripts_dir = r"C:\Users\Kamal\Desktop\py-prg\git\c-data\scripts\cycle\cycle_05_decisions"

# افزودن مسیر
if scripts_dir not in sys.path:
    sys.path.insert(0, scripts_dir)

# 1. بارگذاری ماولها
print("\n1. 🔧 بارگذاری ماولها...")
try:
    from trading_config_manager import TradingConfigManager
    from signal_processor import SignalProcessor
    from portfolio_manager import PortfolioManager
    from decision_maker import DecisionMaker
    from report_generator import ReportGenerator
    print("✅ همه ماولها import شدند")
except Exception as e:
    print(f"❌ خطا در import: {e}")
    import traceback
    traceback.print_exc()
    sys.exit(1)

# 2. ایجاد نمونهها
print("\n2. 🏗️ ایجاد نمونهها...")
try:
    config = TradingConfigManager()
    print("✅ TradingConfigManager ایجاد شد")
    
    processor = SignalProcessor(config)
    print("✅ SignalProcessor ایجاد شد")
    
    portfolio = PortfolioManager(config)
    print("✅ PortfolioManager ایجاد شد")
    
    decision_maker = DecisionMaker(config, portfolio)
    print("✅ DecisionMaker ایجاد شد")
    
    reporter = ReportGenerator(output_dir="reports/real_test_" + datetime.now().strftime("%Y%m%d_%H%M%S"))
    print("✅ ReportGenerator ایجاد شد")
    
except Exception as e:
    print(f"❌ خطا در ایجاد نمونهها: {e}")
    import traceback
    traceback.print_exc()
    sys.exit(1)

# 3. بارگذاری داده واقعی - با اعتماد بالا (>= 50%)
print("\n3. 📡 بارگذاری سیگنالهای واقعی (اعتماد >= 50%)...")
try:
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    # سیگنالهای با اعتماد بالا (حداقل 50%)
    query = """
        SELECT 
            id,
            symbol,
            signal_type,
            confidence_score,
            created_at,
            analysis_data
        FROM trading_signals 
        WHERE confidence_score >= 50 
        AND symbol NOT LIKE '%USDC%'  # فیلتر استیبل کوین
        ORDER BY created_at DESC
        LIMIT 15
    """
    
    cursor.execute(query)
    columns = [desc[0] for desc in cursor.description]
    signals = []
    
    for row in cursor.fetchall():
        signal = dict(zip(columns, row))
        
        # تبدیل confidence_score به 0-1
        if 'confidence_score' in signal:
            signal['confidence'] = signal['confidence_score'] / 100.0
        
        # پارس analysis_data
        if signal.get('analysis_data'):
            try:
                analysis = json.loads(signal['analysis_data'])
                signal['analysis'] = analysis
            except:
                signal['analysis'] = {}
        
        signals.append(signal)
    
    conn.close()
    
    print(f"✅ {len(signals)} سیگنال با اعتماد بالا بارگذاری شد")
    
    if signals:
        print("   • نمونهها:")
        for i, sig in enumerate(signals[:3], 1):
            conf = sig.get('confidence', sig.get('confidence_score', 0) / 100.0)
            print(f"     {i}. {sig['symbol']}: {sig['signal_type']} (اعتماد: {conf:.2f}) - {sig['created_at'][:16]}")
    
except Exception as e:
    print(f"❌ خطا در بارگذاری داده: {e}")
    import traceback
    traceback.print_exc()
    signals = []

# 4. اگر سیگنال داریم پردازش کنیم
if signals:
    print("\n4. 🔄 پردازش سیگنالها...")
    try:
        filtered_signals = processor.filter_signals(signals)
        print(f"   • ورودی: {len(signals)} سیگنال")
        print(f"   • خروجی: {len(filtered_signals)} سیگنال فیلتر شده")
        print(f"   • نرخ فیلتر: {(len(filtered_signals)/len(signals)*100):.1f}%")
        
        if not filtered_signals:
            print("\n⚠️ هیچ سیگنالی بعد از فیلتر باقی نماند")
            
            # تحلیل دلایل
            min_conf = config.get('signal_processing.min_confidence', 0.5)
            print(f"   • حداقل اعتماد تنظیم شده: {min_conf}")
            
            print("\n   🔍 تحلیل سیگنالهای ورودی:")
            for sig in signals[:5]:
                conf = sig.get('confidence', sig.get('confidence_score', 0) / 100.0)
                status = "✅" if conf >= min_conf else "❌"
                print(f"     {status} {sig['symbol']}: اعتماد {conf:.2f}")
            
            print("\n✅ تست اولیه کامل شد (بدون پردازش بیشتر)")
            sys.exit(0)
        
        # نمایش سیگنالهای فیلتر شده
        print("\n   📋 سیگنالهای فیلتر شده:")
        for i, sig in enumerate(filtered_signals[:5], 1):
            conf = sig.get('confidence', sig.get('confidence_score', 0) / 100.0)
            print(f"     {i}. {sig['symbol']}: {sig['signal_type']} (اعتماد: {conf:.2f})")
        
    except Exception as e:
        print(f"❌ خطا در پردازش سیگنالها: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
    
    # 5. مدیریت سبد
    print("\n5. 💼 مدیریت سبد و تخصیص سرمایه...")
    try:
        allocations = portfolio.allocate_capital(filtered_signals)
        print(f"   • تخصیصهای ایجاد شده: {len(allocations)}")
        
        if allocations:
            print("\n   📊 نمونه تخصیصها:")
            for i, alloc in enumerate(allocations[:3], 1):
                if hasattr(alloc, 'symbol'):
                    print(f"     {i}. {alloc.symbol}:")
                    print(f"        سرمایه: ")
                    print(f"        لورج: {getattr(alloc, 'leverage', 1)}x")
                    print(f"        سایز پوزیشن: {getattr(alloc, 'position_size', 0):.4f}")
        
    except Exception as e:
        print(f"❌ خطا در مدیریت سبد: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
    
    # 6. تصمیمگیری
    print("\n6. 🤝 تصمیمگیری نهایی...")
    try:
        decisions = decision_maker.make_decisions_for_portfolio(allocations)
        print(f"   • تصمیمهای گرفته شده: {len(decisions)}")
        
        if decisions:
            # آمار تصمیمها
            approved = [d for d in decisions if hasattr(d, 'status') and d.status == "APPROVED"]
            rejected = [d for d in decisions if hasattr(d, 'status') and d.status == "REJECTED"]
            
            print(f"   • تأیید شده: {len(approved)}")
            print(f"   • رد شده: {len(rejected)}")
            
            if approved:
                print("\n   🎯 تصمیمهای تأیید شده:")
                for i, decision in enumerate(approved[:3], 1):
                    if hasattr(decision, 'symbol'):
                        action = "🟢 خرید" if "BUY" in decision.decision_type else "🔴 فروش" if "SELL" in decision.decision_type else "⚪ نگهداری"
                        print(f"     {i}. {action} {decision.symbol}")
                        print(f"        امتیاز: {getattr(decision, 'final_score', 0):.1f}")
                        print(f"        سرمایه: ")
                        print(f"        R/R: {getattr(decision, 'net_risk_reward', 0):.2f}")
            
            if rejected and len(rejected) > 0:
                print(f"\n   ❌ {len(rejected)} تصمیم رد شد")
                # تحلیل دلایل رد
                reasons = {}
                for decision in rejected[:5]:
                    if hasattr(decision, 'rejection_reason') and decision.rejection_reason:
                        reason = decision.rejection_reason.split(":")[0] if ":" in decision.rejection_reason else decision.rejection_reason
                        reasons[reason] = reasons.get(reason, 0) + 1
                
                if reasons:
                    print("   • دلایل اصلی رد:")
                    for reason, count in reasons.items():
                        print(f"     - {reason}: {count} مورد")
        
    except Exception as e:
        print(f"❌ خطا در تصمیمگیری: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
    
    # 7. گزارشگیری
    print("\n7. 📊 تولید گزارش...")
    try:
        report = reporter.generate_execution_report(
            decisions=decisions,
            signals=filtered_signals,
            config_summary=config.get_config_summary()
        )
        
        # نمایش خلاصه در کنسول
        reporter.generate_console_summary(report)
        
        # ذخیره گزارش
        report_file = reporter.save_report_to_json(report)
        if report_file:
            print(f"   • گزارش ذخیره شد: {report_file}")
        
        # ذخیره HTML
        html_file = reporter.generate_html_report(report)
        if html_file:
            print(f"   • گزارش HTML: {html_file}")
        
    except Exception as e:
        print(f"❌ خطا در گزارشگیری: {e}")
        import traceback
        traceback.print_exc()
    
    print("\n" + "=" * 60)
    print("🎉 تست یکپارچه با داده واقعی موفقیتآمیز بود!")
    print("=" * 60)
    
    # خلاصه نهایی
    if decisions:
        approved = [d for d in decisions if hasattr(d, 'status') and d.status == "APPROVED"]
        if approved:
            total_capital = sum(getattr(d, 'allocated_capital_usd', 0) for d in approved)
            total_profit = sum(getattr(d, 'expected_profit_usd', 0) for d in approved)
            print(f"\n📈 خلاصه نهایی:")
            print(f"   • تصمیمهای قابل اجرا: {len(approved)}")
            print(f"   • سرمایه کل تخصیص یافته: ")
            print(f"   • سود انتظاری کل: ")
            print(f"   • حالت اجرا: {'شبیهسازی 🔄' if config.is_simulation_mode() else 'واقعی 🚨'}")
    
else:
    print("\n⚠️ هیچ سیگنال با اعتماد بالا یافت نشد")

print("\n✅ تست کامل شد!")
