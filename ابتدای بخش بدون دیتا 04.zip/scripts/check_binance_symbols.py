"""
فایل: update_inactive_binance_coins.py
عملکرد: آپدیت ارزهای غیرفعال در Binance با عدد 5 در ستون is_active
"""

import os
import json
import time
import requests

def load_config():
    """بارگذاری تمام مسیرها از فایل کانفیگ"""
    try:
        # مسیر فیکس به فایل کانفیگ
        current_dir = os.path.dirname(os.path.abspath(__file__))
        config_file = r"C:\Users\Kamal\Desktop\py-prg\git\c-data\config\settings.json"
        config_file = os.path.abspath(config_file)
        
        print(f"📁 مسیر فایل کانفیگ: {config_file}")
        
        if not os.path.exists(config_file):
            return {"success": False, "error": f"فایل کانفیگ یافت نشد: {config_file}"}
        
        # خواندن فایل کانفیگ
        with open(config_file, 'r', encoding='utf-8') as f:
            config_data = json.load(f)
        
        # استخراج مسیر دیتابیس - فقط از کانفیگ
        database_section = config_data.get('database', {})
        database_path = database_section.get('path')
        
        if not database_path:
            return {"success": False, "error": "کلید 'database.path' در تنظیمات یافت نشد"}
        
        # استخراج مسیرهای دیگر از کانفیگ
        paths_section = config_data.get('paths', {})
        
        # استخراج تنظیمات API از کانفیگ
        api_section = config_data.get('api', {})
        binance_api = api_section.get('binance', {})
        
        config = {
            # مسیر دیتابیس - فقط از کانفیگ
            "database_path": database_path,
            
            # مسیرهای دیگر - فقط از کانفیگ
            "project_root": paths_section.get('project_root'),
            "data_dir": paths_section.get('data_dir'),
            "logs_dir": paths_section.get('logs_dir'),
            "config_dir": paths_section.get('config_dir'),
            "scripts_dir": paths_section.get('scripts_dir'),
            
            # تنظیمات Binance API - فقط از کانفیگ
            "binance_base_url": binance_api.get('base_url', 'https://api.binance.com/api/v3'),
            "api_timeout": binance_api.get('request_timeout', 10),
            "rate_limit": binance_api.get('rate_limit_per_minute', 1200),
            
            # سایر تنظیمات از کانفیگ
            "system_name": config_data.get('system', {}).get('name'),
            "environment": config_data.get('system', {}).get('environment'),
            "debug_mode": config_data.get('system', {}).get('debug_mode', False),
            
            # فایل کانفیگ
            "config_file_path": config_file
        }
        
        print(f"✅ تنظیمات بارگذاری شد")
        print(f"📁 مسیر دیتابیس: {database_path}")
        print(f"🔗 API Binance: {config['binance_base_url']}")
        
        return {"success": True, "config": config}
        
    except json.JSONDecodeError as e:
        return {"success": False, "error": f"خطا در خواندن فایل JSON: {str(e)}"}
    except Exception as e:
        return {"success": False, "error": f"خطا در بارگذاری تنظیمات: {str(e)}"}

def check_symbol_on_binance(base_url, symbol):
    """چک کردن وجود symbol در Binance"""
    try:
        url = f"{base_url}/exchangeInfo"
        params = {'symbol': symbol.upper()}
        
        response = requests.get(url, params=params, timeout=5)
        
        if response.status_code == 200:
            data = response.json()
            return {"success": True, "exists": True}
        elif response.status_code == 400:
            error_data = response.json()
            if error_data.get('code') == -1121:  # Invalid symbol
                return {"success": True, "exists": False}
        
        return {"success": False, "exists": False}
        
    except requests.exceptions.RequestException as e:
        return {"success": False, "exists": False, "error": str(e)}
    except Exception as e:
        return {"success": False, "exists": False, "error": str(e)}

def get_all_symbols_from_db(db_path):
    """دریافت تمام symbolها از دیتابیس"""
    try:
        import sqlite3
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT id, symbol, is_active FROM crypto_coins ORDER BY id")
        symbols = cursor.fetchall()
        conn.close()
        return {"success": True, "symbols": symbols}
    except Exception as e:
        return {"success": False, "error": f"خطا در اتصال به دیتابیس: {str(e)}"}

def update_is_active_in_db(db_path, coin_id, value):
    """آپدیت ستون is_active با عدد 5 - فقط این کار را انجام بده"""
    try:
        import sqlite3
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        cursor.execute("UPDATE crypto_coins SET is_active = ? WHERE id = ?", (value, coin_id))
        conn.commit()
        conn.close()
        return True
    except Exception as e:
        print(f"❌ خطا در آپدیت coin_id {coin_id}: {e}")
        return False

def main():
    print("=" * 70)
    print("🔄 آپدیت ارزهای غیرفعال Binance")
    print("تنها کار: عدد 5 در ستون is_active برای ارزهای غیرفعال")
    print("=" * 70)
    
    # 1. بارگذاری تنظیمات از فایل کانفیگ
    print("\n1️⃣ بارگذاری تنظیمات از فایل کانفیگ...")
    config_result = load_config()
    if not config_result["success"]:
        print(f"❌ {config_result['error']}")
        return
    
    config = config_result["config"]
    print(f"   ✅ مسیرها از کانفیگ بارگذاری شد")
    
    # 2. دریافت تمام symbolها از دیتابیس
    print("\n2️⃣ دریافت symbolها از دیتابیس...")
    symbols_result = get_all_symbols_from_db(config["database_path"])
    if not symbols_result["success"]:
        print(f"❌ {symbols_result['error']}")
        return
    
    symbols = symbols_result["symbols"]
    print(f"   📊 تعداد symbolها: {len(symbols)}")
    
    # 3. شروع چک کردن در Binance
    print("\n3️⃣ شروع چک symbolها در Binance...")
    print("-" * 50)
    
    inactive_count = 0
    active_count = 0
    error_count = 0
    
    for i, (coin_id, symbol, current_is_active) in enumerate(symbols, 1):
        try:
            print(f"[{i}/{len(symbols)}] {symbol:15s}", end=" -> ")
            
            # چک کردن در Binance
            result = check_symbol_on_binance(config["binance_base_url"], symbol)
            
            if not result["success"]:
                # خطا در چک کردن
                print(f"⚠️ خطا در چک")
                error_count += 1
                continue
            
            if result["exists"]:
                # symbol در Binance فعال است
                print("✅ فعال")
                active_count += 1
                
                # اگر قبلاً 5 بود و الان فعال است، به 1 برگردان
                if current_is_active == 5:
                    if update_is_active_in_db(config["database_path"], coin_id, 1):
                        print(f"   ↪️ تغییر از 5 به 1 (فعال شد)")
            else:
                # symbol در Binance غیرفعال است
                print("❌ غیرفعال")
                
                # فقط عدد 5 را در is_active ذخیره کن
                if update_is_active_in_db(config["database_path"], coin_id, 5):
                    inactive_count += 1
                    print(f"   💾 ذخیره شد: is_active = 5")
            
            # رعایت rate limit
            if i % 50 == 0 and i < len(symbols):
                print(f"   ⏳ استراحت برای رعایت rate limit...")
                time.sleep(2)
            else:
                time.sleep(0.1)
                
        except KeyboardInterrupt:
            print("\n\n⚠️ عملیات توسط کاربر متوقف شد")
            break
        except Exception as e:
            print(f"❌ خطای غیرمنتظره: {e}")
            error_count += 1
            continue
    
    print("-" * 50)
    
    # 4. نتیجه نهایی
    print("\n📋 نتیجه نهایی:")
    print("=" * 70)
    print(f"   📊 کل symbolها: {len(symbols)}")
    print(f"   ✅ فعال در Binance: {active_count}")
    print(f"   ❌ غیرفعال در Binance (is_active=5): {inactive_count}")
    print(f"   ⚠️ با خطا در چک: {error_count}")
    print()
    print(f"   💾 در دیتابیس ذخیره شد:")
    print(f"      - {inactive_count} ارز با is_active = 5")
    print()
    print(f"   🔍 برای مشاهده ارزهای غیرفعال:")
    print(f'      SELECT id, symbol FROM crypto_coins WHERE is_active = 5;')
    print("=" * 70)

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n⏹️ عملیات متوقف شد")
    except Exception as e:
        print(f"\n❌ خطای کلی: {e}")