#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
collector_final.py - جمع‌آوری داده از Binance
جمع‌آوری 100 ارز با بیشترین حجم در 24 ساعت (بدون USDT)

✅ فقط از config_manager استفاده می‌کند
❌ هیچ مسیر سخت‌کد شده‌ای ندارد
❌ هیچ دیتابیسی نمی‌سازد
❌ هیچ جدولی نمی‌سازد
❌ اگر دیتابیس پیدا نشد فقط پیام خطا می‌دهد
"""

import requests
import sqlite3
import time
import sys
import os
from datetime import datetime
import logging
from pathlib import Path
from typing import List, Dict, Any, Optional

# اضافه کردن مسیر برای import config_manager
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

# اول logger را تعریف کن
logging.basicConfig(
    level=logging.INFO,
    format='[%(asctime)s] %(message)s',
    datefmt='%H:%M:%S'
)
logger = logging.getLogger(__name__)

# ایمپورت config_manager
try:
    from config_manager import get, get_database_config, get_api_config, reload
    CONFIG_LOADED = True
except ImportError as e:
    logger.error(f"❌ config_manager.py یافت نشد: {e}")
    logger.error("🚨 config_manager باید در دسترس باشد!")
    CONFIG_LOADED = False
    sys.exit(1)


class EnhancedCollector:
    """جمع‌آوری داده از Binance API"""
    
    def __init__(self, coin_limit: int = 100):
        """مقداردهی اولیه کالکتور"""
        logger.info("🔧 راه‌اندازی کالکتور...")
        
        # محدودیت تعداد ارزها
        self.coin_limit = min(coin_limit, 100)
        
        # دریافت مسیر دیتابیس فقط از config_manager
        self.db_path = self._get_database_path_from_config_only()
        
        # بررسی وجود دیتابیس
        if not self._verify_database_exists():
            self._handle_database_not_found()
            sys.exit(1)
        
        # بارگذاری سایر تنظیمات
        self.load_configurations()
        
        # لیست stablecoins برای فیلتر
        self.stablecoin_symbols = [
            'USDT', 'USDC', 'BUSD', 'DAI', 'TUSD', 'USDP', 
            'USDN', 'GUSD', 'FRAX', 'USDD', 'USDJ'
        ]
        
        logger.info(f"✅ کالکتور راه‌اندازی شد: {self.coin_limit} ارز بر اساس حجم")
    
    def _get_database_path_from_config_only(self) -> str:
        """دریافت مسیر دیتابیس فقط و فقط از config_manager"""
        if not CONFIG_LOADED:
            logger.error("❌ config_manager در دسترس نیست!")
            sys.exit(1)
        
        try:
            # بارگذاری مجدد تنظیمات
            reload()
            
            # دریافت مسیر دیتابیس از config
            db_path = get('database.path')
            
            if not db_path:
                error_msg = """
❌ مسیر دیتابیس در config/settings.json تعریف نشده!

لطفا در فایل config/settings.json بخش زیر را اضافه کنید:
{
    "database": {
        "path": "C:\\\\Users\\\\Kamal\\\\Desktop\\\\py-prg\\\\git\\\\c-data\\\\data\\\\crypto_master.db",
        "timeout": 30,
        "journal_mode": "WAL",
        "synchronous": "NORMAL",
        "cache_size": -2000
    }
}
"""
                logger.error(error_msg)
                raise ValueError("مسیر دیتابیس در تنظیمات تعریف نشده است.")
            
            # تبدیل به Path و بررسی
            db_path_obj = Path(db_path)
            
            # اگر مسیر نسبی است، آن را به مسیر مطلق تبدیل کن
            if not db_path_obj.is_absolute():
                base_dir = Path.cwd()
                absolute_path = (base_dir / db_path_obj).resolve()
                logger.info(f"📁 مسیر نسبی تبدیل شد: {db_path} → {absolute_path}")
                return str(absolute_path)
            
            return str(db_path_obj.resolve())
            
        except Exception as e:
            logger.error(f"❌ خطا در دریافت مسیر دیتابیس از config: {e}")
            raise
    
    def _verify_database_exists(self) -> bool:
        """بررسی وجود دیتابیس"""
        try:
            db_file = Path(self.db_path)
            
            if not db_file.exists():
                logger.error(f"❌ فایل دیتابیس یافت نشد: {self.db_path}")
                return False
            
            if not db_file.is_file():
                logger.error(f"❌ مسیر دیتابیس یک فایل نیست: {self.db_path}")
                return False
            
            # بررسی سایز
            size = db_file.stat().st_size
            if size == 0:
                logger.warning(f"⚠️  دیتابیس خالی است: {self.db_path}")
            
            logger.info(f"✅ دیتابیس یافت شد: {self.db_path}")
            logger.info(f"📏 حجم دیتابیس: {size:,} بایت")
            
            return True
            
        except Exception as e:
            logger.error(f"❌ خطا در بررسی دیتابیس: {e}")
            return False
    
    def _handle_database_not_found(self):
        """مدیریت وضعیت عدم یافتن دیتابیس"""
        error_msg = f"""
🚨 **دیتابیس یافت نشد!**

📁 مسیر جستجو شده: {self.db_path}

🔧 **راه‌حل‌های ممکن:**

1. **اجرای Collector اصلی:**
   - ابتدا Collector اصلی را اجرا کنید تا دیتابیس ایجاد شود
   - معمولاً فایلی به نام main.py یا collector.py

2. **بررسی config/settings.json:**
   - مسیر دیتابیس را در فایل config/settings.json بررسی کنید
   - مطمئن شوید مسیر صحیح است

3. **بررسی وجود فایل دیتابیس:**
   - بررسی کنید دیتابیس در مسیر دیگری وجود ندارد
   - ممکن است توسط اسکریپت دیگری ساخته شده باشد

4. **ایجاد دیتابیس به صورت دستی:**
   - اگر دیتابیس وجود ندارد، باید Collector را اجرا کنید
   - این اسکریپت خودش هیچ دیتابیسی نمی‌سازد

📌 **نکته:** این اسکریپت فقط برای جمع‌آوری داده است
   و برای ایجاد دیتابیس باید Collector اصلی اجرا شود.
"""
        logger.error(error_msg)
    
    def _verify_database_tables(self) -> bool:
        """بررسی وجود جداول اصلی در دیتابیس"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # بررسی جداول اصلی مورد نیاز
            required_tables = ['crypto_coins', 'crypto_klines']
            missing_tables = []
            
            for table in required_tables:
                cursor.execute(
                    "SELECT name FROM sqlite_master WHERE type='table' AND name=?",
                    (table,)
                )
                if not cursor.fetchone():
                    missing_tables.append(table)
            
            conn.close()
            
            if missing_tables:
                logger.error(f"❌ جداول ضروری یافت نشدند: {missing_tables}")
                logger.error("🚨 ابتدا باید Collector اصلی را اجرا کنید تا جداول ایجاد شوند.")
                return False
            
            logger.info("✅ جداول ضروری دیتابیس وجود دارند")
            return True
            
        except Exception as e:
            logger.error(f"❌ خطا در بررسی جداول دیتابیس: {e}")
            return False
    
    def load_configurations(self):
        """بارگذاری همه تنظیمات از config_manager"""
        try:
            # تنظیمات جمع‌آوری
            collection_config = get('collection', {})
            self.timeframe = collection_config.get('timeframe', '5m')
            self.candles_per_request = collection_config.get('candles_per_request', 100)
            self.update_interval = collection_config.get('update_interval_seconds', 300)
            
            # تنظیمات API
            api_config = get_api_config('binance')
            self.binance_base_url = api_config.get('base_url', 'https://api.binance.com/api/v3')
            self.request_timeout = api_config.get('request_timeout', 10)
            
            # تاخیر بین درخواست‌ها
            self.request_delay = collection_config.get('request_delay', 0.5)
            
            logger.info(f"📁 مسیر دیتابیس: {self.db_path}")
            logger.info(f"⚙️ تنظیمات: timeframe={self.timeframe}")
            
        except Exception as e:
            logger.error(f"❌ خطا در بارگذاری تنظیمات: {e}")
            raise
    
    def get_connection(self) -> Optional[sqlite3.Connection]:
        """ایجاد اتصال به دیتابیس"""
        try:
            # بررسی مجدد وجود دیتابیس
            if not Path(self.db_path).exists():
                logger.error(f"❌ فایل دیتابیس حذف شده: {self.db_path}")
                return None
            
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            
            # بررسی جداول
            cursor = conn.cursor()
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
            tables = cursor.fetchall()
            
            if not tables:
                logger.error("❌ دیتابیس خالی است - هیچ جدولی وجود ندارد")
                conn.close()
                return None
            
            return conn
            
        except Exception as e:
            logger.error(f"❌ خطا در اتصال به دیتابیس: {e}")
            return None
    
    def get_top_volume_coins_from_binance(self) -> List[Dict]:
        """دریافت ارزها با بیشترین حجم از Binance API"""
        logger.info(f"📊 دریافت {self.coin_limit} ارز با بیشترین حجم از Binance...")
        
        try:
            url = f"{self.binance_base_url}/ticker/24hr"
            response = requests.get(url, timeout=self.request_timeout)
            
            if response.status_code != 200:
                logger.error(f"❌ خطای Binance API: {response.status_code}")
                return []
            
            tickers = response.json()
            valid_tickers = []
            
            for ticker in tickers:
                symbol = ticker['symbol']
                
                # فقط جفت‌های USDT
                if not symbol.endswith('USDT'):
                    continue
                
                # حذف stablecoin pairs
                base_symbol = symbol.replace('USDT', '')
                if base_symbol in self.stablecoin_symbols:
                    continue
                
                # اطمینان از معاملات فعال
                if float(ticker.get('volume', 0)) == 0:
                    continue
                
                valid_tickers.append({
                    'symbol': symbol,
                    'base_asset': base_symbol,
                    'volume': float(ticker.get('quoteVolume', 0)),
                    'price_change_percent': float(ticker.get('priceChangePercent', 0)),
                    'last_price': float(ticker.get('lastPrice', 0))
                })
            
            # مرتب‌سازی بر اساس حجم
            valid_tickers.sort(key=lambda x: x['volume'], reverse=True)
            top_tickers = valid_tickers[:self.coin_limit]
            
            logger.info(f"✅ {len(top_tickers)} ارز با بیشترین حجم دریافت شد")
            return top_tickers
            
        except Exception as e:
            logger.error(f"❌ خطا در دریافت ارزها از Binance: {e}")
            return []
    
    def fetch_historical_klines(self, symbol: str, limit: int = 100) -> Optional[List]:
        """دریافت کندل‌های تاریخی از Binance"""
        url = f"{self.binance_base_url}/klines"
        params = {
            'symbol': symbol,
            'interval': self.timeframe,
            'limit': limit
        }
        
        try:
            time.sleep(self.request_delay)
            response = requests.get(url, params=params, timeout=self.request_timeout)
            
            if response.status_code == 200:
                return response.json()
            else:
                logger.error(f"❌ خطای API برای {symbol}: {response.status_code}")
                return None
                
        except Exception as e:
            logger.error(f"❌ خطای شبکه برای {symbol}: {e}")
            return None
    
    def collect_all_coins(self) -> bool:
        """جمع‌آوری داده برای همه ارزهای برتر"""
        logger.info("=" * 60)
        logger.info("🚀 شروع جمع‌آوری داده‌ها از Binance")
        logger.info("=" * 60)
        
        # بررسی جداول دیتابیس قبل از شروع
        if not self._verify_database_tables():
            return False
        
        top_coins = self.get_top_volume_coins_from_binance()
        
        if not top_coins:
            logger.error("❌ هیچ ارزی دریافت نشد!")
            return False
        
        total_saved = 0
        successful_coins = 0
        
        for i, ticker in enumerate(top_coins, 1):
            symbol = ticker['symbol']
            
            logger.info(f"[{i}/{len(top_coins)}] 🔄 پردازش {symbol}...")
            
            # 1. پیدا کردن coin_id از دیتابیس
            conn = self.get_connection()
            if not conn:
                continue
            
            try:
                cursor = conn.cursor()
                cursor.execute("SELECT id FROM crypto_coins WHERE symbol = ?", (symbol,))
                result = cursor.fetchone()
                
                if not result:
                    logger.warning(f"⚠️  ارز {symbol} در دیتابیس وجود ندارد - نادیده گرفته شد")
                    continue
                
                coin_id = result[0]
                
                # 2. دریافت کندل‌ها
                klines = self.fetch_historical_klines(symbol, limit=100)
                
                if not klines:
                    logger.warning(f"⚠️  کندلی دریافت نشد: {symbol}")
                    continue
                
                # 3. ذخیره کندل‌ها
                saved = self._save_klines_to_database(coin_id, symbol, klines)
                total_saved += saved
                
                if saved > 0:
                    successful_coins += 1
                    
            except Exception as e:
                logger.error(f"❌ خطا در پردازش {symbol}: {e}")
            finally:
                conn.close()
        
        # گزارش نهایی
        logger.info("\n" + "=" * 60)
        logger.info(f"📊 گزارش: {successful_coins} ارز موفق، {total_saved} کندل جدید")
        logger.info("=" * 60)
        
        return successful_coins > 0
    
    def _save_klines_to_database(self, coin_id: int, symbol: str, klines: List) -> int:
        """ذخیره کندل‌ها در دیتابیس"""
        if not klines:
            return 0
        
        conn = self.get_connection()
        if not conn:
            return 0
        
        cursor = conn.cursor()
        saved_count = 0
        
        try:
            for kline in klines:
                open_time = datetime.fromtimestamp(kline[0] / 1000)
                close_time = datetime.fromtimestamp(kline[6] / 1000)
                
                cursor.execute("""
                    INSERT OR IGNORE INTO crypto_klines 
                    (coin_id, timeframe, open_time, close_time,
                     open_price, high_price, low_price, close_price,
                     volume, quote_volume, number_of_trades,
                     taker_buy_volume, taker_sell_volume, taker_buy_quote_volume,
                     source_exchange)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    coin_id,
                    self.timeframe,
                    open_time.isoformat(),
                    close_time.isoformat(),
                    float(kline[1]),  # open
                    float(kline[2]),  # high
                    float(kline[3]),  # low
                    float(kline[4]),  # close
                    float(kline[5]),  # volume
                    float(kline[7]),  # quote volume
                    int(kline[8]),    # trades
                    float(kline[9]),  # taker buy volume
                    float(kline[10]), # taker sell volume
                    float(kline[11]), # taker buy quote volume
                    'binance'
                ))
                
                if cursor.rowcount > 0:
                    saved_count += 1
            
            conn.commit()
            if saved_count > 0:
                logger.info(f"✅ {symbol}: {saved_count} کندل جدید ذخیره شد")
            
            return saved_count
            
        except Exception as e:
            logger.error(f"❌ خطا در ذخیره کندل‌های {symbol}: {e}")
            conn.rollback()
            return saved_count
        finally:
            conn.close()


# تابع اصلی برای اجرای مستقل
def main():
    print("=" * 60)
    print("🚀 کالکتور Binance - اجرای مستقل")
    print("=" * 60)
    
    try:
        collector = EnhancedCollector(coin_limit=50)
        success = collector.collect_all_coins()
        
        if success:
            print("\n✅ کالکتور با موفقیت اجرا شد")
        else:
            print("\n⚠️  کالکتور با مشکلاتی مواجه شد")
            
    except ValueError as e:
        print(f"\n❌ خطای پیکربندی: {e}")
    except FileNotFoundError as e:
        print(f"\n❌ خطای دیتابیس: {e}")
    except Exception as e:
        print(f"\n❌ خطای غیرمنتظره: {e}")


if __name__ == "__main__":
    main()