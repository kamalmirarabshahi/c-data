#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
📋 پردازش ترتیبی بلوک‌ها - هر بلوک از تکه ۲ تا ۴

🔁 الگوریتم:
برای هر بلوک (1 تا N):
    ├── تکه ۲: جمع‌آوری کندل‌ها
    ├── تکه ۳: تحلیل اندیکاتورها  
    ├── تکه ۴: تحلیل پیشرفته
    └── ذخیره گزارش بلوک
پس از اتمام همه بلوک‌ها:
    └── تولید گزارش کلی
"""

import os
import sys
import json
import time
import logging
import sqlite3
import subprocess
from datetime import datetime
from typing import Dict, List, Any, Optional

# اضافه کردن مسیر پروژه
PROJECT_ROOT = r"C:\Users\Kamal\Desktop\py-prg\git\c-data"
sys.path.insert(0, PROJECT_ROOT)

# تنظیم لاگ‌گیری
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(os.path.join(PROJECT_ROOT, "logs", "sequential_processing.log")),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)


class SequentialProcessor:
    """پردازش ترتیبی بلوک‌ها از تکه ۲ تا ۴"""
    
    def __init__(self):
        self.project_root = PROJECT_ROOT
        self.state_file = os.path.join(PROJECT_ROOT, "state", "cycle_state.json")
        self.results_dir = os.path.join(PROJECT_ROOT, "reports", "sequential")
        
        # ایجاد پوشه‌های لازم
        os.makedirs(self.results_dir, exist_ok=True)
        
        # گزارش کلی
        self.master_report = {
            "start_time": datetime.now().isoformat(),
            "total_blocks": 0,
            "processed_blocks": 0,
            "successful_blocks": 0,
            "failed_blocks": 0,
            "block_reports": [],
            "summary": {}
        }
        
        logger.info("📋 SequentialProcessor راه‌اندازی شد")
    
    def load_blocks(self) -> List[Dict[str, Any]]:
        """بارگذاری بلوک‌ها از فایل وضعیت"""
        try:
            with open(self.state_file, 'r', encoding='utf-8') as f:
                state = json.load(f)
            
            blocks = state.get("blocks", [])
            logger.info(f"📦 {len(blocks)} بلوک بارگذاری شد")
            
            return blocks
            
        except Exception as e:
            logger.error(f"❌ خطا در بارگذاری بلوک‌ها: {e}")
            return []
    
    def run_cycle_02_for_block(self, block_id: int) -> Dict[str, Any]:
        """اجرای تکه ۲ برای یک بلوک خاص"""
        try:
            logger.info(f"  🔄 تکه ۲: جمع‌آوری کندل‌ها برای بلوک {block_id}")
            
            cmd = [
                sys.executable,
                os.path.join(PROJECT_ROOT, "scripts", "cycle", "cycle_02_process_block.py"),
                "--block", str(block_id)
            ]
            
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                encoding='utf-8',
                cwd=PROJECT_ROOT,
                timeout=300  # ۵ دقیقه تایم‌اوت
            )
            
            if result.returncode == 0:
                logger.info(f"    ✅ تکه ۲ برای بلوک {block_id} تکمیل شد")
                return {
                    "success": True,
                    "output": result.stdout[:500]  # فقط ۵۰۰ کاراکتر اول
                }
            else:
                logger.error(f"    ❌ تکه ۲ برای بلوک {block_id} ناموفق")
                return {
                    "success": False,
                    "error": result.stderr,
                    "returncode": result.returncode
                }
                
        except subprocess.TimeoutExpired:
            logger.error(f"    ⏰ تایم‌اوت تکه ۲ برای بلوک {block_id}")
            return {"success": False, "error": "Timeout expired"}
        except Exception as e:
            logger.error(f"    ❌ خطا در تکه ۲ برای بلوک {block_id}: {e}")
            return {"success": False, "error": str(e)}
    
    def run_cycle_03_for_block(self, block_id: int) -> Dict[str, Any]:
        """اجرای تکه ۳ برای یک بلوک خاص"""
        try:
            logger.info(f"  🔄 تکه ۳: تحلیل کندل‌ها برای بلوک {block_id}")
            
            cmd = [
                sys.executable,
                os.path.join(PROJECT_ROOT, "scripts", "cycle", "cycle_03_analyze_block", "main_cycle_03.py"),
                "--block", str(block_id)
            ]
            
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                encoding='utf-8',
                cwd=PROJECT_ROOT,
                timeout=300  # ۵ دقیقه تایم‌اوت
            )
            
            if result.returncode == 0:
                logger.info(f"    ✅ تکه ۳ برای بلوک {block_id} تکمیل شد")
                return {"success": True, "output": result.stdout[:500]}
            else:
                logger.error(f"    ❌ تکه ۳ برای بلوک {block_id} ناموفق")
                return {
                    "success": False,
                    "error": result.stderr,
                    "returncode": result.returncode
                }
                
        except subprocess.TimeoutExpired:
            logger.error(f"    ⏰ تایم‌اوت تکه ۳ برای بلوک {block_id}")
            return {"success": False, "error": "Timeout expired"}
        except Exception as e:
            logger.error(f"    ❌ خطا در تکه ۳ برای بلوک {block_id}: {e}")
            return {"success": False, "error": str(e)}
    
    def run_cycle_04_for_block(self, block_id: int) -> Dict[str, Any]:
        """اجرای تکه ۴ برای یک بلوک خاص"""
        try:
            logger.info(f"  🔄 تکه ۴: تحلیل پیشرفته برای بلوک {block_id}")
            
            cmd = [
                sys.executable,
                os.path.join(PROJECT_ROOT, "scripts", "cycle", "cycle_04_simple.py"),
                "--block", str(block_id)
            ]
            
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                encoding='utf-8',
                cwd=PROJECT_ROOT,
                timeout=300  # ۵ دقیقه تایم‌اوت
            )
            
            if result.returncode == 0:
                logger.info(f"    ✅ تکه ۴ برای بلوک {block_id} تکمیل شد")
                return {"success": True, "output": result.stdout[:500]}
            else:
                logger.error(f"    ❌ تکه ۴ برای بلوک {block_id} ناموفق")
                return {
                    "success": False,
                    "error": result.stderr,
                    "returncode": result.returncode
                }
                
        except subprocess.TimeoutExpired:
            logger.error(f"    ⏰ تایم‌اوت تکه ۴ برای بلوک {block_id}")
            return {"success": False, "error": "Timeout expired"}
        except Exception as e:
            logger.error(f"    ❌ خطا در تکه ۴ برای بلوک {block_id}: {e}")
            return {"success": False, "error": str(e)}
    
    def save_block_report(self, block_id: int, block_data: Dict[str, Any], 
                         results: Dict[str, Any]) -> str:
        """ذخیره گزارش بلوک در فایل JSON"""
        try:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"block_{block_id:03d}_{timestamp}.json"
            filepath = os.path.join(self.results_dir, filename)
            
            report = {
                "block_id": block_id,
                "symbols": block_data.get("symbols", []),
                "coin_count": len(block_data.get("coins", [])),
                "processed_at": datetime.now().isoformat(),
                "cycle_02_result": results.get("cycle_02"),
                "cycle_03_result": results.get("cycle_03"),
                "cycle_04_result": results.get("cycle_04"),
                "overall_success": all([
                    results.get("cycle_02", {}).get("success", False),
                    results.get("cycle_03", {}).get("success", False),
                    results.get("cycle_04", {}).get("success", False)
                ])
            }
            
            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump(report, f, indent=2, ensure_ascii=False)
            
            logger.info(f"    💾 گزارش بلوک {block_id} ذخیره شد: {filename}")
            return filepath
            
        except Exception as e:
            logger.error(f"    ❌ خطا در ذخیره گزارش بلوک {block_id}: {e}")
            return ""
    
    def check_block_prerequisites(self, block_id: int) -> bool:
        """بررسی پیش‌نیازهای بلوک"""
        try:
            # بررسی وجود کندل‌های کافی در دیتابیس
            db_path = os.path.join(PROJECT_ROOT, "data", "crypto_master.db")
            conn = sqlite3.connect(db_path)
            cursor = conn.cursor()
            
            # پیدا کردن اولین ارز بلوک
            with open(self.state_file, 'r', encoding='utf-8') as f:
                state = json.load(f)
            
            target_block = None
            for block in state.get("blocks", []):
                if block.get("block_id") == block_id:
                    target_block = block
                    break
            
            if not target_block or not target_block.get("coins"):
                logger.warning(f"    ⚠️ بلوک {block_id} یا ارزی ندارد")
                return False
            
            first_coin_id = target_block["coins"][0].get("id")
            
            # بررسی تعداد کندل‌ها
            cursor.execute("""
                SELECT COUNT(*) FROM crypto_klines 
                WHERE coin_id = ? AND close_price IS NOT NULL
            """, (first_coin_id,))
            
            candle_count = cursor.fetchone()[0]
            conn.close()
            
            if candle_count < 10:
                logger.warning(f"    ⚠️ بلوک {block_id}: فقط {candle_count} کندل دارد (نیاز: 10+)")
                return False
            
            logger.info(f"    ✓ بلوک {block_id}: {candle_count} کندل موجود است")
            return True
            
        except Exception as e:
            logger.error(f"    ❌ خطا در بررسی پیش‌نیازهای بلوک {block_id}: {e}")
            return False
    
    def process_single_block(self, block_data: Dict[str, Any]) -> Dict[str, Any]:
        """پردازش کامل یک بلوک (تکه ۲ تا ۴)"""
        block_id = block_data.get("block_id")
        symbols = block_data.get("symbols", [])
        
        logger.info(f"\n{'='*60}")
        logger.info(f"📦 شروع پردازش بلوک {block_id}")
        logger.info(f"   ارزها: {len(symbols)} عدد")
        logger.info(f"   نمونه: {', '.join(symbols[:3])}{'...' if len(symbols) > 3 else ''}")
        logger.info(f"{'='*60}")
        
        block_start_time = datetime.now()
        
        # بررسی پیش‌نیازها
        if not self.check_block_prerequisites(block_id):
            logger.warning(f"⚠️ رد کردن بلوک {block_id} به دلیل عدم پیش‌نیاز")
            return {
                "block_id": block_id,
                "status": "skipped",
                "reason": "prerequisites_not_met"
            }
        
        # اجرای تکه‌ها
        results = {}
        
        # 1. تکه ۲
        results["cycle_02"] = self.run_cycle_02_for_block(block_id)
        if not results["cycle_02"].get("success", False):
            logger.error(f"❌ توقف پردازش بلوک {block_id} به دلیل شکست تکه ۲")
            return {
                "block_id": block_id,
                "status": "failed",
                "failed_at": "cycle_02",
                "results": results
            }
        
        time.sleep(2)  # وقفه ۲ ثانیه‌ای
        
        # 2. تکه ۳
        results["cycle_03"] = self.run_cycle_03_for_block(block_id)
        if not results["cycle_03"].get("success", False):
            logger.error(f"❌ توقف پردازش بلوک {block_id} به دلیل شکست تکه ۳")
            return {
                "block_id": block_id,
                "status": "failed",
                "failed_at": "cycle_03",
                "results": results
            }
        
        time.sleep(2)  # وقفه ۲ ثانیه‌ای
        
        # 3. تکه ۴
        results["cycle_04"] = self.run_cycle_04_for_block(block_id)
        
        # محاسبه زمان اجرا
        execution_time = (datetime.now() - block_start_time).total_seconds()
        
        # تعیین وضعیت نهایی
        all_success = all(r.get("success", False) for r in results.values())
        status = "completed" if all_success else "partial"
        
        # ذخیره گزارش بلوک
        report_path = self.save_block_report(block_id, block_data, results)
        
        block_result = {
            "block_id": block_id,
            "status": status,
            "execution_time_seconds": execution_time,
            "results": results,
            "report_path": report_path,
            "processed_at": datetime.now().isoformat()
        }
        
        logger.info(f"\n📊 نتیجه بلوک {block_id}:")
        logger.info(f"   وضعیت: {status}")
        logger.info(f"   زمان اجرا: {execution_time:.2f} ثانیه")
        logger.info(f"   تکه ۲: {'✅' if results.get('cycle_02', {}).get('success') else '❌'}")
        logger.info(f"   تکه ۳: {'✅' if results.get('cycle_03', {}).get('success') else '❌'}")
        logger.info(f"   تکه ۴: {'✅' if results.get('cycle_04', {}).get('success') else '❌'}")
        
        return block_result
    
    def process_all_blocks(self, start_from: int = 1, max_blocks: Optional[int] = None) -> Dict[str, Any]:
        """پردازش ترتیبی همه بلوک‌ها"""
        logger.info("\n" + "=" * 60)
        logger.info("🚀 شروع پردازش ترتیبی همه بلوک‌ها")
        logger.info("=" * 60)
        
        # بارگذاری بلوک‌ها
        all_blocks = self.load_blocks()
        
        if not all_blocks:
            logger.error("❌ هیچ بلوکی برای پردازش یافت نشد")
            return {"success": False, "error": "No blocks found"}
        
        # فیلتر بلوک‌ها بر اساس شروع
        blocks_to_process = [b for b in all_blocks if b.get("block_id", 0) >= start_from]
        
        # محدود کردن تعداد بلوک‌ها
        if max_blocks and max_blocks < len(blocks_to_process):
            blocks_to_process = blocks_to_process[:max_blocks]
            logger.info(f"🔧 محدودیت: پردازش {max_blocks} بلوک اول")
        
        logger.info(f"📊 تعداد بلوک‌های قابل پردازش: {len(blocks_to_process)}")
        
        # پردازش هر بلوک
        block_results = []
        successful = 0
        failed = 0
        
        for i, block in enumerate(blocks_to_process, 1):
            block_id = block.get("block_id")
            
            logger.info(f"\n📋 بلوک {i}/{len(blocks_to_process)} (ID: {block_id})")
            
            try:
                # پردازش بلوک
                result = self.process_single_block(block)
                block_results.append(result)
                
                if result["status"] == "completed":
                    successful += 1
                else:
                    failed += 1
                
                # وقفه بین بلوک‌ها
                if i < len(blocks_to_process):
                    logger.info(f"⏳ وقفه ۱۰ ثانیه‌ای قبل از بلوک بعدی...")
                    time.sleep(10)
                    
            except Exception as e:
                logger.error(f"❌ خطای غیرمنتظره در بلوک {block_id}: {e}")
                import traceback
                logger.error(traceback.format_exc())
                
                block_results.append({
                    "block_id": block_id,
                    "status": "error",
                    "error": str(e)
                })
                failed += 1
        
        # تولید گزارش کلی
        master_report = self.generate_master_report(block_results)
        
        # ذخیره گزارش کلی
        self.save_master_report(master_report)
        
        # نمایش خلاصه
        self.print_summary(master_report)
        
        return master_report
    
    def generate_master_report(self, block_results: List[Dict[str, Any]]) -> Dict[str, Any]:
        """تولید گزارش کلی از همه بلوک‌ها"""
        total_blocks = len(block_results)
        successful = sum(1 for r in block_results if r.get("status") == "completed")
        failed = total_blocks - successful
        
        # جمع‌آوری آمار
        total_time = sum(r.get("execution_time_seconds", 0) for r in block_results)
        avg_time = total_time / total_blocks if total_blocks > 0 else 0
        
        # آمار تکه‌ها
        cycle_stats = {
            "cycle_02_success": sum(1 for r in block_results 
                                  if r.get("results", {}).get("cycle_02", {}).get("success", False)),
            "cycle_03_success": sum(1 for r in block_results 
                                  if r.get("results", {}).get("cycle_03", {}).get("success", False)),
            "cycle_04_success": sum(1 for r in block_results 
                                  if r.get("results", {}).get("cycle_04", {}).get("success", False))
        }
        
        report = {
            "generated_at": datetime.now().isoformat(),
            "total_blocks_processed": total_blocks,
            "successful_blocks": successful,
            "failed_blocks": failed,
            "success_rate": (successful / total_blocks * 100) if total_blocks > 0 else 0,
            "total_execution_time_seconds": total_time,
            "average_time_per_block_seconds": avg_time,
            "cycle_statistics": cycle_stats,
            "block_details": block_results,
            "summary": {
                "message": f"پردازش {total_blocks} بلوک تکمیل شد",
                "status": "COMPLETED" if failed == 0 else "PARTIAL",
                "recommendation": "همه بلوک‌ها با موفقیت پردازش شدند" if failed == 0 
                                else f"{failed} بلوک نیاز به بررسی مجدد دارند"
            }
        }
        
        return report
    
    def save_master_report(self, report: Dict[str, Any]):
        """ذخیره گزارش کلی"""
        try:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"master_report_{timestamp}.json"
            filepath = os.path.join(self.results_dir, filename)
            
            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump(report, f, indent=2, ensure_ascii=False)
            
            logger.info(f"\n💾 گزارش کلی ذخیره شد: {filepath}")
            
        except Exception as e:
            logger.error(f"❌ خطا در ذخیره گزارش کلی: {e}")
    
    def print_summary(self, report: Dict[str, Any]):
        """نمایش خلاصه نتایج"""
        logger.info("\n" + "=" * 60)
        logger.info("📊 خلاصه نهایی پردازش ترتیبی")
        logger.info("=" * 60)
        
        logger.info(f"📅 تاریخ تولید: {report.get('generated_at', 'N/A')}")
        logger.info(f"📦 تعداد بلوک‌های پردازش شده: {report.get('total_blocks_processed', 0)}")
        logger.info(f"✅ بلوک‌های موفق: {report.get('successful_blocks', 0)}")
        logger.info(f"❌ بلوک‌های ناموفق: {report.get('failed_blocks', 0)}")
        logger.info(f"📈 نرخ موفقیت: {report.get('success_rate', 0):.1f}%")
        logger.info(f"⏱️ کل زمان اجرا: {report.get('total_execution_time_seconds', 0):.1f} ثانیه")
        logger.info(f"⏱️ میانگین زمان هر بلوک: {report.get('average_time_per_block_seconds', 0):.1f} ثانیه")
        
        logger.info("\n📊 آمار تکه‌ها:")
        cycle_stats = report.get('cycle_statistics', {})
        logger.info(f"   تکه ۲ (کندل): {cycle_stats.get('cycle_02_success', 0)}/{report.get('total_blocks_processed', 0)} موفق")
        logger.info(f"   تکه ۳ (تحلیل): {cycle_stats.get('cycle_03_success', 0)}/{report.get('total_blocks_processed', 0)} موفق")
        logger.info(f"   تکه ۴ (پیشرفته): {cycle_stats.get('cycle_04_success', 0)}/{report.get('total_blocks_processed', 0)} موفق")
        
        summary = report.get('summary', {})
        logger.info(f"\n📝 پیام: {summary.get('message', 'N/A')}")
        logger.info(f"🎯 وضعیت: {summary.get('status', 'N/A')}")
        logger.info(f"💡 توصیه: {summary.get('recommendation', 'N/A')}")
        
        logger.info("=" * 60)


def main():
    """تابع اصلی"""
    import argparse
    
    parser = argparse.ArgumentParser(description='پردازش ترتیبی بلوک‌ها از تکه ۲ تا ۴')
    parser.add_argument('--start-from', type=int, default=1,
                       help='شروع از بلوک چندم (پیش‌فرض: ۱)')
    parser.add_argument('--max-blocks', type=int,
                       help='حداکثر تعداد بلوک‌های پردازش')
    parser.add_argument('--test', action='store_true',
                       help='حالت تست (فقط ۲ بلوک اول)')
    
    args = parser.parse_args()
    
    # تنظیم حالت تست
    max_blocks = 2 if args.test else args.max_blocks
    
    # ایجاد پردازشگر
    processor = SequentialProcessor()
    
    # اجرای پردازش
    report = processor.process_all_blocks(
        start_from=args.start_from,
        max_blocks=max_blocks
    )
    
    # خروجی بر اساس موفقیت
    if report.get('failed_blocks', 0) == 0:
        return 0
    else:
        return 1


if __name__ == "__main__":
    sys.exit(main())