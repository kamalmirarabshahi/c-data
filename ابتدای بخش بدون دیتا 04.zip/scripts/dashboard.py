#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
dashboard.py - API دشبورد بدون نیاز به HTML
"""

from flask import Flask, jsonify, request
import sqlite3
from datetime import datetime, timedelta
import os
import sys

# اضافه کردن مسیر پوشه scripts به sys.path برای import config_manager
sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'scripts'))

try:
    from config_manager import get, get_database_path, get_project_root, reload
    CONFIG_AVAILABLE = True
    print("✅ config_manager با موفقیت import شد")
except ImportError as e:
    CONFIG_AVAILABLE = False
    print(f"⚠️ خطا در import config_manager: {e}")

app = Flask(__name__)

# حل مشکل CORS
@app.after_request
def after_request(response):
    response.headers.add('Access-Control-Allow-Origin', '*')
    response.headers.add('Access-Control-Allow-Headers', 'Content-Type,Authorization')
    response.headers.add('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE,OPTIONS')
    return response

# دریافت مسیر دیتابیس از کانفیگ
if CONFIG_AVAILABLE:
    DB_PATH = get_database_path()
    print(f"📁 مسیر دیتابیس از کانفیگ: {DB_PATH}")
    
    # اگر مسیر دیتابیس تنظیم نشده، از تنظیمات پیش‌فرض استفاده کن
    if not DB_PATH or DB_PATH == '':
        DB_PATH = os.path.join(get_project_root(), "data", "crypto_master.db")
        print(f"📁 استفاده از مسیر پیش‌فرض: {DB_PATH}")
else:
    # اگر کانفیگ موجود نیست، از مسیر نسبی استفاده کن
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))
    DB_PATH = os.path.join(BASE_DIR, "..", "data", "crypto_master.db")
    DB_PATH = os.path.abspath(DB_PATH)
    print(f"📁 مسیر دیتابیس (بدون کانفیگ): {DB_PATH}")

class DashboardAPI:
    def __init__(self, db_path):
        self.db_path = db_path
        self.ensure_database_exists()
    
    def ensure_database_exists(self):
        """ایجاد دیتابیس و جداول اگر وجود ندارند"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # جدول ارزها
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS crypto_coins (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    symbol TEXT UNIQUE,
                    base_asset TEXT,
                    coin_name TEXT,
                    current_price REAL,
                    price_change_24h REAL,
                    price_change_percent_24h REAL,
                    high_24h REAL,
                    low_24h REAL,
                    volume_24h REAL,
                    market_cap REAL,
                    market_cap_rank INTEGER,
                    last_updated TEXT
                )
            ''')
            
            # جدول کندل‌ها
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS crypto_klines (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    coin_id INTEGER,
                    open_time TEXT,
                    close_time TEXT,
                    open_price REAL,
                    high_price REAL,
                    low_price REAL,
                    close_price REAL,
                    volume REAL,
                    quote_volume REAL,
                    FOREIGN KEY (coin_id) REFERENCES crypto_coins (id)
                )
            ''')
            
            # جدول لاگ‌ها
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS collection_logs (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp TEXT,
                    symbol TEXT,
                    timeframe TEXT,
                    candles_received INTEGER,
                    candles_saved INTEGER,
                    status TEXT,
                    error_msg TEXT
                )
            ''')
            
            # جدول سیگنال‌ها
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS trading_signals (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    signal_time TEXT,
                    symbol TEXT,
                    signal_type TEXT,
                    price REAL,
                    status TEXT,
                    result TEXT
                )
            ''')
            
            conn.commit()
            conn.close()
            print(f"✅ جداول دیتابیس در {self.db_path} بررسی/ایجاد شدند")
        except Exception as e:
            print(f"⚠️ خطا در ایجاد دیتابیس: {e}")
    
    def get_connection(self):
        """ایجاد اتصال به دیتابیس"""
        try:
            return sqlite3.connect(self.db_path)
        except Exception as e:
            print(f"❌ خطا در اتصال به دیتابیس {self.db_path}: {e}")
            raise
    
    def get_system_stats(self):
        """دریافت آمار سیستم"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        # دریافت اطلاعات سیستم از کانفیگ
        if CONFIG_AVAILABLE:
            system_name = get('system.name', 'Crypto Analysis System')
            system_version = get('system.version', '2.0.0')
        else:
            system_name = 'Crypto Analysis System'
            system_version = '2.0.0'
        
        stats = {
            'system': {
                'name': system_name,
                'version': system_version,
                'status': 'RUNNING',
                'timestamp': datetime.now().isoformat(),
                'config_available': CONFIG_AVAILABLE
            },
            'database': {
                'total_coins': 0,
                'total_candles': 0,
                'file_size_mb': 0,
                'last_update': None,
                'path': self.db_path,
                'exists': os.path.exists(self.db_path)
            },
            'collection': {
                'last_collection': None,
                'success_rate': 100,
                'avg_response_time': 0
            },
            'analysis': {
                'active_signals': 0,
                'today_signals': 0,
                'success_rate': 0
            }
        }
        
        try:
            # بررسی وجود جداول
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
            tables = [t[0] for t in cursor.fetchall()]
            
            # 1. تعداد ارزها
            if 'crypto_coins' in tables:
                cursor.execute("SELECT COUNT(*) FROM crypto_coins")
                stats['database']['total_coins'] = cursor.fetchone()[0]
            
            # 2. تعداد کندل‌ها
            if 'crypto_klines' in tables:
                cursor.execute("SELECT COUNT(*) FROM crypto_klines")
                stats['database']['total_candles'] = cursor.fetchone()[0]
            
            # 3. آخرین کندل
            if 'crypto_klines' in tables:
                cursor.execute("SELECT MAX(open_time) FROM crypto_klines")
                last_kline = cursor.fetchone()[0]
                stats['database']['last_update'] = last_kline
            
            # 4. سیگنال‌های فعال
            if 'trading_signals' in tables:
                cursor.execute("SELECT COUNT(*) FROM trading_signals WHERE status = 'ACTIVE'")
                stats['analysis']['active_signals'] = cursor.fetchone()[0]
            
            # 5. سیگنال‌های امروز
            if 'trading_signals' in tables:
                today = datetime.now().date().isoformat()
                cursor.execute("SELECT COUNT(*) FROM trading_signals WHERE DATE(signal_time) = ?", (today,))
                stats['analysis']['today_signals'] = cursor.fetchone()[0]
            
            # 6. اندازه فایل دیتابیس
            if os.path.exists(self.db_path):
                size_bytes = os.path.getsize(self.db_path)
                stats['database']['file_size_mb'] = round(size_bytes / (1024 * 1024), 2)
            
            # 7. آخرین جمع‌آوری از لاگ‌ها
            if 'collection_logs' in tables:
                cursor.execute("SELECT MAX(timestamp) FROM collection_logs")
                last_collection = cursor.fetchone()[0]
                if last_collection:
                    stats['collection']['last_collection'] = last_collection
            
        except Exception as e:
            stats['system']['status'] = f'ERROR: {str(e)}'
            stats['system']['error'] = str(e)
            print(f"⚠️ خطا در دریافت آمار: {e}")
        finally:
            conn.close()
        
        return stats
    
    def get_top_coins(self, limit=10):
        """دریافت ارزهای برتر"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        coins = []
        
        try:
            cursor.execute("""
                SELECT 
                    symbol, base_asset, coin_name,
                    current_price, price_change_percent_24h,
                    volume_24h, market_cap_rank
                FROM crypto_coins 
                WHERE market_cap_rank IS NOT NULL AND market_cap_rank <= 100
                ORDER BY market_cap_rank ASC
                LIMIT ?
            """, (limit,))
            
            columns = [desc[0] for desc in cursor.description]
            
            for row in cursor.fetchall():
                coin = dict(zip(columns, row))
                
                # فرمت‌دهی
                if coin['current_price']:
                    coin['current_price_formatted'] = f"${coin['current_price']:,.2f}"
                
                if coin['volume_24h']:
                    coin['volume_formatted'] = f"${coin['volume_24h']/1_000_000:,.1f}M"
                
                if coin['price_change_percent_24h']:
                    change = coin['price_change_percent_24h']
                    coin['change_color'] = 'green' if change > 0 else 'red'
                    coin['change_formatted'] = f"{change:+.2f}%"
                
                coins.append(coin)
            
        except Exception as e:
            print(f"Error getting top coins: {e}")
        finally:
            conn.close()
        
        return coins
    
    def get_recent_klines(self, symbol=None, limit=50):
        """دریافت کندل‌های اخیر"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        klines = []
        
        try:
            if symbol:
                # کندل‌های یک ارز خاص
                cursor.execute("""
                    SELECT 
                        c.symbol, k.open_time, k.close_time,
                        k.open_price, k.high_price, k.low_price, k.close_price,
                        k.volume, k.quote_volume
                    FROM crypto_klines k
                    JOIN crypto_coins c ON k.coin_id = c.id
                    WHERE c.symbol = ?
                    ORDER BY k.open_time DESC
                    LIMIT ?
                """, (symbol, limit))
            else:
                # آخرین کندل‌ها از همه ارزها
                cursor.execute("""
                    SELECT 
                        c.symbol, k.open_time, k.close_time,
                        k.open_price, k.high_price, k.low_price, k.close_price,
                        k.volume, k.quote_volume
                    FROM crypto_klines k
                    JOIN crypto_coins c ON k.coin_id = c.id
                    ORDER BY k.open_time DESC
                    LIMIT ?
                """, (limit,))
            
            columns = [desc[0] for desc in cursor.description]
            
            for row in cursor.fetchall():
                kline = dict(zip(columns, row))
                
                # محاسبه تغییرات
                if kline['open_price'] and kline['close_price']:
                    change = kline['close_price'] - kline['open_price']
                    change_percent = (change / kline['open_price']) * 100
                    
                    kline['price_change'] = change
                    kline['price_change_percent'] = change_percent
                    kline['change_color'] = 'green' if change > 0 else 'red'
                
                # فرمت زمان
                if kline['open_time']:
                    try:
                        dt = datetime.fromisoformat(kline['open_time'].replace('Z', '+00:00'))
                        kline['time_formatted'] = dt.strftime('%H:%M')
                    except:
                        kline['time_formatted'] = kline['open_time'][11:16] if len(kline['open_time']) >= 16 else kline['open_time']
                
                klines.append(kline)
            
        except Exception as e:
            print(f"Error getting klines: {e}")
        finally:
            conn.close()
        
        return klines
    
    def get_collection_logs(self, limit=20):
        """دریافت لاگ‌های جمع‌آوری"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        logs = []
        
        try:
            cursor.execute("""
                SELECT 
                    timestamp, symbol, timeframe,
                    candles_received, candles_saved,
                    status, error_msg
                FROM collection_logs 
                ORDER BY timestamp DESC
                LIMIT ?
            """, (limit,))
            
            columns = [desc[0] for desc in cursor.description]
            
            for row in cursor.fetchall():
                log = dict(zip(columns, row))
                
                # وضعیت رنگ
                if log['status'] == 'SUCCESS':
                    log['status_color'] = 'green'
                elif log['status'] == 'FAILED':
                    log['status_color'] = 'red'
                else:
                    log['status_color'] = 'orange'
                
                logs.append(log)
            
        except Exception as e:
            print(f"Error getting logs: {e}")
        finally:
            conn.close()
        
        return logs


# ایجاد instance
dashboard = DashboardAPI(DB_PATH)

# Routes
@app.route('/')
def index():
    """صفحه اصلی - اطلاعات کلی"""
    return jsonify({
        'name': 'Crypto Analysis Dashboard API',
        'version': '1.0.0',
        'description': 'API دشبورد سیستم تحلیل کریپتوکارنسی',
        'config_available': CONFIG_AVAILABLE,
        'endpoints': {
            '/': 'اطلاعات کلی API (همین صفحه)',
            '/api/stats': 'آمار کلی سیستم',
            '/api/coins': 'لیست ارزهای برتر',
            '/api/klines': 'کندل‌های اخیر',
            '/api/logs': 'لاگ‌های جمع‌آوری',
            '/api/coin/<symbol>': 'اطلاعات یک ارز خاص',
            '/api/health': 'سلامت سیستم'
        },
        'timestamp': datetime.now().isoformat()
    })

@app.route('/api/stats')
def api_stats():
    """آمار کلی سیستم"""
    return jsonify(dashboard.get_system_stats())

@app.route('/api/coins')
def api_coins():
    """ارزهای برتر"""
    limit = request.args.get('limit', 10, type=int)
    coins = dashboard.get_top_coins(limit)
    return jsonify({
        'coins': coins,
        'count': len(coins),
        'timestamp': datetime.now().isoformat()
    })

@app.route('/api/klines')
def api_klines():
    """کندل‌های اخیر"""
    symbol = request.args.get('symbol', None)
    limit = request.args.get('limit', 50, type=int)
    
    klines = dashboard.get_recent_klines(symbol, limit)
    return jsonify({
        'symbol': symbol or 'ALL',
        'klines': klines,
        'count': len(klines),
        'timestamp': datetime.now().isoformat()
    })

@app.route('/api/logs')
def api_logs():
    """لاگ‌های جمع‌آوری"""
    limit = request.args.get('limit', 20, type=int)
    logs = dashboard.get_collection_logs(limit)
    return jsonify({
        'logs': logs,
        'count': len(logs),
        'timestamp': datetime.now().isoformat()
    })

@app.route('/api/coin/<symbol>')
def api_coin(symbol):
    """اطلاعات یک ارز خاص"""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    try:
        # اطلاعات ارز
        cursor.execute("""
            SELECT 
                symbol, base_asset, coin_name,
                current_price, price_change_24h, price_change_percent_24h,
                high_24h, low_24h, volume_24h,
                market_cap, market_cap_rank,
                last_updated
            FROM crypto_coins 
            WHERE symbol = ?
        """, (symbol.upper(),))
        
        row = cursor.fetchone()
        if not row:
            return jsonify({'error': 'Coin not found'}), 404
        
        columns = [desc[0] for desc in cursor.description]
        coin_info = dict(zip(columns, row))
        
        # کندل‌های اخیر این ارز
        cursor.execute("""
            SELECT 
                open_time, close_time,
                open_price, high_price, low_price, close_price,
                volume
            FROM crypto_klines k
            JOIN crypto_coins c ON k.coin_id = c.id
            WHERE c.symbol = ?
            ORDER BY open_time DESC
            LIMIT 20
        """, (symbol.upper(),))
        
        klines = []
        kline_columns = [desc[0] for desc in cursor.description]
        for kline_row in cursor.fetchall():
            klines.append(dict(zip(kline_columns, kline_row)))
        
        return jsonify({
            'coin': coin_info,
            'recent_klines': klines,
            'klines_count': len(klines),
            'timestamp': datetime.now().isoformat()
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500
    finally:
        conn.close()

@app.route('/api/health')
def api_health():
    """بررسی سلامت سیستم"""
    db_exists = os.path.exists(DB_PATH)
    
    # بررسی اتصال به دیتابیس
    db_connected = False
    if db_exists:
        try:
            conn = sqlite3.connect(DB_PATH)
            cursor = conn.cursor()
            cursor.execute("SELECT 1")
            db_connected = True
            conn.close()
        except:
            db_connected = False
    
    return jsonify({
        'status': 'healthy' if db_connected else 'unhealthy',
        'database': {
            'exists': db_exists,
            'connected': db_connected,
            'path': DB_PATH
        },
        'config': {
            'available': CONFIG_AVAILABLE
        },
        'timestamp': datetime.now().isoformat()
    })

@app.route('/api/config/reload', methods=['POST'])
def reload_config():
    """بارگذاری مجدد تنظیمات"""
    if CONFIG_AVAILABLE:
        success = reload()
        return jsonify({
            'success': success,
            'message': 'تنظیمات بارگذاری مجدد شد' if success else 'خطا در بارگذاری مجدد تنظیمات',
            'timestamp': datetime.now().isoformat()
        })
    else:
        return jsonify({
            'success': False,
            'message': 'config_manager در دسترس نیست',
            'timestamp': datetime.now().isoformat()
        })

@app.route('/api/config/info')
def config_info():
    """نمایش اطلاعات کانفیگ"""
    if CONFIG_AVAILABLE:
        info = {
            'system_name': get('system.name', 'N/A'),
            'system_version': get('system.version', 'N/A'),
            'database_path': get_database_path(),
            'project_root': get_project_root(),
            'api_base_url': get('api.binance.base_url', 'N/A'),
            'collection_settings': get('collection', {}),
            'analysis_settings': get('analysis', {}),
            'timestamp': datetime.now().isoformat()
        }
        return jsonify(info)
    else:
        return jsonify({
            'message': 'config_manager در دسترس نیست',
            'timestamp': datetime.now().isoformat()
        })

if __name__ == '__main__':
    print("=" * 60)
    print("🌐 دشبورد API سیستم تحلیل کریپتو")
    print("=" * 60)
    print(f"📅 شروع: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"📍 آدرس: http://localhost:5000")
    print(f"📁 دیتابیس: {DB_PATH}")
    print(f"📂 وجود دیتابیس: {os.path.exists(DB_PATH)}")
    print(f"⚙️  کانفیگ: {'در دسترس' if CONFIG_AVAILABLE else 'ناموجود'}")
    print("=" * 60)
    print("\n📋 Endpoints:")
    print("  • /                   - اطلاعات کلی API")
    print("  • /api/stats          - آمار سیستم")
    print("  • /api/coins          - ارزهای برتر")
    print("  • /api/klines         - کندل‌های اخیر")
    print("  • /api/logs           - لاگ‌های جمع‌آوری")
    print("  • /api/coin/<symbol>  - اطلاعات یک ارز خاص")
    print("  • /api/health         - سلامت سیستم")
    print("  • /api/config/info    - اطلاعات کانفیگ")
    print("  • /api/config/reload  - بارگذاری مجدد کانفیگ (POST)")
    print("\nبرای توقف Ctrl+C را فشار دهید")
    print("=" * 60)
    
    app.run(debug=True, port=5000, use_reloader=False)