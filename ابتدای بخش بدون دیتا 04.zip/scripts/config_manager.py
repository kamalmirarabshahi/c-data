import json
import os
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional, Union

# ========== تنظیمات مسیرها ==========
# پیدا کردن مسیر پروژه به صورت خودکار
PROJECT_ROOT = Path(__file__).parent.parent
CONFIG_DIR = PROJECT_ROOT / "config"
DATA_DIR = PROJECT_ROOT / "data"
SCRIPTS_DIR = PROJECT_ROOT / "scripts"
LOGS_DIR = PROJECT_ROOT / "logs"

# مسیر فایل تنظیمات
CONFIG_PATH = CONFIG_DIR / "settings.json"

# متغیر جهانی تنظیمات
_SETTINGS = None


def _check_essential_paths() -> bool:
    """بررسی وجود مسیرهای ضروری (بدون ایجاد خودکار)"""
    essential_paths = [
        ("فایل تنظیمات", CONFIG_PATH),
        ("پوشه داده‌ها", DATA_DIR),
        ("پوشه اسکریپت‌ها", SCRIPTS_DIR),
    ]
    
    all_exist = True
    for name, path in essential_paths:
        if not path.exists():
            print(f"❌ {name} یافت نشد: {path}")
            all_exist = False
    
    return all_exist


def _load_settings() -> bool:
    """بارگذاری تنظیمات از فایل JSON"""
    global _SETTINGS
    
    try:
        if CONFIG_PATH.exists():
            with open(CONFIG_PATH, 'r', encoding='utf-8') as f:
                _SETTINGS = json.load(f)
            print(f"✅ تنظیمات از {CONFIG_PATH} بارگذاری شد")
            return True
        else:
            print(f"❌ فایل تنظیمات یافت نشد: {CONFIG_PATH}")
            print("   لطفاً فایل settings.json را در پوشه config ایجاد کنید.")
            _SETTINGS = {}
            return False
    except json.JSONDecodeError as e:
        print(f"❌ خطا در خواندن JSON فایل تنظیمات: {e}")
        print("   لطفاً فرمت JSON فایل را بررسی کنید.")
        _SETTINGS = {}
        return False
    except Exception as e:
        print(f"❌ خطای ناشناخته در خواندن تنظیمات: {e}")
        _SETTINGS = {}
        return False


def get(key_path: str, default: Any = None) -> Any:
    """
    دریافت مقدار از تنظیمات با کلید نقطه‌ای
    
    مثال:
        config.get('api.binance.base_url')
        config.get('analysis.rsi_period', 14)
        config.get('database.path', 'data/crypto_master.db')
    """
    global _SETTINGS
    
    # اگر تنظیمات هنوز بارگذاری نشده
    if _SETTINGS is None:
        if not _load_settings():
            return default
    
    if _SETTINGS is None or not _SETTINGS:
        return default
    
    # تقسیم کلید به بخش‌ها
    keys = key_path.split('.')
    value = _SETTINGS
    
    # دنبال کردن مسیر کلید
    for key in keys:
        if isinstance(value, dict) and key in value:
            value = value[key]
        else:
            return default
    
    return value


# ========== توابع کمکی برای دسترسی راحت‌تر ==========

def get_system_config() -> Dict[str, Any]:
    """دریافت تنظیمات سیستم"""
    return get('system', {})


def get_database_config() -> Dict[str, Any]:
    """دریافت تنظیمات دیتابیس"""
    return get('database', {})


def get_api_config(service: str = 'binance') -> Dict[str, Any]:
    """دریافت تنظیمات API"""
    return get(f'api.{service}', {})


def get_collection_config() -> Dict[str, Any]:
    """دریافت تنظیمات جمع‌آوری داده"""
    return get('collection', {})


def get_analysis_config() -> Dict[str, Any]:
    """دریافت تنظیمات تحلیل تکنیکال"""
    return get('analysis', {})


def get_signal_config() -> Dict[str, Any]:
    """دریافت تنظیمات سیگنال"""
    return get('signals', {})


def get_alert_config() -> Dict[str, Any]:
    """دریافت تنظیمات هشدار"""
    return get('alerts', {})


def get_logging_config() -> Dict[str, Any]:
    """دریافت تنظیمات لاگ‌گیری"""
    return get('logging', {})


def get_monitoring_config() -> Dict[str, Any]:
    """دریافت تنظیمات مانیتورینگ"""
    return get('monitoring', {})


def get_security_config() -> Dict[str, Any]:
    """دریافت تنظیمات امنیتی"""
    return get('security', {})


# ========== توابع برای مسیرها ==========

def get_path_config() -> Dict[str, Any]:
    """دریافت تنظیمات مسیرها"""
    return get('paths', {})


def get_project_root() -> str:
    """دریافت مسیر اصلی پروژه"""
    paths = get_path_config()
    return paths.get('project_root', str(PROJECT_ROOT))


def get_scripts_dir() -> str:
    """دریافت مسیر فایل‌های اجرایی"""
    paths = get_path_config()
    return paths.get('scripts_dir', str(SCRIPTS_DIR))


def get_config_dir() -> str:
    """دریافت مسیر فایل‌های کانفیگ"""
    paths = get_path_config()
    return paths.get('config_dir', str(CONFIG_DIR))


def get_data_dir() -> str:
    """دریافت مسیر دیتابیس و داده‌ها"""
    paths = get_path_config()
    return paths.get('data_dir', str(DATA_DIR))


def get_logs_dir() -> str:
    """دریافت مسیر لاگ‌ها"""
    paths = get_path_config()
    return paths.get('logs_dir', str(LOGS_DIR))


def get_backups_dir() -> str:
    """دریافت مسیر بک‌آپ‌ها"""
    paths = get_path_config()
    return paths.get('backups_dir', str(PROJECT_ROOT / "backups"))


def get_state_dir() -> str:
    """دریافت مسیر state"""
    paths = get_path_config()
    return paths.get('state_dir', str(PROJECT_ROOT / "state"))


def get_database_path() -> str:
    """دریافت مسیر دیتابیس"""
    db_config = get_database_config()
    path = db_config.get('path', '')
    
    if not path:
        print("⚠️ مسیر دیتابیس در تنظیمات مشخص نشده است.")
        # ایجاد مسیر پیش‌فرض
        data_dir = get_data_dir()
        path = os.path.join(data_dir, 'crypto_master.db')
        print(f"   استفاده از مسیر پیش‌فرض: {path}")
    
    if path and os.path.isabs(path):
        return path
    else:
        # اگر مسیر نسبی است، نسبت به data_dir بساز
        data_dir = get_data_dir()
        full_path = os.path.join(data_dir, path)
        return full_path


# ========== توابع برای cycle_03 ==========

def get_timeframes() -> List[str]:
    """دریافت لیست تایم‌فریم‌ها"""
    # اول از collection.timeframes بگیر
    timeframes = get('collection.timeframes')
    
    # اگر نبود، از collection.timeframe (مفرد) بگیر
    if not timeframes:
        timeframe = get('collection.timeframe')
        if timeframe:
            timeframes = [timeframe]
    
    # اگر باز هم نبود، پیش‌فرض
    if not timeframes:
        timeframes = ["5m", "15m", "1h", "4h"]
        print(f"⚠️ تایم‌فریم‌ها در تنظیمات مشخص نشده، استفاده از پیش‌فرض: {timeframes}")
    
    return timeframes


def get_symbols() -> List[str]:
    """دریافت لیست ارزها"""
    symbols = get('collection.symbols')
    
    if not symbols:
        # اگر در collection.symbols نبود، از cycle.symbols_per_block بگیر
        symbols_per_block = get('cycle.symbols_per_block', 10)
        symbols = [f"SYMBOL{i}" for i in range(1, symbols_per_block + 1)]
        print(f"⚠️ ارزها در تنظیمات مشخص نشده، استفاده از پیش‌فرض: {len(symbols)} نماد")
    
    return symbols


def get_analysis_periods() -> Dict[str, Any]:
    """دریافت تنظیمات دوره‌های تحلیل"""
    return {
        'rsi_period': get('analysis.rsi_period', 14),
        'macd_fast': get('analysis.macd_fast', 12),
        'macd_slow': get('analysis.macd_slow', 26),
        'macd_signal': get('analysis.macd_signal', 9),
        'bb_period': get('analysis.bollinger_period', 20),
        'bb_std': get('analysis.bollinger_std', 2.0)
    }


def get_min_candles_for_analysis() -> int:
    """دریافت حداقل کندل‌های لازم برای تحلیل"""
    return get('collection.min_candles_for_analysis', 50)


# ========== توابع جدید برای تحلیل پیشرفته ==========

def get_analysis_settings() -> Dict[str, Any]:
    """دریافت تمام تنظیمات تحلیل"""
    settings = get('analysis', {})
    
    # تنظیمات پیش‌فرض
    defaults = {
        'enabled': True,
        'strict_mode': False,
        'rsi_period': 14,
        'macd_fast': 12,
        'macd_slow': 26,
        'macd_signal': 9,
        'bollinger_period': 20,
        'bollinger_std': 2.0,
        'atr_period': 14,
        'volume_ma_period': 20,
        'min_data_points': 30,
        'data_quality_threshold': 30,
        'max_price_deviation': 1.0,
        'acceptable_null_percentage': 15.0,
        'max_recalculation_attempts': 3,
        'min_confidence_score': 70,
        'signal_check_interval': 60,
        'valid_timeframes': ['1m', '5m', '15m', '30m', '1h', '4h', '1d', '1w']
    }
    
    # ترکیب تنظیمات
    for key, default in defaults.items():
        if key not in settings or settings[key] is None:
            settings[key] = default
            if key in ['min_data_points', 'strict_mode', 'min_volume_threshold']:
                print(f"⚠️ تنظیمات {key} در analysis مشخص نشده، استفاده از پیش‌فرض: {default}")
    
    return settings


def get_quality_control_settings() -> Dict[str, Any]:
    """دریافت تنظیمات کنترل کیفیت"""
    analysis = get('analysis', {})
    
    return {
        'acceptable_null_percentage': analysis.get('acceptable_null_percentage', 15.0),
        'max_recalculation_attempts': analysis.get('max_recalculation_attempts', 3),
        'strict_mode': analysis.get('strict_mode', False)
    }


def get_timeframe_settings(timeframe: Optional[str] = None) -> Dict[str, Any]:
    """دریافت تنظیمات تایم‌فریم"""
    settings = get('analysis.timeframe_settings', {})
    
    if timeframe:
        return settings.get(timeframe, {'atr_multiplier': 1.0, 'volatility_factor': 1.0})
    
    # تنظیمات پیش‌فرض برای تمام تایم‌فریم‌ها
    default_settings = {
        '1m': {'atr_multiplier': 1.0, 'volatility_factor': 5.0},
        '5m': {'atr_multiplier': 1.5, 'volatility_factor': 4.0},
        '15m': {'atr_multiplier': 2.0, 'volatility_factor': 3.0},
        '30m': {'atr_multiplier': 2.5, 'volatility_factor': 2.5},
        '1h': {'atr_multiplier': 3.0, 'volatility_factor': 2.0},
        '4h': {'atr_multiplier': 4.0, 'volatility_factor': 1.5},
        '1d': {'atr_multiplier': 5.0, 'volatility_factor': 1.0},
        '1w': {'atr_multiplier': 6.0, 'volatility_factor': 0.8}
    }
    
    # اگر تنظیمات نداریم، از پیش‌فرض استفاده کن
    if not settings:
        print("⚠️ تنظیمات timeframe_settings در analysis مشخص نشده، استفاده از پیش‌فرض")
        return default_settings
    
    # ترکیب تنظیمات
    result = default_settings.copy()
    result.update(settings)
    
    return result


def get_obv_settings() -> Dict[str, Any]:
    """دریافت تنظیمات محاسبه OBV"""
    return get('obv_calculation', {
        'max_candles_per_coin': 300,
        'update_only_null': True,
        'batch_size': 100,
        'sleep_between_batches': 0.1,
        'report_enabled': True
    })


def get_volume_settings() -> Dict[str, Any]:
    """دریافت تنظیمات حجم"""
    volume_settings = get('analysis.volume', {})
    
    defaults = {
        'avg_trade_size': 1000,
        'min_volume_threshold': 10,
        'volume_ma_period': 20
    }
    
    for key, default in defaults.items():
        if key not in volume_settings:
            volume_settings[key] = default
            if key == 'min_volume_threshold':
                print(f"⚠️ تنظیمات analysis.volume.{key} مشخص نشده، استفاده از پیش‌فرض: {default}")
    
    return volume_settings


def get_pattern_settings() -> Dict[str, Any]:
    """دریافت تنظیمات الگوها"""
    pattern_settings = get('analysis.patterns', {})
    
    defaults = {
        'doji_threshold': 0.1,
        'hammer_shadow_ratio': 2.0,
        'shooting_star_threshold': 2.0,
        'marubozu_threshold': 0.9,
        'spinning_top_threshold': 0.3
    }
    
    for key, default in defaults.items():
        if key not in pattern_settings:
            pattern_settings[key] = default
    
    return pattern_settings


def get_indicator_thresholds() -> Dict[str, Any]:
    """دریافت آستانه‌های اندیکاتورها"""
    return {
        'rsi_oversold': get('analysis.rsi_oversold', 30),
        'rsi_overbought': get('analysis.rsi_overbought', 70),
        'volume_spike_threshold': get('analysis.volume_spike_threshold', 2.0),
        'price_change_alert': get('analysis.price_change_alert', 5.0),
        'atr_stop_loss_multiplier': get('analysis.atr_stop_loss_multiplier', 2.0),
        'trend_strength_threshold': get('analysis.trend_strength_threshold', 60)
    }


# ========== توابع کمکی سریع ==========

def get_min_data_points() -> int:
    """دریافت حداقل داده‌ها"""
    value = get('analysis.min_data_points', 30)
    if value == 30:  # یعنی از پیش‌فرض استفاده شده
        print(f"⚠️ analysis.min_data_points مشخص نشده، استفاده از پیش‌فرض: {value}")
    return value


def get_strict_mode() -> bool:
    """دریافت حالت strict"""
    return get('analysis.strict_mode', False)


def get_min_volume_threshold() -> float:
    """دریافت حداقل حجم"""
    value = get('analysis.volume.min_volume_threshold', 10)
    if value == 10:  # یعنی از پیش‌فرض استفاده شده
        print(f"⚠️ analysis.volume.min_volume_threshold مشخص نشده، استفاده از پیش‌فرض: {value}")
    return value


def get_data_quality_threshold() -> float:
    """دریافت آستانه کیفیت داده"""
    value = get('analysis.data_quality_threshold', 30)
    if value == 30:  # یعنی از پیش‌فرض استفاده شده
        print(f"⚠️ analysis.data_quality_threshold مشخص نشده، استفاده از پیش‌فرض: {value}")
    return value


def get_max_price_deviation() -> float:
    """دریافت حداکثر انحراف قیمت"""
    return get('analysis.max_price_deviation', 1.0)


def get_acceptable_null_percentage() -> float:
    """دریافت درصد قابل قبول مقادیر null"""
    value = get('analysis.acceptable_null_percentage', 15.0)
    if value == 15.0:  # یعنی از پیش‌فرض استفاده شده
        print(f"⚠️ analysis.acceptable_null_percentage مشخص نشده، استفاده از پیش‌فرض: {value}")
    return value


# ========== توابع کمکی برای کار با دیتابیس ==========

def get_database_connection_params() -> Dict[str, Any]:
    """دریافت پارامترهای اتصال به دیتابیس"""
    db_config = get_database_config()
    
    return {
        'database': get_database_path(),
        'timeout': db_config.get('connection_timeout', 30),
        'journal_mode': db_config.get('journal_mode', 'WAL'),
        'synchronous': db_config.get('synchronous', 'NORMAL'),
        'foreign_keys': db_config.get('foreign_keys', True)
    }


def check_database_exists() -> bool:
    """بررسی وجود فایل دیتابیس"""
    db_path = get_database_path()
    if not os.path.exists(db_path):
        print(f"❌ فایل دیتابیس یافت نشد: {db_path}")
        print("   لطفاً مطمئن شوید دیتابیس ایجاد شده است.")
        return False
    return True


# ========== توابع کمکی برای API ==========

def get_binance_config() -> Dict[str, Any]:
    """دریافت تنظیمات Binance API"""
    return get_api_config('binance')


def get_request_timeout() -> int:
    """دریافت timeout درخواست‌ها"""
    binance_config = get_binance_config()
    return binance_config.get('request_timeout', 10)


def get_retry_attempts() -> int:
    """دریافت تعداد تلاش‌های مجدد"""
    binance_config = get_binance_config()
    return binance_config.get('retry_attempts', 3)


# ========== توابع کمکی برای سیگنال‌ها ==========

def get_signal_thresholds() -> Dict[str, Any]:
    """دریافت آستانه‌های سیگنال"""
    signal_config = get_signal_config()
    
    return {
        'min_confidence': signal_config.get('min_confidence', 65),
        'risk_per_trade_percent': signal_config.get('risk_per_trade_percent', 2.0),
        'default_stop_loss_percent': signal_config.get('default_stop_loss_percent', 3.0),
        'min_risk_reward_ratio': signal_config.get('min_risk_reward_ratio', 1.5)
    }


# ========== توابع سیستم ==========

def reload() -> bool:
    """بارگذاری مجدد تنظیمات از فایل"""
    return _load_settings()


def is_debug_mode() -> bool:
    """بررسی حالت debug"""
    system_config = get_system_config()
    return system_config.get('debug_mode', False)


def get_environment() -> str:
    """دریافت محیط اجرا"""
    system_config = get_system_config()
    return system_config.get('environment', 'production')


def get_version() -> str:
    """دریافت نسخه سیستم"""
    system_config = get_system_config()
    return system_config.get('version', '1.0.0')


def initialize() -> bool:
    """مقداردهی اولیه و بررسی ضروریات"""
    print("🔍 بررسی تنظیمات و ساختار پروژه...")
    
    # بررسی فایل تنظیمات
    if not CONFIG_PATH.exists():
        print(f"❌ فایل تنظیمات یافت نشد: {CONFIG_PATH}")
        print("   لطفاً فایل settings.json را در پوشه config ایجاد کنید.")
        return False
    
    # بارگذاری تنظیمات
    if not _load_settings():
        return False
    
    # بررسی دیتابیس
    if not check_database_exists():
        return False
    
    print("✅ سیستم آماده است.")
    return True


# ========== بارگذاری اولیه تنظیمات ==========
# فقط چک می‌کند، اگر مشکل بود فقط پیام می‌دهد
if __name__ != "__main__":
    try:
        if not CONFIG_PATH.exists():
            print(f"⚠️ فایل تنظیمات یافت نشد: {CONFIG_PATH}")
        else:
            _load_settings()
    except Exception as e:
        print(f"⚠️ خطا در بارگذاری اولیه تنظیمات: {e}")


# ========== تست مستقل ==========
if __name__ == "__main__":
    print("=" * 60)
    print("🔧 تست فایل config_manager.py (بدون ایجاد خودکار)")
    print("=" * 60)
    
    # بررسی اولیه
    if not initialize():
        print("\n❌ سیستم آماده نیست. لطفاً مشکلات فوق را رفع کنید.")
        sys.exit(1)
    
    print(f"\n📁 ساختار پروژه:")
    print(f"  1. مسیر اصلی پروژه: {get_project_root()}")
    print(f"  2. مسیر اسکریپت‌ها: {get_scripts_dir()}")
    print(f"  3. مسیر کانفیگ: {get_config_dir()}")
    print(f"  4. مسیر داده‌ها: {get_data_dir()}")
    print(f"  5. مسیر لاگ‌ها: {get_logs_dir()}")
    
    print(f"\n📁 مسیر دیتابیس:")
    db_path = get_database_path()
    print(f"  6. مسیر دیتابیس: {db_path}")
    print(f"  7. وجود دارد: {os.path.exists(db_path)}")
    
    print("\n📋 تنظیمات سیستم:")
    print(f"  8. نام سیستم: {get('system.name')}")
    print(f"  9. ورژن: {get_version()}")
    print(f"  10. محیط: {get_environment()}")
    print(f"  11. Debug Mode: {is_debug_mode()}")
    
    print("\n🔗 تنظیمات API:")
    print(f"  12. Binance URL: {get('api.binance.base_url')}")
    print(f"  13. Timeout: {get_request_timeout()}s")
    print(f"  14. Retry Attempts: {get_retry_attempts()}")
    
    print("\n📈 تنظیمات تحلیل:")
    analysis_settings = get_analysis_settings()
    print(f"  15. min_data_points: {analysis_settings.get('min_data_points')}")
    print(f"  16. strict_mode: {analysis_settings.get('strict_mode')}")
    print(f"  17. data_quality_threshold: {analysis_settings.get('data_quality_threshold')}")
    print(f"  18. acceptable_null_percentage: {get_acceptable_null_percentage()}")
    
    print("\n📊 تنظیمات حجم:")
    volume_settings = get_volume_settings()
    print(f"  19. min_volume_threshold: {volume_settings.get('min_volume_threshold')}")
    
    print("\n⏰ تنظیمات تایم‌فریم‌ها:")
    print(f"  20. تایم‌فریم‌ها: {get_timeframes()}")
    
    print("\n🎯 تنظیمات سیگنال:")
    signal_thresholds = get_signal_thresholds()
    print(f"  21. min_confidence: {signal_thresholds.get('min_confidence')}%")
    
    print("\n" + "=" * 60)
    print("✅ تست کامل شد")
    print("✨ نکات مهم:")
    print("  • هیچ پوشه یا فایلی به طور خودکار ایجاد نمی‌شود")
    print("  • در صورت عدم وجود تنظیمات، از پیش‌فرض‌ها استفاده می‌شود")
    print("  • در صورت مشکل جدی، پیام خطا نمایش داده می‌شود")
    print("=" * 60)