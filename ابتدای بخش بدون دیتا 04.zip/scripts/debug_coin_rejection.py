"""
فایل: debug_specific_coins.py
عملکرد: بررسی دقیق دلایل رد شدن ارزهای خاص در سیستم فیلترینگ
تاریخ: 2024-01-15
"""

import sqlite3
import os
import sys

# لیست ارزهایی که می‌خواهیم بررسی کنیم
TARGET_SYMBOLS = [
    'BTCUSDT', 'BNBUSDT', 'PAXGUSDT', 'BCHUSDT', 'TAOUSDT', 
    'AAVEUSDT', 'WBTCUSDT', 'BNSOLUSDT', 'BIFIUSDT', 'WBETHUSDT', 
    'COMPUSDT', 'QNTUSDT', 'BETHUSDT', 'TRBUSDT', 'ENSUSDT', 
    'YFIIUSDT', 'BTGUSDT', 'YFIUSDT', 'XMRUSDT', 'AUTOUSDT'
]

def find_database():
    """پیدا کردن فایل دیتابیس"""
    possible_paths = [
        "data/crypto_data.db",
        "../data/crypto_data.db",
        "../../data/crypto_data.db",
        "crypto_data.db",
        "../crypto_data.db",
    ]
    
    for path in possible_paths:
        if os.path.exists(path):
            print(f"✅ دیتابیس یافت شد: {path}")
            return path
    
    print("❌ دیتابیس در مسیرهای پیش‌فرض یافت نشد.")
    print("\n📁 جستجو در پوشه فعلی:")
    for file in os.listdir("."):
        if file.endswith(".db"):
            print(f"   - {file}")
    
    db_path = input("\n🔧 مسیر فایل دیتابیس را وارد کنید (یا Enter برای خروج): ").strip()
    
    if not db_path:
        return None
    
    if os.path.exists(db_path):
        return db_path
    else:
        print(f"❌ فایل '{db_path}' وجود ندارد.")
        return None

def check_database_structure(db_path):
    """بررسی ساختار دیتابیس"""
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        print("\n📊 بررسی ساختار دیتابیس:")
        print("-" * 50)
        
        # بررسی وجود جداول
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
        tables = cursor.fetchall()
        
        print(f"✅ تعداد جداول: {len(tables)}")
        for table in tables:
            table_name = table[0]
            cursor.execute(f"SELECT COUNT(*) FROM {table_name}")
            count = cursor.fetchone()[0]
            print(f"   - {table_name}: {count} رکورد")
        
        conn.close()
        return True
    except Exception as e:
        print(f"❌ خطا در بررسی ساختار: {e}")
        return False

def analyze_coins(db_path, symbols):
    """تحلیل دقیق ارزها"""
    try:
        conn = sqlite3.connect(db_path)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        
        print(f"\n🔍 تحلیل {len(symbols)} ارز هدف:")
        print("=" * 80)
        
        # 1. ابتدا بررسی می‌کنیم کدام ارزها در دیتابیس وجود دارند
        placeholders = ','.join(['?' for _ in symbols])
        query = f"""
        SELECT 
            symbol, 
            current_price,
            volume_24h,
            market_cap,
            market_cap_rank,
            is_active,
            last_updated
        FROM crypto_coins 
        WHERE symbol IN ({placeholders})
        ORDER BY symbol
        """
        
        cursor.execute(query, symbols)
        found_coins = cursor.fetchall()
        
        found_symbols = [row['symbol'] for row in found_coins]
        missing_symbols = [s for s in symbols if s not in found_symbols]
        
        print(f"\n📋 وضعیت ارزها:")
        print(f"✅ موجود در دیتابیس: {len(found_coins)} ارز")
        print(f"❌ موجود نیستند: {len(missing_symbols)} ارز")
        
        if missing_symbols:
            print(f"\n📌 ارزهای گمشده:")
            for i, symbol in enumerate(missing_symbols, 1):
                print(f"   {i:2d}. {symbol}")
        
        # 2. تحلیل فیلترهای اصلی
        print(f"\n⚙️ تحلیل فیلترهای اصلی:")
        print("-" * 80)
        
        # پارامترهای فیلتر (مقادیر پیش‌فرض از cycle_01_coin_filter.py)
        FILTER_PARAMS = {
            'min_volume_usd': 100000,      # 100 هزار دلار
            'min_price': 0.001,            # 0.001 دلار
            'max_is_active': 4             # is_active باید کمتر از 5 باشد
        }
        
        print(f"📊 پارامترهای فیلتر:")
        print(f"   • حداقل حجم: ${FILTER_PARAMS['min_volume_usd']:,}")
        print(f"   • حداقل قیمت: ${FILTER_PARAMS['min_price']}")
        print(f"   • حداکثر is_active: {FILTER_PARAMS['max_is_active']}")
        
        # 3. تحلیل هر ارز
        print(f"\n🔎 تحلیل تک تک ارزها:")
        print("-" * 80)
        
        results = []
        
        for row in found_coins:
            symbol = row['symbol']
            current_price = row['current_price'] or 0
            volume_24h = row['volume_24h'] or 0
            is_active = row['is_active'] or 1
            market_cap_rank = row['market_cap_rank'] or 9999
            
            # بررسی فیلترها
            fails = []
            
            # فیلتر is_active
            if is_active >= 5:
                fails.append(f"is_active={is_active} (باید < 5)")
            
            # فیلتر قیمت
            if current_price < FILTER_PARAMS['min_price']:
                fails.append(f"قیمت=${current_price} (باید >= {FILTER_PARAMS['min_price']})")
            
            # فیلتر حجم
            if volume_24h < FILTER_PARAMS['min_volume_usd']:
                fails.append(f"حجم=${volume_24h:,.0f} (باید >= {FILTER_PARAMS['min_volume_usd']:,})")
            
            # وضعیت
            status = "✅ قبول" if not fails else "❌ رد"
            
            results.append({
                'symbol': symbol,
                'price': current_price,
                'volume': volume_24h,
                'is_active': is_active,
                'market_cap_rank': market_cap_rank,
                'fails': fails,
                'status': status
            })
            
            # نمایش اطلاعات
            print(f"\n{symbol}:")
            print(f"   قیمت: ${current_price:,.8f}")
            print(f"   حجم 24h: ${volume_24h:,.2f}")
            print(f"   is_active: {is_active}")
            print(f"   رتبه مارکت‌کپ: {market_cap_rank}")
            print(f"   وضعیت: {status}")
            
            if fails:
                for fail in fails:
                    print(f"   ❌ دلیل: {fail}")
            else:
                print(f"   ✅ تمام فیلترها passed")
        
        # 4. آمار کلی
        print(f"\n📈 آمار کلی:")
        print("=" * 80)
        
        accepted = [r for r in results if r['status'] == "✅ قبول"]
        rejected = [r for r in results if r['status'] == "❌ رد"]
        
        print(f"تعداد کل: {len(results)}")
        print(f"✅ قبول شده: {len(accepted)}")
        print(f"❌ رد شده: {len(rejected)}")
        
        # 5. تحلیل دلایل رد
        if rejected:
            print(f"\n🔴 تحلیل دلایل رد:")
            print("-" * 80)
            
            # گروه‌بندی بر اساس دلیل
            reasons = {'is_active': [], 'price': [], 'volume': []}
            
            for coin in rejected:
                for fail in coin['fails']:
                    if 'is_active' in fail:
                        reasons['is_active'].append(coin['symbol'])
                    elif 'قیمت' in fail:
                        reasons['price'].append(coin['symbol'])
                    elif 'حجم' in fail:
                        reasons['volume'].append(coin['symbol'])
            
            if reasons['is_active']:
                print(f"\n🚫 دلیل: is_active >= 5")
                print(f"   ارزها: {', '.join(reasons['is_active'])}")
                
            if reasons['price']:
                print(f"\n🚫 دلیل: قیمت کمتر از ${FILTER_PARAMS['min_price']}")
                print(f"   ارزها: {', '.join(reasons['price'])}")
                # نمایش قیمت‌ها
                for symbol in reasons['price']:
                    for coin in rejected:
                        if coin['symbol'] == symbol:
                            print(f"     - {symbol}: ${coin['price']}")
                            break
            
            if reasons['volume']:
                print(f"\n🚫 دلیل: حجم کمتر از ${FILTER_PARAMS['min_volume_usd']:,}")
                print(f"   ارزها: {', '.join(reasons['volume'][:5])}")
                if len(reasons['volume']) > 5:
                    print(f"     ... و {len(reasons['volume']) - 5} ارز دیگر")
                
                # نمایش حجم BTC و BNB اگر در لیست هستند
                for important in ['BTCUSDT', 'BNBUSDT', 'ETHUSDT']:
                    if important in reasons['volume']:
                        for coin in rejected:
                            if coin['symbol'] == important:
                                print(f"\n   ⚠️ هشدار: {important} به دلیل حجم کم رد شده!")
                                print(f"      حجم فعلی: ${coin['volume']:,.0f}")
                                print(f"      حداقل لازم: ${FILTER_PARAMS['min_volume_usd']:,}")
                                print(f"      نسبت: {coin['volume'] / FILTER_PARAMS['min_volume_usd']:.1f}x")
                                break
        
        # 6. نمایش ارزهای قبول شده
        if accepted:
            print(f"\n✅ ارزهای قبول شده:")
            print("-" * 80)
            
            # سورت بر اساس مارکت‌کپ
            accepted.sort(key=lambda x: x['market_cap_rank'] if x['market_cap_rank'] != 9999 else 9999)
            
            for i, coin in enumerate(accepted[:10], 1):
                print(f"{i:2d}. {coin['symbol']:10s} - رتبه: {coin['market_cap_rank']:4d} - حجم: ${coin['volume']:,.0f}")
            
            if len(accepted) > 10:
                print(f"... و {len(accepted) - 10} ارز دیگر")
        
        # 7. پیشنهادات
        print(f"\n💡 پیشنهادات:")
        print("=" * 80)
        
        if rejected:
            # اگر BTC یا BNB رد شده‌اند، این مهمترین مشکل است
            important_rejected = [r for r in rejected if r['symbol'] in ['BTCUSDT', 'BNBUSDT']]
            
            if important_rejected:
                print(f"\n🚨 مشکل بحرانی: BTC و/یا BNB رد شده‌اند!")
                print(f"   این غیرمنطقی است چون این ارزها باید همیشه انتخاب شوند.")
                print(f"\n   دلایل احتمالی:")
                
                for coin in important_rejected:
                    print(f"\n   🔴 {coin['symbol']}:")
                    for fail in coin['fails']:
                        print(f"      • {fail}")
                
                print(f"\n   🛠️ راه حل‌ها:")
                print(f"   1. بررسی داده‌های دیتابیس:")
                print(f"      حجم واقعی BTC باید میلیاردها دلار باشد")
                print(f"   2. تغییر تنظیمات فیلتر:")
                print(f"      کاهش min_volume_usd به 0 یا مقدار بسیار کم")
                print(f"   3. بروزرسانی داده‌های دیتابیس:")
                print(f"      اجرای اسکریپت جمع‌آوری داده‌های تازه")
            else:
                print(f"\n⚠️ برخی ارزها رد شده‌اند اما BTC و BNB مشکل ندارند.")
                print(f"   این ممکن است قابل قبول باشد.")
        
        # 8. کوئری‌های تست
        print(f"\n🔧 کوئری‌های تست برای بررسی بیشتر:")
        print("-" * 80)
        
        print(f"\n1. بررسی ارزهای مهم:")
        print(f"""   SELECT symbol, current_price, volume_24h, is_active 
   FROM crypto_coins 
   WHERE symbol IN ('BTCUSDT', 'BNBUSDT', 'ETHUSDT')
   ORDER BY symbol;""")
        
        print(f"\n2. بررسی ارزهای با حجم بالا:")
        print(f"""   SELECT symbol, volume_24h 
   FROM crypto_coins 
   WHERE volume_24h >= 1000000  -- 1 میلیون دلار
   ORDER BY volume_24h DESC 
   LIMIT 10;""")
        
        print(f"\n3. بررسی ارزهای با is_active نامناسب:")
        print(f"""   SELECT symbol, is_active 
   FROM crypto_coins 
   WHERE is_active >= 5 
   ORDER BY is_active DESC;""")
        
        conn.close()
        return results
        
    except sqlite3.Error as e:
        print(f"❌ خطای دیتابیس: {e}")
        return None
    except Exception as e:
        print(f"❌ خطای ناشناخته: {e}")
        return None

def check_kline_data(db_path, symbols):
    """بررسی داده‌های کندل"""
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        print(f"\n📊 بررسی داده‌های کندل:")
        print("-" * 50)
        
        # بررسی وجود جدول crypto_klines
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='crypto_klines'")
        if not cursor.fetchone():
            print("❌ جدول crypto_klines وجود ندارد")
            print("   این روی last_updated_ts تاثیر می‌گذارد")
            conn.close()
            return
        
        # بررسی تعداد کندل برای ارزهای مهم
        for symbol in ['BTCUSDT', 'BNBUSDT', 'ETHUSDT']:
            cursor.execute("""
                SELECT COUNT(*) 
                FROM crypto_klines k
                JOIN crypto_coins c ON k.coin_id = c.id
                WHERE c.symbol = ? AND k.timeframe = '15m'
            """, (symbol,))
            
            count = cursor.fetchone()[0]
            print(f"   {symbol}: {count} کندل 15 دقیقه‌ای")
        
        conn.close()
        
    except Exception as e:
        print(f"⚠️ خطا در بررسی کندل‌ها: {e}")

def main():
    """تابع اصلی"""
    print("=" * 80)
    print("🔍 دیباگ سیستم فیلترینگ - بررسی ارزهای خاص")
    print("=" * 80)
    
    # 1. پیدا کردن دیتابیس
    print("\n1️⃣ جستجوی فایل دیتابیس...")
    db_path = find_database()
    
    if not db_path:
        print("❌ دیتابیس یافت نشد. برنامه خاتمه می‌یابد.")
        return
    
    # 2. بررسی ساختار
    if not check_database_structure(db_path):
        print("❌ مشکل در ساختار دیتابیس.")
        return
    
    # 3. تحلیل ارزها
    results = analyze_coins(db_path, TARGET_SYMBOLS)
    
    if not results:
        print("❌ خطا در تحلیل ارزها.")
        return
    
    # 4. بررسی داده‌های کندل
    check_kline_data(db_path, TARGET_SYMBOLS)
    
    # 5. خلاصه نهایی
    print("\n" + "=" * 80)
    print("🎯 خلاصه نهایی")
    print("=" * 80)
    
    accepted = sum(1 for r in results if r['status'] == "✅ قبول")
    rejected = sum(1 for r in results if r['status'] == "❌ رد")
    
    print(f"\n📊 آمار نهایی:")
    print(f"   • ارزهای بررسی شده: {len(TARGET_SYMBOLS)}")
    print(f"   • موجود در دیتابیس: {len(results)}")
    print(f"   • قبول شده: {accepted}")
    print(f"   • رد شده: {rejected}")
    
    # بررسی وضعیت BTC و BNB
    btc_status = next((r['status'] for r in results if r['symbol'] == 'BTCUSDT'), 'یافت نشد')
    bnb_status = next((r['status'] for r in results if r['symbol'] == 'BNBUSDT'), 'یافت نشد')
    
    print(f"\n⚠️ وضعیت ارزهای حیاتی:")
    print(f"   • BTCUSDT: {btc_status}")
    print(f"   • BNBUSDT: {bnb_status}")
    
    if btc_status == "❌ رد" or bnb_status == "❌ رد":
        print(f"\n🚨 هشدار: BTC یا BNB رد شده‌اند!")
        print(f"   این نشان‌دهنده مشکل جدی در داده‌ها یا تنظیمات است.")
        print(f"   احتمالاً volume_24h در دیتابیس نادرست است.")
    
    print(f"\n🔚 پایان دیباگ")

if __name__ == "__main__":
    main()