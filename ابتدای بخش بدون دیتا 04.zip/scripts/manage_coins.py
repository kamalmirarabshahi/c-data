#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
دریافت 500 ارز برتر - با فیلترهای کامل
wrapped tokens و stablecoins ذخیره نمی‌شوند
"""

import requests
import sqlite3
import time
import sys
from datetime import datetime
import logging

DB_FILE = r"C:\Users\Kamal\Desktop\py-prg\git\c-data\data\crypto_master.db"

# تنظیمات لاگ
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(message)s',
    datefmt='%H:%M:%S'
)
logger = logging.getLogger(__name__)

def is_valid_main_coin(coin_data):
    """بررسی کامل - مانند نسخه اول"""
    symbol = str(coin_data['symbol']).upper()
    name = str(coin_data['name']).lower()
    
    # لیست wrapped tokens
    wrapped_keywords = [
        'wrapped', 'bridged', 'staked', 'vault', 'tokenized',
        'weth', 'wbtc', 'wbnb', 'wmatic', 'wavax', 'wsol',
        'cb', 'binance', 'coinbase', 'polygon', 'avalanche',
        'wormhole', 'cross-chain', 'multichain', 'liquid',
        'ren', 'fantom', 'moonriver', 'moonbeam', 'celer',
        'ankr', 'axelar', 'layerzero', 'stargate'
    ]
    
    # بررسی نام
    for keyword in wrapped_keywords:
        if keyword in name:
            return False
    
    # بررسی symbolهای wrapped
    wrapped_symbols = [
        'WBTC', 'WETH', 'WBNB', 'WMATIC', 'WAVAX', 'WSOL', 'WDOT',
        'CBETH', 'BTCB', 'STETH', 'JITOSOL', 'STSOL', 'MSOL',
        'WSTETH', 'WEETH', 'WBETH', 'CBBTC', 'CBETH', 'TBTC',
        'RENBTC', 'HBTC', 'SBTC', 'BBTC', 'OBTC', 'PBTC',
        'LDO', 'RETH', 'FRXETH', 'SFRXETH', 'RPL', 'SWISE'
    ]
    
    if symbol in wrapped_symbols:
        return False
    
    # حذف stablecoins (به جز USDT که خودش stablecoin است)
    stablecoin_symbols = ['USDC', 'DAI', 'BUSD', 'TUSD', 'USDP', 'USDN', 'GUSD']
    if symbol in stablecoin_symbols:
        return False
    
    # حذف ارزهای با کاراکترهای خاص
    if '-' in symbol or '.' in symbol or '_' in symbol or ' ' in symbol:
        return False
    
    # حذف ارزهای با اعداد در ابتدا
    if symbol and symbol[0].isdigit():
        return False
    
    # حذف نمادهای خیلی کوتاه یا خیلی طولانی
    if len(symbol) < 2 or len(symbol) > 8:
        return False
    
    return True

def add_usdt_if_needed(symbol):
    """اضافه کردن USDT اگر نیاز باشد"""
    symbol_upper = symbol.upper().strip()
    
    if symbol_upper.endswith('USDT'):
        return symbol_upper
    elif symbol_upper.endswith('usdt'):
        base = symbol_upper[:-4]
        return f"{base}USDT"
    else:
        return f"{symbol_upper}USDT"

def fetch_filtered_coins():
    """دریافت ارزها با فیلتر"""
    logger.info("📥 دریافت ارزهای برتر (با فیلتر)...")
    
    all_coins = []
    page = 1
    per_page = 100
    
    while len(all_coins) < 500 and page <= 5:
        logger.info(f"📄 صفحه {page}...")
        
        params = {
            'vs_currency': 'usd',
            'order': 'market_cap_desc',
            'per_page': per_page,
            'page': page,
            'sparkline': False
        }
        
        try:
            response = requests.get(
                "https://api.coingecko.com/api/v3/coins/markets",
                params=params,
                timeout=30
            )
            
            if response.status_code == 200:
                coins = response.json()
                
                # اعمال فیلتر
                filtered_coins = [c for c in coins if is_valid_main_coin(c)]
                
                logger.info(f"   دریافت: {len(coins)} | اصلی: {len(filtered_coins)}")
                all_coins.extend(filtered_coins)
            else:
                logger.error(f"❌ خطای API: {response.status_code}")
                break
                
        except Exception as e:
            logger.error(f"❌ خطای شبکه: {e}")
            break
        
        # تاخیر برای rate limit
        if page < 5:
            time.sleep(10)
        
        page += 1
    
    # محدود کردن به 500 ارز
    final_coins = all_coins[:500]
    logger.info(f"✅ {len(final_coins)} ارز اصلی (فیلتر شده) دریافت شد")
    
    return final_coins

def save_coins_filtered(coins):
    """ذخیره ارزهای فیلتر شده"""
    logger.info("💾 ذخیره ارزهای فیلتر شده...")
    
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    
    # پاک کردن جدول قبلی
    cursor.execute("DELETE FROM crypto_coins")
    logger.info("🗑️  جدول قبلی پاک شد")
    
    saved = 0
    rejected = 0
    
    for i, coin in enumerate(coins, 1):
        try:
            symbol = str(coin['symbol']).upper()
            binance_symbol = add_usdt_if_needed(symbol)
            base_asset = binance_symbol.replace('USDT', '')
            
            # INSERT با INSERT OR REPLACE
            cursor.execute('''
                INSERT OR REPLACE INTO crypto_coins 
                (symbol, base_asset, coin_name, coingecko_id,
                 current_price, price_change_24h, price_change_percent_24h,
                 high_24h, low_24h, volume_24h, market_cap, market_cap_rank,
                 circulating_supply, total_supply, max_supply, last_updated)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                binance_symbol,
                base_asset,
                coin['name'],
                coin['id'],
                coin.get('current_price', 0.0) or 0.0,
                coin.get('price_change_24h', 0.0) or 0.0,
                coin.get('price_change_percentage_24h', 0.0) or 0.0,
                coin.get('high_24h', 0.0) or 0.0,
                coin.get('low_24h', 0.0) or 0.0,
                coin.get('total_volume', 0.0) or 0.0,
                coin.get('market_cap', 0.0) or 0.0,
                coin.get('market_cap_rank', 9999) or 9999,
                coin.get('circulating_supply', 0.0) or 0.0,
                coin.get('total_supply', 0.0) or 0.0,
                coin.get('max_supply', 0.0) or 0.0,
                coin.get('last_updated', '')
            ))
            
            saved += 1
            
            if i % 50 == 0:
                logger.info(f"📝 {i} ارز پردازش شد...")
                
        except Exception as e:
            logger.warning(f"⚠️  خطا در {coin.get('symbol', 'unknown')}: {str(e)[:50]}")
            rejected += 1
            continue
    
    conn.commit()
    
    # آمار نهایی
    cursor.execute("SELECT COUNT(*) FROM crypto_coins")
    total = cursor.fetchone()[0]
    
    cursor.execute("SELECT symbol FROM crypto_coins ORDER BY market_cap_rank ASC LIMIT 10")
    top_symbols = [row[0] for row in cursor.fetchall()]
    
    conn.close()
    
    return saved, rejected, total, top_symbols

def main():
    """تابع اصلی"""
    print("=" * 60)
    print("🔄 سیستم دریافت ارزها - با فیلترهای کامل")
    print("=" * 60)
    print(f"📅 {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("💾 فقط ارزهای اصلی (نه wrapped/stablecoins)")
    print("=" * 60)
    
    print("\nفیلترهای اعمال شده:")
    print("• ❌ Wrapped tokens (WBTC, WETH, etc)")
    print("• ❌ Stablecoins (USDC, DAI, BUSD, etc)")
    print("• ❌ نمادهای با کاراکترهای خاص")
    print("• ✅ اضافه کردن خودکار USDT")
    
    confirm = input("\nادامه؟ (y/n): ").strip().lower()
    if confirm != 'y':
        print("❌ لغو شد")
        return
    
    try:
        # دریافت ارزهای فیلتر شده
        coins = fetch_filtered_coins()
        
        if not coins:
            print("❌ هیچ ارز اصلی دریافت نشد!")
            return
        
        print(f"\n✅ {len(coins)} ارز اصلی (فیلتر شده) دریافت شد")
        
        # ذخیره
        saved, rejected, total, top_symbols = save_coins_filtered(coins)
        
        # نمایش نتیجه
        print("\n" + "=" * 60)
        print("📊 نتیجه:")
        print("=" * 60)
        print(f"• دریافت شده: {len(coins)} ارز")
        print(f"• ذخیره شده: {saved} ارز")
        print(f"• رد شده: {rejected} ارز")
        print(f"• کل در دیتابیس: {total} ارز")
        
        print(f"\n🏆 10 ارز برتر:")
        for i, symbol in enumerate(top_symbols, 1):
            print(f"  {i:2}. {symbol}")
        
        print(f"\n✅ تکمیل شد در {datetime.now().strftime('%H:%M:%S')}")
        
    except KeyboardInterrupt:
        print("\n\n❌ توسط کاربر لغو شد")
    except Exception as e:
        print(f"\n❌ خطا: {e}")

if __name__ == "__main__":
    main()