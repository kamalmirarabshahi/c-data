# scripts/run_cycle_03.py
import sys
import os

# اضافه کردن مسیر پروژه
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

print("🚀 اجرای تکه 03: تحلیل اولیه داده‌ها")
print("=" * 50)

try:
    from scripts.cycle.cycle_03_analyze_block import main
    
    success = main()
    
    if success:
        print("\n✅ تکه 03 با موفقیت اجرا شد!")
        print("📊 داده‌های کیفیت تحلیل و ذخیره شدند")
        print("📈 گزارش آماده در پوشه reports/")
        print("🔄 آماده برای تکه 04...")
    else:
        print("\n❌ اجرای تکه 03 با خطا مواجه شد")
        
except Exception as e:
    print(f"❌ خطا در وارد کردن یا اجرای تکه 03: {e}")
    import traceback
    traceback.print_exc()