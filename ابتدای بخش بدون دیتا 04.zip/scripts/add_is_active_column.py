"""
فایل: add_is_active_column.py
مسیر: scripts/add_is_active_column.py
عملکرد: ایجاد ستون is_active در جدول crypto_coins
تاریخ: 2024-01-15
"""

import sqlite3
import os
import sys
from datetime import datetime

def add_is_active_column():
    """ایجاد ستون is_active در جدول crypto_coins"""
    print("=" * 60)
    print("🔧 ایجاد ستون is_active در جدول crypto_coins")
    print("=" * 60)
    
    # مسیر دیتابیس
    db_path = r"C:\Users\Kamal\Desktop\py-prg\git\c-data\data\crypto_master.db"
    
    # بررسی وجود فایل دیتابیس
    if not os.path.exists(db_path):
        print(f"❌ فایل دیتابیس یافت نشد: {db_path}")
        return False
    
    print(f"📁 مسیر دیتابیس: {db_path}")
    print(f"📊 اندازه فایل: {os.path.getsize(db_path):,} بایت")
    
    try:
        # اتصال به دیتابیس
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # 1. بررسی وجود جدول crypto_coins
        print("\n1️⃣ بررسی جدول crypto_coins...")
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='crypto_coins'")
        if not cursor.fetchone():
            print("❌ جدول crypto_coins وجود ندارد!")
            conn.close()
            return False
        print("✅ جدول crypto_coins موجود است")
        
        # 2. بررسی ستون‌های موجود
        print("\n2️⃣ بررسی ستون‌های موجود...")
        cursor.execute("PRAGMA table_info(crypto_coins)")
        columns = cursor.fetchall()
        
        column_names = [col[1] for col in columns]
        print(f"📋 تعداد ستون‌ها: {len(columns)}")
        
        # نمایش ستون‌های موجود
        print("\n📊 ستون‌های موجود:")
        for i, col in enumerate(columns, 1):
            col_id, name, col_type, not_null, default_val, pk = col
            print(f"  {i:2d}. {name:20s} ({col_type:10s}) - PK: {pk}, NotNull: {not_null}")
        
        # 3. بررسی وجود ستون is_active
        if 'is_active' in column_names:
            print("\n⚠️ ستون is_active از قبل وجود دارد")
            
            # بررسی نوع داده ستون
            for col in columns:
                if col[1] == 'is_active':
                    print(f"   نوع فعلی: {col[2]}")
                    print(f"   مقدار پیش‌فرض: {col[4]}")
                    
                    # اگر نوع INTEGER نیست، آن را تغییر بده
                    if col[2].upper() != 'INTEGER':
                        print("   🔄 تغییر نوع ستون به INTEGER...")
                        cursor.execute("""
                        ALTER TABLE crypto_coins 
                        DROP COLUMN is_active
                        """)
                        print("   ✅ ستون قدیمی حذف شد")
                    else:
                        print("   ✅ ستون از نوع INTEGER است")
                        # فقط مقدار پیش‌فرض را به‌روزرسانی کن
                        cursor.execute("""
                        UPDATE crypto_coins 
                        SET is_active = 1 
                        WHERE is_active IS NULL OR is_active NOT BETWEEN 1 AND 5
                        """)
                        updated = cursor.rowcount
                        print(f"   🔄 {updated} رکورد به‌روزرسانی شد")
                        conn.commit()
                        return True
        else:
            print("\n✅ ستون is_active وجود ندارد - در حال ایجاد...")
        
        # 4. ایجاد ستون جدید
        print("\n3️⃣ ایجاد ستون is_active...")
        
        # اگر ستون وجود نداشت یا حذف شد، ایجاد کن
        cursor.execute("""
        ALTER TABLE crypto_coins 
        ADD COLUMN is_active INTEGER 
        DEFAULT 1 
        CHECK (is_active BETWEEN 1 AND 5)
        """)
        
        print("✅ ستون is_active با موفقیت ایجاد شد")
        print("   📝 نوع: INTEGER")
        print("   📝 محدوده: 1 تا 5")
        print("   📝 پیش‌فرض: 1")
        
        # 5. ایجاد index برای بهبود عملکرد
        print("\n4️⃣ ایجاد ایندکس برای بهبود عملکرد...")
        try:
            cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_crypto_coins_is_active 
            ON crypto_coins(is_active)
            """)
            print("✅ ایندکس ایجاد شد")
        except Exception as e:
            print(f"⚠️ خطا در ایجاد ایندکس: {e}")
        
        # 6. آمار دیتابیس
        print("\n5️⃣ آمار دیتابیس...")
        
        # تعداد رکوردها
        cursor.execute("SELECT COUNT(*) FROM crypto_coins")
        total_records = cursor.fetchone()[0]
        print(f"📊 کل رکوردها: {total_records}")
        
        # توزیع مقادیر is_active
        cursor.execute("""
        SELECT 
            is_active,
            COUNT(*) as count,
            ROUND(COUNT(*) * 100.0 / ?, 2) as percentage
        FROM crypto_coins 
        GROUP BY is_active 
        ORDER BY is_active
        """, (total_records,))
        
        distribution = cursor.fetchall()
        
        print("\n📈 توزیع مقادیر is_active:")
        if distribution:
            for status, count, percentage in distribution:
                print(f"   is_active = {status}: {count:,} رکورد ({percentage}%)")
        else:
            print("   هنوز داده‌ای ثبت نشده است")
        
        # 7. ذخیره تغییرات
        conn.commit()
        print("\n✅ تغییرات با موفقیت ذخیره شد")
        
        # 8. اعتبارسنجی
        print("\n6️⃣ اعتبارسنجی...")
        
        # بررسی محدوده مقادیر
        cursor.execute("SELECT MIN(is_active), MAX(is_active) FROM crypto_coins")
        min_val, max_val = cursor.fetchone()
        print(f"   حداقل مقدار: {min_val}")
        print(f"   حداکثر مقدار: {max_val}")
        
        if min_val >= 1 and max_val <= 5:
            print("✅ محدوده مقادیر معتبر است")
        else:
            print("⚠️ برخی مقادیر خارج از محدوده هستند")
        
        # بررسی مقادیر NULL
        cursor.execute("SELECT COUNT(*) FROM crypto_coins WHERE is_active IS NULL")
        null_count = cursor.fetchone()[0]
        print(f"   مقادیر NULL: {null_count}")
        
        # بستن اتصال
        conn.close()
        
        print("\n" + "=" * 60)
        print("🎉 عملیات با موفقیت تکمیل شد!")
        print("=" * 60)
        
        return True
        
    except sqlite3.Error as e:
        print(f"\n❌ خطای دیتابیس: {e}")
        return False
    except Exception as e:
        print(f"\n❌ خطای ناشناخته: {e}")
        return False

def create_test_data():
    """ایجاد داده‌های تست برای بررسی عملکرد"""
    print("\n" + "=" * 60)
    print("🧪 ایجاد داده‌های تست")
    print("=" * 60)
    
    db_path = r"C:\Users\Kamal\Desktop\py-prg\git\c-data\data\crypto_master.db"
    
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # 1. بررسی وضعیت فعلی
        print("\n1️⃣ وضعیت فعلی:")
        cursor.execute("SELECT is_active, COUNT(*) FROM crypto_coins GROUP BY is_active ORDER BY is_active")
        status_counts = cursor.fetchall()
        
        if status_counts:
            print("📊 توزیع فعلی:")
            for status, count in status_counts:
                print(f"   is_active={status}: {count} رکورد")
        else:
            print("   داده‌ای وجود ندارد")
        
        # 2. ایجاد مقادیر متنوع برای تست
        print("\n2️⃣ به‌روزرسانی مقادیر برای تست...")
        
        # به‌روزرسانی 10 رکورد تصادفی با مقادیر مختلف
        cursor.execute("""
        UPDATE crypto_coins 
        SET is_active = 
            CASE 
                WHEN rowid % 5 = 0 THEN 5
                WHEN rowid % 4 = 0 THEN 4
                WHEN rowid % 3 = 0 THEN 3
                WHEN rowid % 2 = 0 THEN 2
                ELSE 1
            END
        WHERE rowid IN (
            SELECT rowid FROM crypto_coins 
            ORDER BY RANDOM() 
            LIMIT 100
        )
        """)
        
        updated_count = cursor.rowcount
        print(f"✅ {updated_count} رکورد به‌روزرسانی شد")
        
        # 3. نمایش نتایج
        print("\n3️⃣ نتایج نهایی:")
        
        cursor.execute("""
        SELECT 
            is_active,
            COUNT(*) as count,
            ROUND(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM crypto_coins), 2) as percentage
        FROM crypto_coins 
        GROUP BY is_active 
        ORDER BY is_active
        """)
        
        results = cursor.fetchall()
        
        print("\n📈 توزیع نهایی is_active:")
        for status, count, percentage in results:
            stars = "★" * status
            print(f"   {stars:5s} ({status}): {count:6,d} رکورد ({percentage:5.1f}%)")
        
        # 4. مثال‌هایی از ارزها با وضعیت‌های مختلف
        print("\n4️⃣ نمونه‌ای از ارزها:")
        
        cursor.execute("""
        SELECT symbol, base_asset, current_price, volume_24h, is_active
        FROM crypto_coins 
        WHERE is_active IN (1, 3, 5)
        ORDER BY is_active DESC, volume_24h DESC
        LIMIT 9
        """)
        
        samples = cursor.fetchall()
        
        print("\n🔝 9 ارز نمونه:")
        print("-" * 80)
        print(f"{'نماد':10s} {'نام':10s} {'قیمت':12s} {'حجم 24h':15s} {'وضعیت'}")
        print("-" * 80)
        
        for symbol, name, price, volume, status in samples:
            status_str = {
                1: "📊 پایه",
                2: "📈 متوسط",
                3: "📉 فعال",
                4: "🔥 پرریسک",
                5: "⚡ بسیار فعال"
            }.get(status, "نامشخص")
            
            print(f"{symbol:10s} {name:10s} ${price:10,.2f} ${volume:14,.0f} {status} ({status_str})")
        
        conn.commit()
        conn.close()
        
        print("\n✅ داده‌های تست با موفقیت ایجاد شدند")
        return True
        
    except Exception as e:
        print(f"❌ خطا در ایجاد داده‌های تست: {e}")
        return False

def verify_constraints():
    """بررسی اعتبار محدودیت‌ها"""
    print("\n" + "=" * 60)
    print("🔍 بررسی اعتبار محدودیت‌ها")
    print("=" * 60)
    
    db_path = r"C:\Users\Kamal\Desktop\py-prg\git\c-data\data\crypto_master.db"
    
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        print("\n1️⃣ بررسی مقادیر خارج از محدوده...")
        
        # مقادیر خارج از محدوده 1-5
        cursor.execute("""
        SELECT COUNT(*) 
        FROM crypto_coins 
        WHERE is_active IS NOT NULL 
        AND (is_active < 1 OR is_active > 5)
        """)
        
        invalid_count = cursor.fetchone()[0]
        
        if invalid_count > 0:
            print(f"⚠️ {invalid_count} رکورد با مقادیر خارج از محدوده یافت شد")
            
            # نمایش نمونه‌هایی از مقادیر نامعتبر
            cursor.execute("""
            SELECT symbol, is_active 
            FROM crypto_coins 
            WHERE is_active IS NOT NULL 
            AND (is_active < 1 OR is_active > 5)
            LIMIT 5
            """)
            
            invalid_samples = cursor.fetchall()
            print("   نمونه‌هایی از مقادیر نامعتبر:")
            for symbol, status in invalid_samples:
                print(f"   - {symbol}: {status}")
        else:
            print("✅ هیچ مقدار خارج از محدوده یافت نشد")
        
        print("\n2️⃣ بررسی مقادیر NULL...")
        
        cursor.execute("SELECT COUNT(*) FROM crypto_coins WHERE is_active IS NULL")
        null_count = cursor.fetchone()[0]
        
        if null_count > 0:
            print(f"⚠️ {null_count} رکورد با مقدار NULL یافت شد")
        else:
            print("✅ هیچ مقدار NULL یافت نشد")
        
        print("\n3️⃣ بررسی عملکرد ایندکس...")
        
        cursor.execute("""
        SELECT name 
        FROM sqlite_master 
        WHERE type='index' 
        AND name LIKE '%is_active%'
        """)
        
        indexes = cursor.fetchall()
        
        if indexes:
            print(f"✅ {len(indexes)} ایندکس برای is_active یافت شد:")
            for idx in indexes:
                print(f"   - {idx[0]}")
        else:
            print("⚠️ ایندکسی برای is_active یافت نشد")
        
        conn.close()
        
        print("\n✅ بررسی اعتبار با موفقیت انجام شد")
        return True
        
    except Exception as e:
        print(f"❌ خطا در بررسی اعتبار: {e}")
        return False

if __name__ == "__main__":
    print("\n🚀 شروع عملیات مدیریت ستون is_active")
    print("-" * 60)
    
    # 1. ایجاد ستون is_active
    success = add_is_active_column()
    
    if success:
        # 2. ایجاد داده‌های تست (اختیاری)
        response = input("\n🧪 آیا می‌خواهید داده‌های تست ایجاد کنید؟ (y/n): ")
        if response.lower() == 'y':
            create_test_data()
        
        # 3. بررسی اعتبار محدودیت‌ها
        response = input("\n🔍 آیا می‌خواهید محدودیت‌ها را بررسی کنید؟ (y/n): ")
        if response.lower() == 'y':
            verify_constraints()
        
        print("\n" + "=" * 60)
        print("🎉 عملیات کامل شد!")
        print("=" * 60)
        print("\n📌 اکنون می‌توانید:")
        print("   1. از تکه 01 استفاده کنید")
        print("   2. ارزها را بر اساس is_active فیلتر کنید")
        print("   3. وضعیت‌های مختلف را مدیریت کنید")
    else:
        print("\n❌ عملیات ناموفق بود. لطفاً خطاها را بررسی کنید.")