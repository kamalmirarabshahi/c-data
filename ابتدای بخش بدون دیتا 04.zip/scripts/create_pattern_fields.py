#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
create_pattern_fields.py - اسکریپت ایجاد فیلدها و جداول جدید برای PatternDetector
📝 هدف: افزودن ۲۵ فیلد جدید در ۴ جدول برای پشتیبانی کامل از تحلیل الگوهای قیمتی
🔄 سازگاری: با ساختار موجود دیتابیس کاملاً سازگار است
"""

import sqlite3
import os
import sys
from datetime import datetime
import logging
from typing import Dict

# تنظیمات لاگ‌گیری
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('create_pattern_fields.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class DatabasePatternUpdater:
    """
    کلاس بروزرسانی دیتابیس برای افزودن فیلدهای PatternDetector
    """
    
    def __init__(self, db_path: str):
        """
        مقداردهی اولیه
        
        Args:
            db_path: مسیر فایل دیتابیس
        """
        self.db_path = db_path
        self.connection = None
        self.cursor = None
        
        logger.info(f"🔧 راه‌اندازی بروزرسانی دیتابیس")
        logger.info(f"🗄️ مسیر دیتابیس: {db_path}")
    
    def connect(self) -> bool:
        """
        اتصال به دیتابیس
        
        Returns:
            bool: موفقیت اتصال
        """
        try:
            if not os.path.exists(self.db_path):
                logger.error(f"❌ فایل دیتابیس یافت نشد: {self.db_path}")
                return False
            
            self.connection = sqlite3.connect(self.db_path)
            self.connection.row_factory = sqlite3.Row
            self.cursor = self.connection.cursor()
            
            # فعال کردن foreign keys
            self.cursor.execute("PRAGMA foreign_keys = ON")
            
            logger.info("✅ اتصال به دیتابیس برقرار شد")
            return True
            
        except sqlite3.Error as e:
            logger.error(f"❌ خطا در اتصال به دیتابیس: {e}")
            return False
    
    def disconnect(self):
        """قطع اتصال از دیتابیس"""
        if self.connection:
            self.connection.close()
            logger.info("🔌 اتصال به دیتابیس قطع شد")
    
    def check_table_exists(self, table_name: str) -> bool:
        """
        بررسی وجود جدول
        
        Args:
            table_name: نام جدول
            
        Returns:
            bool: وجود دارد یا نه
        """
        try:
            self.cursor.execute(
                "SELECT name FROM sqlite_master WHERE type='table' AND name=?",
                (table_name,)
            )
            return self.cursor.fetchone() is not None
            
        except sqlite3.Error as e:
            logger.error(f"❌ خطا در بررسی وجود جدول {table_name}: {e}")
            return False
    
    def check_column_exists(self, table_name: str, column_name: str) -> bool:
        """
        بررسی وجود ستون در جدول
        
        Args:
            table_name: نام جدول
            column_name: نام ستون
            
        Returns:
            bool: وجود دارد یا نه
        """
        try:
            self.cursor.execute(f"PRAGMA table_info({table_name})")
            columns = self.cursor.fetchall()
            
            for col in columns:
                if col[1] == column_name:  # نام ستون در index 1 است
                    return True
            return False
            
        except sqlite3.Error as e:
            logger.error(f"❌ خطا در بررسی ستون {column_name} در جدول {table_name}: {e}")
            return False
    
    def create_table_pattern_analysis(self) -> bool:
        """
        ایجاد جدول جدید pattern_analysis
        
        Returns:
            bool: موفقیت عملیات
        """
        table_name = "pattern_analysis"
        
        # بررسی وجود جدول
        if self.check_table_exists(table_name):
            logger.info(f"📊 جدول {table_name} از قبل وجود دارد")
            return True
        
        try:
            # ایجاد جدول جدید
            create_table_sql = """
            CREATE TABLE pattern_analysis (
                -- شناسه اولیه
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                
                -- ارتباط با ارز
                coin_id INTEGER NOT NULL,
                symbol TEXT NOT NULL,
                timeframe TEXT NOT NULL,
                
                -- زمان تشخیص
                detection_time TIMESTAMP NOT NULL,
                analysis_duration_ms INTEGER,
                
                -- اطلاعات الگو
                pattern_type TEXT NOT NULL,
                pattern_name TEXT NOT NULL,
                pattern_direction TEXT NOT NULL,
                pattern_confidence INTEGER NOT NULL CHECK (pattern_confidence >= 0 AND pattern_confidence <= 100),
                
                -- ویژگی‌های الگو
                pattern_breakout BOOLEAN DEFAULT 0,
                target_price REAL,
                neckline_price REAL,
                pattern_peaks_json TEXT,
                
                -- کیفیت تحلیل
                historical_performance_score REAL CHECK (historical_performance_score >= 0 AND historical_performance_score <= 1),
                volume_confirmation_score INTEGER CHECK (volume_confirmation_score >= 0 AND volume_confirmation_score <= 100),
                indicator_confirmation_score INTEGER CHECK (indicator_confirmation_score >= 0 AND indicator_confirmation_score <= 100),
                
                -- داده‌های تکمیلی
                pattern_details_json TEXT,
                market_context_json TEXT,
                
                -- متادیتا
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                
                -- محدودیت‌های یکتایی
                UNIQUE(coin_id, timeframe, detection_time, pattern_type),
                
                -- کلیدهای خارجی
                FOREIGN KEY (coin_id) REFERENCES crypto_coins (id)
                    ON DELETE CASCADE
                    ON UPDATE CASCADE
            )
            """
            
            self.cursor.execute(create_table_sql)
            
            # ایجاد ایندکس‌ها برای جدول جدید
            indexes = [
                "CREATE INDEX idx_pattern_analysis_coin ON pattern_analysis(coin_id)",
                "CREATE INDEX idx_pattern_analysis_symbol ON pattern_analysis(symbol)",
                "CREATE INDEX idx_pattern_analysis_type ON pattern_analysis(pattern_type)",
                "CREATE INDEX idx_pattern_analysis_confidence ON pattern_analysis(pattern_confidence)",
                "CREATE INDEX idx_pattern_analysis_time ON pattern_analysis(detection_time)",
                "CREATE INDEX idx_pattern_analysis_coin_time ON pattern_analysis(coin_id, detection_time)"
            ]
            
            for index_sql in indexes:
                try:
                    self.cursor.execute(index_sql)
                except sqlite3.Error as e:
                    logger.warning(f"⚠️ خطا در ایجاد ایندکس: {e}")
            
            self.connection.commit()
            logger.info(f"✅ جدول {table_name} با موفقیت ایجاد شد")
            return True
            
        except sqlite3.Error as e:
            logger.error(f"❌ خطا در ایجاد جدول {table_name}: {e}")
            return False
    
    def add_column_to_table(self, table_name: str, column_def: str) -> bool:
        """
        افزودن ستون جدید به جدول موجود
        
        Args:
            table_name: نام جدول
            column_def: تعریف ستون (مثال: "pattern_type TEXT")
            
        Returns:
            bool: موفقیت عملیات
        """
        # استخراج نام ستون از تعریف
        column_name = column_def.split()[0]
        
        # بررسی وجود ستون
        if self.check_column_exists(table_name, column_name):
            logger.info(f"📝 ستون {column_name} در جدول {table_name} از قبل وجود دارد")
            return True
        
        try:
            # استفاده از ALTER TABLE برای افزودن ستون
            alter_sql = f"ALTER TABLE {table_name} ADD COLUMN {column_def}"
            self.cursor.execute(alter_sql)
            self.connection.commit()
            
            logger.info(f"✅ ستون {column_name} به جدول {table_name} اضافه شد")
            return True
            
        except sqlite3.Error as e:
            logger.error(f"❌ خطا در افزودن ستون {column_name} به جدول {table_name}: {e}")
            return False
    
    def add_trading_signals_columns(self) -> bool:
        """
        افزودن ۸ ستون جدید به جدول trading_signals
        
        Returns:
            bool: موفقیت عملیات
        """
        table_name = "trading_signals"
        columns = [
            # نام ستون، نوع، توضیحات
            ("pattern_type", "TEXT", "نوع الگوی شناسایی شده"),
            ("pattern_confidence", "INTEGER", "اعتماد به الگو (۰-۱۰۰)"),
            ("pattern_direction", "TEXT", "جهت الگو: bullish, bearish, neutral"),
            ("pattern_breakout", "BOOLEAN DEFAULT 0", "وضعیت شکست الگو"),
            ("pattern_target_price", "REAL", "قیمت هدف پیش‌بینی شده"),
            ("pattern_neckline_price", "REAL", "قیمت خط گردن (برای الگوهای خاص)"),
            ("pattern_peaks_json", "TEXT", "JSON موقعیت قله‌ها و دره‌ها"),
            ("pattern_features_json", "TEXT", "JSON ویژگی‌های اضافی الگو")
        ]
        
        logger.info(f"🔄 شروع افزودن ستون‌ها به جدول {table_name}")
        
        success_count = 0
        for column_name, column_type, description in columns:
            column_def = f"{column_name} {column_type}"
            
            if self.add_column_to_table(table_name, column_def):
                success_count += 1
                logger.debug(f"  ➕ {column_name}: {description}")
        
        logger.info(f"📊 {success_count}/{len(columns)} ستون به {table_name} اضافه شد")
        return success_count == len(columns)
    
    def add_crypto_klines_columns(self) -> bool:
        """
        افزودن ۴ ستون جدید به جدول crypto_klines
        
        Returns:
            bool: موفقیت عملیات
        """
        table_name = "crypto_klines"
        columns = [
            ("pattern_markers", "TEXT", "نشانگرهای الگو در این کندل"),
            ("pattern_confidence", "REAL", "احتمال تعلق به الگو (۰-۱)"),
            ("trend_strength", "REAL", "قدرت روند (مثبت: صعودی، منفی: نزولی)"),
            ("support_resistance_level", "REAL", "نزدیک‌ترین سطح حمایت/مقاومت")
        ]
        
        logger.info(f"🔄 شروع افزودن ستون‌ها به جدول {table_name}")
        
        success_count = 0
        for column_name, column_type, description in columns:
            column_def = f"{column_name} {column_type}"
            
            if self.add_column_to_table(table_name, column_def):
                success_count += 1
                logger.debug(f"  ➕ {column_name}: {description}")
        
        logger.info(f"📊 {success_count}/{len(columns)} ستون به {table_name} اضافه شد")
        return success_count == len(columns)
    
    def add_technical_indicators_columns(self) -> bool:
        """
        افزودن ۴ ستون جدید به جدول technical_indicators
        
        Returns:
            bool: موفقیت عملیات
        """
        table_name = "technical_indicators"
        columns = [
            ("pattern_confirmation_score", "INTEGER", "امتیاز تأیید الگو توسط اندیکاتورها (۰-۱۰۰)"),
            ("trend_confirmation", "TEXT", "وضعیت تأیید روند: bullish_confirmed, bearish_confirmed, neutral, conflict"),
            ("volume_anomaly", "BOOLEAN DEFAULT 0", "وجود ناهنجاری حجمی"),
            ("breakout_potential", "REAL", "پتانسیل شکست قیمتی (۰-۱)")
        ]
        
        logger.info(f"🔄 شروع افزودن ستون‌ها به جدول {table_name}")
        
        success_count = 0
        for column_name, column_type, description in columns:
            column_def = f"{column_name} {column_type}"
            
            if self.add_column_to_table(table_name, column_def):
                success_count += 1
                logger.debug(f"  ➕ {column_name}: {description}")
        
        logger.info(f"📊 {success_count}/{len(columns)} ستون به {table_name} اضافه شد")
        return success_count == len(columns)
    
    def create_indexes_for_new_columns(self) -> bool:
        """
        ایجاد ایندکس‌های بهینه برای ستون‌های جدید
        
        Returns:
            bool: موفقیت عملیات
        """
        try:
            indexes = [
                # ایندکس‌های trading_signals
                ("trading_signals", "idx_signal_pattern_type", "pattern_type"),
                ("trading_signals", "idx_signal_pattern_confidence", "pattern_confidence"),
                ("trading_signals", "idx_signal_pattern_direction", "pattern_direction"),
                
                # ایندکس‌های crypto_klines
                ("crypto_klines", "idx_klines_pattern_markers", "pattern_markers"),
                ("crypto_klines", "idx_klines_trend_strength", "trend_strength"),
                
                # ایندکس‌های technical_indicators
                ("technical_indicators", "idx_indicators_pattern_score", "pattern_confirmation_score"),
                
                # ایندکس‌های pattern_analysis
                ("pattern_analysis", "idx_pattern_analysis_type_confidence", "pattern_type, pattern_confidence"),
                ("pattern_analysis", "idx_pattern_analysis_detection_time", "detection_time"),
                ("pattern_analysis", "idx_pattern_analysis_breakout", "pattern_breakout")
            ]
            
            logger.info("🔄 شروع ایجاد ایندکس‌های بهینه")
            
            success_count = 0
            for table_name, index_name, columns in indexes:
                try:
                    # بررسی وجود ایندکس
                    self.cursor.execute(
                        "SELECT name FROM sqlite_master WHERE type='index' AND name=?",
                        (index_name,)
                    )
                    
                    if self.cursor.fetchone() is None:
                        # ایجاد ایندکس جدید
                        create_index_sql = f"CREATE INDEX {index_name} ON {table_name}({columns})"
                        self.cursor.execute(create_index_sql)
                        logger.debug(f"  📈 ایندکس {index_name} ایجاد شد")
                        success_count += 1
                    else:
                        logger.debug(f"  ⚡ ایندکس {index_name} از قبل وجود دارد")
                        
                except sqlite3.Error as e:
                    logger.warning(f"⚠️ خطا در ایجاد ایندکس {index_name}: {e}")
            
            self.connection.commit()
            logger.info(f"✅ {success_count} ایندکس جدید ایجاد شد")
            return True
            
        except sqlite3.Error as e:
            logger.error(f"❌ خطا در ایجاد ایندکس‌ها: {e}")
            return False
    
    def backup_database(self) -> bool:
        """
        ایجاد بک‌آپ از دیتابیس قبل از تغییرات
        
        Returns:
            bool: موفقیت عملیات
        """
        try:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            backup_path = f"{self.db_path}.backup_{timestamp}"
            
            # اتصال به دیتابیس بک‌آپ
            backup_conn = sqlite3.connect(backup_path)
            
            # کپی کردن دیتابیس اصلی به بک‌آپ
            with backup_conn:
                for line in self.connection.iterdump():
                    if line.strip():
                        backup_conn.execute(line)
            
            backup_conn.commit()
            backup_conn.close()
            
            logger.info(f"💾 بک‌آپ ایجاد شد: {backup_path}")
            return True
            
        except Exception as e:
            logger.error(f"❌ خطا در ایجاد بک‌آپ: {e}")
            return False
    
    def verify_changes(self) -> Dict:
        """
        تأیید تغییرات اعمال شده
        
        Returns:
            Dict: گزارش تأیید
        """
        verification = {
            'tables_created': [],
            'columns_added': {},
            'indexes_created': [],
            'errors': []
        }
        
        try:
            # بررسی جدول pattern_analysis
            if self.check_table_exists("pattern_analysis"):
                verification['tables_created'].append("pattern_analysis")
            
            # بررسی ستون‌های اضافه شده
            tables_to_check = [
                ("trading_signals", [
                    "pattern_type", "pattern_confidence", "pattern_direction",
                    "pattern_breakout", "pattern_target_price", 
                    "pattern_neckline_price", "pattern_peaks_json", 
                    "pattern_features_json"
                ]),
                ("crypto_klines", [
                    "pattern_markers", "pattern_confidence", 
                    "trend_strength", "support_resistance_level"
                ]),
                ("technical_indicators", [
                    "pattern_confirmation_score", "trend_confirmation",
                    "volume_anomaly", "breakout_potential"
                ])
            ]
            
            for table_name, columns in tables_to_check:
                verification['columns_added'][table_name] = []
                for column in columns:
                    if self.check_column_exists(table_name, column):
                        verification['columns_added'][table_name].append(column)
            
            # بررسی ایندکس‌ها
            self.cursor.execute(
                "SELECT name FROM sqlite_master WHERE type='index' AND name LIKE 'idx_%pattern%'"
            )
            pattern_indexes = self.cursor.fetchall()
            verification['indexes_created'] = [idx[0] for idx in pattern_indexes]
            
            return verification
            
        except Exception as e:
            verification['errors'].append(str(e))
            return verification
    
    def run_full_update(self, backup_first: bool = True) -> Dict:
        """
        اجرای کامل بروزرسانی دیتابیس
        
        Args:
            backup_first: آیا ابتدا بک‌آپ بگیرد؟
            
        Returns:
            Dict: گزارش کامل اجرا
        """
        report = {
            'start_time': datetime.now().isoformat(),
            'backup_success': False,
            'operations': [],
            'verification': None,
            'success': False,
            'error': None
        }
        
        try:
            # ۱. اتصال به دیتابیس
            if not self.connect():
                report['error'] = "اتصال به دیتابیس ناموفق"
                return report
            
            # ۲. ایجاد بک‌آپ (اختیاری)
            if backup_first:
                report['backup_success'] = self.backup_database()
            
            # ۳. ایجاد جدول جدید pattern_analysis
            report['operations'].append({
                'operation': 'create_pattern_analysis_table',
                'success': self.create_table_pattern_analysis()
            })
            
            # ۴. افزودن ستون‌ها به جداول موجود
            report['operations'].append({
                'operation': 'add_trading_signals_columns',
                'success': self.add_trading_signals_columns()
            })
            
            report['operations'].append({
                'operation': 'add_crypto_klines_columns',
                'success': self.add_crypto_klines_columns()
            })
            
            report['operations'].append({
                'operation': 'add_technical_indicators_columns',
                'success': self.add_technical_indicators_columns()
            })
            
            # ۵. ایجاد ایندکس‌های بهینه
            report['operations'].append({
                'operation': 'create_indexes',
                'success': self.create_indexes_for_new_columns()
            })
            
            # ۶. تأیید تغییرات
            report['verification'] = self.verify_changes()
            
            # ۷. قطع اتصال
            self.disconnect()
            
            # ۸. محاسبه موفقیت کلی
            all_success = all(op['success'] for op in report['operations'])
            report['success'] = all_success
            report['end_time'] = datetime.now().isoformat()
            
            logger.info("=" * 60)
            logger.info("🏁 بروزرسانی دیتابیس تکمیل شد")
            logger.info(f"✅ موفقیت کلی: {'بله' if report['success'] else 'خیر'}")
            
            return report
            
        except Exception as e:
            report['error'] = str(e)
            report['success'] = False
            logger.error(f"❌ خطا در اجرای بروزرسانی: {e}")
            return report
    
    def generate_sql_script(self, output_file: str = "pattern_fields.sql") -> bool:
        """
        تولید اسکریپت SQL برای اجرای دستی
        
        Args:
            output_file: نام فایل خروجی
            
        Returns:
            bool: موفقیت عملیات
        """
        try:
            sql_commands = []
            
            # ۱. ایجاد جدول pattern_analysis
            sql_commands.append("""
            -- ============================================
            -- ایجاد جدول جدید pattern_analysis
            -- ============================================
            
            CREATE TABLE IF NOT EXISTS pattern_analysis (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                coin_id INTEGER NOT NULL,
                symbol TEXT NOT NULL,
                timeframe TEXT NOT NULL,
                detection_time TIMESTAMP NOT NULL,
                analysis_duration_ms INTEGER,
                pattern_type TEXT NOT NULL,
                pattern_name TEXT NOT NULL,
                pattern_direction TEXT NOT NULL,
                pattern_confidence INTEGER NOT NULL CHECK (pattern_confidence >= 0 AND pattern_confidence <= 100),
                pattern_breakout BOOLEAN DEFAULT 0,
                target_price REAL,
                neckline_price REAL,
                pattern_peaks_json TEXT,
                historical_performance_score REAL CHECK (historical_performance_score >= 0 AND historical_performance_score <= 1),
                volume_confirmation_score INTEGER CHECK (volume_confirmation_score >= 0 AND volume_confirmation_score <= 100),
                indicator_confirmation_score INTEGER CHECK (indicator_confirmation_score >= 0 AND indicator_confirmation_score <= 100),
                pattern_details_json TEXT,
                market_context_json TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(coin_id, timeframe, detection_time, pattern_type),
                FOREIGN KEY (coin_id) REFERENCES crypto_coins (id)
                    ON DELETE CASCADE
                    ON UPDATE CASCADE
            );
            """)
            
            # ۲. افزودن ستون‌ها به trading_signals
            sql_commands.append("""
            -- ============================================
            -- افزودن ستون‌های جدید به trading_signals
            -- ============================================
            """)
            
            trading_columns = [
                "pattern_type TEXT",
                "pattern_confidence INTEGER",
                "pattern_direction TEXT",
                "pattern_breakout BOOLEAN DEFAULT 0",
                "pattern_target_price REAL",
                "pattern_neckline_price REAL",
                "pattern_peaks_json TEXT",
                "pattern_features_json TEXT"
            ]
            
            for column_def in trading_columns:
                sql_commands.append(
                    f"ALTER TABLE trading_signals ADD COLUMN {column_def};"
                )
            
            # ۳. افزودن ستون‌ها به crypto_klines
            sql_commands.append("""
            -- ============================================
            -- افزودن ستون‌های جدید به crypto_klines
            -- ============================================
            """)
            
            klines_columns = [
                "pattern_markers TEXT",
                "pattern_confidence REAL",
                "trend_strength REAL",
                "support_resistance_level REAL"
            ]
            
            for column_def in klines_columns:
                sql_commands.append(
                    f"ALTER TABLE crypto_klines ADD COLUMN {column_def};"
                )
            
            # ۴. افزودن ستون‌ها به technical_indicators
            sql_commands.append("""
            -- ============================================
            -- افزودن ستون‌های جدید به technical_indicators
            -- ============================================
            """)
            
            indicators_columns = [
                "pattern_confirmation_score INTEGER",
                "trend_confirmation TEXT",
                "volume_anomaly BOOLEAN DEFAULT 0",
                "breakout_potential REAL"
            ]
            
            for column_def in indicators_columns:
                sql_commands.append(
                    f"ALTER TABLE technical_indicators ADD COLUMN {column_def};"
                )
            
            # ۵. ایجاد ایندکس‌ها
            sql_commands.append("""
            -- ============================================
            -- ایجاد ایندکس‌های بهینه
            -- ============================================
            """)
            
            indexes = [
                ("trading_signals", "idx_signal_pattern_type", "pattern_type"),
                ("trading_signals", "idx_signal_pattern_confidence", "pattern_confidence"),
                ("trading_signals", "idx_signal_pattern_direction", "pattern_direction"),
                ("crypto_klines", "idx_klines_pattern_markers", "pattern_markers"),
                ("crypto_klines", "idx_klines_trend_strength", "trend_strength"),
                ("technical_indicators", "idx_indicators_pattern_score", "pattern_confirmation_score"),
                ("pattern_analysis", "idx_pattern_analysis_type_confidence", "pattern_type, pattern_confidence"),
                ("pattern_analysis", "idx_pattern_analysis_detection_time", "detection_time"),
                ("pattern_analysis", "idx_pattern_analysis_breakout", "pattern_breakout")
            ]
            
            for table_name, index_name, columns in indexes:
                sql_commands.append(
                    f"CREATE INDEX IF NOT EXISTS {index_name} ON {table_name}({columns});"
                )
            
            # ذخیره اسکریپت در فایل
            with open(output_file, 'w', encoding='utf-8') as f:
                f.write('\n'.join(sql_commands))
            
            logger.info(f"📝 اسکریپت SQL در فایل {output_file} ذخیره شد")
            return True
            
        except Exception as e:
            logger.error(f"❌ خطا در تولید اسکریپت SQL: {e}")
            return False


# تابع اصلی اجرا
def main():
    """تابع اصلی اجرای اسکریپت"""
    import argparse
    
    parser = argparse.ArgumentParser(description='افزودن فیلدهای PatternDetector به دیتابیس')
    parser.add_argument('--db', type=str, default='crypto_master.db', 
                       help='مسیر فایل دیتابیس')
    parser.add_argument('--backup', action='store_true', 
                       help='ایجاد بک‌آپ قبل از تغییرات')
    parser.add_argument('--sql-only', action='store_true',
                       help='فقط تولید اسکریپت SQL، بدون اجرا')
    parser.add_argument('--sql-file', type=str, default='pattern_fields.sql',
                       help='نام فایل خروجی اسکریپت SQL')
    
    args = parser.parse_args()
    
    print("=" * 60)
    print("🔧 اسکریپت ایجاد فیلدهای PatternDetector")
    print("=" * 60)
    
    # بررسی وجود فایل دیتابیس
    if not os.path.exists(args.db):
        print(f"❌ فایل دیتابیس یافت نشد: {args.db}")
        sys.exit(1)
    
    # ایجاد نمونه بروزرسان
    updater = DatabasePatternUpdater(args.db)
    
    if args.sql_only:
        # فقط تولید اسکریپت SQL
        print(f"📝 در حال تولید اسکریپت SQL در فایل {args.sql_file}...")
        if updater.generate_sql_script(args.sql_file):
            print("✅ اسکریپت SQL با موفقیت تولید شد")
        else:
            print("❌ خطا در تولید اسکریپت SQL")
            sys.exit(1)
    else:
        # اجرای کامل بروزرسانی
        print("🔄 شروع بروزرسانی دیتابیس...")
        print(f"🗄️ دیتابیس: {args.db}")
        print(f"💾 بک‌آپ: {'بله' if args.backup else 'خیر'}")
        print("-" * 40)
        
        report = updater.run_full_update(backup_first=args.backup)
        
        # نمایش گزارش
        print("\n📊 گزارش اجرا:")
        print(f"  ✅ موفقیت کلی: {'بله' if report['success'] else 'خیر'}")
        
        if report['error']:
            print(f"  ❌ خطا: {report['error']}")
        
        if report['verification']:
            print(f"  📋 جداول ایجاد شده: {len(report['verification']['tables_created'])}")
            for table in report['verification']['tables_created']:
                print(f"    • {table}")
            
            print(f"  📋 ستون‌های اضافه شده:")
            for table, columns in report['verification']['columns_added'].items():
                if columns:
                    print(f"    • {table}: {len(columns)} ستون")
            
            print(f"  📋 ایندکس‌های ایجاد شده: {len(report['verification']['indexes_created'])}")
        
        print("\n🏁 عملیات تکمیل شد")
        
        if not report['success']:
            sys.exit(1)


if __name__ == "__main__":
    main()