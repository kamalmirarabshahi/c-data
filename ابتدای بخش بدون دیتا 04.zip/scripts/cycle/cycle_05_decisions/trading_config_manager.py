"""
trading_config_manager.py
مدیر متمرکز تنظیمات معاملاتی برای تکه ۵ (تصمیم‌گیری معاملاتی)

وظایف:
1. بارگذاری تنظیمات از config_manager اصلی پروژه
2. بارگذاری تنظیمات اختصاصی از فایل cycle_05_trading_config.json
3. ادغام هوشمند تنظیمات از همه منابع
4. ارائه دسترسی یکپارچه به تنظیمات
5. مدیریت تنظیمات تلگرام برای ارسال اعلان‌ها

نویسنده: سیستم معاملاتی کریپتو
ورژن: 1.3.0 (افزوده: پشتیبانی کامل تلگرام)
تاریخ: 2025-12-25
"""

import os
import json
import logging
import sys
import re
from datetime import datetime
from typing import Any, Dict, List, Optional, Union, Tuple

# تنظیمات لاگ‌گیری
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class ValidationResult:
    """
    نتیجه اعتبارسنجی تنظیمات
    """
    
    def __init__(self, is_valid: bool, errors: List[str] = None, warnings: List[str] = None):
        self.is_valid = is_valid
        self.errors = errors or []
        self.warnings = warnings or []
    
    def __str__(self) -> str:
        status = "✅ معتبر" if self.is_valid else "❌ نامعتبر"
        result = f"وضعیت: {status}"
        
        if self.errors:
            result += "\nخطاها:\n" + "\n".join(f"  • {error}" for error in self.errors)
        
        if self.warnings:
            result += "\nهشدارها:\n" + "\n".join(f"  ⚠️ {warning}" for warning in self.warnings)
        
        return result
    
    def to_dict(self) -> Dict:
        return {
            "is_valid": self.is_valid,
            "errors": self.errors,
            "warnings": self.warnings
        }


class TradingConfigManager:
    """
    مدیر متمرکز تنظیمات معاملاتی - تکه ۵
    """
    
    def __init__(self, config_file_path: Optional[str] = None):
        """
        مقداردهی اولیه مدیر تنظیمات
        
        Args:
            config_file_path: مسیر فایل تنظیمات اختصاصی تکه ۵
        """
        # تعیین مسیر فایل تنظیمات تکه ۵
        if not config_file_path:
            config_file_path = os.path.join(
                os.path.dirname(os.path.abspath(__file__)),
                "cycle_05_trading_config.json"
            )
        
        self.config_file_path = config_file_path
        self.config = {}
        self.validation_result = None
        
        self._initialize()
        
        logger.info("TradingConfigManager برای تکه ۵ مقداردهی اولیه شد")
    
    def _initialize(self):
        """پروسه مقداردهی اولیه کامل"""
        try:
            # 1. تنظیمات پیش‌فرض
            default_config = self._get_default_config()
            
            # 2. تنظیمات اصلی (اگر موجود باشد)
            main_config = self._load_main_config()
            
            # 3. تنظیمات تکه ۵
            cycle5_config = self._load_cycle5_config()
            
            # 4. ادغام تنظیمات
            self.config = {}
            self._deep_update(self.config, default_config)
            self._deep_update(self.config, main_config)
            self._deep_update(self.config, cycle5_config)
            
            # 5. اعتبارسنجی
            self.validation_result = self._validate_config()
            
            # 6. لاگ تنظیمات مهم
            self._log_important_settings()
            
        except Exception as e:
            logger.error(f"خطا در مقداردهی اولیه: {e}")
            raise
    
    def _get_default_config(self) -> Dict:
        """تنظیمات پیش‌فرض داخلی"""
        return {
            "config_version": "1.3.0",
            "description": "تنظیمات پیش‌فرض معاملاتی تکه ۵ - با پشتیبانی تلگرام",
            
            "signal_processing": {
                "min_confidence": 0.5,
                "max_signal_age_hours": 2,
                "min_volume_usd": 100000,
                "require_multiple_confirmations": True,
                "confirmation_count": 2,
            },
            
            "portfolio": {
                "total_capital_usd": 1000.0,
                "available_capital_usd": 1000.0,
                "max_open_positions": 5,
                "min_position_size_usd": 10.0,
                "max_position_size_usd": 200.0,
                "position_sizing_method": "fixed_fractional",
            },
            
            "risk_management": {
                "max_risk_per_trade": 0.02,
                "max_daily_loss": 0.05,
                "stop_loss_percentage": 0.03,
                "min_risk_reward_ratio": 1.5,
                "trailing_stop_enabled": False,
                "trailing_stop_distance": 0.02,
            },
            
            "execution_control": {
                "simulation_mode": True,
                "order_type": "limit",
                "execution_delay_seconds": 1,
                "retry_failed_orders": True,
                "max_order_retries": 3,
            },
            
            "position_management": {
                "allow_partial_exits": True,
                "auto_move_to_break_even": False,
                "take_profit_method": "risk_reward",
                "use_scaling_out": False,
            },
            
            "telegram": {
                "enabled": False,
                "bot_token": "",
                "channel_id": "",
                "admin_id": "",
                "send_delay": 2,
                "max_retries": 3,
                "timeout": 10,
                "parse_mode": "Markdown",
                "disable_web_page_preview": True,
                "message_templates": {
                    "position_alert": "professional",
                    "system_alert": "compact",
                    "summary_report": "detailed",
                },
                "alert_levels": ["HIGH", "MEDIUM"],
                "alert_conditions": {
                    "send_position_alerts": True,
                    "send_system_alerts": True,
                    "send_summary_reports": True,
                    "send_error_alerts": True,
                    "send_performance_alerts": True,
                },
                "emoji_settings": {
                    "buy": "🟢",
                    "sell": "🔴",
                    "high_alert": "🚨",
                    "medium_alert": "⚠️",
                    "low_alert": "ℹ️",
                    "profit": "💰",
                    "loss": "📉",
                    "info": "📊",
                },
                "keyboard_settings": {
                    "show_chart_button": True,
                    "show_action_buttons": True,
                    "show_analysis_button": True,
                    "chart_url_template": "https://www.binance.com/en/trade/{symbol}",
                },
                "notification_channels": {
                    "positions_channel": "",
                    "alerts_channel": "",
                    "reports_channel": "",
                },
                "rate_limiting": {
                    "max_messages_per_minute": 20,
                    "max_messages_per_hour": 100,
                }
            }
        }
    
    def _load_main_config(self) -> Dict:
        """بارگذاری از config_manager اصلی پروژه"""
        try:
            # افزودن مسیر پروژه
            current_dir = os.path.dirname(os.path.abspath(__file__))
            project_root = os.path.dirname(os.path.dirname(os.path.dirname(current_dir)))
            
            if project_root not in sys.path:
                sys.path.insert(0, project_root)
            
            from config_manager import get
            
            # تلاش برای دریافت تنظیمات تلگرام از config_manager اصلی
            telegram_config = {}
            try:
                telegram_config = {
                    "enabled": get('telegram.enabled', False),
                    "bot_token": get('telegram.bot_token', ''),
                    "channel_id": get('telegram.channel_id', ''),
                    "admin_id": get('telegram.admin_id', ''),
                }
            except:
                pass
            
            main_config = {
                "main_config": {
                    "api": get("api", {}),
                    "database": get("database", {}),
                    "paths": get("paths", {}),
                    "telegram": telegram_config,
                },
                "loaded_from_main": True,
            }
            
            logger.info("تنظیمات از config_manager اصلی بارگذاری شد")
            return main_config
            
        except ImportError:
            logger.warning("config_manager اصلی یافت نشد")
            return {}
        except Exception as e:
            logger.error(f"خطا در بارگذاری config اصلی: {e}")
            return {}
    
    def _load_cycle5_config(self) -> Dict:
        """بارگذاری از فایل cycle_05_trading_config.json"""
        if not os.path.exists(self.config_file_path):
            logger.warning(f"فایل تنظیمات تکه ۵ یافت نشد: {self.config_file_path}")
            return {}
        
        try:
            with open(self.config_file_path, 'r', encoding='utf-8') as f:
                config = json.load(f)
            
            logger.info(f"تنظیمات از فایل تکه ۵ بارگذاری شد: {self.config_file_path}")
            
            return self._convert_cycle5_format(config)
            
        except json.JSONDecodeError as e:
            logger.error(f"خطا در خواندن فایل JSON: {e}")
            return {}
        except Exception as e:
            logger.error(f"خطا در بارگذاری فایل تکه ۵: {e}")
            return {}
    
    def _convert_cycle5_format(self, cycle5_config: Dict) -> Dict:
        """تبدیل فرمت فایل به فرمت داخلی"""
        converted = {}
        
        # account_settings → portfolio
        if "account_settings" in cycle5_config:
            acc = cycle5_config["account_settings"]
            converted["portfolio"] = {
                "total_capital_usd": acc.get("available_capital_usd", 1000),
                "available_capital_usd": acc.get("available_capital_usd", 1000),
                "min_position_size_usd": acc.get("min_position_size_usd", 10),
                "max_open_positions": acc.get("max_concurrent_trades", 5),
            }
        
        # risk_management
        if "risk_management" in cycle5_config:
            risk = cycle5_config["risk_management"]
            converted["risk_management"] = {
                "max_risk_per_trade": risk.get("max_risk_per_trade", 0.02),
                "max_daily_loss": risk.get("max_daily_loss_percent", 0.05),
                "stop_loss_percentage": risk.get("stop_loss_percentage", 0.03),
                "min_risk_reward_ratio": risk.get("min_risk_reward_ratio", 1.5),
            }
        
        # signal_processing
        if "signal_processing" in cycle5_config:
            sig = cycle5_config["signal_processing"]
            converted["signal_processing"] = {
                "min_confidence": sig.get("min_confidence", 0.5),
                "max_signal_age_hours": sig.get("max_age_hours", 2),
                "min_volume_usd": sig.get("min_volume_usd", 100000),
            }
        
        # telegram settings
        if "telegram" in cycle5_config:
            telegram_config = cycle5_config["telegram"]
            converted["telegram"] = {
                "enabled": telegram_config.get("enabled", False),
                "bot_token": telegram_config.get("bot_token", ""),
                "channel_id": telegram_config.get("channel_id", ""),
                "admin_id": telegram_config.get("admin_id", ""),
                "send_delay": telegram_config.get("send_delay", 2),
                "max_retries": telegram_config.get("max_retries", 3),
                "timeout": telegram_config.get("timeout", 10),
                "parse_mode": telegram_config.get("parse_mode", "Markdown"),
                "disable_web_page_preview": telegram_config.get("disable_web_page_preview", True),
                "message_templates": telegram_config.get("message_templates", {
                    "position_alert": "professional",
                    "system_alert": "compact",
                    "summary_report": "detailed",
                }),
                "alert_levels": telegram_config.get("alert_levels", ["HIGH", "MEDIUM"]),
                "alert_conditions": telegram_config.get("alert_conditions", {
                    "send_position_alerts": True,
                    "send_system_alerts": True,
                    "send_summary_reports": True,
                    "send_error_alerts": True,
                    "send_performance_alerts": True,
                }),
                "emoji_settings": telegram_config.get("emoji_settings", {
                    "buy": "🟢",
                    "sell": "🔴",
                    "high_alert": "🚨",
                    "medium_alert": "⚠️",
                    "low_alert": "ℹ️",
                    "profit": "💰",
                    "loss": "📉",
                    "info": "📊",
                }),
                "keyboard_settings": telegram_config.get("keyboard_settings", {
                    "show_chart_button": True,
                    "show_action_buttons": True,
                    "show_analysis_button": True,
                    "chart_url_template": "https://www.binance.com/en/trade/{symbol}",
                }),
                "notification_channels": telegram_config.get("notification_channels", {
                    "positions_channel": telegram_config.get("channel_id", ""),
                    "alerts_channel": telegram_config.get("admin_id", ""),
                    "reports_channel": telegram_config.get("channel_id", ""),
                }),
                "rate_limiting": telegram_config.get("rate_limiting", {
                    "max_messages_per_minute": 20,
                    "max_messages_per_hour": 100,
                })
            }
        
        # سایر تنظیمات مستقیم
        direct_fields = ["leverage_rules", "exchange_settings", "execution_control", 
                        "position_management", "reporting_config", "logging_config"]
        for field in direct_fields:
            if field in cycle5_config:
                converted[field] = cycle5_config[field]
        
        converted["loaded_from_cycle5"] = True
        
        return converted
    
    def _deep_update(self, target: Dict, source: Dict) -> Dict:
        """ادغام عمیق دیکشنری‌ها"""
        for key, value in source.items():
            if key in target and isinstance(target[key], dict) and isinstance(value, dict):
                self._deep_update(target[key], value)
            else:
                target[key] = value
        return target
    
    def _validate_config(self) -> ValidationResult:
        """اعتبارسنجی تنظیمات"""
        errors = []
        warnings = []
        
        try:
            # اعتبارسنجی سرمایه
            capital = self.get('portfolio.total_capital_usd', 0)
            if capital <= 0:
                errors.append("سرمایه باید عددی مثبت باشد")
            
            # اعتبارسنجی اعتماد سیگنال
            min_confidence = self.get('signal_processing.min_confidence', 0)
            if min_confidence < 0 or min_confidence > 1:
                errors.append("اعتماد سیگنال باید بین 0 تا 1 باشد")
            
            # اعتبارسنجی تنظیمات تلگرام
            telegram_enabled = self.get('telegram.enabled', False)
            
            if telegram_enabled:
                bot_token = self.get('telegram.bot_token', '').strip()
                channel_id = self.get('telegram.channel_id', '').strip()
                
                if not bot_token:
                    errors.append("برای فعال‌سازی تلگرام، bot_token الزامی است")
                elif not self._is_valid_bot_token(bot_token):
                    warnings.append("فرمت bot_token نامعتبر به نظر می‌رسد")
                
                if not channel_id:
                    errors.append("برای فعال‌سازی تلگرام، channel_id الزامی است")
                elif not self._is_valid_telegram_channel(channel_id):
                    warnings.append("فرمت channel_id نامعتبر به نظر می‌رسد")
                
                # بررسی timeout
                timeout = self.get('telegram.timeout', 10)
                if timeout < 1 or timeout > 30:
                    warnings.append("timeout تلگرام خارج از محدوده بهینه است (1-30 ثانیه)")
                
                # بررسی max_retries
                max_retries = self.get('telegram.max_retries', 3)
                if max_retries < 1 or max_retries > 10:
                    warnings.append("max_retries خارج از محدوده بهینه است (1-10)")
                
                # هشدار برای فعال بودن تلگرام
                warnings.append("تلگرام فعال است - اعلان‌ها ارسال می‌شوند")
            
            # هشدار برای حالت غیر شبیه‌سازی
            simulation = self.get('execution_control.simulation_mode', True)
            if not simulation:
                warnings.append("⚠️ حالت شبیه‌سازی غیرفعال است - معاملات واقعی انجام می‌شود")
                
        except Exception as e:
            errors.append(f"خطا در اعتبارسنجی: {str(e)}")
        
        return ValidationResult(
            is_valid=len(errors) == 0,
            errors=errors,
            warnings=warnings
        )
    
    def _is_valid_bot_token(self, bot_token: str) -> bool:
        """اعتبارسنجی فرمت bot_token"""
        pattern = r'^\d+:[A-Za-z0-9_-]+$'
        return bool(re.match(pattern, bot_token))
    
    def _is_valid_telegram_channel(self, channel_id: str) -> bool:
        """اعتبارسنجی فرمت channel_id"""
        if channel_id.startswith('@'):
            return len(channel_id) > 1
        elif channel_id.startswith('-100'):
            return channel_id[4:].isdigit()
        else:
            return channel_id.isdigit()
    
    def _log_important_settings(self):
        """لاگ تنظیمات مهم"""
        telegram_enabled = self.get('telegram.enabled', False)
        simulation_mode = self.get('execution_control.simulation_mode', True)
        
        logger.info(f"📊 تنظیمات بارگذاری شدند:")
        logger.info(f"  • حالت شبیه‌سازی: {'✅ فعال' if simulation_mode else '❌ غیرفعال'}")
        logger.info(f"  • تلگرام: {'✅ فعال' if telegram_enabled else '❌ غیرفعال'}")
        logger.info(f"  • سرمایه: ${self.get('portfolio.total_capital_usd'):,.2f}")
        logger.info(f"  • حداقل اعتماد: {self.get('signal_processing.min_confidence')*100:.1f}%")
    
    # ==================== متدهای عمومی ====================
    
    def get(self, key_path: str, default: Any = None) -> Any:
        """دریافت مقدار تنظیمات"""
        keys = key_path.split('.')
        value = self.config
        
        for key in keys:
            if isinstance(value, dict) and key in value:
                value = value[key]
            else:
                return default
        
        return value
    
    def set(self, key_path: str, value: Any) -> None:
        """تنظیم مقدار"""
        keys = key_path.split('.')
        config = self.config
        
        for key in keys[:-1]:
            if key not in config or not isinstance(config[key], dict):
                config[key] = {}
            config = config[key]
        
        config[keys[-1]] = value
    
    def get_portfolio_settings(self) -> Dict:
        """دریافت تنظیمات سبد"""
        return {
            "total_capital_usd": self.get("portfolio.total_capital_usd"),
            "available_capital_usd": self.get("portfolio.available_capital_usd", self.get("portfolio.total_capital_usd")),
            "max_open_positions": self.get("portfolio.max_open_positions"),
            "min_position_usd": self.get("portfolio.min_position_size_usd"),
            "max_position_usd": self.get("portfolio.max_position_size_usd"),
            "position_sizing_method": self.get("portfolio.position_sizing_method"),
        }
    
    def get_risk_settings(self) -> Dict:
        """دریافت تنظیمات ریسک"""
        return {
            "max_risk_per_trade": self.get("risk_management.max_risk_per_trade"),
            "max_daily_loss": self.get("risk_management.max_daily_loss"),
            "stop_loss_percentage": self.get("risk_management.stop_loss_percentage"),
            "min_risk_reward_ratio": self.get("risk_management.min_risk_reward_ratio"),
            "trailing_stop_enabled": self.get("risk_management.trailing_stop_enabled"),
            "trailing_stop_distance": self.get("risk_management.trailing_stop_distance"),
        }
    
    def get_signal_settings(self) -> Dict:
        """دریافت تنظیمات سیگنال"""
        return {
            "min_confidence": self.get("signal_processing.min_confidence"),
            "max_signal_age_hours": self.get("signal_processing.max_signal_age_hours"),
            "min_volume_usd": self.get("signal_processing.min_volume_usd"),
            "require_multiple_confirmations": self.get("signal_processing.require_multiple_confirmations"),
            "confirmation_count": self.get("signal_processing.confirmation_count"),
        }
    
    def get_telegram_settings(self) -> Dict:
        """دریافت تنظیمات تلگرام"""
        return {
            "enabled": self.get("telegram.enabled", False),
            "bot_token": self.get("telegram.bot_token", ""),
            "channel_id": self.get("telegram.channel_id", ""),
            "admin_id": self.get("telegram.admin_id", ""),
            "send_delay": self.get("telegram.send_delay", 2),
            "max_retries": self.get("telegram.max_retries", 3),
            "timeout": self.get("telegram.timeout", 10),
            "parse_mode": self.get("telegram.parse_mode", "Markdown"),
            "disable_web_page_preview": self.get("telegram.disable_web_page_preview", True),
            "message_templates": self.get("telegram.message_templates", {}),
            "alert_levels": self.get("telegram.alert_levels", []),
            "alert_conditions": self.get("telegram.alert_conditions", {}),
            "emoji_settings": self.get("telegram.emoji_settings", {}),
            "keyboard_settings": self.get("telegram.keyboard_settings", {}),
            "notification_channels": self.get("telegram.notification_channels", {}),
            "rate_limiting": self.get("telegram.rate_limiting", {}),
        }
    
    def is_telegram_enabled(self) -> bool:
        """بررسی فعال بودن تلگرام"""
        return self.get("telegram.enabled", False)
    
    def get_telegram_emoji(self, emoji_key: str, default: str = "") -> str:
        """دریافت ایموجی از تنظیمات تلگرام"""
        emoji_settings = self.get("telegram.emoji_settings", {})
        return emoji_settings.get(emoji_key, default)
    
    def get_telegram_alert_conditions(self) -> Dict:
        """دریافت شرایط ارسال هشدارها"""
        return self.get("telegram.alert_conditions", {})
    
    def should_send_position_alert(self, confidence_score: float = 0.0) -> bool:
        """بررسی آیا باید اعلان پوزیشن ارسال شود"""
        if not self.is_telegram_enabled():
            return False
        
        conditions = self.get_telegram_alert_conditions()
        if not conditions.get("send_position_alerts", True):
            return False
        
        # بررسی سطح هشدار
        alert_level = self.determine_alert_level(confidence_score)
        alert_levels = self.get("telegram.alert_levels", [])
        
        return alert_level in alert_levels
    
    def determine_alert_level(self, confidence_score: float) -> str:
        """تعیین سطح هشدار بر اساس امتیاز اعتماد"""
        if confidence_score >= 0.8:
            return "HIGH"
        elif confidence_score >= 0.6:
            return "MEDIUM"
        else:
            return "LOW"
    
    def get_leverage_for_score(self, signal_score: float) -> float:
        """دریافت اهرم مناسب برای امتیاز سیگنال"""
        leverage_rules = self.get("leverage_rules", [])
        
        for rule in leverage_rules:
            if signal_score >= rule.get("min_signal_score", 0):
                return rule.get("max_leverage", 1.0)
        
        return 1.0
    
    def calculate_position_size(self, capital: float, risk_percent: float = None) -> float:
        """محاسبه سایز پوزیشن"""
        if risk_percent is None:
            risk_percent = self.get("risk_management.max_risk_per_trade", 0.02)
        
        method = self.get("position_management.sizing_method", "fixed_fractional")
        
        if method == "fixed_percentage":
            fixed_pct = self.get("position_management.fixed_percentage", 0.02)
            return capital * fixed_pct
        elif method == "fixed_fractional":
            return capital * risk_percent
        else:
            return min(capital * risk_percent, self.get("portfolio.max_position_size_usd", 200.0))
    
    def calculate_stop_loss(self, entry_price: float, side: str = "long") -> float:
        """محاسبه قیمت استاپ‌لاس"""
        stop_loss_pct = self.get("risk_management.stop_loss_percentage", 0.03)
        
        if side.lower() == "long":
            return entry_price * (1 - stop_loss_pct)
        else:
            return entry_price * (1 + stop_loss_pct)
    
    def calculate_take_profit(self, entry_price: float, stop_loss_price: float, side: str = "long") -> float:
        """محاسبه قیمت تیک‌پروفیت"""
        method = self.get("position_management.take_profit_method", "risk_reward")
        min_rr = self.get("risk_management.min_risk_reward_ratio", 1.5)
        
        if method == "risk_reward":
            risk = abs(entry_price - stop_loss_price)
            target_profit = risk * min_rr
            
            if side.lower() == "long":
                return entry_price + target_profit
            else:
                return entry_price - target_profit
        else:
            take_profit_pct = self.get("risk_management.stop_loss_percentage", 0.03) * min_rr
            
            if side.lower() == "long":
                return entry_price * (1 + take_profit_pct)
            else:
                return entry_price * (1 - take_profit_pct)
    
    def is_simulation_mode(self) -> bool:
        """بررسی حالت شبیه‌سازی"""
        return self.get("execution_control.simulation_mode", True)
    
    def validate(self) -> ValidationResult:
        """اعتبارسنجی کامل تنظیمات"""
        self.validation_result = self._validate_config()
        return self.validation_result
    
    def get_config_summary(self) -> Dict:
        """دریافت خلاصه تنظیمات"""
        return {
            "config_version": self.get("config_version", "1.3.0"),
            "loaded_from_main": self.get("loaded_from_main", False),
            "loaded_from_cycle5": self.get("loaded_from_cycle5", False),
            "simulation_mode": self.is_simulation_mode(),
            "telegram_enabled": self.is_telegram_enabled(),
            "total_capital_usd": self.get("portfolio.total_capital_usd"),
            "min_confidence": self.get("signal_processing.min_confidence"),
            "max_risk_per_trade": self.get("risk_management.max_risk_per_trade"),
            "config_path": self.config_file_path,
        }
    
    def save_config(self, file_path: Optional[str] = None) -> bool:
        """ذخیره تنظیمات در فایل"""
        if file_path is None:
            file_path = self.config_file_path
        
        try:
            # ایجاد پوشه اگر وجود ندارد
            os.makedirs(os.path.dirname(file_path), exist_ok=True)
            
            with open(file_path, 'w', encoding='utf-8') as f:
                json.dump(self.config, f, ensure_ascii=False, indent=2)
            
            logger.info(f"تنظیمات در {file_path} ذخیره شدند")
            return True
            
        except Exception as e:
            logger.error(f"خطا در ذخیره تنظیمات: {e}")
            return False


# ==================== تابع کمکی برای تست ====================

def test_config_manager():
    """تابع تست برای بررسی عملکرد"""
    print("🧪 تست TradingConfigManager")
    print("=" * 50)
    
    try:
        config = TradingConfigManager()
        
        # نمایش خلاصه
        summary = config.get_config_summary()
        print("📊 خلاصه تنظیمات:")
        for key, value in summary.items():
            print(f"  {key}: {value}")
        
        print("\n✅ بررسی اعتبارسنجی:")
        validation = config.validate()
        print(validation)
        
        print("\n⚙️ تنظیمات تلگرام:")
        telegram_settings = config.get_telegram_settings()
        for key, value in telegram_settings.items():
            if key == "bot_token" and value:
                print(f"  {key}: {'*****' + value[-5:]}")
            elif key == "emoji_settings":
                print(f"  {key}: {len(value)} ایموجی")
            elif isinstance(value, dict):
                print(f"  {key}: dict با {len(value)} کلید")
            elif isinstance(value, list):
                print(f"  {key}: list با {len(value)} آیتم")
            else:
                print(f"  {key}: {value}")
        
        print("\n📈 تست محاسبات:")
        entry_price = 50000
        stop_loss = config.calculate_stop_loss(entry_price, "long")
        take_profit = config.calculate_take_profit(entry_price, stop_loss, "long")
        position_size = config.calculate_position_size(1000)
        
        print(f"  قیمت ورود: ${entry_price:,.2f}")
        print(f"  استاپ‌لاس: ${stop_loss:,.2f}")
        print(f"  تیک‌پروفیت: ${take_profit:,.2f}")
        print(f"  سایز پوزیشن برای $1000: ${position_size:,.2f}")
        
        print("\n✅ تست با موفقیت انجام شد")
        return True
        
    except Exception as e:
        print(f"❌ خطا در تست: {e}")
        return False


# ==================== نقطه ورود اصلی ====================

if __name__ == "__main__":
    print("🚀 TradingConfigManager - ورژن 1.3.0")
    print("فعال کردن تست خودکار...")
    
    success = test_config_manager()
    
    if success:
        print("\n🎉 همه چیز آماده است!")
        print("📝 نحوه استفاده در سایر ماژول‌ها:")
        print("""
        from trading_config_manager import TradingConfigManager
        
        # ایجاد نمونه
        config = TradingConfigManager()
        
        # دریافت تنظیمات
        if config.is_telegram_enabled():
            print("تلگرام فعال است")
            telegram_config = config.get_telegram_settings()
            
        # بررسی اعتبارسنجی
        if config.should_send_position_alert(confidence_score=0.75):
            print("باید اعلان تلگرام ارسال شود")
        """)
    else:
        print("\n⚠️ نیاز به بررسی و رفع خطاها")