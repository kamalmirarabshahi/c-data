#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
decision_maker.py - تصمیم‌گیر نهایی معاملات
تکه ۵ - فایل ۴ از ۸

ورودی: سیگنال‌های فیلتر شده + تخصیص سرمایه
خروجی: تصمیم‌های نهایی معاملاتی با تمام پارامترها
وابستگی: portfolio_manager, trading_config_manager
"""

import logging
import json
from typing import Dict, List, Any, Optional, Tuple
from datetime import datetime
from dataclasses import dataclass, asdict

@dataclass
class TradingDecision:
    """تصمیم نهایی معاملاتی"""
    decision_id: str
    timestamp: str
    
    # اطلاعات ارز
    coin_id: int
    symbol: str
    
    # تصمیم
    decision_type: str  # EXECUTE_BUY, EXECUTE_SELL, HOLD, REJECT
    signal_id: int
    original_signal_type: str  # BUY/SELL از تکه ۴
    
    # پارامترهای اجرا
    entry_price: float
    stop_loss: float
    take_profit: float
    position_size: float
    leverage: int
    
    # سرمایه
    allocated_capital_usd: float
    position_value_usd: float
    margin_required_usd: float
    
    # ریسک/بازده
    risk_amount_usd: float
    expected_profit_usd: float
    expected_loss_usd: float
    risk_reward_ratio: float
    net_risk_reward: float
    
    # کارمزدها
    entry_fee_usd: float
    exit_fee_usd: float
    total_fee_usd: float
    
    # امتیازها
    confidence_score: float
    priority_score: float
    final_score: float
    
    # وضعیت
    status: str  # PENDING, APPROVED, REJECTED, EXECUTED
    rejection_reason: Optional[str] = None
    approval_criteria: List[str] = None
    
    # متادیتا
    analysis_summary: Dict[str, Any] = None
    execution_time: Optional[str] = None

class DecisionMaker:
    """
    🤝 تصمیم‌گیر نهایی معاملات
    ارزیابی نهایی تخصیص‌های پوزیشن و تصمیم‌گیری نهایی
    """
    
    def __init__(self, config_manager, portfolio_manager=None):
        """
        مقداردهی اولیه تصمیم‌گیر
        
        Args:
            config_manager: مدیر تنظیمات
            portfolio_manager: مدیر سبد (اختیاری)
        """
        self.config = config_manager
        self.portfolio_manager = portfolio_manager
        self.logger = self._setup_logger()
        self.decisions = []
        
        # معیارهای تأیید
        self.approval_criteria = self._load_approval_criteria()
        
        self.logger.info("✅ DecisionMaker راه‌اندازی شد")
    
    def _setup_logger(self) -> logging.Logger:
        """تنظیم لاگر"""
        logger = logging.getLogger("DecisionMaker")
        if not logger.handlers:
            handler = logging.StreamHandler()
            formatter = logging.Formatter(
                '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
                datefmt='%H:%M:%S'
            )
            handler.setFormatter(formatter)
            logger.addHandler(handler)
            logger.setLevel(logging.INFO)
        return logger
    
    def _load_approval_criteria(self) -> Dict[str, Any]:
        """بارگذاری معیارهای تأیید"""
        return {
            "min_confidence": 0.5,
            "min_net_rr": 1.0,
            "max_leverage": 5,
            "max_position_percent": 0.1,
            "min_volume_usd": 100000,
            "max_slippage_percent": 0.5,
            "max_age_hours": 2,
            "require_volume_confirmation": True
        }
    
    def calculate_final_score(self, allocation) -> float:
        """
        محاسبه امتیاز نهایی برای تصمیم‌گیری
        
        Args:
            allocation: تخصیص پوزیشن
            
        Returns:
            امتیاز نهایی (0-100)
        """
        weights = {
            "confidence": 0.30,      # اعتماد سیگنال
            "net_risk_reward": 0.25, # ریسک/بازده خالص
            "volume_score": 0.15,    # امتیاز حجم
            "trend_score": 0.10,     # امتیاز روند
            "risk_score": 0.10,      # امتیاز ریسک
            "liquidity_score": 0.10  # امتیاز نقدشوندگی
        }
        
        # ۱. امتیاز اعتماد (0-30)
        confidence_score = allocation.confidence * weights["confidence"] * 100
        
        # ۲. امتیاز ریسک/بازده (0-25)
        rr_score = 0
        if allocation.net_risk_reward >= 2.0:
            rr_score = 25
        elif allocation.net_risk_reward >= 1.5:
            rr_score = 20
        elif allocation.net_risk_reward >= 1.0:
            rr_score = 15
        else:
            rr_score = max(0, allocation.net_risk_reward * 15)
        
        # ۳. امتیاز حجم (فرضی - در واقعیت از داده‌های بازار)
        volume_score = 10  # مقدار پیش‌فرض
        
        # ۴. امتیاز روند (فرضی)
        trend_score = 8  # مقدار پیش‌فرض
        
        # ۵. امتیاز ریسک (بر اساس لورج و سایز)
        risk_score = 10
        if allocation.leverage > 3:
            risk_score = 6
        elif allocation.leverage > 1:
            risk_score = 8
        
        # ۶. امتیاز نقدشوندگی (فرضی)
        liquidity_score = 8
        
        final_score = (
            confidence_score + 
            rr_score + 
            volume_score + 
            trend_score + 
            risk_score + 
            liquidity_score
        )
        
        return min(100, final_score)
    
    def check_approval_criteria(self, allocation) -> Tuple[bool, List[str], List[str]]:
        """
        بررسی معیارهای تأیید برای یک تخصیص
        
        Args:
            allocation: تخصیص پوزیشن
            
        Returns:
            (تأیید شده, دلایل تأیید, دلایل رد)
        """
        passed_criteria = []
        failed_criteria = []
        
        # ۱. حداقل اعتماد
        if allocation.confidence >= self.approval_criteria["min_confidence"]:
            passed_criteria.append(f"اعتماد کافی: {allocation.confidence:.2f} >= {self.approval_criteria['min_confidence']}")
        else:
            failed_criteria.append(f"اعتماد ناکافی: {allocation.confidence:.2f} < {self.approval_criteria['min_confidence']}")
        
        # ۲. حداقل ریسک/بازده خالص
        if allocation.net_risk_reward >= self.approval_criteria["min_net_rr"]:
            passed_criteria.append(f"ریسک/بازده قابل قبول: {allocation.net_risk_reward:.2f} >= {self.approval_criteria['min_net_rr']}")
        else:
            failed_criteria.append(f"ریسک/بازده پایین: {allocation.net_risk_reward:.2f} < {self.approval_criteria['min_net_rr']}")
        
        # ۳. حداکثر لورج
        if allocation.leverage <= self.approval_criteria["max_leverage"]:
            passed_criteria.append(f"لورج مجاز: {allocation.leverage} <= {self.approval_criteria['max_leverage']}")
        else:
            failed_criteria.append(f"لورج بیش از حد: {allocation.leverage} > {self.approval_criteria['max_leverage']}")
        
        # ۴. حداکثر سهم پوزیشن
        position_percent = (allocation.position_value_usd / self.config.account_settings.available_capital_usd) * 100
        max_percent = self.approval_criteria["max_position_percent"] * 100
        if position_percent <= max_percent:
            passed_criteria.append(f"سهم پوزیشن مناسب: {position_percent:.1f}% <= {max_percent:.1f}%")
        else:
            failed_criteria.append(f"سهم پوزیشن زیاد: {position_percent:.1f}% > {max_percent:.1f}%")
        
        # ۵. بررسی فاصله استاپ لاس معقول
        stop_distance_percent = abs(allocation.entry_price - allocation.stop_loss) / allocation.entry_price * 100
        if 1.0 <= stop_distance_percent <= 10.0:
            passed_criteria.append(f"فاصله استاپ لاس معقول: {stop_distance_percent:.1f}%")
        else:
            failed_criteria.append(f"فاصله استاپ لاس نامتعارف: {stop_distance_percent:.1f}%")
        
        # تصمیم نهایی
        is_approved = len(failed_criteria) == 0
        
        return is_approved, passed_criteria, failed_criteria
    
    def make_decision_for_allocation(self, allocation, signal_data: Dict = None) -> TradingDecision:
        """
        تصمیم‌گیری برای یک تخصیص پوزیشن
        
        Args:
            allocation: تخصیص پوزیشن
            signal_data: داده‌های سیگنال (اختیاری)
            
        Returns:
            تصمیم نهایی
        """
        decision_id = f"DEC_{allocation.coin_id}_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        
        # بررسی معیارهای تأیید
        is_approved, passed_criteria, failed_criteria = self.check_approval_criteria(allocation)
        
        # تعیین نوع تصمیم
        if not is_approved:
            decision_type = "REJECT"
            status = "REJECTED"
            rejection_reason = "، ".join(failed_criteria)
        else:
            if allocation.signal_type == "BUY":
                decision_type = "EXECUTE_BUY"
            elif allocation.signal_type == "SELL":
                decision_type = "EXECUTE_SELL"
            else:
                decision_type = "HOLD"
            status = "APPROVED"
            rejection_reason = None
        
        # محاسبه امتیاز نهایی
        final_score = self.calculate_final_score(allocation)
        
        # ایجاد تصمیم
        decision = TradingDecision(
            decision_id=decision_id,
            timestamp=datetime.now().isoformat(),
            
            coin_id=allocation.coin_id,
            symbol=allocation.symbol,
            
            decision_type=decision_type,
            signal_id=allocation.signal_id,
            original_signal_type=allocation.signal_type,
            
            entry_price=allocation.entry_price,
            stop_loss=allocation.stop_loss,
            take_profit=allocation.take_profit,
            position_size=allocation.position_size,
            leverage=allocation.leverage,
            
            allocated_capital_usd=allocation.allocated_capital_usd,
            position_value_usd=allocation.position_value_usd,
            margin_required_usd=allocation.margin_required_usd,
            
            risk_amount_usd=allocation.risk_amount_usd,
            expected_profit_usd=allocation.expected_profit_usd,
            expected_loss_usd=allocation.expected_loss_usd,
            risk_reward_ratio=allocation.risk_reward_ratio,
            net_risk_reward=allocation.net_risk_reward,
            
            entry_fee_usd=allocation.entry_fee_usd,
            exit_fee_usd=allocation.exit_fee_usd,
            total_fee_usd=allocation.total_fee_usd,
            
            confidence_score=allocation.confidence,
            priority_score=allocation.priority_score,
            final_score=final_score,
            
            status=status,
            rejection_reason=rejection_reason,
            approval_criteria=passed_criteria if is_approved else [],
            
            analysis_summary={
                "passed_criteria": passed_criteria,
                "failed_criteria": failed_criteria,
                "is_approved": is_approved,
                "score_breakdown": {
                    "confidence": allocation.confidence * 100,
                    "net_rr": allocation.net_risk_reward,
                    "final_score": final_score
                }
            }
        )
        
        # ثبت لاگ
        if is_approved:
            self.logger.info(f"✅ تصمیم APPROVED: {allocation.symbol} ({decision_type})")
            self.logger.info(f"   امتیاز: {final_score:.1f}, لورج: {allocation.leverage}x")
            self.logger.info(f"   سرمایه: ${allocation.allocated_capital_usd:,.2f}")
            self.logger.info(f"   ریسک/بازده: {allocation.net_risk_reward:.2f}")
        else:
            self.logger.warning(f"❌ تصمیم REJECTED: {allocation.symbol}")
            for reason in failed_criteria:
                self.logger.warning(f"   - {reason}")
        
        return decision
    
    def make_decisions_for_portfolio(self, allocations: List) -> List[TradingDecision]:
        """
        تصمیم‌گیری برای کل سبد
        
        Args:
            allocations: لیست تخصیص‌های پوزیشن
            
        Returns:
            لیست تصمیم‌های نهایی
        """
        self.logger.info(f"🤝 شروع تصمیم‌گیری برای {len(allocations)} پوزیشن")
        
        decisions = []
        
        for i, allocation in enumerate(allocations, 1):
            self.logger.info(f"   📋 پردازش پوزیشن {i}/{len(allocations)}: {allocation.symbol}")
            
            decision = self.make_decision_for_allocation(allocation)
            decisions.append(decision)
        
        # آمار تصمیم‌ها
        approved = [d for d in decisions if d.status == "APPROVED"]
        rejected = [d for d in decisions if d.status == "REJECTED"]
        
        buy_decisions = [d for d in approved if d.decision_type == "EXECUTE_BUY"]
        sell_decisions = [d for d in approved if d.decision_type == "EXECUTE_SELL"]
        
        self.logger.info(f"📊 آمار تصمیم‌گیری:")
        self.logger.info(f"   کل تصمیم‌ها: {len(decisions)}")
        self.logger.info(f"   تأیید شده: {len(approved)}")
        self.logger.info(f"   رد شده: {len(rejected)}")
        self.logger.info(f"   خرید: {len(buy_decisions)}")
        self.logger.info(f"   فروش: {len(sell_decisions)}")
        
        if approved:
            avg_score = sum(d.final_score for d in approved) / len(approved)
            avg_rr = sum(d.net_risk_reward for d in approved) / len(approved)
            self.logger.info(f"   میانگین امتیاز: {avg_score:.1f}")
            self.logger.info(f"   میانگین ریسک/بازده: {avg_rr:.2f}")
        
        self.decisions = decisions
        return decisions
    
    def get_decisions_summary(self) -> Dict[str, Any]:
        """
        دریافت خلاصه تصمیم‌ها
        
        Returns:
            خلاصه تصمیم‌ها
        """
        if not self.decisions:
            return {"message": "هیچ تصمیمی گرفته نشده است"}
        
        approved = [d for d in self.decisions if d.status == "APPROVED"]
        rejected = [d for d in self.decisions if d.status == "REJECTED"]
        
        buy_decisions = [d for d in approved if d.decision_type == "EXECUTE_BUY"]
        sell_decisions = [d for d in approved if d.decision_type == "EXECUTE_SELL"]
        
        summary = {
            "total_decisions": len(self.decisions),
            "approved": len(approved),
            "rejected": len(rejected),
            "buy_signals": len(buy_decisions),
            "sell_signals": len(sell_decisions),
            "approval_rate": (len(approved) / len(self.decisions)) * 100 if self.decisions else 0,
            "top_decisions": []
        }
        
        # ۳ تصمیم برتر
        approved_sorted = sorted(approved, key=lambda x: x.final_score, reverse=True)
        for decision in approved_sorted[:3]:
            summary["top_decisions"].append({
                "symbol": decision.symbol,
                "decision": decision.decision_type,
                "score": decision.final_score,
                "leverage": decision.leverage,
                "capital": decision.allocated_capital_usd,
                "risk_reward": decision.net_risk_reward
            })
        
        # دلایل اصلی رد
        if rejected:
            rejection_reasons = {}
            for decision in rejected:
                if decision.rejection_reason:
                    reason = decision.rejection_reason.split(":")[0] if ":" in decision.rejection_reason else decision.rejection_reason
                    rejection_reasons[reason] = rejection_reasons.get(reason, 0) + 1
            
            summary["rejection_reasons"] = rejection_reasons
        
        return summary
    
    def save_decisions_to_json(self, filename: Optional[str] = None) -> str:
        """
        ذخیره تصمیم‌ها در فایل JSON
        
        Args:
            filename: نام فایل (اختیاری)
            
        Returns:
            مسیر فایل ذخیره شده
        """
        import os
        
        if not filename:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"trading_decisions_{timestamp}.json"
        
        # تبدیل به دیکشنری
        decisions_dict = [asdict(d) for d in self.decisions]
        
        data = {
            "generated_at": datetime.now().isoformat(),
            "total_decisions": len(self.decisions),
            "decisions": decisions_dict,
            "summary": self.get_decisions_summary()
        }
        
        try:
            # ایجاد پوشه اگر وجود نداشت
            os.makedirs("decisions", exist_ok=True)
            filepath = os.path.join("decisions", filename)
            
            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
            
            self.logger.info(f"💾 تصمیم‌ها ذخیره شد: {filepath}")
            return filepath
            
        except Exception as e:
            self.logger.error(f"❌ خطا در ذخیره تصمیم‌ها: {e}")
            return ""


# ==================== تست ====================
def test_decision_maker():
    """تست DecisionMaker"""
    print("\n🧪 TESTING DECISION MAKER")
    print("=" * 60)
    
    try:
        # کلاس تست PositionAllocation
        from dataclasses import dataclass
        
        @dataclass
        class TestAllocation:
            coin_id: int = 1125
            symbol: str = "BTCUSDT"
            signal_id: int = 1
            signal_type: str = "BUY"
            confidence: float = 0.75
            priority_score: float = 85.5
            entry_price: float = 49000
            stop_loss: float = 48500
            take_profit: float = 51000
            allocated_capital_usd: float = 2000
            position_size: float = 0.04
            leverage: int = 3
            position_value_usd: float = 1960
            margin_required_usd: float = 653.33
            risk_amount_usd: float = 40
            expected_profit_usd: float = 800
            expected_loss_usd: float = 120
            risk_reward_ratio: float = 2.0
            net_risk_reward: float = 1.8
            entry_fee_usd: float = 1.96
            exit_fee_usd: float = 1.96
            total_fee_usd: float = 3.92
        
        # کلاس تست ConfigManager
        class TestConfigManager:
            class AccountSettings:
                available_capital_usd = 10000.0
            
            account_settings = AccountSettings()
        
        print("🔧 ایجاد اشیاء تست...")
        
        # ایجاد Allocation تست
        allocation = TestAllocation()
        
        print(f"✅ Test Allocation created:")
        print(f"   - Symbol: {allocation.symbol}")
        print(f"   - Confidence: {allocation.confidence:.2f}")
        print(f"   - Leverage: {allocation.leverage}x")
        print(f"   - Net R/R: {allocation.net_risk_reward:.2f}")
        print(f"   - Capital: ${allocation.allocated_capital_usd:,.2f}")
        
        # ایجاد DecisionMaker
        config = TestConfigManager()
        decision_maker = DecisionMaker(config)
        
        print(f"\n✅ DecisionMaker created")
        
        # تست ۱: بررسی معیارهای تأیید
        print("\n🎯 TEST 1: Checking Approval Criteria...")
        is_approved, passed, failed = decision_maker.check_approval_criteria(allocation)
        
        print(f"   Approved: {'✅' if is_approved else '❌'}")
        print(f"   Passed criteria: {len(passed)}")
        for criteria in passed[:3]:  # فقط ۳ مورد اول
            print(f"     ✅ {criteria}")
        
        if failed:
            print(f"   Failed criteria: {len(failed)}")
            for criteria in failed[:3]:  # فقط ۳ مورد اول
                print(f"     ❌ {criteria}")
        
        # تست ۲: ایجاد تصمیم
        print("\n🤝 TEST 2: Making Decision...")
        decision = decision_maker.make_decision_for_allocation(allocation)
        
        print(f"   Decision ID: {decision.decision_id}")
        print(f"   Decision Type: {decision.decision_type}")
        print(f"   Status: {decision.status}")
        print(f"   Final Score: {decision.final_score:.1f}")
        
        # تست ۳: تصمیم‌گیری برای چند پوزیشن
        print("\n📊 TEST 3: Portfolio Decisions...")
        
        # ایجاد چند Allocation مختلف
        allocations = [
            TestAllocation(symbol="BTCUSDT", confidence=0.85, net_risk_reward=2.2, leverage=2),
            TestAllocation(symbol="ETHUSDT", confidence=0.65, net_risk_reward=1.2, leverage=3),
            TestAllocation(symbol="BNBUSDT", confidence=0.45, net_risk_reward=0.8, leverage=5),  # باید رد شود
            TestAllocation(symbol="XRPUSDT", confidence=0.72, net_risk_reward=1.5, leverage=1),
        ]
        
        decisions = decision_maker.make_decisions_for_portfolio(allocations)
        
        print(f"   Total decisions: {len(decisions)}")
        approved = [d for d in decisions if d.status == "APPROVED"]
        rejected = [d for d in decisions if d.status == "REJECTED"]
        print(f"   Approved: {len(approved)}")
        print(f"   Rejected: {len(rejected)}")
        
        # تست ۴: خلاصه تصمیم‌ها
        print("\n📈 TEST 4: Decisions Summary...")
        summary = decision_maker.get_decisions_summary()
        
        print(f"   Approval rate: {summary['approval_rate']:.1f}%")
        print(f"   Buy signals: {summary['buy_signals']}")
        print(f"   Sell signals: {summary['sell_signals']}")
        
        if summary.get('top_decisions'):
            print(f"   Top decisions:")
            for top in summary['top_decisions']:
                print(f"     - {top['symbol']}: Score {top['score']:.1f}, R/R {top['risk_reward']:.2f}")
        
        print("\n" + "=" * 60)
        print("✅ ALL DECISION MAKER TESTS PASSED!")
        
        return True
        
    except Exception as e:
        print(f"❌ Test failed: {e}")
        import traceback
        traceback.print_exc()
        return False


if __name__ == "__main__":
    test_result = test_decision_maker()
    
    if test_result:
        print("\n🚀 DecisionMaker is ready for integration!")
        print("\n📝 Next: Integrate with PortfolioManager and real data")
    else:
        print("\n❌ Needs debugging before integration")