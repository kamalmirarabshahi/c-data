#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
signal_processor.py - پردازش و فیلتر سیگنال‌های تکه ۴
تکه ۵ - فایل ۲ از ۸

ورودی: سیگنال‌های خام از جدول trading_signals
خروجی: سیگنال‌های فیلتر شده و اولویت‌بندی شده
وابستگی: sqlite3, config_manager, datetime
"""

import os
import sys
import sqlite3
import logging
import json
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass

# اضافه کردن مسیر برای import کردن config_manager
current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = os.path.dirname(os.path.dirname(os.path.dirname(current_dir)))
sys.path.insert(0, project_root)

try:
    from config_manager import get_database_path
    DB_PATH = get_database_path()
except ImportError:
    # Fallback path
    DB_PATH = os.path.join(project_root, "data", "crypto_master.db")

@dataclass
class SignalData:
    """ساختار داده سیگنال"""
    signal_id: int
    coin_id: int
    symbol: str
    signal_type: str
    confidence: float
    entry_price: float
    stop_loss: float
    take_profit: float
    created_at: str
    signal_details: Optional[Dict] = None
    volume_24h: Optional[float] = None
    current_price: Optional[float] = None
    age_hours: Optional[float] = None

@dataclass
class FilterStats:
    """آمار فیلتر سیگنال‌ها"""
    total_signals: int = 0
    passed_filters: int = 0
    failed_confidence: int = 0
    failed_age: int = 0
    failed_volume: int = 0
    failed_duplicates: int = 0
    final_signals: int = 0

class SignalProcessor:
    """
    🎯 پردازشگر سیگنال‌ها
    خواندن، فیلتر و اولویت‌بندی سیگنال‌های تکه ۴
    """
    
    def __init__(self, config_manager):
        """
        مقداردهی اولیه پردازشگر
        
        Args:
            config_manager: مدیر تنظیمات TradingConfigManager
        """
        self.config = config_manager
        self.db_path = DB_PATH
        self.logger = self._setup_logger()
        self.filter_stats = FilterStats()
        
        # تنظیمات پردازش سیگنال
        self.signal_config = self.config.config.get("signal_processing", {})
        
        self.logger.info("✅ SignalProcessor راه‌اندازی شد")
    
    def _setup_logger(self) -> logging.Logger:
        """تنظیم لاگر"""
        logger = logging.getLogger("SignalProcessor")
        if not logger.handlers:
            handler = logging.StreamHandler()
            formatter = logging.Formatter(
                '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
                datefmt='%H:%M:%S'
            )
            handler.setFormatter(formatter)
            logger.addHandler(handler)
            logger.setLevel(logging.INFO)
        return logger
    
    def get_raw_signals(self, block_id: Optional[int] = None) -> List[Dict[str, Any]]:
        """
        خواندن سیگنال‌های خام از دیتابیس
        
        Args:
            block_id: شماره بلوک (اختیاری)
            
        Returns:
            لیست سیگنال‌های خام
        """
        try:
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            # کوئری اصلی برای دریافت سیگنال‌ها
            query = """
                SELECT 
                    ts.id as signal_id,
                    ts.coin_id,
                    ts.symbol,
                    ts.signal_type,
                    ts.confidence_score as confidence,
                    ts.entry_price,
                    ts.stop_loss,
                    ts.take_profit,
                    ts.created_at,
                    ts.signal_details,
                    cc.volume_24h,
                    cc.current_price
                FROM trading_signals ts
                LEFT JOIN crypto_coins cc ON ts.coin_id = cc.id
                WHERE ts.status = 'active'
            """
            
            params = []
            if block_id:
                # اگر بلوک مشخص شده، فقط سیگنال‌های ارزهای همان بلوک
                query += """
                    AND ts.coin_id IN (
                        SELECT coin_id FROM coin_collection_status 
                        WHERE block_id = ?
                    )
                """
                params.append(block_id)
            
            query += " ORDER BY ts.created_at DESC"
            
            cursor.execute(query, params)
            rows = cursor.fetchall()
            
            raw_signals = []
            for row in rows:
                signal_dict = dict(row)
                
                # پردازش signal_details اگر JSON است
                if signal_dict.get("signal_details"):
                    try:
                        signal_dict["signal_details"] = json.loads(signal_dict["signal_details"])
                    except:
                        signal_dict["signal_details"] = None
                
                raw_signals.append(signal_dict)
            
            conn.close()
            
            self.logger.info(f"📊 {len(raw_signals)} سیگنال خام خوانده شد")
            return raw_signals
            
        except sqlite3.Error as e:
            self.logger.error(f"❌ خطای دیتابیس: {e}")
            return []
        except Exception as e:
            self.logger.error(f"❌ خطای ناشناخته: {e}")
            return []
    
    def convert_to_signal_data(self, raw_signal: Dict[str, Any]) -> SignalData:
        """
        تبدیل داده خام به ساختار SignalData
        
        Args:
            raw_signal: داده خام از دیتابیس
            
        Returns:
            شیء SignalData
        """
        # محاسبه سن سیگنال
        created_at = raw_signal.get("created_at")
        age_hours = None
        
        if created_at:
            try:
                if isinstance(created_at, str):
                    signal_time = datetime.fromisoformat(created_at.replace('Z', '+00:00'))
                else:
                    signal_time = datetime.fromtimestamp(created_at)
                
                current_time = datetime.now()
                age_hours = (current_time - signal_time).total_seconds() / 3600
            except:
                age_hours = 999  # مقدار زیاد برای سیگنال‌های قدیمی
        
        return SignalData(
            signal_id=raw_signal.get("signal_id", 0),
            coin_id=raw_signal.get("coin_id", 0),
            symbol=raw_signal.get("symbol", "UNKNOWN"),
            signal_type=raw_signal.get("signal_type", "HOLD"),
            confidence=float(raw_signal.get("confidence", 0)),
            entry_price=float(raw_signal.get("entry_price", 0)),
            stop_loss=float(raw_signal.get("stop_loss", 0)),
            take_profit=float(raw_signal.get("take_profit", 0)),
            created_at=created_at or "",
            signal_details=raw_signal.get("signal_details"),
            volume_24h=float(raw_signal.get("volume_24h", 0)) if raw_signal.get("volume_24h") else None,
            current_price=float(raw_signal.get("current_price", 0)) if raw_signal.get("current_price") else None,
            age_hours=age_hours
        )
    
    def apply_filters(self, signal: SignalData) -> Tuple[bool, str]:
        """
        اعمال فیلترها روی یک سیگنال
        
        Args:
            signal: سیگنال برای فیلتر
            
        Returns:
            (قبول شد/نشد, دلیل)
        """
        # ۱. فیلتر اعتماد
        min_confidence = self.signal_config.get("min_confidence", 0.5)
        if signal.confidence < min_confidence:
            return False, f"اعتماد کم: {signal.confidence:.2f} < {min_confidence}"
        
        # ۲. فیلتر سن
        max_age = self.signal_config.get("max_age_hours", 2)
        if signal.age_hours and signal.age_hours > max_age:
            return False, f"سیگنال قدیمی: {signal.age_hours:.1f}h > {max_age}h"
        
        # ۳. فیلتر حجم
        min_volume = self.signal_config.get("min_volume_usd", 100000)
        if signal.volume_24h and signal.volume_24h < min_volume:
            return False, f"حجم کم: ${signal.volume_24h:,.0f} < ${min_volume:,.0f}"
        
        # ۴. تأیید حجم (اگر فعال باشد)
        require_volume = self.signal_config.get("require_volume_confirmation", True)
        if require_volume and signal.volume_24h:
            # بررسی افزایش حجم نسبت به میانگین
            if signal.volume_24h < min_volume * 1.5:  # حداقل 1.5 برابر حداقل حجم
                return False, f"تأیید حجم کافی نیست: ${signal.volume_24h:,.0f}"
        
        # ۵. بررسی قیمت‌های معتبر
        if signal.entry_price <= 0 or signal.stop_loss <= 0:
            return False, "قیمت‌های نامعتبر"
        
        # ۶. بررسی فاصله استاپ لاس
        price_distance = abs(signal.entry_price - signal.stop_loss)
        if price_distance / signal.entry_price > 0.1:  # حداکثر 10% فاصله
            return False, f"فاصله استاپ لاس زیاد: {(price_distance/signal.entry_price)*100:.1f}%"
        
        return True, "معتبر"
    
    def remove_duplicates(self, signals: List[SignalData]) -> List[SignalData]:
        """
        حذف سیگنال‌های تکراری برای هر ارز
        
        Args:
            signals: لیست سیگنال‌ها
            
        Returns:
            لیست بدون تکراری
        """
        if not self.signal_config.get("exclude_duplicates", True):
            return signals
        
        # گروه‌بندی بر اساس ارز
        signals_by_coin = {}
        for signal in signals:
            if signal.coin_id not in signals_by_coin:
                signals_by_coin[signal.coin_id] = []
            signals_by_coin[signal.coin_id].append(signal)
        
        # انتخاب بهترین سیگنال برای هر ارز
        filtered_signals = []
        for coin_id, coin_signals in signals_by_coin.items():
            if len(coin_signals) == 1:
                filtered_signals.append(coin_signals[0])
                continue
            
            # انتخاب سیگنال با بالاترین امتیاز
            best_signal = max(coin_signals, key=lambda s: s.confidence)
            filtered_signals.append(best_signal)
            
            self.filter_stats.failed_duplicates += len(coin_signals) - 1
        
        return filtered_signals
    
    def calculate_priority_score(self, signal: SignalData) -> float:
        """
        محاسبه امتیاز اولویت برای سیگنال
        
        Args:
            signal: سیگنال
            
        Returns:
            امتیاز اولویت (0-100)
        """
        priority_method = self.signal_config.get("priority_method", "confidence_volume")
        
        if priority_method == "confidence_only":
            # فقط بر اساس اعتماد
            return signal.confidence * 100
        
        elif priority_method == "volume_weighted":
            # تأکید بیشتر بر حجم
            volume_factor = min(signal.volume_24h / 1000000, 2) if signal.volume_24h else 1
            return signal.confidence * 50 * volume_factor
        
        else:  # confidence_volume (پیش‌فرض)
            # ترکیب اعتماد و حجم
            confidence_weight = 0.7
            volume_weight = 0.3
            
            # نرمال‌سازی حجم (0-1)
            volume_norm = 0
            if signal.volume_24h:
                volume_norm = min(signal.volume_24h / 5000000, 1)  # حداکثر 5M دلار
            
            score = (signal.confidence * confidence_weight) + (volume_norm * volume_weight)
            return score * 100
    
    def process_signals(self, block_id: Optional[int] = None) -> List[Dict[str, Any]]:
        """
        پردازش کامل سیگنال‌ها
        
        Args:
            block_id: شماره بلوک
            
        Returns:
            لیست سیگنال‌های پردازش شده
        """
        self.logger.info(f"🚀 شروع پردازش سیگنال‌ها (بلوک: {block_id or 'همه'})")
        
        # ۱. خواندن سیگنال‌های خام
        raw_signals = self.get_raw_signals(block_id)
        self.filter_stats.total_signals = len(raw_signals)
        
        if not raw_signals:
            self.logger.warning("⚠️ هیچ سیگنالی یافت نشد")
            return []
        
        # ۲. تبدیل به ساختار داده
        signals = []
        for raw in raw_signals:
            signal_data = self.convert_to_signal_data(raw)
            signals.append(signal_data)
        
        # ۳. اعمال فیلترها
        filtered_signals = []
        for signal in signals:
            passed, reason = self.apply_filters(signal)
            
            if passed:
                filtered_signals.append(signal)
                self.filter_stats.passed_filters += 1
            else:
                # ثبت دلیل رد
                if "اعتماد کم" in reason:
                    self.filter_stats.failed_confidence += 1
                elif "سیگنال قدیمی" in reason:
                    self.filter_stats.failed_age += 1
                elif "حجم" in reason:
                    self.filter_stats.failed_volume += 1
        
        # ۴. حذف تکراری‌ها
        unique_signals = self.remove_duplicates(filtered_signals)
        
        # ۵. محاسبه امتیاز اولویت
        for signal in unique_signals:
            signal.priority_score = self.calculate_priority_score(signal)
        
        # ۶. مرتب‌سازی بر اساس امتیاز
        sorted_signals = sorted(unique_signals, key=lambda s: s.priority_score, reverse=True)
        
        # ۷. تبدیل به دیکشنری برای خروجی
        processed_signals = []
        for signal in sorted_signals:
            processed_signal = {
                "signal_id": signal.signal_id,
                "coin_id": signal.coin_id,
                "symbol": signal.symbol,
                "signal_type": signal.signal_type,
                "confidence": signal.confidence,
                "priority_score": signal.priority_score,
                "entry_price": signal.entry_price,
                "stop_loss": signal.stop_loss,
                "take_profit": signal.take_profit,
                "age_hours": signal.age_hours,
                "volume_24h": signal.volume_24h,
                "current_price": signal.current_price,
                "risk_reward_ratio": abs(signal.take_profit - signal.entry_price) / 
                                     abs(signal.entry_price - signal.stop_loss) 
                                     if signal.entry_price != signal.stop_loss else 0
            }
            processed_signals.append(processed_signal)
        
        self.filter_stats.final_signals = len(processed_signals)
        
        # گزارش آمار
        self._log_filter_stats()
        
        return processed_signals
    
    def _log_filter_stats(self):
        """ثبت آمار فیلترها"""
        stats = self.filter_stats
        self.logger.info(f"📊 آمار فیلتر سیگنال‌ها:")
        self.logger.info(f"   کل سیگنال‌ها: {stats.total_signals}")
        self.logger.info(f"   رد اعتماد: {stats.failed_confidence}")
        self.logger.info(f"   رد سن: {stats.failed_age}")
        self.logger.info(f"   رد حجم: {stats.failed_volume}")
        self.logger.info(f"   رد تکراری: {stats.failed_duplicates}")
        self.logger.info(f"   سیگنال‌های نهایی: {stats.final_signals}")
        
        if stats.total_signals > 0:
            success_rate = (stats.final_signals / stats.total_signals) * 100
            self.logger.info(f"   نرخ موفقیت: {success_rate:.1f}%")


# ==================== تست ====================
def test_signal_processor():
    """تابع تست پردازشگر سیگنال"""
    print("\n🧪 TESTING SIGNAL PROCESSOR")
    print("=" * 50)
    
    try:
        # تست نیاز به TradingConfigManager
        # برای تست از تنظیمات نمونه استفاده می‌کنیم
        class TestConfig:
            def __init__(self):
                self.config = {
                    "signal_processing": {
                        "min_confidence": 0.5,
                        "max_age_hours": 2,
                        "min_volume_usd": 100000,
                        "require_volume_confirmation": True,
                        "exclude_duplicates": True,
                        "priority_method": "confidence_volume"
                    }
                }
        
        # ایجاد پردازشگر
        test_config = TestConfig()
        processor = SignalProcessor(test_config)
        
        # تست ۱: ساختار داده سیگنال
        print("\n📋 1. تست ساختار داده:")
        test_signal = SignalData(
            signal_id=1,
            coin_id=1125,
            symbol="BTCUSDT",
            signal_type="BUY",
            confidence=0.75,
            entry_price=49000,
            stop_loss=48500,
            take_profit=51000,
            created_at=datetime.now().isoformat(),
            volume_24h=1500000,
            current_price=49100,
            age_hours=0.5
        )
        
        print(f"   ساختار SignalData ایجاد شد:")
        print(f"   - Symbol: {test_signal.symbol}")
        print(f"   - Confidence: {test_signal.confidence:.2f}")
        print(f"   - Volume: ${test_signal.volume_24h:,.0f}")
        print(f"   - Age: {test_signal.age_hours:.1f}h")
        
        # تست ۲: اعمال فیلترها
        print("\n🎯 2. تست فیلترها:")
        
        # سیگنال معتبر
        valid_passed, valid_reason = processor.apply_filters(test_signal)
        print(f"   سیگنال معتبر: {'✅' if valid_passed else '❌'} - {valid_reason}")
        
        # سیگنال با اعتماد کم
        low_conf = SignalData(
            signal_id=2, coin_id=1126, symbol="ETHUSDT",
            signal_type="BUY", confidence=0.3,  # کم
            entry_price=3000, stop_loss=2950, take_profit=3200,
            created_at=datetime.now().isoformat(),
            volume_24h=800000, current_price=3010, age_hours=0.5
        )
        low_conf_passed, low_conf_reason = processor.apply_filters(low_conf)
        print(f"   اعتماد کم: {'✅' if low_conf_passed else '❌'} - {low_conf_reason}")
        
        # سیگنال قدیمی
        old_signal = SignalData(
            signal_id=3, coin_id=1128, symbol="BNBUSDT",
            signal_type="BUY", confidence=0.8,
            entry_price=850, stop_loss=830, take_profit=900,
            created_at=(datetime.now() - timedelta(hours=3)).isoformat(),  # 3 ساعت
            volume_24h=500000, current_price=855, age_hours=3.0
        )
        old_passed, old_reason = processor.apply_filters(old_signal)
        print(f"   سیگنال قدیمی: {'✅' if old_passed else '❌'} - {old_reason}")
        
        # تست ۳: محاسبه امتیاز اولویت
        print("\n📊 3. تست امتیاز اولویت:")
        score = processor.calculate_priority_score(test_signal)
        print(f"   امتیاز BTCUSDT: {score:.1f}")
        
        # سیگنال با حجم کم
        low_volume = SignalData(
            signal_id=4, coin_id=9999, symbol="TESTUSDT",
            signal_type="BUY", confidence=0.7,
            entry_price=1.0, stop_loss=0.95, take_profit=1.2,
            created_at=datetime.now().isoformat(),
            volume_24h=50000,  # کم
            current_price=1.01, age_hours=0.5
        )
        low_volume_score = processor.calculate_priority_score(low_volume)
        print(f"   امتیاز با حجم کم: {low_volume_score:.1f}")
        
        print("\n" + "=" * 50)
        print("✅ تمام تست‌ها با موفقیت انجام شد")
        
        return True
        
    except Exception as e:
        print(f"❌ خطا در تست: {e}")
        import traceback
        traceback.print_exc()
        return False


if __name__ == "__main__":
    # اجرای تست
    test_result = test_signal_processor()
    
    if test_result:
        print("\n🚀 SignalProcessor آماده استفاده است!")
        print("\n📝 نکته: برای استفاده واقعی، باید TradingConfigManager واقعی به آن پاس داده شود.")
    else:
        print("\n❌ نیاز به رفع خطا دارد")