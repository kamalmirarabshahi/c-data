"""
report_generator.py - تولیدکننده گزارش برای تکه ۵
تکه ۵ - فایل ۶ از ۶

وظایف:
1. تولید گزارش‌های جامع از فرآیند تصمیم‌گیری
2. ذخیره گزارش در فرمت‌های مختلف
3. نمایش خلاصه در کنسول
4. تحلیل عملکرد و ارائه آمار

نویسنده: سیستم معاملاتی کریپتو
ورژن: 1.0.0
"""

import json
import logging
import os
from datetime import datetime
from typing import Dict, List, Any, Optional
from dataclasses import asdict


class ReportGenerator:
    """
    📊 تولیدکننده گزارش برای تکه ۵
    """
    
    def __init__(self, output_dir: str = "reports/cycle_05"):
        """
        مقداردهی اولیه
        
        Args:
            output_dir: دایرکتوری خروجی گزارش‌ها
        """
        self.output_dir = output_dir
        self.logger = self._setup_logger()
        
        # ایجاد دایرکتوری خروجی
        os.makedirs(output_dir, exist_ok=True)
        
        self.logger.info(f"✅ ReportGenerator راه‌اندازی شد. خروجی: {output_dir}")
    
    def _setup_logger(self) -> logging.Logger:
        """تنظیم لاگر"""
        logger = logging.getLogger("ReportGenerator")
        if not logger.handlers:
            handler = logging.StreamHandler()
            formatter = logging.Formatter(
                '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
            )
            handler.setFormatter(formatter)
            logger.addHandler(handler)
            logger.setLevel(logging.INFO)
        return logger
    
    def generate_execution_report(self, 
                                 decisions: List, 
                                 allocations: List = None,
                                 signals: List = None,
                                 config_summary: Dict = None) -> Dict[str, Any]:
        """
        تولید گزارش کامل اجرا
        
        Args:
            decisions: لیست تصمیم‌های گرفته شده
            allocations: لیست تخصیص‌ها (اختیاری)
            signals: لیست سیگنال‌ها (اختیاری)
            config_summary: خلاصه تنظیمات (اختیاری)
            
        Returns:
            گزارش کامل
        """
        timestamp = datetime.now().isoformat()
        
        # آمار تصمیم‌ها
        approved = [d for d in decisions if hasattr(d, 'status') and d.status == "APPROVED"]
        rejected = [d for d in decisions if hasattr(d, 'status') and d.status == "REJECTED"]
        buy_decisions = [d for d in approved if hasattr(d, 'decision_type') and 'BUY' in d.decision_type]
        sell_decisions = [d for d in approved if hasattr(d, 'decision_type') and 'SELL' in d.decision_type]
        
        # محاسبات مالی
        total_capital_allocated = sum(d.allocated_capital_usd for d in approved if hasattr(d, 'allocated_capital_usd'))
        total_risk = sum(d.risk_amount_usd for d in approved if hasattr(d, 'risk_amount_usd'))
        total_expected_profit = sum(d.expected_profit_usd for d in approved if hasattr(d, 'expected_profit_usd'))
        
        # آماده‌سازی گزارش
        report = {
            "metadata": {
                "report_type": "execution_summary",
                "generated_at": timestamp,
                "report_version": "1.0.0",
                "cycle": "cycle_05"
            },
            
            "execution_summary": {
                "total_processed": len(decisions),
                "approved": len(approved),
                "rejected": len(rejected),
                "approval_rate": (len(approved) / len(decisions) * 100) if decisions else 0,
                
                "buy_signals": len(buy_decisions),
                "sell_signals": len(sell_decisions),
                "hold_signals": len(approved) - len(buy_decisions) - len(sell_decisions),
                
                "financial_summary": {
                    "total_capital_allocated_usd": total_capital_allocated,
                    "total_risk_usd": total_risk,
                    "total_expected_profit_usd": total_expected_profit,
                    "avg_risk_per_trade_usd": total_risk / len(approved) if approved else 0,
                    "avg_expected_profit_per_trade_usd": total_expected_profit / len(approved) if approved else 0,
                },
                
                "performance_metrics": {
                    "avg_confidence_score": self._calculate_average(approved, 'confidence_score'),
                    "avg_final_score": self._calculate_average(approved, 'final_score'),
                    "avg_risk_reward_ratio": self._calculate_average(approved, 'risk_reward_ratio'),
                    "avg_net_risk_reward": self._calculate_average(approved, 'net_risk_reward'),
                    "avg_leverage": self._calculate_average(approved, 'leverage'),
                }
            },
            
            "top_decisions": self._get_top_decisions(approved, count=5),
            "rejection_analysis": self._analyze_rejections(rejected),
            
            "timestamp_analysis": {
                "processing_start": None,
                "processing_end": timestamp,
                "execution_duration_seconds": None
            }
        }
        
        # افزودن اطلاعات اضافی اگر موجود باشد
        if config_summary:
            report["configuration"] = config_summary
        
        if allocations:
            report["allocation_summary"] = self._summarize_allocations(allocations)
        
        if signals:
            report["signal_summary"] = self._summarize_signals(signals)
        
        self.logger.info(f"📊 گزارش اجرا تولید شد: {len(decisions)} تصمیم، {len(approved)} تأیید شده")
        
        return report
    
    def _calculate_average(self, items: List, attribute: str) -> float:
        """محاسبه میانگین یک ویژگی از لیست"""
        valid_items = [item for item in items if hasattr(item, attribute)]
        if not valid_items:
            return 0.0
        
        total = sum(getattr(item, attribute) for item in valid_items)
        return total / len(valid_items)
    
    def _get_top_decisions(self, decisions: List, count: int = 5) -> List[Dict]:
        """دریافت بهترین تصمیم‌ها"""
        if not decisions:
            return []
        
        # مرتب‌سازی بر اساس امتیاز نهایی
        sorted_decisions = sorted(
            decisions, 
            key=lambda x: getattr(x, 'final_score', 0), 
            reverse=True
        )[:count]
        
        top_decisions = []
        for decision in sorted_decisions:
            top_decisions.append({
                "symbol": getattr(decision, 'symbol', 'N/A'),
                "decision_type": getattr(decision, 'decision_type', 'N/A'),
                "final_score": getattr(decision, 'final_score', 0),
                "confidence": getattr(decision, 'confidence_score', 0),
                "risk_reward": getattr(decision, 'net_risk_reward', 0),
                "leverage": getattr(decision, 'leverage', 1),
                "capital_allocated_usd": getattr(decision, 'allocated_capital_usd', 0),
                "expected_profit_usd": getattr(decision, 'expected_profit_usd', 0),
            })
        
        return top_decisions
    
    def _analyze_rejections(self, rejected_decisions: List) -> Dict[str, Any]:
        """تحلیل دلایل رد تصمیم‌ها"""
        if not rejected_decisions:
            return {"total_rejected": 0, "rejection_reasons": {}}
        
        rejection_reasons = {}
        
        for decision in rejected_decisions:
            reason = getattr(decision, 'rejection_reason', 'نامشخص')
            
            # تجزیه دلیل
            if "اعتماد ناکافی" in reason:
                key = "اعتماد ناکافی"
            elif "ریسک/بازده پایین" in reason:
                key = "ریسک/بازده نامناسب"
            elif "لورج بیش از حد" in reason:
                key = "لورج زیاد"
            elif "سهم پوزیشن زیاد" in reason:
                key = "سایز پوزیشن بزرگ"
            elif "فاصله استاپ لاس نامتعارف" in reason:
                key = "استاپ لاس نامناسب"
            else:
                key = "سایر دلایل"
            
            rejection_reasons[key] = rejection_reasons.get(key, 0) + 1
        
        return {
            "total_rejected": len(rejected_decisions),
            "rejection_reasons": rejection_reasons,
            "rejection_rate_percent": 100.0,
            "top_rejection_reason": max(rejection_reasons.items(), key=lambda x: x[1])[0] if rejection_reasons else "نامشخص"
        }
    
    def _summarize_allocations(self, allocations: List) -> Dict[str, Any]:
        """خلاصه‌سازی تخصیص‌ها"""
        if not allocations:
            return {"total_allocations": 0}
        
        total_allocations = len(allocations)
        total_capital = sum(getattr(a, 'allocated_capital_usd', 0) for a in allocations)
        avg_leverage = sum(getattr(a, 'leverage', 1) for a in allocations) / total_allocations
        
        return {
            "total_allocations": total_allocations,
            "total_capital_allocated_usd": total_capital,
            "average_leverage": avg_leverage,
            "average_position_size_usd": total_capital / total_allocations if total_allocations > 0 else 0
        }
    
    def _summarize_signals(self, signals: List) -> Dict[str, Any]:
        """خلاصه‌سازی سیگنال‌ها"""
        if not signals:
            return {"total_signals": 0}
        
        buy_signals = [s for s in signals if getattr(s, 'signal_type', '').upper() == 'BUY']
        sell_signals = [s for s in signals if getattr(s, 'signal_type', '').upper() == 'SELL']
        
        return {
            "total_signals": len(signals),
            "buy_signals": len(buy_signals),
            "sell_signals": len(sell_signals),
            "avg_confidence": sum(getattr(s, 'confidence', 0) for s in signals) / len(signals) if signals else 0,
            "signal_types_distribution": {
                "BUY": len(buy_signals),
                "SELL": len(sell_signals),
                "HOLD": len(signals) - len(buy_signals) - len(sell_signals)
            }
        }
    
    def save_report_to_json(self, report: Dict[str, Any], filename: Optional[str] = None) -> str:
        """
        ذخیره گزارش در فایل JSON
        
        Args:
            report: گزارش
            filename: نام فایل (اختیاری)
            
        Returns:
            مسیر فایل ذخیره شده
        """
        if not filename:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"cycle_05_report_{timestamp}.json"
        
        filepath = os.path.join(self.output_dir, filename)
        
        try:
            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump(report, f, indent=2, ensure_ascii=False)
            
            self.logger.info(f"💾 گزارش JSON ذخیره شد: {filepath}")
            return filepath
            
        except Exception as e:
            self.logger.error(f"❌ خطا در ذخیره گزارش: {e}")
            return ""
    
    def generate_console_summary(self, report: Dict[str, Any]):
        """
        نمایش خلاصه گزارش در کنسول
        
        Args:
            report: گزارش
        """
        summary = report.get("execution_summary", {})
        financial = summary.get("financial_summary", {})
        metrics = summary.get("performance_metrics", {})
        
        print("\n" + "="*70)
        print("📊 گزارش اجرای تکه ۵ - تصمیم‌گیری معاملاتی")
        print("="*70)
        
        print(f"\n📈 آمار کلی:")
        print(f"   • تصمیم‌های پردازش شده: {summary.get('total_processed', 0)}")
        print(f"   • تصمیم‌های تأیید شده: {summary.get('approved', 0)}")
        print(f"   • تصمیم‌های رد شده: {summary.get('rejected', 0)}")
        print(f"   • نرخ تأیید: {summary.get('approval_rate', 0):.1f}%")
        
        print(f"\n💰 خلاصه مالی:")
        print(f"   • سرمایه تخصیص یافته: ${financial.get('total_capital_allocated_usd', 0):,.2f}")
        print(f"   • ریسک کل: ${financial.get('total_risk_usd', 0):,.2f}")
        print(f"   • سود انتظاری کل: ${financial.get('total_expected_profit_usd', 0):,.2f}")
        print(f"   • ریسک متوسط هر معامله: ${financial.get('avg_risk_per_trade_usd', 0):,.2f}")
        
        print(f"\n🎯 معیارهای عملکرد:")
        print(f"   • میانگین اعتماد: {metrics.get('avg_confidence_score', 0):.1f}%")
        print(f"   • میانگین امتیاز نهایی: {metrics.get('avg_final_score', 0):.1f}")
        print(f"   • میانگین ریسک/بازده: {metrics.get('avg_net_risk_reward', 0):.2f}")
        print(f"   • میانگین لورج: {metrics.get('avg_leverage', 0):.1f}x")
        
        # تحلیل رد شدن‌ها
        rejection_analysis = report.get("rejection_analysis", {})
        if rejection_analysis.get("total_rejected", 0) > 0:
            print(f"\n❌ تحلیل رد شدن‌ها:")
            reasons = rejection_analysis.get("rejection_reasons", {})
            for reason, count in reasons.items():
                print(f"   • {reason}: {count} مورد")
        
        # بهترین تصمیم‌ها
        top_decisions = report.get("top_decisions", [])
        if top_decisions:
            print(f"\n🏆 بهترین تصمیم‌ها:")
            for i, decision in enumerate(top_decisions[:3], 1):
                symbol = decision.get("symbol", "N/A")
                score = decision.get("final_score", 0)
                rr = decision.get("risk_reward", 0)
                profit = decision.get("expected_profit_usd", 0)
                print(f"   {i}. {symbol}: امتیاز {score:.1f}, R/R {rr:.2f}, سود انتظاری ${profit:,.2f}")
        
        print("\n" + "="*70)
        print(f"🕒 گزارش تولید شده در: {report.get('metadata', {}).get('generated_at', 'نامشخص')}")
        print("="*70)
    
    def generate_html_report(self, report: Dict[str, Any], filename: Optional[str] = None) -> str:
        """
        تولید گزارش HTML (نسخه ساده)
        
        Args:
            report: گزارش
            filename: نام فایل (اختیاری)
            
        Returns:
            مسیر فایل ذخیره شده
        """
        if not filename:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"cycle_05_report_{timestamp}.html"
        
        filepath = os.path.join(self.output_dir, filename)
        
        try:
            # HTML ساده
            html_content = f"""
            <!DOCTYPE html>
            <html lang="fa" dir="rtl">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>گزارش تکه ۵ - تصمیم‌گیری معاملاتی</title>
                <style>
                    body {{ font-family: Tahoma, sans-serif; margin: 20px; direction: rtl; }}
                    .container {{ max-width: 1200px; margin: 0 auto; }}
                    .header {{ background: #2c3e50; color: white; padding: 20px; border-radius: 5px; }}
                    .section {{ background: #f8f9fa; margin: 20px 0; padding: 15px; border-radius: 5px; border-right: 4px solid #3498db; }}
                    .stat-box {{ background: white; padding: 10px; margin: 10px; border-radius: 5px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }}
                    .positive {{ color: #27ae60; }}
                    .negative {{ color: #e74c3c; }}
                    table {{ width: 100%; border-collapse: collapse; margin: 10px 0; }}
                    th, td {{ padding: 10px; text-align: right; border-bottom: 1px solid #ddd; }}
                    th {{ background: #ecf0f1; }}
                </style>
            </head>
            <body>
                <div class="container">
                    <div class="header">
                        <h1>📊 گزارش تکه ۵ - تصمیم‌گیری معاملاتی</h1>
                        <p>تولید شده در: {report.get('metadata', {}).get('generated_at', 'نامشخص')}</p>
                    </div>
                    
                    <div class="section">
                        <h2>📈 آمار کلی اجرا</h2>
                        <div style="display: flex; flex-wrap: wrap;">
                            <div class="stat-box">
                                <h3>تصمیم‌های پردازش شده</h3>
                                <p style="font-size: 24px; font-weight: bold;">{report.get('execution_summary', {}).get('total_processed', 0)}</p>
                            </div>
                            <div class="stat-box">
                                <h3>تصمیم‌های تأیید شده</h3>
                                <p style="font-size: 24px; font-weight: bold; color: #27ae60;">{report.get('execution_summary', {}).get('approved', 0)}</p>
                            </div>
                            <div class="stat-box">
                                <h3>نرخ تأیید</h3>
                                <p style="font-size: 24px; font-weight: bold;">{report.get('execution_summary', {}).get('approval_rate', 0):.1f}%</p>
                            </div>
                        </div>
                    </div>
                    
                    <div class="section">
                        <h2>💰 خلاصه مالی</h2>
                        <table>
                            <tr>
                                <th>عنوان</th>
                                <th>مقدار</th>
                            </tr>
                            <tr>
                                <td>سرمایه تخصیص یافته</td>
                                <td>${report.get('execution_summary', {}).get('financial_summary', {}).get('total_capital_allocated_usd', 0):,.2f}</td>
                            </tr>
                            <tr>
                                <td>ریسک کل</td>
                                <td>${report.get('execution_summary', {}).get('financial_summary', {}).get('total_risk_usd', 0):,.2f}</td>
                            </tr>
                            <tr>
                                <td>سود انتظاری کل</td>
                                <td>${report.get('execution_summary', {}).get('financial_summary', {}).get('total_expected_profit_usd', 0):,.2f}</td>
                            </tr>
                        </table>
                    </div>
                    
                    <div class="section">
                        <h2>🏆 بهترین تصمیم‌ها</h2>
                        <table>
                            <tr>
                                <th>نماد</th>
                                <th>نوع تصمیم</th>
                                <th>امتیاز</th>
                                <th>ریسک/بازده</th>
                                <th>سرمایه</th>
                            </tr>
            """
            
            # افزودن بهترین تصمیم‌ها
            top_decisions = report.get('top_decisions', [])
            for decision in top_decisions[:5]:
                html_content += f"""
                            <tr>
                                <td>{decision.get('symbol', 'N/A')}</td>
                                <td>{decision.get('decision_type', 'N/A')}</td>
                                <td>{decision.get('final_score', 0):.1f}</td>
                                <td>{decision.get('risk_reward', 0):.2f}</td>
                                <td>${decision.get('capital_allocated_usd', 0):,.2f}</td>
                            </tr>
                """
            
            html_content += """
                        </table>
                    </div>
                    
                    <div class="section">
                        <h3>📝 اطلاعات فنی</h3>
                        <p><strong>ورژن گزارش:</strong> 1.0.0</p>
                        <p><strong>چرخه:</strong> تکه ۵ - تصمیم‌گیری معاملاتی</p>
                        <p><strong>سیستم:</strong> جمع‌آوری و تحلیل داده‌های کریپتو</p>
                    </div>
                </div>
            </body>
            </html>
            """
            
            with open(filepath, 'w', encoding='utf-8') as f:
                f.write(html_content)
            
            self.logger.info(f"💾 گزارش HTML ذخیره شد: {filepath}")
            return filepath
            
        except Exception as e:
            self.logger.error(f"❌ خطا در تولید گزارش HTML: {e}")
            return ""
    
    def generate_all_reports(self, 
                            decisions: List, 
                            allocations: List = None,
                            signals: List = None,
                            config_summary: Dict = None) -> Dict[str, str]:
        """
        تولید همه نوع گزارش
        
        Returns:
            دیکشنری مسیر فایل‌های ذخیره شده
        """
        # تولید گزارش اصلی
        report = self.generate_execution_report(
            decisions=decisions,
            allocations=allocations,
            signals=signals,
            config_summary=config_summary
        )
        
        # نمایش در کنسول
        self.generate_console_summary(report)
        
        # ذخیره در فایل‌های مختلف
        saved_files = {
            "json_report": self.save_report_to_json(report),
            "html_report": self.generate_html_report(report),
            "report_data": report
        }
        
        return saved_files


# ==================== تابع تست سریع ====================
def test_report_generator():
    """تست ReportGenerator"""
    print("\n🧪 تست ReportGenerator")
    print("=" * 50)
    
    try:
        # ایجاد نمونه
        reporter = ReportGenerator(output_dir="test_reports")
        
        # ایجاد داده تست
        from dataclasses import dataclass
        
        @dataclass
        class TestDecision:
            status: str
            decision_type: str
            symbol: str
            confidence_score: float
            final_score: float
            net_risk_reward: float
            leverage: int
            allocated_capital_usd: float
            risk_amount_usd: float
            expected_profit_usd: float
            rejection_reason: str = None
        
        # داده تست
        test_decisions = [
            TestDecision("APPROVED", "EXECUTE_BUY", "BTCUSDT", 0.85, 92.5, 2.2, 2, 2000, 40, 800),
            TestDecision("APPROVED", "EXECUTE_SELL", "ETHUSDT", 0.72, 78.3, 1.8, 1, 1500, 30, 540),
            TestDecision("REJECTED", "REJECT", "BNBUSDT", 0.45, 42.1, 0.8, 5, 1000, 20, 160, "اعتماد ناکافی: 0.45 < 0.5"),
            TestDecision("APPROVED", "EXECUTE_BUY", "XRPUSDT", 0.68, 71.2, 1.5, 1, 1200, 24, 360),
        ]
        
        print("📊 تولید گزارش...")
        
        # تولید گزارش
        report = reporter.generate_execution_report(
            decisions=test_decisions,
            config_summary={"version": "1.0.0", "simulation_mode": True}
        )
        
        print("✅ گزارش تولید شد")
        print(f"   • تصمیم‌ها: {report['execution_summary']['total_processed']}")
        print(f"   • تأیید شده: {report['execution_summary']['approved']}")
        print(f"   • رد شده: {report['execution_summary']['rejected']}")
        
        # ذخیره گزارش
        print("\n💾 ذخیره گزارش‌ها...")
        saved_files = reporter.generate_all_reports(
            decisions=test_decisions,
            config_summary={"version": "1.0.0"}
        )
        
        print(f"✅ فایل JSON: {saved_files.get('json_report', 'خطا')}")
        print(f"✅ فایل HTML: {saved_files.get('html_report', 'خطا')}")
        
        print("\n" + "=" * 50)
        print("✅ تست ReportGenerator موفق بود!")
        
        return True
        
    except Exception as e:
        print(f"❌ خطا در تست: {e}")
        import traceback
        traceback.print_exc()
        return False


if __name__ == "__main__":
    # اجرای تست اگر فایل مستقیماً اجرا شود
    test_result = test_report_generator()
    
    if test_result:
        print("\n🚀 ReportGenerator آماده استفاده است!")
        print("\n📝 نحوه استفاده:")
        print("""
        from report_generator import ReportGenerator
        
        # ایجاد گزارش‌گیر
        reporter = ReportGenerator()
        
        # تولید گزارش از تصمیم‌ها
        report = reporter.generate_execution_report(decisions=my_decisions)
        
        # نمایش در کنسول
        reporter.generate_console_summary(report)
        
        # ذخیره در فایل
        reporter.save_report_to_json(report)
        """)
    else:
        print("\n❌ نیاز به دیباگ دارد")