#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
portfolio_manager.py - مدیریت سبد معاملاتی و تخصیص سرمایه
تکه ۵ - فایل ۳ از ۸

ورودی: سیگنال‌های فیلتر شده + تنظیمات سرمایه
خروجی: تخصیص سرمایه، لورج، سایز پوزیشن برای هر سیگنال
وابستگی: trading_config_manager, signal_processor
"""

import logging
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass

@dataclass
class PositionAllocation:
    """تخصیص پوزیشن برای یک سیگنال"""
    signal_id: int
    coin_id: int
    symbol: str
    signal_type: str
    confidence: float
    priority_score: float
    
    # قیمت‌ها
    entry_price: float
    stop_loss: float
    take_profit: float
    current_price: float
    
    # تخصیص سرمایه
    allocated_capital_usd: float
    position_size: float  # تعداد واحد
    leverage: int
    
    # ریسک/بازده
    risk_amount_usd: float
    expected_profit_usd: float
    expected_loss_usd: float
    risk_reward_ratio: float
    
    # کارمزدها
    entry_fee_usd: float
    exit_fee_usd: float
    total_fee_usd: float
    net_risk_reward: float
    
    # متادیتا
    position_value_usd: float
    margin_required_usd: float
    free_margin_usd: float

@dataclass  
class PortfolioStats:
    """آمار سبد معاملاتی"""
    total_capital_usd: float = 0
    allocated_capital_usd: float = 0
    free_capital_usd: float = 0
    total_positions: int = 0
    total_risk_usd: float = 0
    total_expected_profit_usd: float = 0
    avg_leverage: float = 0
    avg_risk_reward: float = 0
    max_concurrent_trades: int = 0

class PortfolioManager:
    """
    💼 مدیر سبد معاملاتی
    تخصیص هوشمند سرمایه به سیگنال‌ها با درنظرگیری ریسک و لورج
    """
    
    def __init__(self, config_manager):
        """
        مقداردهی اولیه مدیر سبد
        
        Args:
            config_manager: مدیر تنظیمات TradingConfigManager
        """
        self.config = config_manager
        self.logger = self._setup_logger()
        self.stats = PortfolioStats()
        
        # تنظیمات از کانفیگ
        self.account_settings = self.config.account_settings
        self.risk_settings = self.config.risk_settings
        
        self.logger.info("✅ PortfolioManager راه‌اندازی شد")
    
    def _setup_logger(self) -> logging.Logger:
        """تنظیم لاگر"""
        logger = logging.getLogger("PortfolioManager")
        if not logger.handlers:
            handler = logging.StreamHandler()
            formatter = logging.Formatter(
                '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
                datefmt='%H:%M:%S'
            )
            handler.setFormatter(formatter)
            logger.addHandler(handler)
            logger.setLevel(logging.INFO)
        return logger
    
    def calculate_leverage(self, signal_confidence: float) -> int:
        """
        محاسبه لورج مناسب برای سیگنال
        
        Args:
            signal_confidence: اعتماد سیگنال (0-1)
            
        Returns:
            لورج مجاز
        """
        return self.config.get_leverage_for_score(signal_confidence)
    
    def calculate_position_size(self, 
                               entry_price: float, 
                               stop_loss: float,
                               signal_confidence: float,
                               allocated_capital: float) -> Dict[str, Any]:
        """
        محاسبه دقیق سایز پوزیشن با درنظرگیری همه پارامترها
        
        Args:
            entry_price: قیمت ورود
            stop_loss: حد ضرر
            signal_confidence: اعتماد سیگنال
            allocated_capital: سرمایه تخصیص یافته
            
        Returns:
            محاسبات کامل پوزیشن
        """
        # ۱. محاسبه لورج
        leverage = self.calculate_leverage(signal_confidence)
        
        # ۲. محاسبه ریسک به دلار
        max_risk_percent = self.risk_settings.max_risk_per_trade
        risk_amount_usd = allocated_capital * max_risk_percent
        
        # ۳. محاسبه فاصله قیمتی
        price_distance = abs(entry_price - stop_loss)
        if price_distance == 0:
            self.logger.warning("❌ فاصله قیمتی صفر")
            price_distance = entry_price * 0.01  # فرض 1% برای محاسبه
        
        # ۴. سایز پوزیشن پایه (بدون لورج)
        position_size_base = risk_amount_usd / price_distance
        
        # ۵. اعمال لورج
        position_size = position_size_base * leverage
        
        # ۶. ارزش پوزیشن
        position_value_usd = position_size * entry_price
        
        # ۷. مارجین مورد نیاز (سرمایه واقعی)
        margin_required = position_value_usd / leverage if leverage > 0 else position_value_usd
        
        # ۸. محدودیت‌های اضافی
        max_position_percent = self.config.config.get("position_management", {}).get("max_position_percent", 0.1)
        max_position_by_percent = allocated_capital * max_position_percent
        
        if position_value_usd > max_position_by_percent:
            position_value_usd = max_position_by_percent
            position_size = position_value_usd / entry_price
            margin_required = position_value_usd / leverage if leverage > 0 else position_value_usd
            self.logger.debug(f"📏 محدودیت اندازه پوزیشن اعمال شد")
        
        # ۹. محاسبه سود/زیان تخمینی
        take_profit_distance = abs(entry_price * self.risk_settings.min_risk_reward_ratio * (price_distance/entry_price))
        take_profit_price = entry_price + take_profit_distance if entry_price < stop_loss else entry_price - take_profit_distance
        
        expected_profit = abs(take_profit_price - entry_price) * position_size
        expected_loss = risk_amount_usd * leverage  # با احتساب لورج
        
        return {
            "position_size": position_size,
            "leverage": leverage,
            "position_value_usd": position_value_usd,
            "margin_required_usd": margin_required,
            "risk_amount_usd": risk_amount_usd,
            "expected_profit_usd": expected_profit,
            "expected_loss_usd": expected_loss,
            "take_profit_price": take_profit_price,
            "risk_reward_ratio": self.risk_settings.min_risk_reward_ratio
        }
    
    def calculate_fees(self, position_value_usd: float, leverage: int) -> Dict[str, float]:
        """
        محاسبه کارمزدهای معامله
        
        Args:
            position_value_usd: ارزش پوزیشن
            leverage: لورج استفاده شده
            
        Returns:
            کارمزدهای محاسبه شده
        """
        # ارزش واقعی معامله (با لورج)
        trade_value = position_value_usd * leverage if leverage > 1 else position_value_usd
        
        # محاسبه کارمزدها
        fees = self.config.calculate_fees(trade_value)
        
        return {
            "entry_fee_usd": fees["entry_fee_usd"],
            "exit_fee_usd": fees["exit_fee_usd"],
            "total_fee_usd": fees["total_fee_usd"],
            "entry_fee_percent": fees["entry_fee_percent"],
            "exit_fee_percent": fees["exit_fee_percent"],
            "trade_value_usd": trade_value
        }
    
    def allocate_capital_to_signals(self, 
                                   signals: List[Dict[str, Any]], 
                                   max_signals: Optional[int] = None) -> List[PositionAllocation]:
        """
        تخصیص سرمایه به سیگنال‌ها
        
        Args:
            signals: لیست سیگنال‌های فیلتر شده
            max_signals: حداکثر تعداد سیگنال (اختیاری)
            
        Returns:
            لیست تخصیص‌های پوزیشن
        """
        self.logger.info(f"💰 شروع تخصیص سرمایه به {len(signals)} سیگنال")
        
        if not signals:
            self.logger.warning("⚠️ هیچ سیگنالی برای تخصیص سرمایه وجود ندارد")
            return []
        
        # محدود کردن تعداد سیگنال‌ها
        max_concurrent = self.account_settings.max_concurrent_trades
        if max_signals:
            max_concurrent = min(max_signals, max_concurrent)
        
        signals_to_process = signals[:max_concurrent]
        
        # سرمایه قابل استفاده
        total_capital = self.account_settings.available_capital_usd
        reserve_percent = self.account_settings.reserve_capital_percent
        reserve_amount = total_capital * reserve_percent
        available_capital = total_capital - reserve_amount
        
        self.logger.info(f"   سرمایه کل: ${total_capital:,.2f}")
        self.logger.info(f"   سرمایه قابل استفاده: ${available_capital:,.2f}")
        self.logger.info(f"   حداکثر معاملات همزمان: {max_concurrent}")
        
        # تخصیص سرمایه به هر سیگنال (بر اساس امتیاز اولویت)
        allocations = []
        total_priority = sum(s.get("priority_score", 0) for s in signals_to_process)
        
        for signal in signals_to_process:
            # محاسبه سهم سرمایه بر اساس امتیاز
            priority_score = signal.get("priority_score", 0)
            capital_share = (priority_score / total_priority) if total_priority > 0 else (1 / len(signals_to_process))
            
            allocated_capital = available_capital * capital_share
            
            # محاسبه پوزیشن
            position_calc = self.calculate_position_size(
                entry_price=signal.get("entry_price", 0),
                stop_loss=signal.get("stop_loss", 0),
                signal_confidence=signal.get("confidence", 0),
                allocated_capital=allocated_capital
            )
            
            # محاسبه کارمزدها
            fees = self.calculate_fees(position_calc["position_value_usd"], position_calc["leverage"])
            
            # محاسبه ریسک/بازده خالص (با احتساب کارمزد)
            net_profit = position_calc["expected_profit_usd"] - fees["total_fee_usd"]
            net_loss = position_calc["expected_loss_usd"] + fees["total_fee_usd"]
            net_risk_reward = net_profit / net_loss if net_loss > 0 else 0
            
            # ایجاد تخصیص پوزیشن
            allocation = PositionAllocation(
                signal_id=signal.get("signal_id", 0),
                coin_id=signal.get("coin_id", 0),
                symbol=signal.get("symbol", "UNKNOWN"),
                signal_type=signal.get("signal_type", "HOLD"),
                confidence=signal.get("confidence", 0),
                priority_score=priority_score,
                
                entry_price=signal.get("entry_price", 0),
                stop_loss=signal.get("stop_loss", 0),
                take_profit=position_calc["take_profit_price"],
                current_price=signal.get("current_price", 0),
                
                allocated_capital_usd=allocated_capital,
                position_size=position_calc["position_size"],
                leverage=position_calc["leverage"],
                
                risk_amount_usd=position_calc["risk_amount_usd"],
                expected_profit_usd=position_calc["expected_profit_usd"],
                expected_loss_usd=position_calc["expected_loss_usd"],
                risk_reward_ratio=position_calc["risk_reward_ratio"],
                
                entry_fee_usd=fees["entry_fee_usd"],
                exit_fee_usd=fees["exit_fee_usd"],
                total_fee_usd=fees["total_fee_usd"],
                net_risk_reward=net_risk_reward,
                
                position_value_usd=position_calc["position_value_usd"],
                margin_required_usd=position_calc["margin_required_usd"],
                free_margin_usd=allocated_capital - position_calc["margin_required_usd"]
            )
            
            allocations.append(allocation)
            
            # ثبت لاگ
            self.logger.info(f"   📈 {signal.get('symbol')}:")
            self.logger.info(f"     سرمایه: ${allocated_capital:,.2f}")
            self.logger.info(f"     لورج: {position_calc['leverage']}")
            self.logger.info(f"     سایز: {position_calc['position_size']:.4f}")
            self.logger.info(f"     ریسک: ${position_calc['risk_amount_usd']:,.2f}")
            self.logger.info(f"     کارمزد: ${fees['total_fee_usd']:.2f}")
        
        # به‌روزرسانی آمار
        self._update_portfolio_stats(allocations, total_capital, available_capital)
        
        return allocations
    
    def _update_portfolio_stats(self, 
                               allocations: List[PositionAllocation],
                               total_capital: float,
                               available_capital: float):
        """
        به‌روزرسانی آمار سبد
        
        Args:
            allocations: تخصیص‌های پوزیشن
            total_capital: سرمایه کل
            available_capital: سرمایه قابل استفاده
        """
        if not allocations:
            return
        
        total_allocated = sum(a.allocated_capital_usd for a in allocations)
        total_risk = sum(a.risk_amount_usd for a in allocations)
        total_expected_profit = sum(a.expected_profit_usd for a in allocations)
        avg_leverage = sum(a.leverage for a in allocations) / len(allocations)
        avg_risk_reward = sum(a.net_risk_reward for a in allocations) / len(allocations)
        
        self.stats = PortfolioStats(
            total_capital_usd=total_capital,
            allocated_capital_usd=total_allocated,
            free_capital_usd=available_capital - total_allocated,
            total_positions=len(allocations),
            total_risk_usd=total_risk,
            total_expected_profit_usd=total_expected_profit,
            avg_leverage=avg_leverage,
            avg_risk_reward=avg_risk_reward,
            max_concurrent_trades=self.account_settings.max_concurrent_trades
        )
    
    def get_portfolio_summary(self) -> Dict[str, Any]:
        """
        دریافت خلاصه سبد معاملاتی
        
        Returns:
            خلاصه سبد
        """
        return {
            "capital": {
                "total": f"${self.stats.total_capital_usd:,.2f}",
                "allocated": f"${self.stats.allocated_capital_usd:,.2f}",
                "free": f"${self.stats.free_capital_usd:,.2f}",
                "utilization": f"{(self.stats.allocated_capital_usd/self.stats.total_capital_usd)*100:.1f}%" 
                               if self.stats.total_capital_usd > 0 else "0%"
            },
            "positions": {
                "total": self.stats.total_positions,
                "max_allowed": self.stats.max_concurrent_trades,
                "avg_leverage": f"{self.stats.avg_leverage:.1f}x",
                "avg_risk_reward": f"{self.stats.avg_risk_reward:.2f}"
            },
            "risk": {
                "total_risk": f"${self.stats.total_risk_usd:,.2f}",
                "total_expected_profit": f"${self.stats.total_expected_profit_usd:,.2f}",
                "portfolio_risk_percent": f"{(self.stats.total_risk_usd/self.stats.total_capital_usd)*100:.1f}%" 
                                         if self.stats.total_capital_usd > 0 else "0%"
            }
        }
    
    def validate_portfolio(self, allocations: List[PositionAllocation]) -> Tuple[bool, List[str]]:
        """
        اعتبارسنجی سبد معاملاتی
        
        Args:
            allocations: تخصیص‌های پوزیشن
            
        Returns:
            (معتبر است/نیست, لیست خطاها)
        """
        errors = []
        
        if not allocations:
            return True, ["سبد خالی است"]
        
        # ۱. بررسی بیش‌ازحد سرمایه تخصیص یافته
        total_allocated = sum(a.allocated_capital_usd for a in allocations)
        if total_allocated > self.account_settings.available_capital_usd:
            errors.append(f"سرمایه تخصیص یافته (${total_allocated:,.2f}) بیش از سرمایه کل است")
        
        # ۲. بررسی تعداد پوزیشن‌ها
        if len(allocations) > self.account_settings.max_concurrent_trades:
            errors.append(f"تعداد پوزیشن‌ها ({len(allocations)}) بیش از حد مجاز است")
        
        # ۳. بررسی ریسک کل
        total_risk = sum(a.risk_amount_usd for a in allocations)
        max_portfolio_risk = self.stats.total_capital_usd * self.risk_settings.max_portfolio_risk
        if total_risk > max_portfolio_risk:
            errors.append(f"ریسک کل (${total_risk:,.2f}) بیش از حد مجاز است")
        
        # ۴. بررسی لورج‌های خیلی بالا
        high_leverage = [a for a in allocations if a.leverage > 5]
        if high_leverage:
            errors.append(f"{len(high_leverage)} پوزیشن با لورج بالا (>5x) وجود دارد")
        
        # ۵. بررسی ریسک/بازده پایین
        low_rr = [a for a in allocations if a.net_risk_reward < 1.0]
        if low_rr:
            errors.append(f"{len(low_rr)} پوزیشن با ریسک/بازده پایین (<1.0) وجود دارد")
        
        is_valid = len(errors) == 0
        return is_valid, errors


# ==================== تست ساده ====================
def test_simple():
    """تست ساده عملکرد"""
    print("🧪 Simple PortfolioManager Test")
    print("=" * 50)
    
    # استفاده از کلاس تست از فایل قبلی
    class TestConfigManager:
        def __init__(self):
            class AccountSettings:
                available_capital_usd = 10000.0
                max_concurrent_trades = 5
                reserve_capital_percent = 0.1
            
            class RiskSettings:
                max_risk_per_trade = 0.02
                max_portfolio_risk = 0.15
                min_risk_reward_ratio = 1.5
            
            self.account_settings = AccountSettings()
            self.risk_settings = RiskSettings()
            self.config = {"position_management": {"max_position_percent": 0.1}}
        
        def get_leverage_for_score(self, score):
            if score >= 0.9: return 5
            elif score >= 0.7: return 3
            elif score >= 0.6: return 2
            else: return 1
        
        def calculate_fees(self, trade_value):
            return {
                "entry_fee_usd": trade_value * 0.001,
                "exit_fee_usd": trade_value * 0.001,
                "total_fee_usd": trade_value * 0.002,
                "entry_fee_percent": 0.001,
                "exit_fee_percent": 0.001
            }
    
    # تست
    config = TestConfigManager()
    manager = PortfolioManager(config)
    
    print("✅ PortfolioManager created successfully")
    print(f"   Capital: ${config.account_settings.available_capital_usd:,.2f}")
    print(f"   Max trades: {config.account_settings.max_concurrent_trades}")
    
    return True


if __name__ == "__main__":
    test_simple()