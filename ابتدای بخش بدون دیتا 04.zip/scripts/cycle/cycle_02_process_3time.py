"""
فایل: cycle_02_process_3time.py
مسیر: /cycle/cycle_02_process_3time.py
عملکرد: پردازش بلوک با رویکرد محافظه‌کارانه - جلوگیری از بلاک شدن IP
ورژن: 3.2 (اصلاح شده - محاسبه پویای تعداد کندل‌ها بر اساس آخرین بروزرسانی)
تاریخ: 2025-01-01
ویژگی‌ها:
- 3 تایم‌فریم: 15m, 1h, 4h
- تاخیرهای تصادفی بین درخواست‌ها
- نمایش پیشرفت با Progress Bar
- گزارش‌دهی واضح بدون شلوغی کنسول
- رعایت دقیق Rate Limit
- لاگ‌گیری جامع
- ذخیره قیمت‌ها بدون گرد کردن (تا ۸ رقم اعشار)
- محاسبه پویای تعداد کندل‌ها بر اساس آخرین بروزرسانی
"""

import os
import sys
import sqlite3
import json
import time
import random
import requests
import argparse
from datetime import datetime, timedelta, timezone
from pathlib import Path
from decimal import Decimal, getcontext, ROUND_HALF_UP
import math
from typing import Dict, List, Tuple, Optional, Any, Union

# ==================== پکیج‌های سفارشی برای Progress Bar ====================
try:
    from tqdm import tqdm
    TQDM_AVAILABLE = True
except ImportError:
    TQDM_AVAILABLE = False
    print("⚠️ پکیج tqdm نصب نیست. برای نصب: pip install tqdm")

# ==================== DECIMAL PRECISION SETUP ====================
getcontext().prec = 30  # افزایش دقت برای محاسبات

# ==================== ثابت‌های محافظه‌کارانه ====================
SAFE_SETTINGS = {
    'DELAYS': {
        'BETWEEN_SYMBOLS': (2, 5),  # تاخیر تصادفی بین ارزها (ثانیه)
        'BETWEEN_TIMEFRAMES': (1, 3),  # تاخیر بین تایم‌فریم‌ها
        'AFTER_RATE_LIMIT': (10, 30),  # تاخیر بعد از Rate Limit
        'BETWEEN_BLOCKS': (10, 20),  # تاخیر بین بلوک‌ها
    },
    'API_LIMITS': {
        'REQUESTS_PER_MINUTE': 100,  # 100 درخواست در دقیقه (محافظه‌کارانه)
        'MAX_RETRIES': 5,  # حداکثر تلاش مجدد
        'TIMEOUT': 30,  # تایم‌اوت درخواست
    },
    'BATCH_SIZE': {
        'CANDLES_PER_REQUEST': 200,  # 200 کندل در هر درخواست (حداکثر)
        'SYMBOLS_PER_BLOCK': 10,  # حداکثر 10 ارز در هر بلوک
    },
    'PRECISION': {
        'MAX_DECIMAL_PLACES': 8,  # حداکثر 8 رقم اعشار برای قیمت‌ها
    }
}

# ==================== FUNCTIONS FOR SAFE OPERATION ====================
class SafeAPIRequest:
    """کلاس مدیریت درخواست‌های API به صورت ایمن"""
    
    def __init__(self, base_url: str, max_retries: int = 5):
        self.base_url = base_url
        self.max_retries = max_retries
        self.request_count = 0
        self.reset_time = time.time() + 60  # ریست بعد از 60 ثانیه
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        })
    
    def safe_delay(self, delay_range: Tuple[float, float]) -> float:
        """تاخیر ایمن با محدوده تصادفی"""
        delay = random.uniform(*delay_range)
        time.sleep(delay)
        return delay
    
    def check_rate_limit(self) -> None:
        """بررسی Rate Limit"""
        current_time = time.time()
        if current_time >= self.reset_time:
            self.request_count = 0
            self.reset_time = current_time + 60
        
        if self.request_count >= SAFE_SETTINGS['API_LIMITS']['REQUESTS_PER_MINUTE']:
            wait_time = self.reset_time - current_time
            if wait_time > 0:
                print(f"⏳ رسیدن به حد Rate Limit. انتظار {wait_time:.1f} ثانیه...")
                time.sleep(wait_time + 1)  # یک ثانیه اضافه برای اطمینان
                self.request_count = 0
                self.reset_time = time.time() + 60
    
    def make_request(self, url: str, params: Dict) -> Dict[str, Any]:
        """انجام درخواست API با تلاش مجدد"""
        for attempt in range(self.max_retries):
            try:
                # بررسی Rate Limit
                self.check_rate_limit()
                
                # انجام درخواست
                response = self.session.get(
                    url, 
                    params=params, 
                    timeout=SAFE_SETTINGS['API_LIMITS']['TIMEOUT'],
                    verify=True  # بررسی SSL certificate
                )
                
                # افزایش شمارنده درخواست
                self.request_count += 1
                
                if response.status_code == 200:
                    return {"success": True, "data": response.json()}
                
                elif response.status_code == 429:  # Rate Limit
                    retry_after = int(response.headers.get('Retry-After', 30))
                    print(f"⚠️ Rate Limit فعال. انتظار {retry_after} ثانیه...")
                    time.sleep(retry_after)
                    continue
                
                elif response.status_code >= 500:  # خطای سرور
                    wait_time = 2 ** attempt  # Exponential backoff
                    print(f"⚠️ خطای سرور ({response.status_code}). انتظار {wait_time} ثانیه...")
                    time.sleep(wait_time)
                    continue
                
                else:
                    return {"success": False, "error": f"HTTP {response.status_code}: {response.text[:100]}"}
                    
            except requests.exceptions.Timeout:
                print(f"⚠️ Timeout (تلاش {attempt + 1}/{self.max_retries})")
                time.sleep(2 ** attempt)
            except requests.exceptions.ConnectionError:
                print(f"⚠️ خطای اتصال (تلاش {attempt + 1}/{self.max_retries})")
                time.sleep(5 * (attempt + 1))
            except Exception as e:
                return {"success": False, "error": f"خطای ناشناخته: {str(e)}"}
        
        return {"success": False, "error": f"تلاش‌های ناموفق پس از {self.max_retries} بار"}

# ==================== PRICE PRECISION FUNCTIONS ====================
def format_decimal_price(price_str: str, max_decimal_places: int = 8) -> str:
    """
    فرمت قیمت به صورت رشته با حداکثر 8 رقم اعشار
    بدون گرد کردن - فقط حذف ارقام اضافی
    """
    try:
        if not price_str or price_str.strip() == '':
            return price_str
            
        # تبدیل به Decimal برای دقت
        dec_price = Decimal(price_str)
        
        # اگر عدد صحیح است
        if dec_price == dec_price.to_integral():
            return str(dec_price.quantize(Decimal(1)))
        
        # تبدیل به رشته و حفظ ارقام اعشار
        price_str_normalized = format(dec_price, 'f')
        
        if '.' in price_str_normalized:
            integer_part, decimal_part = price_str_normalized.split('.')
            
            # محدود کردن به حداکثر 8 رقم اعشار بدون گرد کردن
            if len(decimal_part) > max_decimal_places:
                decimal_part = decimal_part[:max_decimal_places]
            
            # حذف صفرهای انتهای اعشار
            decimal_part = decimal_part.rstrip('0')
            
            if decimal_part:
                return f"{integer_part}.{decimal_part}"
            else:
                return integer_part
        else:
            return price_str_normalized
            
    except Exception:
        # در صورت خطا، مقدار اصلی برگردانده شود
        return price_str

def adjust_price_precision_for_low_prices(
    open_price_str: str, 
    close_price_str: str, 
    high_price_str: str, 
    low_price_str: str
) -> Tuple[str, str, str, str, bool]:
    """
    تنظیم دقت برای ارزهای کم‌قیمت (فقط در صورت Open=Close)
    """
    try:
        open_dec = Decimal(open_price_str)
        close_dec = Decimal(close_price_str)
        high_dec = Decimal(high_price_str)
        low_dec = Decimal(low_price_str)
        
        # فقط برای ارزهای کم‌قیمت و وقتی Open=Close
        if open_dec < Decimal('0.01') and open_dec == close_dec:
            # محاسبه دقت اعشار
            open_str = format_decimal_price(open_price_str)
            
            # تعیین کوچکترین گام
            if '.' in open_str:
                decimal_places = len(open_str.split('.')[1])
                smallest_step = Decimal('1') / (Decimal('10') ** decimal_places)
            else:
                smallest_step = Decimal('0.00000001')
            
            # ایجاد تغییر کوچک
            if high_dec > open_dec:
                adjusted_close = close_dec + smallest_step
            elif low_dec < open_dec:
                adjusted_close = close_dec - smallest_step
            else:
                adjusted_close = close_dec + smallest_step
            
            # فرمت کردن قیمت‌ها بدون گرد کردن
            open_final = format_decimal_price(str(open_dec))
            close_final = format_decimal_price(str(adjusted_close))
            high_final = format_decimal_price(high_price_str)
            low_final = format_decimal_price(low_price_str)
            
            return open_final, close_final, high_final, low_final, True
        else:
            # فقط فرمت کردن بدون تغییر
            open_final = format_decimal_price(open_price_str)
            close_final = format_decimal_price(close_price_str)
            high_final = format_decimal_price(high_price_str)
            low_final = format_decimal_price(low_price_str)
            
            return open_final, close_final, high_final, low_final, False
            
    except Exception as e:
        # در صورت خطا، مقادیر اصلی فرمت شده برگردانده شود
        open_final = format_decimal_price(open_price_str)
        close_final = format_decimal_price(close_price_str)
        high_final = format_decimal_price(high_price_str)
        low_final = format_decimal_price(low_price_str)
        
        return open_final, close_final, high_final, low_final, False

def validate_candle_data(candle: List) -> bool:
    """اعتبارسنجی داده‌های کندل"""
    try:
        if len(candle) < 11:
            return False
        
        # بررسی timestamp
        open_time = candle[0]
        close_time = candle[6]
        
        if open_time <= 0 or close_time <= 0 or close_time < open_time:
            return False
        
        # بررسی قیمت‌ها
        open_price = Decimal(str(candle[1]))
        high_price = Decimal(str(candle[2]))
        low_price = Decimal(str(candle[3]))
        close_price = Decimal(str(candle[4]))
        
        # high باید بزرگتر یا مساوی low باشد
        if high_price < low_price:
            return False
        
        # open و close باید بین high و low باشند
        if not (low_price <= open_price <= high_price):
            return False
        
        if not (low_price <= close_price <= high_price):
            return False
        
        # بررسی volume
        volume = Decimal(str(candle[5]))
        if volume < 0:
            return False
        
        return True
        
    except Exception:
        return False

# ==================== CONFIGURATION ====================
def load_config() -> Dict[str, Any]:
    """بارگذاری تنظیمات"""
    try:
        current_dir = os.path.dirname(os.path.abspath(__file__))
        config_file = os.path.join(current_dir, "..", "..", "config", "settings.json")
        config_file = os.path.abspath(config_file)
        
        if not os.path.exists(config_file):
            return {"success": False, "error": f"فایل کانفیگ یافت نشد: {config_file}"}
        
        with open(config_file, 'r', encoding='utf-8') as f:
            config_data = json.load(f)
        
        # اعتبارسنجی ساختار config
        if not isinstance(config_data, dict):
            return {"success": False, "error": "ساختار فایل کانفیگ نامعتبر است"}
        
        # تنظیمات پایه
        paths = config_data.get('paths', {})
        database = config_data.get('database', {})
        
        project_root = paths.get('project_root')
        if not project_root:
            return {"success": False, "error": "'paths.project_root' یافت نشد"}
        
        # مسیر دیتابیس
        database_path = database.get('path')
        if not database_path:
            database_name = database.get('name', 'crypto_master.db')
            data_dir = paths.get('data_dir', os.path.join(project_root, 'data'))
            database_path = os.path.join(data_dir, database_name)
        
        # تنظیمات تایم‌فریم‌های جدید
        timeframes = ['15m', '1h', '4h']  # تایم‌فریم‌های ثابت
        
        # ترکیب تنظیمات
        config = {
            "project_root": project_root,
            "database_path": database_path,
            "timeframes": timeframes,
            "candles_per_request": SAFE_SETTINGS['BATCH_SIZE']['CANDLES_PER_REQUEST'],
            "api_retry_attempts": SAFE_SETTINGS['API_LIMITS']['MAX_RETRIES'],
            "binance_base_url": 'https://api.binance.com/api/v3',
            "safe_settings": SAFE_SETTINGS
        }
        
        # مسیر state file
        state_dir = os.path.join(project_root, "state")
        os.makedirs(state_dir, exist_ok=True)
        config["state_file"] = os.path.join(state_dir, "cycle_state.json")
        
        print(f"✅ تنظیمات بارگذاری شد")
        print(f"📁 دیتابیس: {Path(database_path).name}")
        print(f"📊 تایم‌فریم‌ها: {', '.join(timeframes)}")
        print(f"🔒 حالت محافظه‌کارانه: فعال")
        print(f"💰 دقت قیمت: تا {SAFE_SETTINGS['PRECISION']['MAX_DECIMAL_PLACES']} رقم اعشار")
        
        return {"success": True, "config": config}
        
    except json.JSONDecodeError as e:
        return {"success": False, "error": f"خطای JSON در فایل کانفیگ: {str(e)}"}
    except Exception as e:
        return {"success": False, "error": f"خطا در بارگذاری تنظیمات: {str(e)}"}

# ==================== FUNCTIONS FOR DYNAMIC CANDLE CALCULATION ====================
def get_last_update_info(symbol: str, db_path: str) -> Dict[str, Any]:
    """
    دریافت اطلاعات آخرین بروزرسانی برای یک ارز از دیتابیس
    """
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        clean_symbol = symbol.upper()
        if not clean_symbol.endswith('USDT'):
            clean_symbol = f"{clean_symbol}USDT"
        
        # دریافت coin_id
        cursor.execute("SELECT id FROM crypto_coins WHERE symbol = ?", (clean_symbol,))
        coin_result = cursor.fetchone()
        
        if not coin_result:
            conn.close()
            return {"success": False, "error": f"ارز {clean_symbol} یافت نشد"}
        
        coin_id = coin_result[0]
        
        # دریافت آخرین کندل بر اساس تایم‌فریم
        last_updates = {}
        
        for timeframe in ['15m', '1h', '4h']:
            cursor.execute('''
                SELECT MAX(close_time) FROM crypto_klines 
                WHERE coin_id = ? AND timeframe = ?
            ''', (coin_id, timeframe))
            
            result = cursor.fetchone()
            if result and result[0]:
                last_updates[timeframe] = result[0]
            else:
                last_updates[timeframe] = None
        
        conn.close()
        
        return {
            "success": True,
            "symbol": clean_symbol,
            "coin_id": coin_id,
            "last_updates": last_updates
        }
        
    except Exception as e:
        return {"success": False, "error": f"خطا در دریافت اطلاعات آخرین بروزرسانی: {str(e)}"}

def calculate_required_candles(timeframe: str, last_update_str: Optional[str]) -> int:
    """
    محاسبه تعداد کندل‌های مورد نیاز بر اساس آخرین بروزرسانی
    
    فرمول: (اختلاف ساعت از آخرین بروزرسانی) × 5
    اگر اختلاف ساعت بیش از 200/5=40 ساعت باشد، حداکثر 200 کندل
    """
    MAX_CANDLES = SAFE_SETTINGS['BATCH_SIZE']['CANDLES_PER_REQUEST']  # 200
    
    # اگر تاریخ آخرین بروزرسانی وجود نداشته باشد، حداکثر مقدار برگردان
    if not last_update_str:
        return MAX_CANDLES
    
    try:
        # تبدیل رشته تاریخ به datetime object
        # فرمت: 'YYYY-MM-DD HH:MM:SS' یا 'YYYY-MM-DD HH:MM:SS.999000'
        if '.' in last_update_str:
            last_update_str = last_update_str.split('.')[0]
        
        last_update = datetime.strptime(last_update_str, '%Y-%m-%d %H:%M:%S')
        
        # زمان فعلی
        current_time = datetime.now()
        
        # محاسبه اختلاف به ساعت
        time_diff = current_time - last_update
        hours_diff = time_diff.total_seconds() / 3600
        
        # اگر اختلاف منفی باشد (آینده) یا مشکوک باشد
        if hours_diff < 0 or hours_diff > 24 * 30:  # بیش از 30 روز
            print(f"   ⚠️ تاریخ آخرین بروزرسانی مشکوک: {last_update_str} (اختلاف: {hours_diff:.1f} ساعت)")
            return MAX_CANDLES
        
        # رند کردن ساعت به پایین (بدون اعشار)
        hours_diff_int = int(math.floor(hours_diff))
        
        # اگر کمتر از 1 ساعت گذشته باشد، حداقل 1 کندل درخواست کنیم
        if hours_diff_int < 1:
            hours_diff_int = 1
        
        # محاسبه تعداد کندل‌های مورد نیاز
        required_candles = hours_diff_int * 5
        
        # محدود کردن به حداکثر مقدار
        if required_candles > MAX_CANDLES:
            required_candles = MAX_CANDLES
        
        # اطمینان از حداقل 1 کندل
        if required_candles < 1:
            required_candles = 1
        
        print(f"   ⏰ {timeframe}: آخرین بروزرسانی: {last_update_str}")
        print(f"   ⏳ اختلاف: {hours_diff:.1f} ساعت، کندل‌های مورد نیاز: {required_candles}")
        
        return required_candles
        
    except Exception as e:
        print(f"   ⚠️ خطا در محاسبه تعداد کندل‌ها: {str(e)}")
        return MAX_CANDLES

def get_dynamic_candle_limit(symbol: str, timeframe: str, db_path: str) -> int:
    """
    دریافت تعداد پویای کندل‌ها برای یک ارز و تایم‌فریم
    """
    # دریافت اطلاعات آخرین بروزرسانی
    update_info = get_last_update_info(symbol, db_path)
    
    if not update_info["success"]:
        print(f"   ⚠️ خطا در دریافت اطلاعات {symbol}: {update_info.get('error')}")
        return SAFE_SETTINGS['BATCH_SIZE']['CANDLES_PER_REQUEST']  # مقدار پیش‌فرض
    
    # دریافت تاریخ آخرین بروزرسانی برای این تایم‌فریم
    last_update = update_info["last_updates"].get(timeframe)
    
    # محاسبه تعداد کندل‌های مورد نیاز
    return calculate_required_candles(timeframe, last_update)

# ==================== PROGRESS DISPLAY ====================
class ProgressTracker:
    """کلاس پیگیری و نمایش پیشرفت"""
    
    def __init__(self):
        self.start_time = time.time()
        self.block_start_time = None
        self.symbol_start_time = None
        
    def print_header(self, title: str) -> None:
        """چاپ هدر زیبا"""
        print("\n" + "=" * 70)
        print(f"📊 {title}")
        print("=" * 70)
    
    def print_block_header(self, block_num: int, total_blocks: int, symbols: List[str]) -> None:
        """چاپ هدر بلوک"""
        self.block_start_time = time.time()
        print(f"\n{'='*60}")
        print(f"📦 بلوک {block_num}/{total_blocks}")
        print(f"💰 {len(symbols) if symbols else 0} ارز")
        print(f"{'='*60}")
    
    def print_block_summary(self, block_num: int, stats: Dict[str, Any]) -> None:
        """چاپ خلاصه بلوک"""
        block_time = time.time() - self.block_start_time
        
        print(f"\n📋 خلاصه بلوک {block_num}:")
        print(f"   ✅ ارزهای موفق: {stats.get('successful', 0)}")
        print(f"   ❌ ارزهای ناموفق: {stats.get('failed', 0)}")
        print(f"   📈 کندل‌های جدید: {stats.get('inserted', 0)}")
        print(f"   🔄 کندل‌های تکراری: {stats.get('duplicates', 0)}")
        print(f"   ⏱️ زمان بلوک: {block_time:.1f} ثانیه")
        
        if stats.get('delays') and len(stats['delays']) > 0:
            avg_delay = sum(stats['delays']) / len(stats['delays'])
            print(f"   ⏳ میانگین تاخیر: {avg_delay:.1f} ثانیه")
    
    def print_final_summary(self, total_stats: Dict[str, Any]) -> None:
        """چاپ خلاصه نهایی"""
        total_time = time.time() - self.start_time
        
        print("\n" + "=" * 70)
        print("🎉 خلاصه نهایی اجرا")
        print("=" * 70)
        print(f"   ⏱️ زمان کل: {total_time:.1f} ثانیه ({total_time/60:.1f} دقیقه)")
        print(f"   📦 بلوک‌های پردازش شده: {total_stats.get('blocks_processed', 0)}")
        print(f"   💰 کل ارزها: {total_stats.get('total_symbols', 0)}")
        print(f"   ✅ ارزهای موفق کل: {total_stats.get('total_successful', 0)}")
        print(f"   ❌ ارزهای ناموفق کل: {total_stats.get('total_failed', 0)}")
        print(f"   📈 کندل‌های جدید کل: {total_stats.get('total_inserted', 0)}")
        print(f"   🔄 کندل‌های تکراری کل: {total_stats.get('total_duplicates', 0)}")
        print(f"   ⚠️ خطاهای API کل: {total_stats.get('total_api_errors', 0)}")
        print("=" * 70)

# ==================== DATABASE FUNCTIONS ====================
def check_database_connection(db_path: str) -> Dict[str, Any]:
    """بررسی اتصال دیتابیس"""
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # بررسی جداول ضروری
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='crypto_coins'")
        if not cursor.fetchone():
            conn.close()
            return {"success": False, "error": "جدول crypto_coins وجود ندارد"}
        
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='crypto_klines'")
        if not cursor.fetchone():
            conn.close()
            return {"success": False, "error": "جدول crypto_klines وجود ندارد"}
        
        # آمار موجودی
        cursor.execute("SELECT COUNT(*) FROM crypto_klines")
        total_candles = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM crypto_coins")
        total_coins = cursor.fetchone()[0]
        
        conn.close()
        
        print(f"   ✅ دیتابیس سالم - {total_coins} ارز، {total_candles} کندل")
        return {"success": True, "total_coins": total_coins, "total_candles": total_candles}
        
    except Exception as e:
        return {"success": False, "error": f"خطای دیتابیس: {str(e)}"}

def save_candle_data(db_path: str, symbol: str, timeframe: str, candles: List[List]) -> Dict[str, Any]:
    """ذخیره داده‌های کندل"""
    if not candles:
        return {
            "success": True, 
            "inserted_count": 0, 
            "duplicate_count": 0,
            "total_candles": 0,
            "symbol": symbol.upper()
        }
    
    try:
        # دریافت coin_id
        with sqlite3.connect(db_path) as conn:
            cursor = conn.cursor()
            
            clean_symbol = symbol.upper()
            if not clean_symbol.endswith('USDT'):
                clean_symbol = f"{clean_symbol}USDT"
            
            cursor.execute("SELECT id FROM crypto_coins WHERE symbol = ?", (clean_symbol,))
            result = cursor.fetchone()
            
            if not result:
                return {"success": False, "error": f"ارز {clean_symbol} یافت نشد"}
            
            coin_id = result[0]
            
            # ذخیره کندل‌ها
            inserted_count = 0
            duplicate_count = 0
            invalid_candle_count = 0
            
            for candle in candles:
                try:
                    # اعتبارسنجی کندل
                    if not validate_candle_data(candle):
                        invalid_candle_count += 1
                        continue
                    
                    # تنظیم دقت قیمت
                    open_raw = str(candle[1])
                    close_raw = str(candle[4])
                    high_raw = str(candle[2])
                    low_raw = str(candle[3])
                    
                    open_final, close_final, high_final, low_final, _ = adjust_price_precision_for_low_prices(
                        open_raw, close_raw, high_raw, low_raw
                    )
                    
                    # تبدیل زمان (با UTC)
                    open_timestamp = candle[0]
                    close_timestamp = candle[6]
                    
                    open_time = datetime.fromtimestamp(open_timestamp / 1000, tz=timezone.utc).strftime('%Y-%m-%d %H:%M:%S')
                    close_time = datetime.fromtimestamp(close_timestamp / 1000, tz=timezone.utc).strftime('%Y-%m-%d %H:%M:%S.999000')
                    candle_date = datetime.fromtimestamp(open_timestamp / 1000, tz=timezone.utc).strftime('%Y-%m-%d')
                    
                    # داده‌ها به صورت رشته برای حفظ دقت
                    open_price = open_final
                    close_price = close_final
                    high_price = high_final
                    low_price = low_final
                    
                    # حجم‌ها با دقت بالا
                    volume = str(candle[5])
                    quote_volume = str(candle[7])
                    number_of_trades = candle[8]
                    taker_buy_volume = str(candle[9])
                    taker_buy_quote_volume = str(candle[10])
                    
                    # محاسبه taker_sell_volume با Decimal برای دقت
                    try:
                        volume_dec = Decimal(volume)
                        taker_buy_volume_dec = Decimal(taker_buy_volume)
                        taker_sell_volume_dec = max(Decimal('0'), volume_dec - taker_buy_volume_dec)
                        taker_sell_volume = format_decimal_price(str(taker_sell_volume_dec))
                    except:
                        taker_sell_volume = '0'
                    
                    # درج داده
                    cursor.execute('''
                    INSERT OR IGNORE INTO crypto_klines 
                    (coin_id, timeframe, open_time, close_time, candle_date,
                     open_price, high_price, low_price, close_price, 
                     volume, quote_volume, number_of_trades,
                     taker_buy_volume, taker_sell_volume, taker_buy_quote_volume,
                     created_at, updated_at, source_exchange, is_verified)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 
                            datetime('now'), datetime('now'), 'binance', 1)
                    ''', (
                        coin_id, timeframe, open_time, close_time, candle_date,
                        open_price, high_price, low_price, close_price,
                        volume, quote_volume, number_of_trades,
                        taker_buy_volume, taker_sell_volume, taker_buy_quote_volume
                    ))
                    
                    if cursor.rowcount > 0:
                        inserted_count += 1
                    else:
                        duplicate_count += 1
                        
                except Exception as e:
                    duplicate_count += 1
                    continue
            
            conn.commit()
            
            if invalid_candle_count > 0:
                print(f"   ⚠️ {invalid_candle_count} کندل نامعتبر حذف شد")
            
            return {
                "success": True, 
                "inserted_count": inserted_count, 
                "duplicate_count": duplicate_count,
                "total_candles": len(candles),
                "symbol": clean_symbol,
                "invalid_candles": invalid_candle_count
            }
            
    except Exception as e:
        return {"success": False, "error": f"خطای ذخیره‌سازی: {str(e)}"}

# ==================== BLOCK PROCESSING ====================
def process_block_safely(
    config: Dict[str, Any], 
    state_data: Dict[str, Any], 
    block_num: int, 
    progress_tracker: ProgressTracker, 
    api_client: SafeAPIRequest,
    end_block: int
) -> Dict[str, Any]:
    """پردازش ایمن یک بلوک"""
    # یافتن بلوک
    block_data = None
    for block in state_data['blocks']:
        if block['block_id'] == block_num:
            block_data = block
            break
    
    if not block_data:
        return {"success": False, "error": f"بلوک {block_num} یافت نشد"}
    
    symbols = block_data['symbols']
    
    # بررسی بلوک خالی
    if not symbols:
        print(f"   ⚠️ بلوک {block_num} خالی است - رد شدن")
        return {
            "success": True, 
            "block_stats": {
                'successful': 0,
                'failed': 0,
                'inserted': 0,
                'duplicates': 0,
                'api_errors': 0,
                'delays': []
            }
        }
    
    # چاپ هدر بلوک
    progress_tracker.print_block_header(block_num, len(state_data['blocks']), symbols)
    
    # آمار بلوک
    block_stats = {
        'successful': 0,
        'failed': 0,
        'inserted': 0,
        'duplicates': 0,
        'api_errors': 0,
        'delays': []
    }
    
    # استفاده از Progress Bar اگر موجود باشد
    if TQDM_AVAILABLE:
        symbols_iterator = tqdm(symbols, desc=f"بلوک {block_num}", unit="ارز")
    else:
        symbols_iterator = symbols
        print(f"📊 پردازش {len(symbols)} ارز...")
    
    # پردازش هر ارز
    for symbol_idx, symbol in enumerate(symbols_iterator):
        if not TQDM_AVAILABLE:
            print(f"\n  • {symbol} ", end="", flush=True)
        
        symbol_success = False
        symbol_inserted = 0
        symbol_duplicates = 0
        symbol_api_errors = 0
        
        # پردازش هر تایم‌فریم
        for timeframe in config['timeframes']:
            # محاسبه پویای تعداد کندل‌های مورد نیاز
            dynamic_limit = get_dynamic_candle_limit(symbol, timeframe, config['database_path'])
            
            # دریافت داده از API
            url = f"{config['binance_base_url']}/klines"
            params = {
                'symbol': symbol.upper(),
                'interval': timeframe,
                'limit': dynamic_limit  # استفاده از مقدار پویا
            }
            
            api_result = api_client.make_request(url, params)
            
            if api_result['success']:
                # ذخیره داده‌ها
                save_result = save_candle_data(
                    config['database_path'], 
                    symbol, 
                    timeframe, 
                    api_result['data']
                )
                
                if save_result['success']:
                    symbol_inserted += save_result['inserted_count']
                    symbol_duplicates += save_result['duplicate_count']
                    symbol_success = True
                else:
                    if not TQDM_AVAILABLE:
                        print("❌", end="")
            else:
                symbol_api_errors += 1
                block_stats['api_errors'] += 1
                if not TQDM_AVAILABLE:
                    print("⚠️", end="")
            
            # تاخیر بین تایم‌فریم‌ها
            delay = api_client.safe_delay(SAFE_SETTINGS['DELAYS']['BETWEEN_TIMEFRAMES'])
            block_stats['delays'].append(delay)
        
        # بروزرسانی آمار
        if symbol_success:
            block_stats['successful'] += 1
            block_stats['inserted'] += symbol_inserted
            block_stats['duplicates'] += symbol_duplicates
            if not TQDM_AVAILABLE:
                print(f" ✅ ({symbol_inserted} جدید)")
        else:
            block_stats['failed'] += 1
            if not TQDM_AVAILABLE:
                print(" ❌")
        
        # تاخیر بین ارزها
        if symbol_idx < len(symbols) - 1:  # تاخیر برای همه به جز آخرین ارز
            delay = api_client.safe_delay(SAFE_SETTINGS['DELAYS']['BETWEEN_SYMBOLS'])
            block_stats['delays'].append(delay)
    
    # تاخیر بین بلوک‌ها
    if block_num < end_block:
        delay = api_client.safe_delay(SAFE_SETTINGS['DELAYS']['BETWEEN_BLOCKS'])
        print(f"\n⏳ تاخیر بین بلوک‌ها: {delay:.1f} ثانیه")
        block_stats['delays'].append(delay)
    
    # نمایش خلاصه بلوک
    progress_tracker.print_block_summary(block_num, block_stats)
    
    # بروزرسانی state
    block_index = block_num - 1
    state_data['blocks'][block_index]['processed'] = True
    state_data['blocks'][block_index]['processed_at'] = datetime.now(timezone.utc).isoformat()
    state_data['blocks'][block_index]['stats'] = block_stats
    
    return {"success": True, "block_stats": block_stats}

# ==================== STATE MANAGEMENT ====================
def save_state_file(state_file: str, state_data: Dict[str, Any]) -> bool:
    """ذخیره ایمن state file"""
    try:
        # ذخیره در فایل موقت
        temp_file = f"{state_file}.tmp"
        with open(temp_file, 'w', encoding='utf-8') as f:
            json.dump(state_data, f, indent=2, ensure_ascii=False)
        
        # جایگزینی فایل اصلی
        if os.path.exists(state_file):
            os.replace(temp_file, state_file)
        else:
            os.rename(temp_file, state_file)
        
        return True
    except Exception as e:
        print(f"   ⚠️ خطا در ذخیره state: {e}")
        # حذف فایل موقت در صورت خطا
        if os.path.exists(temp_file):
            try:
                os.remove(temp_file)
            except:
                pass
        return False

# ==================== MAIN FUNCTION ====================
def run_safe_block_processing(start_block: Optional[int] = None, end_block: Optional[int] = None) -> Dict[str, Any]:
    """تابع اصلی اجرا با رویکرد ایمن"""
    
    # ایجاد tracker
    progress = ProgressTracker()
    progress.print_header("🔐 پردازش بلوک با رویکرد محافظه‌کارانه")
    print("✨ ورژن 3.2 - محاسبه پویای تعداد کندل‌ها بر اساس آخرین بروزرسانی")
    print("💰 قیمت‌ها تا ۸ رقم اعشار دقیق ذخیره می‌شوند")
    print("📊 تعداد کندل‌ها به صورت پویا محاسبه می‌شود")
    
    start_time = time.time()
    
    # 1. بارگذاری تنظیمات
    print("\n1️⃣ بارگذاری تنظیمات...")
    config_result = load_config()
    if not config_result["success"]:
        print(f"❌ {config_result['error']}")
        return config_result
    
    config = config_result["config"]
    
    # 2. بارگذاری وضعیت
    print("\n2️⃣ بارگذاری وضعیت چرخه...")
    try:
        with open(config["state_file"], 'r', encoding='utf-8') as f:
            state_data = json.load(f)
        
        print(f"   ✅ چرخه: {state_data.get('cycle_id')}")
        print(f"   📊 کل بلوک‌ها: {len(state_data.get('blocks', []))}")
        
    except Exception as e:
        return {"success": False, "error": f"خطا در بارگذاری وضعیت: {str(e)}"}
    
    # 3. بررسی دیتابیس
    print("\n3️⃣ بررسی اتصال دیتابیس...")
    db_result = check_database_connection(config["database_path"])
    if not db_result["success"]:
        print(f"❌ {db_result['error']}")
        return db_result
    
    # 4. ایجاد API Client
    print("\n4️⃣ آماده‌سازی اتصال API...")
    api_client = SafeAPIRequest(
        config['binance_base_url'],
        max_retries=config['api_retry_attempts']
    )
    
    # 5. تعیین محدوده بلوک‌ها با اعتبارسنجی
    total_blocks = len(state_data['blocks'])
    
    if start_block is None:
        start_block = state_data.get('current_block', 1)
    
    if end_block is None:
        end_block = total_blocks
    
    # اعتبارسنجی محدوده
    if start_block < 1:
        start_block = 1
    
    if end_block > total_blocks:
        end_block = total_blocks
    
    if start_block > end_block:
        return {"success": False, "error": f"شماره بلوک شروع ({start_block}) بزرگتر از پایان ({end_block}) است"}
    
    if total_blocks == 0:
        return {"success": False, "error": "هیچ بلوکی برای پردازش وجود ندارد"}
    
    print(f"\n🎯 محدوده پردازش: بلوک‌های {start_block} تا {end_block}")
    print(f"   📦 تعداد بلوک‌ها: {end_block - start_block + 1}")
    print(f"   🔄 محاسبه پویای تعداد کندل‌ها فعال است")
    
    # 6. پردازش بلوک‌ها
    total_stats = {
        'blocks_processed': 0,
        'total_symbols': 0,
        'total_successful': 0,
        'total_failed': 0,
        'total_inserted': 0,
        'total_duplicates': 0,
        'total_api_errors': 0
    }
    
    try:
        for block_num in range(start_block, end_block + 1):
            # پردازش بلوک
            result = process_block_safely(config, state_data, block_num, progress, api_client, end_block)
            
            if result['success']:
                # جمع‌آوری آمار کل
                block_stats = result['block_stats']
                total_stats['blocks_processed'] += 1
                
                # محاسبه تعداد کل ارزهای این بلوک
                for block in state_data['blocks']:
                    if block['block_id'] == block_num:
                        total_stats['total_symbols'] += len(block['symbols'])
                        break
                
                total_stats['total_successful'] += block_stats['successful']
                total_stats['total_failed'] += block_stats['failed']
                total_stats['total_inserted'] += block_stats['inserted']
                total_stats['total_duplicates'] += block_stats['duplicates']
                total_stats['total_api_errors'] += block_stats['api_errors']
                
                # بروزرسانی current_block
                state_data['current_block'] = block_num + 1
                
                # ذخیره وضعیت پس از هر بلوک (با atomic operation)
                if save_state_file(config["state_file"], state_data):
                    print(f"   💾 وضعیت ذخیره شد (بلوک {block_num})")
                else:
                    print(f"   ⚠️ خطا در ذخیره وضعیت بلوک {block_num}")
                
                # نمایش Progress Bar کلی
                processed_count = block_num - start_block + 1
                total_count = end_block - start_block + 1
                
                if total_count > 0:
                    progress_percent = (processed_count / total_count) * 100
                    print(f"\n📊 پیشرفت کل: {progress_percent:.1f}%")
                    
                    if block_num < end_block:
                        print(f"   🔄 بلوک بعدی: {block_num + 1}")
            else:
                print(f"❌ خطا در پردازش بلوک {block_num}: {result.get('error')}")
                
                # ذخیره state قبل از خروج
                save_state_file(config["state_file"], state_data)
                break
        
        # 7. ذخیره نهایی وضعیت
        print("\n💾 ذخیره وضعیت نهایی...")
        if save_state_file(config["state_file"], state_data):
            print("   ✅ وضعیت ذخیره شد")
        else:
            print("   ⚠️ خطا در ذخیره وضعیت نهایی")
        
        # 8. نمایش خلاصه نهایی
        progress.print_final_summary(total_stats)
        
        # 9. تخمین زمان تکمیل چرخه
        total_time = time.time() - start_time
        if total_stats['blocks_processed'] > 0:
            avg_time_per_block = total_time / total_stats['blocks_processed']
            remaining_blocks = total_blocks - end_block
            
            if remaining_blocks > 0:
                estimated_remaining = avg_time_per_block * remaining_blocks
                print(f"\n⏳ تخمین زمان تکمیل چرخه:")
                print(f"   • زمان باقی‌مانده: ~{estimated_remaining/60:.1f} دقیقه")
                print(f"   • تعداد بلوک باقی‌مانده: {remaining_blocks}")
                print(f"   • میانگین زمان هر بلوک: {avg_time_per_block/60:.1f} دقیقه")
        
        return {
            "success": True,
            "total_stats": total_stats,
            "next_block": min(state_data['current_block'], total_blocks + 1),
            "message": f"پردازش {total_stats['blocks_processed']} بلوک کامل شد."
        }
        
    except KeyboardInterrupt:
        print("\n\n⏹️ پردازش توسط کاربر متوقف شد")
        # ذخیره state قبل از خروج
        save_state_file(config["state_file"], state_data)
        return {
            "success": False,
            "error": "پردازش توسط کاربر متوقف شد",
            "next_block": state_data.get('current_block', start_block)
        }
    except Exception as e:
        print(f"\n❌ خطای غیرمنتظره: {str(e)}")
        # ذخیره state قبل از خروج
        save_state_file(config["state_file"], state_data)
        return {
            "success": False,
            "error": f"خطای غیرمنتظره: {str(e)}",
            "next_block": state_data.get('current_block', start_block)
        }

# ==================== EXECUTION ====================
if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description='پردازش ایمن بلوک‌های داده از بایننس',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog='''
مثال‌ها:
  %(prog)s                    # ادامه از بلوک فعلی
  %(prog)s --start 5          # شروع از بلوک 5
  %(prog)s --start 3 --end 10 # پردازش بلوک‌های 3 تا 10
        '''
    )
    
    parser.add_argument(
        '--start', '-s', 
        type=int, 
        help='شماره بلوک شروع'
    )
    
    parser.add_argument(
        '--end', '-e', 
        type=int, 
        help='شماره بلوک پایان'
    )
    
    args = parser.parse_args()
    
    result = run_safe_block_processing(args.start, args.end)
    
    # خروجی مناسب
    if result["success"]:
        print(f"\n✅ {result['message']}")
        
        next_block = result.get('next_block')
        total_stats = result.get('total_stats', {})
        
        if next_block:
            print(f"\n📌 برای ادامه اجرا کنید:")
            print(f"   python {os.path.basename(__file__)} --start {next_block}")
        
        if total_stats.get('total_api_errors', 0) > 0:
            print(f"\n⚠️ توجه: {total_stats['total_api_errors']} خطای API رخ داد")
            print(f"   این طبیعی است در حالت محافظه‌کارانه")
    else:
        print(f"\n❌ خطا: {result.get('error', 'خطای ناشناخته')}")
        
        next_block = result.get('next_block')
        if next_block:
            print(f"\n📌 برای ادامه از بلوک {next_block} اجرا کنید:")
            print(f"   python {os.path.basename(__file__)} --start {next_block}")
        
        sys.exit(1)