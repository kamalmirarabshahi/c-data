"""
فایل: fetch_coin_candles.py
عملکرد: دریافت 200 کندل آخر برای یک ارز خاص در تایم‌فریم‌های 15m، 1h و 4h از بایننس
ورژن: 1.0
تاریخ: 2025-01-01
ویژگی‌ها:
- دریافت 200 کندل آخر برای یک ارز مشخص
- پردازش 3 تایم‌فریم: 15m, 1h, 4h
- ذخیره در دیتابیس با حفظ دقت قیمت‌ها (تا 8 رقم اعشار)
- بروزرسانی فیلد last_updated در جدول crypto_coins
- رعایت Rate Limit بایننس
- گزارش‌دهی کامل
"""

import os
import sys
import sqlite3
import json
import time
import random
import requests
import argparse
from datetime import datetime, timezone
from pathlib import Path
from decimal import Decimal
from typing import Dict, List, Tuple, Optional, Any

# ==================== DECIMAL PRECISION SETUP ====================
from decimal import getcontext
getcontext().prec = 30

# ==================== ثابت‌های محافظه‌کارانه ====================
SAFE_SETTINGS = {
    'DELAYS': {
        'BETWEEN_TIMEFRAMES': (1, 3),
        'AFTER_RATE_LIMIT': (10, 30),
    },
    'API_LIMITS': {
        'REQUESTS_PER_MINUTE': 100,
        'MAX_RETRIES': 5,
        'TIMEOUT': 30,
    },
    'PRECISION': {
        'MAX_DECIMAL_PLACES': 8,
    }
}

# ==================== FUNCTIONS FOR SAFE OPERATION ====================
class SafeAPIRequest:
    """کلاس مدیریت درخواست‌های API به صورت ایمن"""
    
    def __init__(self, base_url: str, max_retries: int = 5):
        self.base_url = base_url
        self.max_retries = max_retries
        self.request_count = 0
        self.reset_time = time.time() + 60
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        })
    
    def safe_delay(self, delay_range: Tuple[float, float]) -> float:
        """تاخیر ایمن با محدوده تصادفی"""
        delay = random.uniform(*delay_range)
        time.sleep(delay)
        return delay
    
    def check_rate_limit(self) -> None:
        """بررسی Rate Limit"""
        current_time = time.time()
        if current_time >= self.reset_time:
            self.request_count = 0
            self.reset_time = current_time + 60
        
        if self.request_count >= SAFE_SETTINGS['API_LIMITS']['REQUESTS_PER_MINUTE']:
            wait_time = self.reset_time - current_time
            if wait_time > 0:
                print(f"⏳ رسیدن به حد Rate Limit. انتظار {wait_time:.1f} ثانیه...")
                time.sleep(wait_time + 1)
                self.request_count = 0
                self.reset_time = time.time() + 60
    
    def make_request(self, url: str, params: Dict) -> Dict[str, Any]:
        """انجام درخواست API با تلاش مجدد"""
        for attempt in range(self.max_retries):
            try:
                self.check_rate_limit()
                
                response = self.session.get(
                    url, 
                    params=params, 
                    timeout=SAFE_SETTINGS['API_LIMITS']['TIMEOUT'],
                    verify=True
                )
                
                self.request_count += 1
                
                if response.status_code == 200:
                    return {"success": True, "data": response.json()}
                
                elif response.status_code == 429:
                    retry_after = int(response.headers.get('Retry-After', 30))
                    print(f"⚠️ Rate Limit فعال. انتظار {retry_after} ثانیه...")
                    time.sleep(retry_after)
                    continue
                
                elif response.status_code >= 500:
                    wait_time = 2 ** attempt
                    print(f"⚠️ خطای سرور ({response.status_code}). انتظار {wait_time} ثانیه...")
                    time.sleep(wait_time)
                    continue
                
                else:
                    return {"success": False, "error": f"HTTP {response.status_code}: {response.text[:100]}"}
                    
            except requests.exceptions.Timeout:
                print(f"⚠️ Timeout (تلاش {attempt + 1}/{self.max_retries})")
                time.sleep(2 ** attempt)
            except requests.exceptions.ConnectionError:
                print(f"⚠️ خطای اتصال (تلاش {attempt + 1}/{self.max_retries})")
                time.sleep(5 * (attempt + 1))
            except Exception as e:
                return {"success": False, "error": f"خطای ناشناخته: {str(e)}"}
        
        return {"success": False, "error": f"تلاش‌های ناموفق پس از {self.max_retries} بار"}

# ==================== PRICE PRECISION FUNCTIONS ====================
def format_decimal_price(price_str: str, max_decimal_places: int = 8) -> str:
    """فرمت قیمت به صورت رشته با حداکثر 8 رقم اعشار بدون گرد کردن"""
    try:
        if not price_str or price_str.strip() == '':
            return price_str
            
        dec_price = Decimal(price_str)
        
        if dec_price == dec_price.to_integral():
            return str(dec_price.quantize(Decimal(1)))
        
        price_str_normalized = format(dec_price, 'f')
        
        if '.' in price_str_normalized:
            integer_part, decimal_part = price_str_normalized.split('.')
            
            if len(decimal_part) > max_decimal_places:
                decimal_part = decimal_part[:max_decimal_places]
            
            decimal_part = decimal_part.rstrip('0')
            
            if decimal_part:
                return f"{integer_part}.{decimal_part}"
            else:
                return integer_part
        else:
            return price_str_normalized
            
    except Exception:
        return price_str

def adjust_price_precision_for_low_prices(
    open_price_str: str, 
    close_price_str: str, 
    high_price_str: str, 
    low_price_str: str
) -> Tuple[str, str, str, str, bool]:
    """تنظیم دقت برای ارزهای کم‌قیمت (فقط در صورت Open=Close)"""
    try:
        open_dec = Decimal(open_price_str)
        close_dec = Decimal(close_price_str)
        high_dec = Decimal(high_price_str)
        low_dec = Decimal(low_price_str)
        
        if open_dec < Decimal('0.01') and open_dec == close_dec:
            open_str = format_decimal_price(open_price_str)
            
            if '.' in open_str:
                decimal_places = len(open_str.split('.')[1])
                smallest_step = Decimal('1') / (Decimal('10') ** decimal_places)
            else:
                smallest_step = Decimal('0.00000001')
            
            if high_dec > open_dec:
                adjusted_close = close_dec + smallest_step
            elif low_dec < open_dec:
                adjusted_close = close_dec - smallest_step
            else:
                adjusted_close = close_dec + smallest_step
            
            open_final = format_decimal_price(str(open_dec))
            close_final = format_decimal_price(str(adjusted_close))
            high_final = format_decimal_price(high_price_str)
            low_final = format_decimal_price(low_price_str)
            
            return open_final, close_final, high_final, low_final, True
        else:
            open_final = format_decimal_price(open_price_str)
            close_final = format_decimal_price(close_price_str)
            high_final = format_decimal_price(high_price_str)
            low_final = format_decimal_price(low_price_str)
            
            return open_final, close_final, high_final, low_final, False
            
    except Exception as e:
        open_final = format_decimal_price(open_price_str)
        close_final = format_decimal_price(close_price_str)
        high_final = format_decimal_price(high_price_str)
        low_final = format_decimal_price(low_price_str)
        
        return open_final, close_final, high_final, low_final, False

def validate_candle_data(candle: List) -> bool:
    """اعتبارسنجی داده‌های کندل"""
    try:
        if len(candle) < 11:
            return False
        
        open_time = candle[0]
        close_time = candle[6]
        
        if open_time <= 0 or close_time <= 0 or close_time < open_time:
            return False
        
        open_price = Decimal(str(candle[1]))
        high_price = Decimal(str(candle[2]))
        low_price = Decimal(str(candle[3]))
        close_price = Decimal(str(candle[4]))
        
        if high_price < low_price:
            return False
        
        if not (low_price <= open_price <= high_price):
            return False
        
        if not (low_price <= close_price <= high_price):
            return False
        
        volume = Decimal(str(candle[5]))
        if volume < 0:
            return False
        
        return True
        
    except Exception:
        return False

# ==================== CONFIGURATION ====================
def load_config() -> Dict[str, Any]:
    """بارگذاری تنظیمات"""
    try:
        current_dir = os.path.dirname(os.path.abspath(__file__))
        config_file = os.path.join(current_dir, "..", "..", "config", "settings.json")
        config_file = os.path.abspath(config_file)
        
        if not os.path.exists(config_file):
            return {"success": False, "error": f"فایل کانفیگ یافت نشد: {config_file}"}
        
        with open(config_file, 'r', encoding='utf-8') as f:
            config_data = json.load(f)
        
        if not isinstance(config_data, dict):
            return {"success": False, "error": "ساختار فایل کانفیگ نامعتبر است"}
        
        paths = config_data.get('paths', {})
        database = config_data.get('database', {})
        
        project_root = paths.get('project_root')
        if not project_root:
            return {"success": False, "error": "'paths.project_root' یافت نشد"}
        
        database_path = database.get('path')
        if not database_path:
            database_name = database.get('name', 'crypto_master.db')
            data_dir = paths.get('data_dir', os.path.join(project_root, 'data'))
            database_path = os.path.join(data_dir, database_name)
        
        timeframes = ['15m', '1h', '4h']
        
        config = {
            "project_root": project_root,
            "database_path": database_path,
            "timeframes": timeframes,
            "binance_base_url": 'https://api.binance.com/api/v3',
            "safe_settings": SAFE_SETTINGS
        }
        
        print(f"✅ تنظیمات بارگذاری شد")
        print(f"📁 دیتابیس: {Path(database_path).name}")
        
        return {"success": True, "config": config}
        
    except json.JSONDecodeError as e:
        return {"success": False, "error": f"خطای JSON در فایل کانفیگ: {str(e)}"}
    except Exception as e:
        return {"success": False, "error": f"خطا در بارگذاری تنظیمات: {str(e)}"}

# ==================== DATABASE FUNCTIONS ====================
def check_database_connection(db_path: str) -> Dict[str, Any]:
    """بررسی اتصال دیتابیس"""
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='crypto_coins'")
        if not cursor.fetchone():
            conn.close()
            return {"success": False, "error": "جدول crypto_coins وجود ندارد"}
        
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='crypto_klines'")
        if not cursor.fetchone():
            conn.close()
            return {"success": False, "error": "جدول crypto_klines وجود ندارد"}
        
        cursor.execute("SELECT COUNT(*) FROM crypto_coins")
        total_coins = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM crypto_klines")
        total_candles = cursor.fetchone()[0]
        
        conn.close()
        
        print(f"   ✅ دیتابیس سالم - {total_coins} ارز، {total_candles} کندل")
        return {"success": True, "total_coins": total_coins, "total_candles": total_candles}
        
    except Exception as e:
        return {"success": False, "error": f"خطای دیتابیس: {str(e)}"}

def get_coin_id(symbol: str, db_path: str) -> Tuple[bool, Optional[int], str]:
    """دریافت coin_id از جدول crypto_coins"""
    try:
        clean_symbol = symbol.upper()
        if not clean_symbol.endswith('USDT'):
            clean_symbol = f"{clean_symbol}USDT"
        
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        cursor.execute("SELECT id FROM crypto_coins WHERE symbol = ?", (clean_symbol,))
        result = cursor.fetchone()
        
        conn.close()
        
        if result:
            return True, result[0], clean_symbol
        else:
            return False, None, f"ارز {clean_symbol} در دیتابیس یافت نشد"
            
    except Exception as e:
        return False, None, f"خطا در جستجوی ارز: {str(e)}"

def update_last_updated_field(db_path: str, coin_id: int) -> bool:
    """
    بروزرسانی فیلد last_updated برای یک ارز با تاریخ روز کامل (23:59:59)
    
    فرمت: '2025-12-30 23:59:59.999000'
    """
    try:
        # دریافت تاریخ روز قبل به صورت کامل (برای اطمینان)
        today = datetime.now(timezone.utc).date()
        yesterday = today  # یا می‌توانید از today - timedelta(days=1) استفاده کنید
        
        # ایجاد timestamp برای انتهای روز (23:59:59.999)
        full_day_datetime = datetime.combine(
            yesterday, 
            datetime.max.time()
        ).replace(microsecond=999000)
        
        # فرمت تاریخ
        last_updated_str = full_day_datetime.strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]
        
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        cursor.execute(
            "UPDATE crypto_coins SET last_updated = ? WHERE id = ?",
            (last_updated_str, coin_id)
        )
        
        conn.commit()
        conn.close()
        
        print(f"   ✅ فیلد last_updated بروزرسانی شد: {last_updated_str}")
        return True
        
    except Exception as e:
        print(f"   ❌ خطا در بروزرسانی last_updated: {str(e)}")
        return False

def save_candle_data(db_path: str, symbol: str, timeframe: str, candles: List[List]) -> Dict[str, Any]:
    """ذخیره داده‌های کندل"""
    if not candles:
        return {
            "success": True, 
            "inserted_count": 0, 
            "duplicate_count": 0,
            "total_candles": 0,
            "symbol": symbol.upper()
        }
    
    try:
        # دریافت coin_id
        success, coin_id, error_msg = get_coin_id(symbol, db_path)
        if not success:
            return {"success": False, "error": error_msg}
        
        clean_symbol = symbol.upper()
        if not clean_symbol.endswith('USDT'):
            clean_symbol = f"{clean_symbol}USDT"
        
        with sqlite3.connect(db_path) as conn:
            cursor = conn.cursor()
            
            inserted_count = 0
            duplicate_count = 0
            invalid_candle_count = 0
            
            for candle in candles:
                try:
                    if not validate_candle_data(candle):
                        invalid_candle_count += 1
                        continue
                    
                    open_raw = str(candle[1])
                    close_raw = str(candle[4])
                    high_raw = str(candle[2])
                    low_raw = str(candle[3])
                    
                    open_final, close_final, high_final, low_final, _ = adjust_price_precision_for_low_prices(
                        open_raw, close_raw, high_raw, low_raw
                    )
                    
                    open_timestamp = candle[0]
                    close_timestamp = candle[6]
                    
                    open_time = datetime.fromtimestamp(open_timestamp / 1000, tz=timezone.utc).strftime('%Y-%m-%d %H:%M:%S')
                    close_time = datetime.fromtimestamp(close_timestamp / 1000, tz=timezone.utc).strftime('%Y-%m-%d %H:%M:%S.999000')
                    candle_date = datetime.fromtimestamp(open_timestamp / 1000, tz=timezone.utc).strftime('%Y-%m-%d')
                    
                    open_price = open_final
                    close_price = close_final
                    high_price = high_final
                    low_price = low_final
                    
                    volume = str(candle[5])
                    quote_volume = str(candle[7])
                    number_of_trades = candle[8]
                    taker_buy_volume = str(candle[9])
                    taker_buy_quote_volume = str(candle[10])
                    
                    try:
                        volume_dec = Decimal(volume)
                        taker_buy_volume_dec = Decimal(taker_buy_volume)
                        taker_sell_volume_dec = max(Decimal('0'), volume_dec - taker_buy_volume_dec)
                        taker_sell_volume = format_decimal_price(str(taker_sell_volume_dec))
                    except:
                        taker_sell_volume = '0'
                    
                    cursor.execute('''
                    INSERT OR IGNORE INTO crypto_klines 
                    (coin_id, timeframe, open_time, close_time, candle_date,
                     open_price, high_price, low_price, close_price, 
                     volume, quote_volume, number_of_trades,
                     taker_buy_volume, taker_sell_volume, taker_buy_quote_volume,
                     created_at, updated_at, source_exchange, is_verified)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 
                            datetime('now'), datetime('now'), 'binance', 1)
                    ''', (
                        coin_id, timeframe, open_time, close_time, candle_date,
                        open_price, high_price, low_price, close_price,
                        volume, quote_volume, number_of_trades,
                        taker_buy_volume, taker_sell_volume, taker_buy_quote_volume
                    ))
                    
                    if cursor.rowcount > 0:
                        inserted_count += 1
                    else:
                        duplicate_count += 1
                        
                except Exception as e:
                    duplicate_count += 1
                    continue
            
            conn.commit()
            
            if invalid_candle_count > 0:
                print(f"   ⚠️ {invalid_candle_count} کندل نامعتبر حذف شد")
            
            return {
                "success": True, 
                "inserted_count": inserted_count, 
                "duplicate_count": duplicate_count,
                "total_candles": len(candles),
                "symbol": clean_symbol,
                "coin_id": coin_id,
                "invalid_candles": invalid_candle_count
            }
            
    except Exception as e:
        return {"success": False, "error": f"خطای ذخیره‌سازی: {str(e)}"}

# ==================== MAIN FUNCTION ====================
def fetch_coin_candles(symbol: str) -> Dict[str, Any]:
    """تابع اصلی دریافت کندل‌های یک ارز"""
    
    print("=" * 70)
    print(f"📊 دریافت داده‌های کندل برای ارز: {symbol.upper()}")
    print("=" * 70)
    
    start_time = time.time()
    
    # 1. بارگذاری تنظیمات
    print("\n1️⃣ بارگذاری تنظیمات...")
    config_result = load_config()
    if not config_result["success"]:
        print(f"❌ {config_result['error']}")
        return config_result
    
    config = config_result["config"]
    
    # 2. بررسی دیتابیس
    print("\n2️⃣ بررسی اتصال دیتابیس...")
    db_result = check_database_connection(config["database_path"])
    if not db_result["success"]:
        print(f"❌ {db_result['error']}")
        return db_result
    
    # 3. بررسی وجود ارز در دیتابیس
    print("\n3️⃣ بررسی وجود ارز در دیتابیس...")
    success, coin_id, error_msg = get_coin_id(symbol, config["database_path"])
    if not success:
        print(f"❌ {error_msg}")
        return {"success": False, "error": error_msg}
    
    print(f"   ✅ ارز یافت شد: Coin ID = {coin_id}")
    
    # 4. ایجاد API Client
    print("\n4️⃣ آماده‌سازی اتصال API...")
    api_client = SafeAPIRequest(
        config['binance_base_url'],
        max_retries=SAFE_SETTINGS['API_LIMITS']['MAX_RETRIES']
    )
    
    # 5. تعیین تایم‌فریم‌ها
    timeframes = config['timeframes']
    print(f"\n5️⃣ دریافت داده برای {len(timeframes)} تایم‌فریم:")
    print(f"   • {', '.join(timeframes)}")
    print(f"   • تعداد کندل‌ها: 200 کندل آخر برای هر تایم‌فریم")
    
    # آمار کلی
    total_stats = {
        'successful_timeframes': 0,
        'failed_timeframes': 0,
        'total_inserted': 0,
        'total_duplicates': 0,
        'total_api_errors': 0,
        'timeframes_detail': {}
    }
    
    # 6. پردازش هر تایم‌فریم
    for timeframe in timeframes:
        print(f"\n   📊 تایم‌فریم {timeframe}:")
        
        # دریافت داده از API
        url = f"{config['binance_base_url']}/klines"
        params = {
            'symbol': symbol.upper(),
            'interval': timeframe,
            'limit': 200  # 200 کندل آخر
        }
        
        api_result = api_client.make_request(url, params)
        
        if api_result['success']:
            # ذخیره داده‌ها
            save_result = save_candle_data(
                config["database_path"], 
                symbol, 
                timeframe, 
                api_result['data']
            )
            
            if save_result['success']:
                total_stats['successful_timeframes'] += 1
                total_stats['total_inserted'] += save_result['inserted_count']
                total_stats['total_duplicates'] += save_result['duplicate_count']
                
                total_stats['timeframes_detail'][timeframe] = {
                    'inserted': save_result['inserted_count'],
                    'duplicates': save_result['duplicate_count'],
                    'total': save_result['total_candles']
                }
                
                print(f"      ✅ دریافت و ذخیره شد")
                print(f"      📈 کندل‌های جدید: {save_result['inserted_count']}")
                print(f"      🔄 کندل‌های تکراری: {save_result['duplicate_count']}")
            else:
                total_stats['failed_timeframes'] += 1
                print(f"      ❌ خطا در ذخیره‌سازی: {save_result.get('error', 'خطای نامشخص')}")
        else:
            total_stats['failed_timeframes'] += 1
            total_stats['total_api_errors'] += 1
            print(f"      ❌ خطای API: {api_result.get('error', 'خطای نامشخص')}")
        
        # تاخیر بین تایم‌فریم‌ها (به جز آخرین)
        if timeframe != timeframes[-1]:
            delay = api_client.safe_delay(SAFE_SETTINGS['DELAYS']['BETWEEN_TIMEFRAMES'])
            print(f"      ⏳ تاخیر: {delay:.1f} ثانیه")
    
    # 7. بروزرسانی فیلد last_updated
    print(f"\n6️⃣ بروزرسانی فیلد last_updated...")
    if total_stats['successful_timeframes'] > 0:
        update_success = update_last_updated_field(config["database_path"], coin_id)
        
        if update_success:
            total_stats['last_updated_success'] = True
        else:
            total_stats['last_updated_success'] = False
            print("   ⚠️ خطا در بروزرسانی last_updated")
    else:
        print("   ⚠️ به دلیل عدم دریافت داده، last_updated بروزرسانی نشد")
        total_stats['last_updated_success'] = False
    
    # 8. نمایش خلاصه نهایی
    total_time = time.time() - start_time
    
    print("\n" + "=" * 70)
    print("🎉 خلاصه نهایی اجرا")
    print("=" * 70)
    print(f"   💰 ارز: {symbol.upper()}")
    print(f"   ⏱️ زمان کل: {total_time:.1f} ثانیه")
    print(f"   📊 تایم‌فریم‌های موفق: {total_stats['successful_timeframes']}/{len(timeframes)}")
    print(f"   📈 کندل‌های جدید کل: {total_stats['total_inserted']}")
    print(f"   🔄 کندل‌های تکراری کل: {total_stats['total_duplicates']}")
    print(f"   ⚠️ خطاهای API: {total_stats['total_api_errors']}")
    
    if total_stats.get('last_updated_success'):
        print(f"   ✅ فیلد last_updated بروزرسانی شد")
    else:
        print(f"   ❌ فیلد last_updated بروزرسانی نشد")
    
    print("=" * 70)
    
    # جزئیات هر تایم‌فریم
    print("\n📋 جزئیات تایم‌فریم‌ها:")
    for timeframe, details in total_stats['timeframes_detail'].items():
        print(f"   • {timeframe}: {details['inserted']} جدید، {details['duplicates']} تکراری")
    
    # بررسی موفقیت کلی
    overall_success = total_stats['successful_timeframes'] > 0
    
    return {
        "success": overall_success,
        "total_stats": total_stats,
        "symbol": symbol.upper(),
        "coin_id": coin_id,
        "message": f"دریافت داده برای ارز {symbol.upper()} تکمیل شد."
    }

# ==================== EXECUTION ====================
if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description='دریافت 200 کندل آخر برای یک ارز خاص از بایننس',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog='''
مثال‌ها:
  %(prog)s BTC      # دریافت داده‌های بیت‌کوین
  %(prog)s ETH      # دریافت داده‌های اتریوم
  %(prog)s ADA      # دریافت داده‌های کاردانو
        '''
    )
    
    parser.add_argument(
        'symbol',
        type=str,
        help='نماد ارز (مثال: BTC یا BTCUSDT)'
    )
    
    args = parser.parse_args()
    
    if not args.symbol:
        print("❌ لطفا نماد ارز را وارد کنید")
        parser.print_help()
        sys.exit(1)
    
    result = fetch_coin_candles(args.symbol)
    
    if result["success"]:
        print(f"\n✅ {result['message']}")
        
        total_stats = result.get('total_stats', {})
        
        if total_stats.get('failed_timeframes', 0) > 0:
            print(f"\n⚠️ توجه: {total_stats['failed_timeframes']} تایم‌فریم با مشکل مواجه شد")
        
        if total_stats.get('total_api_errors', 0) > 0:
            print(f"⚠️ توجه: {total_stats['total_api_errors']} خطای API رخ داد")
    else:
        print(f"\n❌ خطا: {result.get('error', 'خطای ناشناخته')}")
        sys.exit(1)