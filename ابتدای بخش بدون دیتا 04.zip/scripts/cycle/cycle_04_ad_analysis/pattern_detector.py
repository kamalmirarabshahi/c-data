"""
🎯 Pattern Detector Complete - نسخه کامل با تحلیل واگرایی و اندیکاتورهای کامل
نسخه بازنویسی شده: استفاده از crypto_klines به جای technical_indicators
"""

import sqlite3
import json
import numpy as np
from datetime import datetime, timedelta
import logging
from typing import Dict, List, Optional, Tuple, Any
import sys
import os

# اضافه کردن مسیر پروژه
current_dir = os.path.dirname(os.path.abspath(__file__))
scripts_dir = os.path.dirname(os.path.dirname(current_dir))
project_root = os.path.dirname(scripts_dir)

sys.path.insert(0, project_root)
sys.path.insert(0, scripts_dir)

try:
    import config_manager
    print("✅ config_manager import شد")
except ImportError as e:
    print(f"❌ خطا در import config_manager: {e}")
    sys.exit(1)

# ========== اصلاح بخش لاگ‌گیری ==========
# ایجاد پوشه logs در مسیر جاری قبل از تعریف لاگ
log_dir = os.path.join(os.path.dirname(current_dir), 'logs')
os.makedirs(log_dir, exist_ok=True)

log_file = os.path.join(log_dir, 'pattern_detector_complete.log')

# تنظیمات لاگ‌گیری
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(log_file, encoding='utf-8'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)
print(f"📁 فایل لاگ: {log_file}")
# ========== پایان اصلاح ==========


class CompletePatternDetector:
    """کلاس کامل تشخیص الگوهای قیمتی با تحلیل واگرایی - نسخه اصلاح شده با crypto_klines"""
    
    def __init__(self, config_path: str = "config/settings.json"):
        """مقداردهی اولیه"""
        
        self.config_manager = config_manager
        self.db_path = self.config_manager.get_database_path()
        logger.info(f"📁 مسیر دیتابیس: {self.db_path}")
        
        # دریافت تنظیمات
        analysis_config = self.config_manager.get_analysis_config()
        self.pattern_params = analysis_config.get('pattern_detection', {})
        
        if not self.pattern_params:
            logger.warning("⚠️ تنظیمات pattern_detection یافت نشد، استفاده از پیش‌فرض‌ها")
            self.pattern_params = {
                'head_shoulders_threshold': 0.7,
                'double_top_threshold': 0.65,
                'triangle_threshold': 0.6,
                'flag_threshold': 0.55,
                'candlestick_threshold': 0.5,
                'divergence_threshold': 0.6
            }
        self.confidence_thresholds = {
            'head_shoulders': 0.98,    # بسیار بسیار بالا - تقریباً غیرفعال
            'double_top': 0.85,
            'triangle': 0.80,
            'flag': 0.75,
            'candlestick': 0.70,
            'divergence': 0.80
        }
        
        logger.info(f"📊 آستانه‌های تشخیص: {self.confidence_thresholds}")
        logger.info("✅ CompletePatternDetector راه‌اندازی شد")
    
    # ========== توابع کمکی ==========
    
    def _get_technical_indicators_from_klines(self, coin_id: int, limit: int = 50) -> Dict:
        """دریافت اندیکاتورهای تکنیکال از جدول crypto_klines"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        try:
            query = """
            SELECT 
                open_time,
                close_price,
                rsi,
                macd,
                macd_signal,
                macd_histogram,
                bollinger_upper,
                bollinger_middle,
                bollinger_lower,
                ma_7,
                ma_25,
                ma_99,
                volume_ma_20,
                volume,
                pattern_confidence,
                trend_strength,
                atr,
                volatility,
                obv
            FROM crypto_klines 
            WHERE coin_id = ? 
            ORDER BY open_time DESC 
            LIMIT ?
            """
            
            cursor.execute(query, (coin_id, limit))
            rows = cursor.fetchall()
            
            if not rows:
                return {}
            
            # تبدیل به ساختار مناسب
            indicators = {
                'timestamps': [row[0] for row in rows],
                'closes': [float(row[1]) if row[1] is not None else 0 for row in rows],
                'rsi': [float(row[2]) if row[2] is not None else 50 for row in rows],
                'macd': [float(row[3]) if row[3] is not None else 0 for row in rows],
                'macd_signal': [float(row[4]) if row[4] is not None else 0 for row in rows],
                'macd_histogram': [float(row[5]) if row[5] is not None else 0 for row in rows],
                'bollinger_upper': [float(row[6]) if row[6] is not None else 0 for row in rows],
                'bollinger_middle': [float(row[7]) if row[7] is not None else 0 for row in rows],
                'bollinger_lower': [float(row[8]) if row[8] is not None else 0 for row in rows],
                'sma_5': [float(row[9]) if row[9] is not None else 0 for row in rows],
                'sma_10': [float(row[9]) if row[9] is not None else 0 for row in rows],
                'sma_20': [float(row[10]) if row[10] is not None else 0 for row in rows],
                'sma_50': [float(row[11]) if row[11] is not None else 0 for row in rows],
                'ema_12': [float(row[9]) if row[9] is not None else 0 for row in rows],
                'ema_26': [float(row[10]) if row[10] is not None else 0 for row in rows],
                'volume_ma_20': [float(row[12]) if row[12] is not None else 0 for row in rows],
                'volume': [float(row[13]) if row[13] is not None else 0 for row in rows],
                'pattern_confirmation': [float(row[14]) if row[14] is not None else 0 for row in rows],
                'trend_strength': [float(row[15]) if row[15] is not None else 0 for row in rows],
                'atr': [float(row[16]) if row[16] is not None else 0 for row in rows],
                'volatility': [float(row[17]) if row[17] is not None else 0 for row in rows],
                'obv': [float(row[18]) if row[18] is not None else 0 for row in rows]
            }
            
            # اگر اندیکاتورهای خاصی وجود ندارند، محاسبه ساده
            if all(rsi == 50 for rsi in indicators['rsi']) and indicators['closes']:
                indicators['rsi'] = self._calculate_simple_rsi(indicators['closes'])
            
            if all(macd == 0 for macd in indicators['macd']) and indicators['closes']:
                indicators['macd'], indicators['macd_signal'], indicators['macd_histogram'] = \
                    self._calculate_simple_macd(indicators['closes'])
            
            logger.debug(f"📊 اندیکاتورهای دریافت شده: {len(indicators['closes'])} کندل")
            return indicators
            
        except Exception as e:
            logger.error(f"❌ خطا در دریافت اندیکاتورها از klines: {e}")
            return {}
        finally:
            conn.close()
    
    def _calculate_simple_rsi(self, prices: List[float], period: int = 14) -> List[float]:
        """محاسبه RSI ساده"""
        if len(prices) < period + 1:
            return [50.0] * len(prices)
        
        deltas = np.diff(prices)
        seed = deltas[:period]
        
        up = seed[seed >= 0].sum() / period
        down = -seed[seed < 0].sum() / period
        
        if down == 0:
            return [100.0] * len(prices)
        
        rs = up / down
        rsi = np.zeros_like(prices)
        rsi[:period] = 100.0 - 100.0 / (1.0 + rs)
        
        for i in range(period, len(prices)):
            delta = deltas[i-1]
            
            if delta > 0:
                upval = delta
                downval = 0.0
            else:
                upval = 0.0
                downval = -delta
            
            up = (up * (period - 1) + upval) / period
            down = (down * (period - 1) + downval) / period
            
            if down == 0:
                rs = 0
            else:
                rs = up / down
            
            rsi[i] = 100.0 - 100.0 / (1.0 + rs)
        
        return rsi.tolist()
    
    def _calculate_simple_macd(self, prices: List[float], 
                              fast_period: int = 12, 
                              slow_period: int = 26, 
                              signal_period: int = 9) -> Tuple[List[float], List[float], List[float]]:
        """محاسبه MACD ساده"""
        if len(prices) < slow_period + signal_period:
            zeros = [0.0] * len(prices)
            return zeros, zeros, zeros
        
        prices_array = np.array(prices)
        ema_fast = self._calculate_ema(prices_array, fast_period)
        ema_slow = self._calculate_ema(prices_array, slow_period)
        
        macd_line = ema_fast - ema_slow
        signal_line = self._calculate_ema(macd_line, signal_period)
        histogram = macd_line - signal_line
        
        return macd_line.tolist(), signal_line.tolist(), histogram.tolist()
    
    def _calculate_ema(self, data: np.ndarray, period: int) -> np.ndarray:
        """محاسبه EMA"""
        if len(data) < period:
            return np.array([np.nan] * len(data))
        
        alpha = 2.0 / (period + 1.0)
        ema = np.zeros_like(data)
        ema[period-1] = np.mean(data[:period])
        
        for i in range(period, len(data)):
            ema[i] = alpha * data[i] + (1 - alpha) * ema[i-1]
        
        ema[:period-1] = np.nan
        return ema
    
    def _find_peaks_valleys(self, data: List[float], lookback: int = 3) -> Tuple[List, List]:
        """یافتن قله‌ها و دره‌ها"""
        peaks = []
        valleys = []
        
        for i in range(lookback, len(data) - lookback):
            window = data[i-lookback:i+lookback+1]
            current = data[i]
            
            if current == max(window):
                peaks.append((i, current))
            
            if current == min(window):
                valleys.append((i, current))
        
        return peaks, valleys
    
    def _calculate_trend_strength(self, prices: List[float]) -> Dict:
        """محاسبه قدرت و جهت روند"""
        if len(prices) < 10:
            return {'strength': 0.0, 'direction': 'neutral', 'slope': 0.0}
        
        x = np.arange(len(prices))
        y = np.array(prices)
        
        A = np.vstack([x, np.ones(len(x))]).T
        slope, intercept = np.linalg.lstsq(A, y, rcond=None)[0]
        
        y_pred = slope * x + intercept
        ss_res = np.sum((y - y_pred) ** 2)
        ss_tot = np.sum((y - np.mean(y)) ** 2)
        r_squared = 1 - (ss_res / ss_tot) if ss_tot != 0 else 0
        
        if slope > 0.0001:
            direction = 'bullish'
        elif slope < -0.0001:
            direction = 'bearish'
        else:
            direction = 'neutral'
        
        return {
            'strength': min(max(r_squared, 0), 1),
            'direction': direction,
            'slope': slope
        }
    
    # ========== تشخیص الگوهای قیمتی ==========
    
    def detect_head_shoulders(self, prices: List[float], volumes: List[float]) -> Optional[Dict]:
        """تشخیص الگوی سر و شانه"""
        if len(prices) < 40:
            return None
        
        peaks, valleys = self._find_peaks_valleys(prices)
        
        if len(peaks) < 3:
            return None
        
        peaks.sort(key=lambda x: x[1], reverse=True)
        
        if len(peaks) >= 3:
            head = peaks[0]
            left_shoulder = None
            right_shoulder = None
            
            for peak in peaks[1:]:
                if peak[0] < head[0] and (not left_shoulder or peak[1] > left_shoulder[1]):
                    left_shoulder = peak
                elif peak[0] > head[0] and (not right_shoulder or peak[1] > right_shoulder[1]):
                    right_shoulder = peak
            
            if left_shoulder and right_shoulder:
                symmetry = abs(left_shoulder[1] - right_shoulder[1]) / head[1]
                
                # تایید حجم ساده
                volume_confirmation = 0.5  # پیش‌فرض
                if volumes and len(volumes) > max(head[0], right_shoulder[0]):
                    left_volume = volumes[left_shoulder[0]] if left_shoulder[0] < len(volumes) else 0
                    head_volume = volumes[head[0]] if head[0] < len(volumes) else 0
                    right_volume = volumes[right_shoulder[0]] if right_shoulder[0] < len(volumes) else 0
                    
                    # حجم در سر باید بیشتر باشد
                    if head_volume > left_volume and head_volume > right_volume:
                        volume_confirmation = 0.8
                
                confidence = max(0.1, 0.7 - symmetry * 2 + volume_confirmation * 0.3)
                
                if confidence > self.confidence_thresholds['head_shoulders']:
                    neckline = (left_shoulder[1] + right_shoulder[1]) / 2
                    target_price = neckline - (head[1] - neckline)
                    
                    return {
                        'pattern_type': 'head_shoulders',
                        'pattern_name': 'Head and Shoulders',
                        'pattern_confidence': round(confidence, 4),
                        'pattern_direction': 'bearish',
                        'pattern_breakout': prices[-1] < neckline,
                        'pattern_target_price': round(target_price, 6),
                        'pattern_neckline_price': round(neckline, 6),
                        'pattern_peaks_json': json.dumps([
                            {'position': left_shoulder[0], 'price': left_shoulder[1], 'type': 'left_shoulder'},
                            {'position': head[0], 'price': head[1], 'type': 'head'},
                            {'position': right_shoulder[0], 'price': right_shoulder[1], 'type': 'right_shoulder'}
                        ]),
                        'pattern_features_json': json.dumps({
                            'symmetry': round(symmetry, 4),
                            'volume_confirmation': round(volume_confirmation, 4),
                            'head_height': round(head[1] - neckline, 6)
                        })
                    }
        
        return None
    
    def detect_double_top_bottom(self, prices: List[float], volumes: List[float]) -> List[Dict]:
        """تشخیص الگوی دو قله/دو دره"""
        results = []
        
        if len(prices) < 30:
            return results
        
        peaks, valleys = self._find_peaks_valleys(prices)
        
        # تشخیص دو قله (bearish)
        if len(peaks) >= 2:
            peaks.sort(key=lambda x: x[0])
            
            for i in range(len(peaks)-1):
                p1 = peaks[i]
                p2 = peaks[i+1]
                
                position_diff = abs(p1[0] - p2[0])
                if not (10 <= position_diff <= 40):
                    continue
                
                price_diff = abs(p1[1] - p2[1]) / ((p1[1] + p2[1]) / 2)
                if price_diff > 0.02:
                    continue
                
                start_idx = min(p1[0], p2[0])
                end_idx = max(p1[0], p2[0])
                valley_between = min(prices[start_idx:end_idx+1])
                
                avg_peak = (p1[1] + p2[1]) / 2
                depth = (avg_peak - valley_between) / avg_peak
                
                if depth < 0.03:
                    continue
                
                confidence = min(0.9, depth * 10) * (1 - price_diff * 10)
                
                if confidence > self.confidence_thresholds['double_top']:
                    neckline = valley_between
                    target_price = neckline - (avg_peak - neckline)
                    
                    results.append({
                        'pattern_type': 'double_top',
                        'pattern_name': 'Double Top',
                        'pattern_confidence': round(confidence, 4),
                        'pattern_direction': 'bearish',
                        'pattern_breakout': prices[-1] < neckline,
                        'pattern_target_price': round(target_price, 6),
                        'pattern_neckline_price': round(neckline, 6),
                        'pattern_peaks_json': json.dumps([
                            {'position': p1[0], 'price': p1[1], 'type': 'first_top'},
                            {'position': p2[0], 'price': p2[1], 'type': 'second_top'}
                        ]),
                        'pattern_features_json': json.dumps({
                            'price_similarity': round(1 - price_diff, 4),
                            'pattern_depth': round(depth, 4),
                            'time_distance': position_diff
                        })
                    })
        
        # تشخیص دو دره (bullish)
        if len(valleys) >= 2:
            valleys.sort(key=lambda x: x[0])
            
            for i in range(len(valleys)-1):
                v1 = valleys[i]
                v2 = valleys[i+1]
                
                position_diff = abs(v1[0] - v2[0])
                if not (10 <= position_diff <= 40):
                    continue
                
                price_diff = abs(v1[1] - v2[1]) / ((v1[1] + v2[1]) / 2)
                if price_diff > 0.02:
                    continue
                
                start_idx = min(v1[0], v2[0])
                end_idx = max(v1[0], v2[0])
                peak_between = max(prices[start_idx:end_idx+1])
                
                avg_valley = (v1[1] + v2[1]) / 2
                depth = (peak_between - avg_valley) / peak_between
                
                if depth < 0.03:
                    continue
                
                confidence = min(0.9, depth * 10) * (1 - price_diff * 10)
                
                if confidence > self.confidence_thresholds['double_top']:
                    neckline = peak_between
                    target_price = neckline + (neckline - avg_valley)
                    
                    results.append({
                        'pattern_type': 'double_bottom',
                        'pattern_name': 'Double Bottom',
                        'pattern_confidence': round(confidence, 4),
                        'pattern_direction': 'bullish',
                        'pattern_breakout': prices[-1] > neckline,
                        'pattern_target_price': round(target_price, 6),
                        'pattern_neckline_price': round(neckline, 6),
                        'pattern_peaks_json': json.dumps([
                            {'position': v1[0], 'price': v1[1], 'type': 'first_bottom'},
                            {'position': v2[0], 'price': v2[1], 'type': 'second_bottom'}
                        ]),
                        'pattern_features_json': json.dumps({
                            'price_similarity': round(1 - price_diff, 4),
                            'pattern_depth': round(depth, 4),
                            'time_distance': position_diff
                        })
                    })
        
        return results
    
    def detect_triangles(self, prices: List[float], volumes: List[float]) -> List[Dict]:
        """تشخیص الگوی مثلث"""
        results = []
        
        if len(prices) < 25:
            return results
        
        peaks, valleys = self._find_peaks_valleys(prices, lookback=2)
        
        if len(peaks) < 3 or len(valleys) < 3:
            return results
        
        peaks.sort(key=lambda x: x[0])
        valleys.sort(key=lambda x: x[0])
        
        if len(peaks) >= 3 and len(valleys) >= 3:
            early_volatility = np.std(prices[:len(prices)//3]) / np.mean(prices[:len(prices)//3])
            late_volatility = np.std(prices[2*len(prices)//3:]) / np.mean(prices[2*len(prices)//3])
            
            compression = early_volatility - late_volatility
            
            if compression > 0.01:
                peak_prices = [p[1] for p in peaks[-3:]]
                valley_prices = [v[1] for v in valleys[-3:]]
                
                peak_slope = self._calculate_trend_strength(peak_prices)['slope']
                valley_slope = self._calculate_trend_strength(valley_prices)['slope']
                
                confidence = min(0.85, compression * 15)
                
                if confidence > self.confidence_thresholds['triangle']:
                    if valley_slope > 0.0001 and abs(peak_slope) < 0.0001:
                        results.append({
                            'pattern_type': 'ascending_triangle',
                            'pattern_name': 'Ascending Triangle',
                            'pattern_confidence': round(confidence, 4),
                            'pattern_direction': 'bullish',
                            'pattern_breakout': False,
                            'pattern_target_price': round(peak_prices[-1] + (peak_prices[-1] - valley_prices[-1]), 6),
                            'pattern_neckline_price': round(peak_prices[-1], 6),
                            'pattern_peaks_json': json.dumps([{'position': p[0], 'price': p[1]} for p in peaks[-3:]]),
                            'pattern_features_json': json.dumps({
                                'compression': round(compression, 4),
                                'valley_slope': round(valley_slope, 6),
                                'peak_slope': round(peak_slope, 6)
                            })
                        })
                    elif peak_slope < -0.0001 and abs(valley_slope) < 0.0001:
                        results.append({
                            'pattern_type': 'descending_triangle',
                            'pattern_name': 'Descending Triangle',
                            'pattern_confidence': round(confidence, 4),
                            'pattern_direction': 'bearish',
                            'pattern_breakout': False,
                            'pattern_target_price': round(valley_prices[-1] - (peak_prices[-1] - valley_prices[-1]), 6),
                            'pattern_neckline_price': round(valley_prices[-1], 6),
                            'pattern_peaks_json': json.dumps([{'position': p[0], 'price': p[1]} for p in peaks[-3:]]),
                            'pattern_features_json': json.dumps({
                                'compression': round(compression, 4),
                                'valley_slope': round(valley_slope, 6),
                                'peak_slope': round(peak_slope, 6)
                            })
                        })
        
        return results
    
    def detect_candlestick_patterns(self, ohlc_data: List[Dict]) -> List[Dict]:
        """تشخیص الگوهای کندل‌استیک"""
        results = []
        
        if len(ohlc_data) < 5:
            return results
        
        for i in range(2, len(ohlc_data)):
            try:
                current = ohlc_data[i]
                prev = ohlc_data[i-1]
                
                current_open = float(current['open'])
                current_close = float(current['close'])
                current_high = float(current['high'])
                current_low = float(current['low'])
                
                prev_open = float(prev['open'])
                prev_close = float(prev['close'])
                
                current_body = abs(current_close - current_open)
                prev_body = abs(prev_close - prev_open)
                
                current_lower_shadow = current_low - min(current_open, current_close)
                current_upper_shadow = max(current_open, current_close) - current_high
                
                current_range = current_high - current_low
                
                if current_range == 0:
                    continue
                
                # چکش
                if (current_lower_shadow > current_body * 2 and 
                    current_upper_shadow < current_body * 0.3):
                    
                    direction = 'bullish' if current_close > current_open else 'bearish'
                    confidence = 0.6 if direction == 'bullish' else 0.5
                    
                    results.append({
                        'pattern_type': 'hammer',
                        'pattern_name': 'Hammer' if direction == 'bullish' else 'Hanging Man',
                        'pattern_confidence': round(confidence, 4),
                        'pattern_direction': direction,
                        'pattern_breakout': True,
                        'pattern_target_price': round(current_close * (1.02 if direction == 'bullish' else 0.98), 6),
                        'pattern_neckline_price': round(current_close, 6),
                        'pattern_peaks_json': json.dumps([]),
                        'pattern_features_json': json.dumps({
                            'body_ratio': round(current_body / current_range, 4),
                            'lower_shadow_ratio': round(current_lower_shadow / current_body, 4)
                        })
                    })
                
                # Engulfing
                if (current_body > prev_body * 1.5 and
                    min(current_open, current_close) < min(prev_open, prev_close) and
                    max(current_open, current_close) > max(prev_open, prev_close)):
                    
                    direction = 'bullish' if current_close > current_open else 'bearish'
                    prev_direction = 'bullish' if prev_close > prev_open else 'bearish'
                    
                    confidence = 0.7
                    if direction != prev_direction:
                        confidence += 0.1
                    
                    results.append({
                        'pattern_type': 'engulfing',
                        'pattern_name': 'Bullish Engulfing' if direction == 'bullish' else 'Bearish Engulfing',
                        'pattern_confidence': round(confidence, 4),
                        'pattern_direction': direction,
                        'pattern_breakout': True,
                        'pattern_target_price': round(current_close * (1.03 if direction == 'bullish' else 0.97), 6),
                        'pattern_neckline_price': round(current_close, 6),
                        'pattern_peaks_json': json.dumps([]),
                        'pattern_features_json': json.dumps({
                            'engulfing_ratio': round(current_body / prev_body, 4),
                            'prev_direction': prev_direction
                        })
                    })
                    
            except Exception:
                continue
        
        if len(results) > 10:
            results.sort(key=lambda x: x['pattern_confidence'], reverse=True)
            results = results[:10]
        
        return results
    
    def detect_divergences(self, prices: List[float], indicators: Dict) -> List[Dict]:
        """تشخیص واگرایی‌ها"""
        results = []
        
        if len(prices) < 20:
            return results
        
        # واگرایی RSI
        if 'rsi' in indicators and len(indicators['rsi']) >= 20:
            rsi = indicators['rsi']
            
            recent_prices = prices[-20:]
            recent_rsi = rsi[-20:]
            
            price_trend = self._calculate_trend_strength(recent_prices)
            rsi_trend = self._calculate_trend_strength(recent_rsi)
            
            if (price_trend['direction'] == 'bullish' and rsi_trend['direction'] == 'bearish'):
                confidence = max(0.3, abs(price_trend['strength'] - rsi_trend['strength']))
                
                if confidence > self.confidence_thresholds['divergence']:
                    results.append({
                        'divergence_type': 'bearish_divergence',
                        'direction': 'bearish',
                        'confidence': round(confidence, 4),
                        'indicator': 'RSI',
                        'price_trend_strength': round(price_trend['strength'], 4),
                        'indicator_trend_strength': round(rsi_trend['strength'], 4),
                        'description': 'قیمت در حال افزایش اما RSI در حال کاهش است'
                    })
            
            elif (price_trend['direction'] == 'bearish' and rsi_trend['direction'] == 'bullish'):
                confidence = max(0.3, abs(price_trend['strength'] - rsi_trend['strength']))
                
                if confidence > self.confidence_thresholds['divergence']:
                    results.append({
                        'divergence_type': 'bullish_divergence',
                        'direction': 'bullish',
                        'confidence': round(confidence, 4),
                        'indicator': 'RSI',
                        'price_trend_strength': round(price_trend['strength'], 4),
                        'indicator_trend_strength': round(rsi_trend['strength'], 4),
                        'description': 'قیمت در حال کاهش اما RSI در حال افزایش است'
                    })
        
        # واگرایی MACD
        if 'macd' in indicators and 'macd_histogram' in indicators:
            macd = indicators['macd']
            histogram = indicators['macd_histogram']
            
            if len(macd) >= 20 and len(histogram) >= 20:
                recent_macd = macd[-20:]
                recent_histogram = histogram[-20:]
                
                macd_trend = self._calculate_trend_strength(recent_macd)
                histogram_trend = self._calculate_trend_strength(recent_histogram)
                price_trend = self._calculate_trend_strength(prices[-20:])
                
                if (price_trend['direction'] == 'bullish' and macd_trend['direction'] == 'bearish'):
                    confidence = max(0.3, abs(price_trend['strength'] - macd_trend['strength']))
                    
                    if confidence > self.confidence_thresholds['divergence']:
                        results.append({
                            'divergence_type': 'bearish_divergence',
                            'direction': 'bearish',
                            'confidence': round(confidence, 4),
                            'indicator': 'MACD',
                            'price_trend_strength': round(price_trend['strength'], 4),
                            'indicator_trend_strength': round(macd_trend['strength'], 4),
                            'description': 'قیمت در حال افزایش اما MACD در حال کاهش است'
                        })
                
                elif (price_trend['direction'] == 'bearish' and macd_trend['direction'] == 'bullish'):
                    confidence = max(0.3, abs(price_trend['strength'] - macd_trend['strength']))
                    
                    if confidence > self.confidence_thresholds['divergence']:
                        results.append({
                            'divergence_type': 'bullish_divergence',
                            'direction': 'bullish',
                            'confidence': round(confidence, 4),
                            'indicator': 'MACD',
                            'price_trend_strength': round(price_trend['strength'], 4),
                            'indicator_trend_strength': round(macd_trend['strength'], 4),
                            'description': 'قیمت در حال کاهش اما MACD در حال افزایش است'
                        })
        
        return results
    
    # ========== متد اصلی تحلیل ==========
    
    def analyze_coin(self, coin_id: int, symbol: str, limit: int = 80) -> Dict[str, Any]:
        """تحلیل کامل یک ارز - نسخه بهبود یافته با فیلترهای هوشمند"""
        logger.info(f"🔍 تحلیل ارز: {symbol} (ID: {coin_id})")
        
        try:
            # دریافت اندیکاتورها
            indicators = self._get_technical_indicators_from_klines(coin_id, limit)
            
            if not indicators or not indicators.get('closes'):
                logger.warning(f"⚠️ داده کافی برای {symbol} وجود ندارد")
                return {
                    'success': False, 
                    'reason': 'داده کافی وجود ندارد',
                    'coin_id': coin_id,
                    'symbol': symbol
                }
            
            # استخراج داده‌ها
            prices = indicators['closes'][::-1]  # معکوس: قدیمی به جدید
            volumes = indicators.get('volume', [])[::-1] if indicators.get('volume') else []
            
            if len(prices) < 30:  # حداقل 30 کندل
                logger.warning(f"⚠️ داده‌های {symbol} بسیار کم است ({len(prices)} کندل)")
                return {
                    'success': False, 
                    'reason': f'داده‌های بسیار کم ({len(prices)} کندل)',
                    'coin_id': coin_id,
                    'symbol': symbol
                }
            
            # تحلیل روند
            trend = self._calculate_trend_strength(prices)
            current_price = prices[-1] if prices else 0
            
            # لاگ اطلاعات اولیه
            logger.info(f"📊 {symbol}: {len(prices)} کندل، قیمت: {current_price:.6f}")
            logger.info(f"📈 روند {symbol}: {trend['direction']} با قدرت {trend['strength']:.1%}")
            
            # ========== تشخیص الگوها ==========
            patterns = []
            
            # ۱. سر و شانه
            head_shoulders = self.detect_head_shoulders(prices, volumes)
            if head_shoulders:
                patterns.append(head_shoulders)
            
            # ۲. دو قله/دو دره
            double_patterns = self.detect_double_top_bottom(prices, volumes)
            patterns.extend(double_patterns)
            
            # ۳. مثلث‌ها
            triangles = self.detect_triangles(prices, volumes)
            patterns.extend(triangles)
            
            # ========== فیلترهای هوشمند ==========
            
            # فیلتر ۱: حذف الگوهای با اعتماد کم
            min_confidence = 0.65  # حداقل اعتماد 65%
            patterns = [p for p in patterns if p['pattern_confidence'] >= min_confidence]
            
            # فیلتر ۲: بررسی یکنواختی الگوها
            bearish_count = sum(1 for p in patterns if p['pattern_direction'] == 'bearish')
            bullish_count = sum(1 for p in patterns if p['pattern_direction'] == 'bullish')
            
            # اگر بیش از 80% الگوها یک جهت باشند، مشکوک است
            total_patterns = len(patterns)
            if total_patterns > 0:
                max_direction_ratio = max(bearish_count, bullish_count) / total_patterns
                if max_direction_ratio > 0.8:
                    logger.warning(f"⚠️ {symbol}: تشخیص یکطرفه ({bearish_count} bearish, {bullish_count} bullish)")
                    # در صورت تشخیص یکطرفه، اعتماد همه الگوها را کاهش می‌دهیم
                    for pattern in patterns:
                        pattern['pattern_confidence'] *= 0.7  # کاهش 30% اعتماد
            
            # فیلتر ۳: بررسی تطابق با روند کلی
            for pattern in patterns:
                pattern_direction = pattern['pattern_direction']
                trend_direction = trend['direction']
                
                # اگر الگو با روند هم‌جهت نباشد، اعتماد کم می‌کنیم
                if pattern_direction != trend_direction:
                    pattern['pattern_confidence'] *= 0.8  # کاهش 20% اعتماد
                
                # اگر روند قوی باشد و الگو مخالف آن باشد، اعتماد بیشتری کم می‌کنیم
                if trend['strength'] > 0.6 and pattern_direction != trend_direction:
                    pattern['pattern_confidence'] *= 0.7  # کاهش 30% اعتماد اضافی
            
            # فیلتر ۴: حذف الگوهای تکراری یا مشابه
            unique_patterns = []
            seen_pattern_types = set()
            
            for pattern in patterns:
                pattern_type = pattern['pattern_type']
                
                # اگر این نوع الگو قبلاً دیده شده، اعتماد کم می‌کنیم
                if pattern_type in seen_pattern_types:
                    pattern['pattern_confidence'] *= 0.6  # کاهش 40% اعتماد برای تکراری
                    pattern['pattern_name'] = f"{pattern['pattern_name']} (Duplicate)"
                
                seen_pattern_types.add(pattern_type)
                unique_patterns.append(pattern)
            
            patterns = unique_patterns
            
            # فیلتر ۵: مرتب‌سازی بر اساس اعتماد
            patterns.sort(key=lambda x: x['pattern_confidence'], reverse=True)
            
            # محدود کردن تعداد الگوها
            max_patterns = 5  # حداکثر 5 الگو
            if len(patterns) > max_patterns:
                patterns = patterns[:max_patterns]
            
            # ========== تشخیص واگرایی‌ها ==========
            divergences = self.detect_divergences(prices, indicators)
            
            # فیلتر واگرایی‌ها
            min_divergence_confidence = 0.7  # حداقل اعتماد 70%
            divergences = [d for d in divergences if d['confidence'] >= min_divergence_confidence]
            
            # محدود کردن تعداد واگرایی‌ها
            max_divergences = 3  # حداکثر 3 واگرایی
            if len(divergences) > max_divergences:
                divergences = divergences[:max_divergences]
            
            # ========== جمع‌بندی نهایی ==========
            
            # محاسبه سیگنال کلی
            overall_signal = 'neutral'
            overall_confidence = 0.0
            
            if patterns:
                # میانگین وزنی اعتماد الگوها
                bullish_sum = 0
                bearish_sum = 0
                
                for pattern in patterns:
                    if pattern['pattern_direction'] == 'bullish':
                        bullish_sum += pattern['pattern_confidence']
                    else:
                        bearish_sum += pattern['pattern_confidence']
                
                if bullish_sum > bearish_sum:
                    overall_signal = 'bullish'
                    overall_confidence = bullish_sum / len(patterns)
                elif bearish_sum > bullish_sum:
                    overall_signal = 'bearish'
                    overall_confidence = bearish_sum / len(patterns)
                else:
                    overall_signal = 'neutral'
                    overall_confidence = (bullish_sum + bearish_sum) / (2 * len(patterns))
            
            # اعتبارسنجی نهایی
            if overall_confidence < 0.5:  # اگر اعتماد کلی کمتر از 50% باشد
                logger.info(f"📭 {symbol}: اعتماد کلی کم ({overall_confidence:.1%}) - سیگنال ضعیف")
            
            # لاگ نتایج
            logger.info(f"✅ تحلیل {symbol} کامل شد:")
            logger.info(f"   • {len(patterns)} الگو ({bullish_count} bullish, {bearish_count} bearish)")
            logger.info(f"   • {len(divergences)} واگرایی")
            logger.info(f"   • سیگنال کلی: {overall_signal} ({overall_confidence:.1%})")
            
            # نمایش الگوهای برتر
            if patterns:
                for i, pattern in enumerate(patterns[:3]):  # فقط 3 الگوی برتر
                    logger.info(f"   {i+1}. {pattern['pattern_name']}: "
                              f"{pattern['pattern_direction']} ({pattern['pattern_confidence']:.1%})")
            
            return {
                'success': True,
                'coin_id': coin_id,
                'symbol': symbol,
                'price': current_price,
                'price_change_24h': 0,  # اگر در دیتابیس دارید اضافه کنید
                'trend': trend,
                'patterns': patterns,
                'divergences': divergences,
                'overall_signal': overall_signal,
                'overall_confidence': overall_confidence,
                'data_points': len(prices),
                'analysis_summary': {
                    'bullish_patterns': bullish_count,
                    'bearish_patterns': bearish_count,
                    'total_patterns': len(patterns),
                    'total_divergences': len(divergences),
                    'trend_strength': trend['strength'],
                    'trend_direction': trend['direction']
                },
                'timestamp': datetime.now().isoformat(),
                'analysis_version': 'v2.0_improved'
            }
            
        except Exception as e:
            logger.error(f"❌ خطا در تحلیل {symbol}: {str(e)[:100]}")
            import traceback
            logger.error(traceback.format_exc())
            
            return {
                'success': False,
                'coin_id': coin_id,
                'symbol': symbol,
                'error': str(e),
                'reason': 'خطای تحلیل',
                'timestamp': datetime.now().isoformat()
            }
    
    def process_all_coins(self, block_id: Optional[int] = None, limit: int = 10):
        """پردازش همه ارزها"""
        logger.info(f"🔧 شروع پردازش {limit} ارز")
        
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        try:
            if block_id:
                cursor.execute("""
                    SELECT id, symbol 
                    FROM crypto_coins 
                    WHERE block_id = ? AND is_active = 1
                    ORDER BY market_cap DESC
                    LIMIT ?
                """, (block_id, limit))
            else:
                cursor.execute("""
                    SELECT id, symbol 
                    FROM crypto_coins 
                    WHERE is_active = 1
                    ORDER BY market_cap DESC
                    LIMIT ?
                """, (limit,))
            
            coins = cursor.fetchall()
            
            logger.info(f"📊 تعداد ارزها برای پردازش: {len(coins)}")
            
            results = []
            for coin_id, symbol in coins:
                result = self.analyze_coin(coin_id, symbol)
                results.append(result)
                
                if result['success']:
                    patterns = len(result.get('patterns', []))
                    divergences = len(result.get('divergences', []))
                    print(f"✅ {symbol}: {patterns} الگو، {divergences} واگرایی")
                else:
                    print(f"🚫 {symbol}: {result.get('reason', 'خطا')}")
            
            logger.info(f"✅ پردازش کامل شد: {len([r for r in results if r['success']])}/{len(coins)} موفق")
            
        except Exception as e:
            logger.error(f"❌ خطا در پردازش ارزها: {e}")
        finally:
            conn.close()


def main():
    """تابع اصلی اجرا"""
    
    print("=" * 70)
    print("🎯 COMPLETE PATTERN DETECTOR - سیستم تشخیص کامل الگوها و واگرایی")
    print("📊 نسخه اصلاح شده: استفاده از crypto_klines به جای technical_indicators")
    print("=" * 70)
    
    try:
        detector = CompletePatternDetector()
        
        import argparse
        
        parser = argparse.ArgumentParser(description='تشخیص کامل الگوهای قیمتی و واگرایی')
        parser.add_argument('--block', type=int, help='شماره بلوک برای پردازش')
        parser.add_argument('--coin', type=str, help='نماد ارز برای پردازش تکی')
        parser.add_argument('--all', action='store_true', help='پردازش همه ارزها')
        parser.add_argument('--limit', type=int, default=3, help='تعداد ارزها برای پردازش')
        
        args = parser.parse_args()
        
        if args.coin:
            conn = sqlite3.connect(detector.db_path)
            cursor = conn.cursor()
            cursor.execute(
                "SELECT id FROM crypto_coins WHERE symbol = ?", 
                (args.coin.upper(),)
            )
            result = cursor.fetchone()
            conn.close()
            
            if result:
                coin_id = result[0]
                analysis = detector.analyze_coin(coin_id, args.coin)
                
                if analysis.get('success'):
                    patterns = analysis.get('patterns', [])
                    divergences = analysis.get('divergences', [])
                    
                    print(f"\n✅ تحلیل کامل برای {args.coin} (با crypto_klines):")
                    print(f"   • قیمت: ${analysis['price']:,.2f}")
                    print(f"   • روند: {analysis['trend']['direction']} ({analysis['trend']['strength']:.1%})")
                    
                    if patterns:
                        print(f"\n📊 الگوهای تشخیص داده شده ({len(patterns)}):")
                        for i, pattern in enumerate(patterns[:5]):
                            print(f"   {i+1}. {pattern['pattern_name']} - "
                                  f"{pattern['pattern_direction']} ({pattern['pattern_confidence']:.2%})")
                    
                    if divergences:
                        print(f"\n📈 واگرایی‌های تشخیص داده شده ({len(divergences)}):")
                        for i, div in enumerate(divergences[:3]):
                            print(f"   {i+1}. {div['divergence_type']} - "
                                  f"{div['direction']} ({div['confidence']:.2%})")
                    
                    print(f"\n📁 ذخیره شده در دیتابیس (از crypto_klines)")
                else:
                    print(f"\n⚠️ تحلیل ناموفق: {analysis.get('reason', 'نامشخص')}")
            else:
                print(f"\n❌ ارز {args.coin} یافت نشد")
        
        elif args.block:
            print(f"\n🔧 پردازش بلوک {args.block} با crypto_klines...")
            detector.process_all_coins(block_id=args.block, limit=args.limit)
        
        elif args.all:
            print(f"\n🔧 پردازش {args.limit} ارز فعال با crypto_klines...")
            detector.process_all_coins(limit=args.limit)
        
        else:
            print("\n🔧 پردازش بلوک 1 (پیش‌فرض) با crypto_klines...")
            detector.process_all_coins(block_id=1, limit=3)
        
        print("\n" + "=" * 70)
        print("✅ پردازش CompletePatternDetector با موفقیت انجام شد")
        print("📊 منبع داده: crypto_klines")
        print("=" * 70)
        
    except Exception as e:
        print(f"\n❌ خطا در اجرای CompletePatternDetector: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    main()