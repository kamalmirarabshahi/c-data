"""
🎯 Signal Combiner Complete - سیستم ترکیب سیگنال‌های پیشرفته
با سیستم امتیازدهی پویا و استفاده کامل از اندیکاتورها
نسخه بازنویسی شده: استفاده از crypto_klines به جای technical_indicators
"""

import sqlite3
import json
import numpy as np
from datetime import datetime, timedelta
import logging
from typing import Dict, List, Optional
import sys
import os

current_dir = os.path.dirname(os.path.abspath(__file__))
scripts_dir = os.path.dirname(os.path.dirname(current_dir))
project_root = os.path.dirname(scripts_dir)

sys.path.insert(0, project_root)
sys.path.insert(0, scripts_dir)

try:
    import config_manager
    print("✅ config_manager import شد")
except ImportError as e:
    print(f"❌ خطا در import config_manager: {e}")
    sys.exit(1)

# تنظیمات لاگ‌گیری
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('logs/signal_combiner_complete.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)


class AdvancedScoringSystem:
    """سیستم امتیازدهی پیشرفته"""
    
    def __init__(self):
        # وزن‌های پویا (بر اساس عملکرد تاریخی)
        self.weights = {
            'pattern': 0.35,      # الگوهای قیمتی
            'divergence': 0.25,   # واگرایی‌ها
            'trend': 0.15,        # تحلیل روند
            'volume': 0.10,       # تحلیل حجم
            'indicators': 0.15    # اندیکاتورها
        }
        
        # آستانه‌ها
        self.thresholds = {
            'strong_buy': 0.75,
            'buy': 0.60,
            'neutral': 0.40,
            'sell': 0.25,
            'strong_sell': 0.15
        }
    
    def _score_patterns(self, patterns: List[Dict]) -> float:
        """امتیازدهی الگوهای قیمتی"""
        if not patterns:
            return 0.3  # امتیاز خنثی
        
        total_confidence = sum(p.get('pattern_confidence', 0) for p in patterns)
        avg_confidence = total_confidence / len(patterns)
        
        # وزن‌دهی بر اساس نوع الگو
        pattern_weights = {
            'head_shoulders': 1.0,
            'double_top': 0.9,
            'double_bottom': 0.9,
            'ascending_triangle': 0.8,
            'descending_triangle': 0.8,
            'hammer': 0.7,
            'engulfing': 0.8
        }
        
        weighted_score = 0
        for pattern in patterns:
            weight = pattern_weights.get(pattern.get('pattern_type', ''), 0.5)
            weighted_score += pattern.get('pattern_confidence', 0) * weight
        
        return min(max(weighted_score / len(patterns), 0), 1)
    
    def _score_divergences(self, divergences: List[Dict]) -> float:
        """امتیازدهی واگرایی‌ها"""
        if not divergences:
            return 0.5  # امتیاز خنثی
        
        total_confidence = sum(d.get('confidence', 0) for d in divergences)
        avg_confidence = total_confidence / len(divergences)
        
        # واگرایی قوی‌تر وزن بیشتری دارد
        return avg_confidence * 1.2 if avg_confidence > 0.7 else avg_confidence
    
    def _score_trend(self, trend_data: Dict) -> float:
        """امتیازدهی تحلیل روند"""
        strength = trend_data.get('strength', 0)
        direction = trend_data.get('direction', 'neutral')
        
        if direction == 'bullish':
            return 0.5 + (strength * 0.5)
        elif direction == 'bearish':
            return 0.5 - (strength * 0.5)
        else:
            return 0.5
    
    def _score_volume(self, volume_data: Dict) -> float:
        """امتیازدهی تحلیل حجم"""
        if not volume_data:
            return 0.5
        
        score = 0.5
        
        # بررسی ناهنجاری حجم
        if volume_data.get('volume_anomaly'):
            anomaly_strength = volume_data.get('anomaly_strength', 0.5)
            score += anomaly_strength * 0.3
        
        # بررسی نسبت حجم
        if volume_data.get('volume_ratio'):
            ratio = volume_data['volume_ratio']
            if ratio > 1.5:
                score += 0.2
            elif ratio < 0.5:
                score -= 0.1
        
        return min(max(score, 0), 1)
    
    def _score_indicators(self, indicators: Dict) -> float:
        """امتیازدهی اندیکاتورها از crypto_klines"""
        if not indicators:
            return 0.5
        
        scores = []
        
        # RSI
        if 'rsi' in indicators and indicators['rsi'] is not None:
            rsi = indicators['rsi']
            if rsi < 30:
                scores.append(0.85)
            elif rsi < 40:
                scores.append(0.70)
            elif rsi > 70:
                scores.append(0.15)
            elif rsi > 60:
                scores.append(0.30)
            else:
                scores.append(0.50)
        
        # MACD Histogram
        if 'macd_histogram' in indicators and indicators['macd_histogram'] is not None:
            macd = indicators['macd_histogram']
            if macd > 0.001:
                scores.append(0.70)
            elif macd < -0.001:
                scores.append(0.30)
            else:
                scores.append(0.50)
        
        # Bollinger Bands Position
        if all(k in indicators for k in ['price', 'bollinger_upper', 'bollinger_lower']):
            price = indicators['price']
            upper = indicators['bollinger_upper']
            lower = indicators['bollinger_lower']
            
            if upper is not None and lower is not None and price is not None:
                position = (price - lower) / (upper - lower) if (upper - lower) != 0 else 0.5
                if position < 0.2:
                    scores.append(0.80)  # نزدیک باند پایین
                elif position > 0.8:
                    scores.append(0.20)  # نزدیک باند بالا
                else:
                    scores.append(0.50)
        
        # Moving Averages (از ma_7 به جای sma_20 استفاده می‌کنیم)
        if 'price' in indicators and indicators['price'] is not None:
            price = indicators['price']
            
            # بررسی MA 7
            if 'ma_7' in indicators and indicators['ma_7'] is not None:
                ma7 = indicators['ma_7']
                if price > ma7 * 1.02:
                    scores.append(0.65)
                elif price < ma7 * 0.98:
                    scores.append(0.35)
                else:
                    scores.append(0.50)
            
            # بررسی MA 25
            if 'ma_25' in indicators and indicators['ma_25'] is not None:
                ma25 = indicators['ma_25']
                if price > ma25 * 1.03:
                    scores.append(0.70)
                elif price < ma25 * 0.97:
                    scores.append(0.30)
                else:
                    scores.append(0.50)
        
        # Volatility
        if 'volatility' in indicators and indicators['volatility'] is not None:
            vol = indicators['volatility']
            if vol > 0.03:  # نوسان بالا
                scores.append(0.35)  # ریسک بیشتر
            elif vol < 0.01:  # نوسان پایین
                scores.append(0.65)  # ریسک کمتر
            else:
                scores.append(0.50)
        
        # ATR (Average True Range)
        if 'atr' in indicators and indicators['atr'] is not None:
            atr = indicators['atr']
            if atr > 0.02:  # ATR بالا
                scores.append(0.40)
            elif atr < 0.005:  # ATR پایین
                scores.append(0.60)
            else:
                scores.append(0.50)
        
        return np.mean(scores) if scores else 0.5
    
    def calculate_composite_score(self, analysis_results: Dict) -> Dict:
        """محاسبه امتیاز ترکیبی نهایی"""
        component_scores = {
            'pattern': self._score_patterns(analysis_results.get('patterns', [])),
            'divergence': self._score_divergences(analysis_results.get('divergences', [])),
            'trend': self._score_trend(analysis_results.get('trend', {})),
            'volume': self._score_volume(analysis_results.get('volume', {})),
            'indicators': self._score_indicators(analysis_results.get('indicators', {}))
        }
        
        # محاسبه امتیاز نهایی
        final_score = sum(component_scores[k] * self.weights[k] for k in self.weights)
        final_score = min(max(final_score, 0), 1)
        
        # تعیین سیگنال
        if final_score >= self.thresholds['strong_buy']:
            signal = 'STRONG_BUY'
            confidence = final_score
        elif final_score >= self.thresholds['buy']:
            signal = 'BUY'
            confidence = final_score
        elif final_score <= self.thresholds['strong_sell']:
            signal = 'STRONG_SELL'
            confidence = 1 - final_score
        elif final_score <= self.thresholds['sell']:
            signal = 'SELL'
            confidence = 1 - final_score
        else:
            signal = 'NEUTRAL'
            confidence = 0.5
        
        return {
            'final_score': round(final_score, 4),
            'signal': signal,
            'confidence': round(confidence, 4),
            'component_scores': component_scores,
            'components_used': len([v for v in component_scores.values() if v != 0.5])
        }


class CompleteSignalCombiner:
    """ترکیب‌کننده کامل سیگنال‌ها - نسخه اصلاح شده با crypto_klines"""
    
    def __init__(self):
        self.config_manager = config_manager
        self.db_path = self.config_manager.get_database_path()
        self.scoring_system = AdvancedScoringSystem()
        
        logger.info(f"📁 مسیر دیتابیس: {self.db_path}")
        logger.info("✅ CompleteSignalCombiner راه‌اندازی شد (نسخه crypto_klines)")
    
    def _get_complete_analysis(self, coin_id: int, symbol: str) -> Dict:
        """دریافت تحلیل کامل از همه منابع با استفاده از crypto_klines"""
        conn = sqlite3.connect(self.db_path)
        
        try:
            cursor = conn.cursor()
            
            # 1. دریافت الگوهای اخیر از pattern_analysis
            cursor.execute("""
                SELECT pattern_type, pattern_name, pattern_direction, 
                       pattern_confidence, pattern_breakout, target_price
                FROM pattern_analysis 
                WHERE coin_id = ? 
                AND detection_time > datetime('now', '-2 days')
                ORDER BY detection_time DESC
            """, (coin_id,))
            
            patterns = []
            for row in cursor.fetchall():
                patterns.append({
                    'pattern_type': row[0],
                    'pattern_name': row[1],
                    'pattern_direction': row[2],
                    'pattern_confidence': row[3] / 100,
                    'pattern_breakout': bool(row[4]),
                    'target_price': row[5]
                })
            
            # 2. دریافت واگرایی‌های اخیر از trading_signals
            cursor.execute("""
                SELECT signal_type, confidence_score, trigger_indicators
                FROM trading_signals 
                WHERE coin_id = ? 
                AND (signal_category = 'divergence' OR signal_type LIKE '%DIVERGENCE%')
                AND signal_time > datetime('now', '-1 day')
                ORDER BY signal_time DESC
            """, (coin_id,))
            
            divergences = []
            for row in cursor.fetchall():
                divergences.append({
                    'divergence_type': row[2] if row[2] else 'unknown',
                    'direction': 'bullish' if 'BULLISH' in str(row[0]) else 'bearish',
                    'confidence': row[1] / 100
                })
            
            # 3. دریافت اندیکاتورها و داده‌های جدید از crypto_klines
            cursor.execute("""
                SELECT 
                    close_price,
                    rsi,
                    macd,
                    macd_signal,
                    macd_histogram,
                    bollinger_upper,
                    bollinger_middle,
                    bollinger_lower,
                    ma_7,
                    ma_25,
                    ma_99,
                    volume_ma_20,
                    volume,
                    pattern_confidence,
                    trend_strength,
                    atr,
                    volatility,
                    obv,
                    pattern_markers
                FROM crypto_klines 
                WHERE coin_id = ? 
                ORDER BY open_time DESC 
                LIMIT 1
            """, (coin_id,))
            
            row = cursor.fetchone()
            indicators = {}
            
            if row:
                # دریافت اطلاعات بازار از crypto_coins
                cursor.execute("""
                    SELECT current_price, price_change_percent_24h, volume_24h, market_cap_rank
                    FROM crypto_coins 
                    WHERE id = ?
                """, (coin_id,))
                
                market_row = cursor.fetchone()
                current_price = row[0] if row[0] else (market_row[0] if market_row else 0)
                
                indicators = {
                    'price': current_price,
                    'close_price': row[0],
                    'rsi': row[1],
                    'macd': row[2],
                    'macd_signal': row[3],
                    'macd_histogram': row[4],
                    'bollinger_upper': row[5],
                    'bollinger_middle': row[6],
                    'bollinger_lower': row[7],
                    'ma_7': row[8],
                    'ma_25': row[9],
                    'ma_99': row[10],
                    'volume_ma_20': row[11],
                    'volume': row[12],
                    'pattern_confidence': row[13],
                    'trend_strength': row[14],
                    'atr': row[15],
                    'volatility': row[16],
                    'obv': row[17],
                    'pattern_markers': row[18]
                }
            
            # 4. تحلیل حجم
            volume_data = {}
            if 'volume' in indicators and 'volume_ma_20' in indicators:
                current_volume = indicators['volume']
                volume_ma = indicators['volume_ma_20']
                
                if current_volume is not None and volume_ma is not None and volume_ma > 0:
                    volume_ratio = current_volume / volume_ma
                    
                    # تشخیص ناهنجاری حجم (حجم بیشتر از 2 برابر میانگین)
                    volume_anomaly = volume_ratio > 2.0
                    
                    volume_data = {
                        'volume_ratio': volume_ratio,
                        'volume_anomaly': volume_anomaly,
                        'anomaly_strength': min((volume_ratio - 1), 3.0)  # حداکثر 3.0
                    }
            
            # 5. تحلیل روند از crypto_klines
            trend_data = {'strength': 0.5, 'direction': 'neutral'}
            
            if 'trend_strength' in indicators and indicators['trend_strength'] is not None:
                trend_data['strength'] = indicators['trend_strength']
                
                # تعیین جهت روند از اطلاعات کالای اخیر
                cursor.execute("""
                    SELECT close_price FROM crypto_klines 
                    WHERE coin_id = ? 
                    ORDER BY open_time DESC 
                    LIMIT 20
                """, (coin_id,))
                
                recent_prices = [float(row[0]) for row in cursor.fetchall() if row[0] is not None]
                
                if len(recent_prices) >= 5:
                    # رگرسیون خطی ساده
                    if recent_prices[-1] > recent_prices[-5] * 1.02:
                        trend_data['direction'] = 'bullish'
                    elif recent_prices[-1] < recent_prices[-5] * 0.98:
                        trend_data['direction'] = 'bearish'
                    else:
                        trend_data['direction'] = 'neutral'
            
            # 6. اطلاعات بازار
            market_data = {}
            if market_row:
                market_data = {
                    'price_change_24h': market_row[1],
                    'volume_24h': market_row[2],
                    'market_rank': market_row[3]
                }
            
            # 7. داده‌های اضافی برای کیفیت تحلیل
            analysis_quality = {
                'data_source': 'crypto_klines',
                'indicators_count': len([k for k in indicators if indicators[k] is not None]),
                'latest_kline_time': None
            }
            
            # دریافت زمان آخرین کندل
            cursor.execute("""
                SELECT open_time FROM crypto_klines 
                WHERE coin_id = ? 
                ORDER BY open_time DESC 
                LIMIT 1
            """, (coin_id,))
            
            time_row = cursor.fetchone()
            if time_row:
                analysis_quality['latest_kline_time'] = time_row[0]
            
            return {
                'patterns': patterns,
                'divergences': divergences,
                'indicators': indicators,
                'volume': volume_data,
                'trend': trend_data,
                'market': market_data,
                'analysis_quality': analysis_quality,
                'timestamp': datetime.now().isoformat()
            }
            
        except Exception as e:
            logger.error(f"❌ خطا در دریافت تحلیل کامل برای {symbol}: {e}")
            return {
                'patterns': [],
                'divergences': [],
                'indicators': {},
                'volume': {},
                'trend': {'strength': 0.5, 'direction': 'neutral'},
                'market': {},
                'analysis_quality': {'data_source': 'error'},
                'timestamp': datetime.now().isoformat()
            }
        finally:
            conn.close()
    
    def combine_for_coin(self, coin_id: int, symbol: str) -> Dict:
        """ترکیب سیگنال‌ها برای یک ارز"""
        logger.info(f"🔍 ترکیب سیگنال‌ها برای {symbol} (نسخه crypto_klines)")
        
        try:
            # دریافت تحلیل کامل
            analysis = self._get_complete_analysis(coin_id, symbol)
            
            # بررسی کیفیت داده‌ها
            if analysis['analysis_quality'].get('data_source') == 'error':
                logger.warning(f"⚠️ خطا در دریافت داده‌ها برای {symbol}")
                return {
                    'success': False,
                    'reason': 'خطا در دریافت داده‌ها',
                    'symbol': symbol,
                    'coin_id': coin_id
                }
            
            # امتیازدهی
            scoring_result = self.scoring_system.calculate_composite_score(analysis)
            
            # بررسی حداقل مؤلفه‌ها
            if scoring_result['components_used'] < 1:
                logger.warning(f"⚠️ مؤلفه‌های ناکافی برای {symbol}: {scoring_result['components_used']}")
                return {
                    'success': False,
                    'reason': f'مؤلفه‌های ناکافی ({scoring_result["components_used"]})',
                    'symbol': symbol,
                    'coin_id': coin_id
                }
            
            # بررسی اعتماد نهایی
            if scoring_result['confidence'] < 0.30:
                logger.info(f"🚫 اعتماد ناکافی برای {symbol}: {scoring_result['confidence']:.2%}")
                return {
                    'success': False,
                    'reason': f'اعتماد ناکافی ({scoring_result["confidence"]:.2%})',
                    'symbol': symbol,
                    'coin_id': coin_id
                }
            
            # بررسی کیفیت اندیکاتورها
            indicators_count = analysis['analysis_quality'].get('indicators_count', 0)
            if indicators_count < 2:
                logger.info(f"⚠️ اندیکاتورهای ناکافی برای {symbol}: {indicators_count}")
                # کاهش اعتماد
                scoring_result['confidence'] *= 0.95
            
            # جمع‌بندی نهایی
            final_result = {
                'success': True,
                'symbol': symbol,
                'coin_id': coin_id,
                'signal': scoring_result['signal'],
                'confidence': scoring_result['confidence'],
                'final_score': scoring_result['final_score'],
                'components_count': scoring_result['components_used'],
                'analysis_summary': {
                    'patterns_count': len(analysis['patterns']),
                    'divergences_count': len(analysis['divergences']),
                    'indicators_count': indicators_count,
                    'trend_strength': analysis['trend']['strength'],
                    'trend_direction': analysis['trend']['direction'],
                    'data_source': analysis['analysis_quality'].get('data_source', 'crypto_klines')
                },
                'component_scores': scoring_result['component_scores'],
                'timestamp': datetime.now().isoformat()
            }
            
            # ذخیره در دیتابیس
            self._save_combined_signal(final_result, analysis)
            
            logger.info(f"✅ سیگنال ترکیبی برای {symbol}: "
                       f"{scoring_result['signal']} ({scoring_result['confidence']:.2%})")
            
            return final_result
            
        except Exception as e:
            logger.error(f"❌ خطا در ترکیب سیگنال‌های {symbol}: {e}")
            return {
                'success': False,
                'error': str(e),
                'symbol': symbol,
                'coin_id': coin_id
            }
    
    def _save_combined_signal(self, signal_data: Dict, analysis: Dict):
        """ذخیره سیگنال ترکیبی در دیتابیس"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        try:
            # بررسی وجود جدول combined_signals
            cursor.execute("""
                SELECT name FROM sqlite_master 
                WHERE type='table' AND name='combined_signals'
            """)
            
            if not cursor.fetchone():
                # ایجاد جدول جدید
                cursor.execute("""
                    CREATE TABLE combined_signals (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        coin_id INTEGER NOT NULL,
                        symbol TEXT NOT NULL,
                        final_score REAL NOT NULL,
                        final_confidence REAL NOT NULL,
                        signal_type TEXT NOT NULL,
                        components_count INTEGER NOT NULL,
                        analysis_summary_json TEXT NOT NULL,
                        components_scores_json TEXT NOT NULL,
                        indicators_count INTEGER DEFAULT 0,
                        data_source TEXT DEFAULT 'crypto_klines',
                        status TEXT DEFAULT 'ACTIVE',
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        FOREIGN KEY (coin_id) REFERENCES crypto_coins (id)
                    )
                """)
                
                # ایجاد ایندکس
                cursor.execute("""
                    CREATE INDEX idx_combined_signals_coin 
                    ON combined_signals(coin_id, created_at)
                """)
                cursor.execute("""
                    CREATE INDEX idx_combined_signals_status 
                    ON combined_signals(status, signal_type)
                """)
                
                logger.info("✅ جدول combined_signals ایجاد شد")
            
            # ذخیره سیگنال
            cursor.execute("""
                INSERT INTO combined_signals (
                    coin_id, symbol, final_score, final_confidence,
                    signal_type, components_count, analysis_summary_json,
                    components_scores_json, indicators_count, data_source, status
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                signal_data['coin_id'],
                signal_data['symbol'],
                signal_data['final_score'],
                signal_data['confidence'],
                signal_data['signal'],
                signal_data['components_count'],
                json.dumps(signal_data['analysis_summary']),
                json.dumps(signal_data.get('component_scores', {})),
                signal_data['analysis_summary'].get('indicators_count', 0),
                signal_data['analysis_summary'].get('data_source', 'crypto_klines'),
                'ACTIVE'
            ))
            
            # همچنین در trading_decisions هم ذخیره می‌کنیم
            try:
                decision_id = f"COMBINED_{signal_data['symbol']}_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
                
                cursor.execute("""
                    INSERT INTO trading_decisions (
                        decision_id, block_id, symbol, signal_type,
                        decision_type, confidence_score, current_price,
                        position_size_usd, created_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    decision_id,
                    1,  # block_id پیش‌فرض
                    signal_data['symbol'],
                    signal_data['signal'],
                    'COMBINED_SIGNAL',
                    signal_data['confidence'] * 100,  # تبدیل به درصد
                    signal_data['analysis_summary'].get('current_price', 0),
                    1000.0,  # position_size پیش‌فرض
                    datetime.now().isoformat()
                ))
                
                logger.debug(f"💾 تصمیم معاملاتی ذخیره شد: {signal_data['symbol']}")
            except Exception as e:
                logger.warning(f"⚠️ خطا در ذخیره تصمیم معاملاتی: {e}")
            
            conn.commit()
            logger.debug(f"💾 سیگنال ترکیبی ذخیره شد: {signal_data['symbol']}")
            
        except Exception as e:
            conn.rollback()
            logger.error(f"❌ خطا در ذخیره سیگنال ترکیبی: {e}")
        
        finally:
            conn.close()
    
    def process_all_coins(self, limit: int = 10):
        """پردازش چندین ارز"""
        conn = sqlite3.connect(self.db_path)
        
        try:
            # دریافت ارزهای فعال
            cursor = conn.cursor()
            cursor.execute("""
                SELECT id, symbol 
                FROM crypto_coins 
                WHERE is_active = 1
                ORDER BY market_cap DESC
                LIMIT ?
            """, (limit,))
            
            coins = cursor.fetchall()
            
            if not coins:
                logger.warning("هیچ ارز فعالی یافت نشد")
                return
            
            successful = 0
            filtered = 0
            total_coins = len(coins)
            
            results = []
            
            for coin_id, symbol in coins:
                result = self.combine_for_coin(coin_id, symbol)
                results.append(result)
                
                if result.get('success'):
                    successful += 1
                    logger.info(f"   ✅ {symbol}: {result['signal']} ({result['confidence']:.2%})")
                else:
                    filtered += 1
                    logger.info(f"   🚫 {symbol}: {result.get('reason', 'فیلتر شد')}")
            
            signal_rate = (successful / total_coins) * 100 if total_coins > 0 else 0
            
            # تحلیل آماری نتایج
            buy_signals = sum(1 for r in results if r.get('success') and 'BUY' in r.get('signal', ''))
            sell_signals = sum(1 for r in results if r.get('success') and 'SELL' in r.get('signal', ''))
            neutral_signals = sum(1 for r in results if r.get('success') and 'NEUTRAL' in r.get('signal', ''))
            
            logger.info(f"🎯 پردازش کامل شد: ")
            logger.info(f"   • کل ارزها: {total_coins}")
            logger.info(f"   • سیگنال‌های موفق: {successful} ({signal_rate:.1f}%)")
            logger.info(f"   • فیلتر شده: {filtered}")
            logger.info(f"   • سیگنال‌های BUY: {buy_signals}")
            logger.info(f"   • سیگنال‌های SELL: {sell_signals}")
            logger.info(f"   • سیگنال‌های NEUTRAL: {neutral_signals}")
            
            # ارزیابی واقع‌بینانه
            if signal_rate > 50:
                logger.warning(f"⚠️ نرخ سیگنال بالا ({signal_rate:.1f}%). ممکن است واقع‌بینانه نباشد.")
            elif signal_rate < 10:
                logger.warning(f"⚠️ نرخ سیگنال پایین ({signal_rate:.1f}%). ممکن است فیلترها خیلی سخت‌گیرانه باشند.")
            
            # ذخیره خلاصه نتایج
            self._save_summary_report(successful, filtered, total_coins, buy_signals, sell_signals)
            
        except Exception as e:
            logger.error(f"❌ خطا در پردازش ارزها: {e}")
        
        finally:
            conn.close()
    
    def _save_summary_report(self, successful: int, filtered: int, total: int,
                            buy_signals: int, sell_signals: int):
        """ذخیره خلاصه گزارش"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # بررسی وجود جدول statistics_reports
            cursor.execute("""
                SELECT name FROM sqlite_master 
                WHERE type='table' AND name='statistics_reports'
            """)
            
            if cursor.fetchone():
                report_date = datetime.now().strftime('%Y-%m-%d')
                report_id = f"SIGNAL_COMBINER_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
                
                cursor.execute("""
                    INSERT INTO statistics_reports (
                        report_date, report_period, generated_at,
                        total_coins_tracked, active_coins_count,
                        successful_requests, failed_requests,
                        recommendations, created_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    report_date,
                    'hourly',
                    datetime.now().isoformat(),
                    total,
                    successful,
                    successful,
                    filtered,
                    json.dumps({
                        'signal_combiner_version': 'crypto_klines_v2',
                        'buy_signals': buy_signals,
                        'sell_signals': sell_signals,
                        'success_rate': (successful / total) * 100 if total > 0 else 0,
                        'data_source': 'crypto_klines'
                    }),
                    datetime.now().isoformat()
                ))
                
                conn.commit()
                logger.info(f"📊 خلاصه گزارش ذخیره شد: {report_id}")
            
            conn.close()
        except Exception as e:
            logger.warning(f"⚠️ خطا در ذخیره گزارش: {e}")


def main():
    """تابع اصلی اجرا"""
    
    print("=" * 70)
    print("🎯 COMPLETE SIGNAL COMBINER - سیستم ترکیب پیشرفته سیگنال‌ها")
    print("📊 نسخه اصلاح شده: استفاده از crypto_klines به جای technical_indicators")
    print("=" * 70)
    
    try:
        combiner = CompleteSignalCombiner()
        
        import argparse
        
        parser = argparse.ArgumentParser(description='ترکیب پیشرفته سیگنال‌ها')
        parser.add_argument('--coin', type=str, help='نماد ارز برای پردازش تکی')
        parser.add_argument('--all', action='store_true', help='پردازش همه ارزهای فعال')
        parser.add_argument('--limit', type=int, default=5, help='تعداد ارزها برای پردازش')
        
        args = parser.parse_args()
        
        if args.coin:
            conn = sqlite3.connect(combiner.db_path)
            cursor = conn.cursor()
            cursor.execute(
                "SELECT id FROM crypto_coins WHERE symbol = ?", 
                (args.coin.upper(),)
            )
            result = cursor.fetchone()
            conn.close()
            
            if result:
                coin_id = result[0]
                combined = combiner.combine_for_coin(coin_id, args.coin)
                
                if combined.get('success'):
                    print(f"\n✅ سیگنال ترکیبی برای {args.coin}:")
                    print(f"   • سیگنال: {combined['signal']}")
                    print(f"   • اعتماد: {combined['confidence']:.2%}")
                    print(f"   • امتیاز نهایی: {combined['final_score']:.4f}")
                    print(f"   • مؤلفه‌ها: {combined['components_count']}")
                    
                    summary = combined.get('analysis_summary', {})
                    print(f"\n📊 خلاصه تحلیل (از crypto_klines):")
                    print(f"   • الگوها: {summary.get('patterns_count', 0)}")
                    print(f"   • واگرایی‌ها: {summary.get('divergences_count', 0)}")
                    print(f"   • اندیکاتورها: {summary.get('indicators_count', 0)}")
                    print(f"   • قدرت روند: {summary.get('trend_strength', 0):.2%}")
                    print(f"   • جهت روند: {summary.get('trend_direction', 'unknown')}")
                    print(f"   • منبع داده: {summary.get('data_source', 'unknown')}")
                    
                    # نمایش امتیاز مؤلفه‌ها
                    print(f"\n📈 امتیاز مؤلفه‌ها:")
                    scores = combined.get('component_scores', {})
                    for component, score in scores.items():
                        print(f"   • {component}: {score:.4f}")
                else:
                    print(f"\n⚠️ سیگنال ترکیبی کافی برای {args.coin} یافت نشد")
                    print(f"   دلیل: {combined.get('reason', 'نامشخص')}")
            else:
                print(f"\n❌ ارز {args.coin} یافت نشد")
        
        elif args.all:
            print(f"\n🔧 پردازش {args.limit} ارز فعال با crypto_klines...")
            combiner.process_all_coins(args.limit)
        
        else:
            # حالت پیش‌فرض: پردازش 3 ارز برتر
            print("\n🔧 پردازش 3 ارز برتر (پیش‌فرض) با crypto_klines...")
            combiner.process_all_coins(3)
        
        print("\n" + "=" * 70)
        print("✅ پردازش CompleteSignalCombiner با موفقیت انجام شد")
        print("📊 منبع داده: crypto_klines")
        print("=" * 70)
        
    except Exception as e:
        print(f"\n❌ خطا در اجرای CompleteSignalCombiner: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    main()