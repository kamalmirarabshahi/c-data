﻿#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
main_cycle_04_complete.py - پردازشگر کامل تکه ۴
نسخه نهایی با همه ویژگی‌های تحلیل پیشرفته
"""

import os
import sys
import json
import logging
import argparse
from datetime import datetime, timedelta
from typing import List, Dict, Any
import traceback

# افزودن مسیر پروژه به sys.path
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(SCRIPT_DIR)))
sys.path.insert(0, PROJECT_ROOT)

print("=" * 80)
print("🚀 CYCLE 04 COMPLETE - تحلیل پیشرفته کامل")
print("=" * 80)
print("📁 شامل: Pattern Detection + Divergence Analysis + Signal Combination")
print("=" * 80)

# بارگذاری config_manager
try:
    from config_manager import get_database_path, get_project_root
    
    PROJECT_ROOT = get_project_root()
    DB_PATH = get_database_path()
    
    print(f"✅ config_manager بارگذاری شد")
    print(f"📁 مسیر پروژه: {PROJECT_ROOT}")
    
except ImportError as e:
    print(f"❌ خطا در بارگذاری config_manager: {e}")
    DB_PATH = os.path.join(PROJECT_ROOT, "data", "crypto_master.db")
    print(f"⚠️ استفاده از مسیر پیش‌فرض دیتابیس: {DB_PATH}")

# تنظیمات لاگ‌گیری
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(
            os.path.join(PROJECT_ROOT, 'logs', 'cycle_04_complete.log'),
            encoding='utf-8'
        ),
        logging.StreamHandler()
    ]
)

logger = logging.getLogger("Cycle04Complete")

class CompleteCycle04Processor:
    """پردازشگر کامل تکه ۴"""
    
    def __init__(self, strict_mode: bool = True, enable_all: bool = True):
        self.strict_mode = strict_mode
        self.enable_all = enable_all
        self.db_path = DB_PATH
        
        self.pattern_detector = None
        self.signal_combiner = None
        
        self.results_summary = {
            'patterns_detected': 0,
            'divergences_detected': 0,
            'signals_generated': 0,
            'combined_signals': 0,
            'failed_analysis': 0,
            'filtered_signals': 0
        }
        
        self._load_all_modules()
    
    def _load_all_modules(self):
        """بارگذاری همه ماژول‌های مورد نیاز"""
        print("\n📁 بارگذاری ماژول‌های تحلیل پیشرفته...")
        
        # 1. CompletePatternDetector
        try:
            from pattern_detector import CompletePatternDetector
            self.pattern_detector = CompletePatternDetector()
            print("   ✅ CompletePatternDetector بارگذاری شد")
            self.pattern_available = True
        except ImportError as e:
            print(f"   ⚠️ CompletePatternDetector یافت نشد: {e}")
            self.pattern_available = False
            self.pattern_detector = None
        
        # 2. CompleteSignalCombiner
        try:
            from signal_combiner_complete import CompleteSignalCombiner
            self.signal_combiner = CompleteSignalCombiner()
            print("   ✅ CompleteSignalCombiner بارگذاری شد")
            self.combiner_available = True
        except ImportError as e:
            print(f"   ⚠️ CompleteSignalCombiner یافت نشد: {e}")
            self.combiner_available = False
            self.signal_combiner = None
        
        # خلاصه وضعیت
        print(f"\n📊 وضعیت ماژول‌ها:")
        print(f"   • PatternDetector: {'فعال' if self.pattern_available else 'غیرفعال'}")
        print(f"   • SignalCombiner: {'فعال' if self.combiner_available else 'غیرفعال'}")
        
        if not self.pattern_available and not self.combiner_available:
            print("❌ هیچ ماژول تحلیلی بارگذاری نشد!")
            raise ImportError("هیچ ماژول تحلیلی در دسترس نیست")
    
    def get_block_coins(self, block_id: int) -> List[Dict[str, Any]]:
        """دریافت ارزهای یک بلوک"""
        state_path = os.path.join(PROJECT_ROOT, "state", "cycle_state.json")
        
        if not os.path.exists(state_path):
            logger.error(f"❌ فایل state یافت نشد: {state_path}")
            # Fallback: دریافت از دیتابیس
            return self._get_coins_from_db(limit=10)
        
        try:
            with open(state_path, 'r', encoding='utf-8') as f:
                state = json.load(f)
            
            blocks = state.get('blocks', [])
            logger.info(f"📊 تعداد بلوک‌ها در state: {len(blocks)}")
            
            # پیدا کردن بلوک مورد نظر
            target_block = None
            for block in blocks:
                if block.get('block_id') == block_id:
                    target_block = block
                    break
            
            if not target_block:
                logger.error(f"❌ بلوک {block_id} در state یافت نشد")
                return self._get_coins_from_db(limit=5)
            
            block_coins = target_block.get('coins', [])
            logger.info(f"📦 بلوک {block_id}: {len(block_coins)} ارز")
            
            # نمایش نمونه
            sample_coins = min(3, len(block_coins))
            for i in range(sample_coins):
                coin = block_coins[i]
                logger.info(f"  {i+1}. {coin.get('symbol', 'نامشخص')} (ID: {coin.get('id', '?')})")
            
            if len(block_coins) > sample_coins:
                logger.info(f"  ... و {len(block_coins) - sample_coins} ارز دیگر")
            
            return block_coins
            
        except Exception as e:
            logger.error(f"❌ خطا در خواندن state: {e}")
            return self._get_coins_from_db(limit=5)
    
    def _get_coins_from_db(self, limit: int = 10) -> List[Dict]:
        """دریافت ارزها از دیتابیس (fallback)"""
        import sqlite3
        
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute("""
                SELECT id, symbol, current_price, market_cap
                FROM crypto_coins 
                WHERE is_active = 1
                ORDER BY market_cap DESC
                LIMIT ?
            """, (limit,))
            
            rows = cursor.fetchall()
            conn.close()
            
            coins = []
            for row in rows:
                coins.append({
                    'id': row[0],
                    'symbol': row[1],
                    'current_price': row[2],
                    'market_cap': row[3]
                })
            
            logger.info(f"📊 دریافت {len(coins)} ارز از دیتابیس")
            return coins
            
        except Exception as e:
            logger.error(f"❌ خطا در دریافت ارزها از دیتابیس: {e}")
            return []
    
    def process_coin_complete(self, coin_id: int, symbol: str) -> Dict[str, Any]:
        """پردازش کامل یک ارز"""
        logger.info(f"  🪙 پردازش کامل: {symbol} (ID: {coin_id})")
        
        try:
            # مرحله ۱: تشخیص الگوها و واگرایی‌ها (اگر فعال باشد)
            pattern_result = None
            if self.pattern_available and self.pattern_detector:
                logger.info(f"    🔍 تشخیص الگوها و واگرایی‌ها...")
                pattern_result = self.pattern_detector.analyze_coin(coin_id, symbol, limit=80)
                
                if pattern_result.get('success'):
                    patterns = len(pattern_result.get('patterns', []))
                    divergences = len(pattern_result.get('divergences', []))
                    
                    self.results_summary['patterns_detected'] += patterns
                    self.results_summary['divergences_detected'] += divergences
                    
                    logger.info(f"    ✅ {patterns} الگو، {divergences} واگرایی")
                else:
                    logger.info(f"    ⚠️ تشخیص الگو ناموفق: {pattern_result.get('reason', 'نامشخص')}")
            
            # مرحله ۲: ترکیب سیگنال‌ها (اگر فعال باشد)
            combined_result = None
            if self.combiner_available and self.signal_combiner:
                logger.info(f"    🔧 ترکیب سیگنال‌ها...")
                combined_result = self.signal_combiner.combine_for_coin(coin_id, symbol)
                
                if combined_result.get('success'):
                    self.results_summary['combined_signals'] += 1
                    
                    logger.info(f"    ✅ سیگنال ترکیبی: {combined_result['signal']} "
                               f"({combined_result['confidence']:.2%})")
                else:
                    self.results_summary['filtered_signals'] += 1
                    
                    logger.info(f"    🚫 فیلتر شد: {combined_result.get('reason', 'نامشخص')}")
            
            # جمع‌بندی نتایج
            if combined_result and combined_result.get('success'):
                # سیگنال ترکیبی موفق
                return {
                    'success': True,
                    'coin_id': coin_id,
                    'symbol': symbol,
                    'signal': combined_result['signal'],
                    'confidence': combined_result['confidence'],
                    'final_score': combined_result['final_score'],
                    'components_count': combined_result['components_count'],
                    'patterns_detected': len(pattern_result.get('patterns', [])) if pattern_result else 0,
                    'divergences_detected': len(pattern_result.get('divergences', [])) if pattern_result else 0,
                    'analysis_method': 'complete',
                    'timestamp': datetime.now().isoformat()
                }
            elif pattern_result and pattern_result.get('success'):
                # فقط الگوها موفق
                patterns = pattern_result.get('patterns', [])
                if patterns:
                    best_pattern = max(patterns, key=lambda x: x.get('pattern_confidence', 0))
                    
                    return {
                        'success': True,
                        'coin_id': coin_id,
                        'symbol': symbol,
                        'signal': f"PATTERN_{best_pattern['pattern_direction'].upper()}",
                        'confidence': best_pattern.get('pattern_confidence', 0.5),
                        'final_score': best_pattern.get('pattern_confidence', 0.5),
                        'components_count': 1,
                        'patterns_detected': len(patterns),
                        'divergences_detected': len(pattern_result.get('divergences', [])),
                        'analysis_method': 'pattern_only',
                        'timestamp': datetime.now().isoformat()
                    }
                else:
                    self.results_summary['failed_analysis'] += 1
                    return {
                        'success': False,
                        'coin_id': coin_id,
                        'symbol': symbol,
                        'reason': 'هیچ سیگنال معتبری تولید نشد',
                        'analysis_method': 'none'
                    }
            else:
                # هیچکدام موفق نبود
                self.results_summary['failed_analysis'] += 1
                return {
                    'success': False,
                    'coin_id': coin_id,
                    'symbol': symbol,
                    'reason': 'تحلیل ناموفق',
                    'analysis_method': 'failed'
                }
                
        except Exception as e:
            logger.error(f"❌ خطا در پردازش کامل {symbol}: {e}")
            self.results_summary['failed_analysis'] += 1
            
            return {
                'success': False,
                'coin_id': coin_id,
                'symbol': symbol,
                'error': str(e),
                'analysis_method': 'error'
            }
    
    def process_block(self, block_id: int) -> Dict[str, Any]:
        """پردازش کامل یک بلوک"""
        print(f"\n🚀 شروع پردازش تکه ۴ کامل برای بلوک {block_id}")
        print("-" * 50)
        
        # دریافت ارزهای بلوک
        block_coins = self.get_block_coins(block_id)
        
        if not block_coins:
            print(f"❌ هیچ ارزی در بلوک {block_id} یافت نشد")
            return {
                'success': False,
                'block_id': block_id,
                'error': 'بلوک خالی است'
            }
        
        print(f"📊 تعداد ارزها در بلوک {block_id}: {len(block_coins)}")
        print("-" * 50)
        
        # پردازش هر ارز
        results = []
        successful = 0
        
        for coin in block_coins:
            coin_id = coin.get('id')
            symbol = coin.get('symbol', f'COIN_{coin_id}')
            
            if not coin_id:
                continue
            
            result = self.process_coin_complete(coin_id, symbol)
            results.append(result)
            
            if result.get('success'):
                successful += 1
                self.results_summary['signals_generated'] += 1
                
                # نمایش لحظه‌ای
                print(f"  ✅ {symbol}: {result['signal']} ({result['confidence']:.1%}) "
                      f"[{result['analysis_method']}]")
            else:
                print(f"  🚫 {symbol}: {result.get('reason', 'فیلتر شد')}")
        
        # آمار نهایی
        total_coins = len(block_coins)
        signal_rate = (successful / total_coins) * 100 if total_coins > 0 else 0
        
        print("\n" + "=" * 50)
        print("📊 نتایج نهایی:")
        print(f"  🪙 کل ارزها: {total_coins}")
        print(f"  ✅ سیگنال‌ها: {successful} ({signal_rate:.1f}%)")
        print(f"  🔍 الگوها: {self.results_summary['patterns_detected']}")
        print(f"  📈 واگرایی‌ها: {self.results_summary['divergences_detected']}")
        print(f"  🔗 سیگنال‌های ترکیبی: {self.results_summary['combined_signals']}")
        print(f"  🚫 فیلتر شد: {self.results_summary['filtered_signals']}")
        print(f"  ❌ خطا: {self.results_summary['failed_analysis']}")
        
        # ارزیابی واقع‌بینانه
        realistic = self._evaluate_realism(signal_rate)
        
        # جمع‌بندی
        summary = {
            'success': True,
            'block_id': block_id,
            'total_coins': total_coins,
            'signals_generated': successful,
            'signal_rate_percent': round(signal_rate, 1),
            'patterns_detected': self.results_summary['patterns_detected'],
            'divergences_detected': self.results_summary['divergences_detected'],
            'combined_signals': self.results_summary['combined_signals'],
            'filtered_signals': self.results_summary['filtered_signals'],
            'failed_analysis': self.results_summary['failed_analysis'],
            'modules_available': {
                'pattern_detector': self.pattern_available,
                'signal_combiner': self.combiner_available
            },
            'realistic': realistic,
            'timestamp': datetime.now().isoformat(),
            'results': results
        }
        
        # ذخیره گزارش
        self.save_report(summary, block_id)
        
        # به‌روزرسانی وضعیت سیستم
        self.update_system_state(block_id, True)
        
        return summary
    
    def _evaluate_realism(self, signal_rate: float) -> bool:
        """ارزیابی واقع‌بینانه بودن نتایج"""
        # در بازار واقعی، معمولاً 10-30% سیگنال معتبر داریم
        if signal_rate > 40:
            print(f"\n⚠️ هشدار: نرخ سیگنال {signal_rate:.1f}% خیلی بالاست!")
            print("   در بازار واقعی معمولاً کمتر از 30% است.")
            return False
        elif signal_rate < 10:
            print(f"\n⚠️ هشدار: نرخ سیگنال {signal_rate:.1f}% خیلی پایین است!")
            print("   احتمالاً فیلترها خیلی سخت‌گیرانه هستند.")
            return False
        
        return True
    
    def save_report(self, summary: Dict[str, Any], block_id: int):
        """ذخیره گزارش پردازش"""
        try:
            reports_dir = os.path.join(PROJECT_ROOT, "reports", "cycle_04_complete")
            os.makedirs(reports_dir, exist_ok=True)
            
            report_file = os.path.join(
                reports_dir,
                f"block_{block_id:03d}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
            )
            
            with open(report_file, 'w', encoding='utf-8') as f:
                json.dump(summary, f, indent=2, ensure_ascii=False)
            
            print(f"\n📄 گزارش ذخیره شد: {report_file}")
            
        except Exception as e:
            print(f"⚠️ خطا در ذخیره گزارش: {e}")
    
    def update_system_state(self, block_id: int, success: bool):
        """به‌روزرسانی وضعیت سیستم"""
        try:
            state_path = os.path.join(PROJECT_ROOT, "state", "cycle_state.json")
            
            if not os.path.exists(state_path):
                return
            
            with open(state_path, 'r', encoding='utf-8') as f:
                state = json.load(f)
            
            # به‌روزرسانی بلوک
            for block in state.get('blocks', []):
                if block.get('block_id') == block_id:
                    block['cycle_04_processed'] = success
                    block['cycle_04_time'] = datetime.now().isoformat()
                    block['cycle_04_status'] = 'COMPLETED_COMPLETE' if success else 'FAILED'
                    block['cycle_04_version'] = 'complete_v1'
                    break
            
            with open(state_path, 'w', encoding='utf-8') as f:
                json.dump(state, f, indent=2, ensure_ascii=False)
            
            print("💾 وضعیت سیستم به‌روزرسانی شد")
            
        except Exception as e:
            print(f"⚠️ خطا در به‌روزرسانی وضعیت: {e}")
    
    def print_detailed_results(self, results: List[Dict]):
        """چاپ نتایج جزئی"""
        successful = [r for r in results if r.get('success')]
        
        if not successful:
            print("\n📭 هیچ سیگنال موفقی تولید نشد")
            return
        
        print(f"\n🎯 سیگنال‌های تولید شده ({len(successful)}):")
        print("-" * 70)
        
        for i, signal in enumerate(successful[:10]):  # حداکثر 10 مورد
            method = signal.get('analysis_method', 'unknown')
            patterns = signal.get('patterns_detected', 0)
            divergences = signal.get('divergences_detected', 0)
            
            print(f"{i+1:2d}. {signal['symbol']:8} "
                  f"| {signal['signal']:15} "
                  f"| اعتماد: {signal['confidence']:5.1%} "
                  f"| امتیاز: {signal.get('final_score', 0):.3f} "
                  f"| مؤلفه‌ها: {signal.get('components_count', 0)} "
                  f"| روش: {method[:10]} "
                  f"| الگوها: {patterns} "
                  f"| واگرایی: {divergences}")
        
        if len(successful) > 10:
            print(f"   ... و {len(successful) - 10} مورد دیگر")


def main():
    """تابع اصلی"""
    parser = argparse.ArgumentParser(
        description='پردازشگر کامل تکه ۴ - تحلیل پیشرفته'
    )
    parser.add_argument('--block', type=int, default=1, help='شماره بلوک (پیش‌فرض: 1)')
    parser.add_argument('--lenient', action='store_true', help='استفاده از حالت آسان‌گیر')
    parser.add_argument('--no-patterns', action='store_true', help='غیرفعال کردن تشخیص الگوها')
    parser.add_argument('--no-combiner', action='store_true', help='غیرفعال کردن ترکیب سیگنال‌ها')
    parser.add_argument('--test', action='store_true', help='حالت تست (پردازش 2 ارز)')
    
    args = parser.parse_args()
    
    print(f"\n🎯 پیکربندی پردازش:")
    print(f"   • بلوک: {args.block}")
    print(f"   • حالت: {'آسان‌گیر' if args.lenient else 'سخت‌گیرانه'}")
    print(f"   • تشخیص الگو: {'غیرفعال' if args.no_patterns else 'فعال'}")
    print(f"   • ترکیب سیگنال: {'غیرفعال' if args.no_combiner else 'فعال'}")
    print(f"   • حالت: {'تست' if args.test else 'عادی'}")
    print("-" * 50)
    
    try:
        # ایجاد پردازشگر
        processor = CompleteCycle04Processor(strict_mode=not args.lenient)
        
        # غیرفعال کردن ماژول‌ها در صورت نیاز
        if args.no_patterns:
            processor.pattern_available = False
            processor.pattern_detector = None
            print("⚠️ تشخیص الگوها غیرفعال شد")
        
        if args.no_combiner:
            processor.combiner_available = False
            processor.signal_combiner = None
            print("⚠️ ترکیب سیگنال‌ها غیرفعال شد")
        
        # پردازش بلوک
        start_time = datetime.now()
        result = processor.process_block(args.block)
        
        if args.test:
            # در حالت تست، پردازش محدود
            print("\n🔧 حالت تست فعال - محدود کردن پردازش")
            # فقط 2 ارز اول پردازش شدند
        
        if result.get('success'):
            end_time = datetime.now()
            duration = (end_time - start_time).total_seconds()
            
            print(f"\n📊 آمار نهایی بلوک {args.block}:")
            print(f"   • زمان پردازش: {duration:.1f} ثانیه")
            print(f"   • نرخ سیگنال: {result['signal_rate_percent']:.1f}%")
            print(f"   • الگوهای تشخیص داده شده: {result['patterns_detected']}")
            print(f"   • واگرایی‌های تشخیص داده شده: {result['divergences_detected']}")
            
            # نمایش نتایج جزئی
            processor.print_detailed_results(result.get('results', []))
            
            # ارزیابی
            if result.get('realistic'):
                print(f"\n✅ نتایج واقع‌بینانه است")
            else:
                print(f"\n⚠️ هشدار: نتایج ممکن است غیرواقع‌بینانه باشد")
            
            print(f"\n🎉 پردازش کامل با موفقیت انجام شد!")
            
        else:
            print(f"\n❌ پردازش بلوک {args.block} ناموفق بود")
            print(f"   خطا: {result.get('error')}")
        
    except Exception as e:
        print(f"\n❌ خطای غیرمنتظره: {e}")
        traceback.print_exc()


if __name__ == "__main__":
    main()