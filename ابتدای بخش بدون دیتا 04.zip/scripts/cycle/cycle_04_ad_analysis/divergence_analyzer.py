"""
ماژول تحلیل واگرایی‌های RSI و MACD
- واگرایی معمولی (Regular Divergence): سیگنال بازگشتی قوی
- واگرایی مخفی (Hidden Divergence): سیگنال ادامه روند
همه تنظیمات از config_manager خوانده می‌شود
"""

import numpy as np
import logging
from typing import List, Dict, Tuple, Optional
from datetime import datetime

try:
    from config_manager import get
except ImportError:
    # Fallback for relative import
    import sys
    import os
    sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))
    from config_manager import get


class DivergenceAnalyzer:
    """
    کلاس تحلیل واگرایی‌های RSI و MACD
    """
    
    def __init__(self, logger=None):
        """مقداردهی اولیه با تنظیمات از config_manager"""
        self.logger = logger or logging.getLogger(__name__)
        
        # دریافت تنظیمات از config_manager
        self.rsi_period = get('analysis.rsi_period', 14)
        self.macd_fast = get('analysis.macd_fast', 12)
        self.macd_slow = get('analysis.macd_slow', 26)
        self.macd_signal = get('analysis.macd_signal', 9)
        
        # تنظیمات اختصاصی واگرایی
        self.divergence_lookback = get('divergence.lookback_period', 20)
        self.min_swing_length = get('divergence.min_swing_length', 5)
        self.confidence_threshold = get('divergence.confidence_threshold', 0.7)
        self.price_tolerance = get('divergence.price_tolerance', 0.002)  # 0.2%
        
        self.logger.debug(f"تنظیمات DivergenceAnalyzer بارگذاری شد: RSI={self.rsi_period}")
    
    # ==================== تحلیل اصلی ====================
    
    def analyze_divergences(self, coin_id: int, candles: List[Dict], 
                           timeframe: str = '5m') -> Optional[Dict]:
        """
        تحلیل کامل واگرایی‌ها برای یک ارز
        
        Args:
            coin_id: شناسه ارز
            candles: لیست کندل‌ها با اندیکاتورها
            timeframe: تایم‌فریم تحلیل
            
        Returns:
            دیکشنری حاوی تمام واگرایی‌های شناسایی شده
        """
        try:
            if not candles or len(candles) < 30:
                self.logger.warning(f"داده‌های ناکافی برای تحلیل واگرایی: {len(candles)} کندل")
                return None
            
            self.logger.info(f"شروع تحلیل واگرایی برای ارز {coin_id}")
            
            # استخراج داده‌ها
            close_prices = [c.get('close_price', 0) for c in candles]
            rsi_values = [c.get('rsi') for c in candles]
            macd_values = [c.get('macd') for c in candles]
            macd_signal = [c.get('macd_signal') for c in candles]
            
            # محاسبه MACD histogram اگر موجود نیست
            if None in macd_values or None in macd_signal:
                macd_values, macd_signal, macd_hist = self._calculate_macd(close_prices)
            else:
                macd_hist = [macd - sig for macd, sig in zip(macd_values, macd_signal)]
            
            # محاسبه RSI اگر موجود نیست
            if None in rsi_values:
                rsi_values = self._calculate_rsi(close_prices)
            
            # اجرای تحلیل‌های مختلف
            results = {
                'coin_id': coin_id,
                'timeframe': timeframe,
                'analysis_time': datetime.now().isoformat(),
                'candle_count': len(candles),
                'current_price': close_prices[-1] if close_prices else 0,
                'current_rsi': rsi_values[-1] if rsi_values else None,
                'current_macd': {
                    'macd': macd_values[-1] if macd_values else None,
                    'signal': macd_signal[-1] if macd_signal else None,
                    'histogram': macd_hist[-1] if macd_hist else None
                },
                'regular_divergences': self._find_regular_divergences(
                    close_prices, rsi_values, macd_hist
                ),
                'hidden_divergences': self._find_hidden_divergences(
                    close_prices, rsi_values, macd_hist
                ),
                'momentum_divergences': self._find_momentum_divergences(
                    close_prices, rsi_values, macd_values
                ),
                'divergence_summary': self._generate_divergence_summary(
                    close_prices, rsi_values, macd_values, macd_hist
                ),
                'signal_strength': self._calculate_signal_strength(
                    close_prices, rsi_values, macd_hist
                )
            }
            
            # اعتبارسنجی
            if self._validate_results(results):
                self.logger.info(f"تحلیل واگرایی برای {coin_id} تکمیل شد")
                return results
            else:
                self.logger.warning(f"نتایج تحلیل واگرایی برای {coin_id} نامعتبر است")
                return None
                
        except Exception as e:
            self.logger.error(f"خطا در تحلیل واگرایی برای {coin_id}: {e}", exc_info=True)
            return None
    
    # ==================== واگرایی معمولی ====================
    
    def _find_regular_divergences(self, prices: List[float], 
                                 rsi_values: List[float], 
                                 macd_hist: List[float]) -> List[Dict]:
        """
        پیدا کردن واگرایی‌های معمولی (بازگشتی)
        
        Regular Divergence:
        - قیمت: Higher High / Lower Low
        - اندیکاتور: Lower High / Higher Low
        - سیگنال: بازگشت روند
        """
        divergences = []
        
        if len(prices) < self.divergence_lookback:
            return divergences
        
        # پیدا کردن سقف‌ها و کف‌های قیمتی
        price_peaks = self._find_peaks(prices, is_max=True)
        price_troughs = self._find_peaks(prices, is_max=False)
        
        # پیدا کردن سقف‌ها و کف‌های RSI
        rsi_peaks = self._find_peaks(rsi_values, is_max=True) if rsi_values else []
        rsi_troughs = self._find_peaks(rsi_values, is_max=False) if rsi_values else []
        
        # پیدا کردن سقف‌ها و کف‌های MACD Histogram
        macd_peaks = self._find_peaks(macd_hist, is_max=True) if macd_hist else []
        macd_troughs = self._find_peaks(macd_hist, is_max=False) if macd_hist else []
        
        # 1. واگرایی نزولی معمولی (Bearish Regular)
        # قیمت: Higher High، RSI: Lower High
        for i in range(1, len(price_peaks)):
            if i < len(rsi_peaks):
                price_hh = price_peaks[i]['value'] > price_peaks[i-1]['value']
                rsi_lh = rsi_peaks[i]['value'] < rsi_peaks[i-1]['value']
                
                if price_hh and rsi_lh:
                    confidence = self._calculate_divergence_confidence(
                        price_peaks[i], price_peaks[i-1],
                        rsi_peaks[i], rsi_peaks[i-1]
                    )
                    
                    if confidence >= self.confidence_threshold:
                        divergences.append({
                            'type': 'regular_bearish',
                            'indicator': 'RSI',
                            'price_peak1': price_peaks[i-1],
                            'price_peak2': price_peaks[i],
                            'indicator_peak1': rsi_peaks[i-1],
                            'indicator_peak2': rsi_peaks[i],
                            'confidence': confidence,
                            'signal_strength': confidence * 0.8,
                            'description': 'واگرایی نزولی معمولی RSI'
                        })
        
        # 2. واگرایی صعودی معمولی (Bullish Regular)
        # قیمت: Lower Low، RSI: Higher Low
        for i in range(1, len(price_troughs)):
            if i < len(rsi_troughs):
                price_ll = price_troughs[i]['value'] < price_troughs[i-1]['value']
                rsi_hl = rsi_troughs[i]['value'] > rsi_troughs[i-1]['value']
                
                if price_ll and rsi_hl:
                    confidence = self._calculate_divergence_confidence(
                        price_troughs[i], price_troughs[i-1],
                        rsi_troughs[i], rsi_troughs[i-1]
                    )
                    
                    if confidence >= self.confidence_threshold:
                        divergences.append({
                            'type': 'regular_bullish',
                            'indicator': 'RSI',
                            'price_trough1': price_troughs[i-1],
                            'price_trough2': price_troughs[i],
                            'indicator_trough1': rsi_troughs[i-1],
                            'indicator_trough2': rsi_troughs[i],
                            'confidence': confidence,
                            'signal_strength': confidence * 0.8,
                            'description': 'واگرایی صعودی معمولی RSI'
                        })
        
        # 3. واگرایی‌های MACD
        divergences.extend(self._find_macd_divergences(
            prices, macd_hist, macd_peaks, macd_troughs, 'regular'
        ))
        
        return sorted(divergences, key=lambda x: x['confidence'], reverse=True)
    
    # ==================== واگرایی مخفی ====================
    
    def _find_hidden_divergences(self, prices: List[float], 
                                rsi_values: List[float], 
                                macd_hist: List[float]) -> List[Dict]:
        """
        پیدا کردن واگرایی‌های مخفی (ادامه روند)
        
        Hidden Divergence:
        - قیمت: Lower High / Higher Low
        - اندیکاتور: Higher High / Lower Low
        - سیگنال: ادامه روند
        """
        divergences = []
        
        if len(prices) < self.divergence_lookback:
            return divergences
        
        # پیدا کردن سقف‌ها و کف‌ها
        price_peaks = self._find_peaks(prices, is_max=True)
        price_troughs = self._find_peaks(prices, is_max=False)
        rsi_peaks = self._find_peaks(rsi_values, is_max=True) if rsi_values else []
        rsi_troughs = self._find_peaks(rsi_values, is_max=False) if rsi_values else []
        macd_peaks = self._find_peaks(macd_hist, is_max=True) if macd_hist else []
        macd_troughs = self._find_peaks(macd_hist, is_max=False) if macd_hist else []
        
        # 1. واگرایی مخفی نزولی (Bearish Hidden)
        # قیمت: Lower High، RSI: Higher High
        for i in range(1, len(price_peaks)):
            if i < len(rsi_peaks):
                price_lh = price_peaks[i]['value'] < price_peaks[i-1]['value']
                rsi_hh = rsi_peaks[i]['value'] > rsi_peaks[i-1]['value']
                
                if price_lh and rsi_hh:
                    confidence = self._calculate_divergence_confidence(
                        price_peaks[i], price_peaks[i-1],
                        rsi_peaks[i], rsi_peaks[i-1]
                    )
                    
                    if confidence >= self.confidence_threshold:
                        divergences.append({
                            'type': 'hidden_bearish',
                            'indicator': 'RSI',
                            'price_peak1': price_peaks[i-1],
                            'price_peak2': price_peaks[i],
                            'indicator_peak1': rsi_peaks[i-1],
                            'indicator_peak2': rsi_peaks[i],
                            'confidence': confidence,
                            'signal_strength': confidence * 0.6,  # قدرت کمتر از معمولی
                            'description': 'واگرایی مخفی نزولی RSI (ادامه روند نزولی)'
                        })
        
        # 2. واگرایی مخفی صعودی (Bullish Hidden)
        # قیمت: Higher Low، RSI: Lower Low
        for i in range(1, len(price_troughs)):
            if i < len(rsi_troughs):
                price_hl = price_troughs[i]['value'] > price_troughs[i-1]['value']
                rsi_ll = rsi_troughs[i]['value'] < rsi_troughs[i-1]['value']
                
                if price_hl and rsi_ll:
                    confidence = self._calculate_divergence_confidence(
                        price_troughs[i], price_troughs[i-1],
                        rsi_troughs[i], rsi_troughs[i-1]
                    )
                    
                    if confidence >= self.confidence_threshold:
                        divergences.append({
                            'type': 'hidden_bullish',
                            'indicator': 'RSI',
                            'price_trough1': price_troughs[i-1],
                            'price_trough2': price_troughs[i],
                            'indicator_trough1': rsi_troughs[i-1],
                            'indicator_trough2': rsi_troughs[i],
                            'confidence': confidence,
                            'signal_strength': confidence * 0.6,
                            'description': 'واگرایی مخفی صعودی RSI (ادامه روند صعودی)'
                        })
        
        # 3. واگرایی‌های مخفی MACD
        divergences.extend(self._find_macd_divergences(
            prices, macd_hist, macd_peaks, macd_troughs, 'hidden'
        ))
        
        return sorted(divergences, key=lambda x: x['confidence'], reverse=True)
    
    # ==================== توابع کمکی ====================
    
    def _find_peaks(self, data: List[float], is_max: bool = True, 
                   min_distance: int = 3) -> List[Dict]:
        """پیدا کردن قله‌ها یا دره‌ها در داده‌ها"""
        if not data or len(data) < min_distance * 2:
            return []
        
        peaks = []
        n = len(data)
        
        for i in range(min_distance, n - min_distance):
            window = data[i-min_distance:i+min_distance+1]
            
            if is_max:
                if data[i] == max(window):
                    peaks.append({
                        'index': i,
                        'value': data[i],
                        'position': i / n
                    })
            else:
                if data[i] == min(window):
                    peaks.append({
                        'index': i,
                        'value': data[i],
                        'position': i / n
                    })
        
        return peaks
    
    def _calculate_divergence_confidence(self, price_point1: Dict, price_point2: Dict,
                                        indicator_point1: Dict, indicator_point2: Dict) -> float:
        """محاسبه اعتماد واگرایی"""
        confidence = 0.5
        
        time_diff = abs(price_point2['index'] - price_point1['index'])
        if 5 <= time_diff <= 30:
            confidence += 0.2
        
        price_change = abs(price_point2['value'] - price_point1['value']) / price_point1['value']
        indicator_change = abs(indicator_point2['value'] - indicator_point1['value'])
        
        if price_change > 0.02 and indicator_change > 1.0:
            confidence += 0.2
        
        if price_point2['position'] > 0.7:
            confidence += 0.1
        
        return min(confidence, 1.0)
    
    def _find_macd_divergences(self, prices: List[float], 
                              macd_hist: List[float], 
                              macd_peaks: List[Dict], 
                              macd_troughs: List[Dict], 
                              divergence_type: str) -> List[Dict]:
        """پیدا کردن واگرایی‌های MACD"""
        divergences = []
        
        if not macd_hist or len(macd_hist) < 10:
            return divergences
        
        price_peaks = self._find_peaks(prices, is_max=True)
        price_troughs = self._find_peaks(prices, is_max=False)
        
        if divergence_type == 'regular':
            for i in range(1, min(len(price_peaks), len(macd_peaks))):
                if price_peaks[i]['value'] > price_peaks[i-1]['value'] and \
                   macd_peaks[i]['value'] < macd_peaks[i-1]['value']:
                    
                    divergences.append({
                        'type': 'regular_bearish',
                        'indicator': 'MACD',
                        'price_peak1': price_peaks[i-1],
                        'price_peak2': price_peaks[i],
                        'indicator_peak1': macd_peaks[i-1],
                        'indicator_peak2': macd_peaks[i],
                        'confidence': 0.7,
                        'signal_strength': 0.7,
                        'description': 'واگرایی نزولی معمولی MACD'
                    })
        
        elif divergence_type == 'hidden':
            for i in range(1, min(len(price_peaks), len(macd_peaks))):
                if price_peaks[i]['value'] < price_peaks[i-1]['value'] and \
                   macd_peaks[i]['value'] > macd_peaks[i-1]['value']:
                    
                    divergences.append({
                        'type': 'hidden_bearish',
                        'indicator': 'MACD',
                        'price_peak1': price_peaks[i-1],
                        'price_peak2': price_peaks[i],
                        'indicator_peak1': macd_peaks[i-1],
                        'indicator_peak2': macd_peaks[i],
                        'confidence': 0.6,
                        'signal_strength': 0.6,
                        'description': 'واگرایی مخفی نزولی MACD'
                    })
        
        return divergences
    
    def _calculate_rsi(self, prices: List[float]) -> List[float]:
        """محاسبه RSI"""
        if len(prices) < self.rsi_period + 1:
            return [50.0] * len(prices)
        
        deltas = np.diff(prices)
        seed = deltas[:self.rsi_period]
        
        up = seed[seed >= 0].sum() / self.rsi_period
        down = -seed[seed < 0].sum() / self.rsi_period
        
        if down == 0:
            rs = float('inf')
        else:
            rs = up / down
        
        rsi = np.zeros_like(prices)
        rsi[:self.rsi_period] = 100.0 - 100.0 / (1.0 + rs)
        
        for i in range(self.rsi_period, len(prices)):
            delta = deltas[i-1]
            
            if delta > 0:
                upval = delta
                downval = 0.0
            else:
                upval = 0.0
                downval = -delta
            
            up = (up * (self.rsi_period - 1) + upval) / self.rsi_period
            down = (down * (self.rsi_period - 1) + downval) / self.rsi_period
            
            if down == 0:
                rs = float('inf')
            else:
                rs = up / down
            
            rsi[i] = 100.0 - 100.0 / (1.0 + rs)
        
        return rsi.tolist()
    
    def _calculate_macd(self, prices: List[float]) -> Tuple[List[float], List[float], List[float]]:
        """محاسبه MACD"""
        if len(prices) < self.macd_slow:
            return [], [], []
        
        prices_np = np.array(prices)
        
        def calculate_ema(data, period):
            if len(data) < period:
                return np.array([])
            alpha = 2 / (period + 1)
            ema = np.zeros_like(data)
            ema[period-1] = np.mean(data[:period])
            for i in range(period, len(data)):
                ema[i] = alpha * data[i] + (1 - alpha) * ema[i-1]
            return ema
        
        ema_fast = calculate_ema(prices_np, self.macd_fast)
        ema_slow = calculate_ema(prices_np, self.macd_slow)
        
        if len(ema_fast) == 0 or len(ema_slow) == 0:
            return [], [], []
        
        macd_line = ema_fast - ema_slow
        signal_line = calculate_ema(macd_line, self.macd_signal)
        histogram = macd_line - signal_line
        
        return macd_line.tolist(), signal_line.tolist(), histogram.tolist()
    
    def _find_momentum_divergences(self, prices: List[float], 
                                  rsi_values: List[float], 
                                  macd_values: List[float]) -> List[Dict]:
        """تحلیل واگرایی‌های مومنتوم"""
        divergences = []
        
        if len(prices) < 10:
            return divergences
        
        def calculate_momentum(data):
            if len(data) < 2:
                return []
            momentum = [0.0]
            for i in range(1, len(data)):
                change = ((data[i] - data[i-1]) / data[i-1]) * 100 if data[i-1] != 0 else 0
                momentum.append(change)
            return momentum
        
        price_momentum = calculate_momentum(prices)
        
        if rsi_values:
            rsi_momentum = []
            for i in range(1, len(rsi_values)):
                change = rsi_values[i] - rsi_values[i-1]
                rsi_momentum.append(change)
            rsi_momentum.insert(0, 0.0)
            
            for i in range(1, len(price_momentum)):
                if i < len(rsi_momentum):
                    if (price_momentum[i] > 0 and rsi_momentum[i] < 0) or \
                       (price_momentum[i] < 0 and rsi_momentum[i] > 0):
                        
                        strength = abs(price_momentum[i] - rsi_momentum[i])
                        
                        divergences.append({
                            'type': 'momentum_divergence',
                            'indicator': 'RSI_Momentum',
                            'price_momentum': price_momentum[i],
                            'indicator_momentum': rsi_momentum[i],
                            'strength': strength,
                            'index': i,
                            'description': 'واگرایی مومنتوم قیمت و RSI'
                        })
        
        return divergences
    
    def _generate_divergence_summary(self, prices: List[float], 
                                    rsi_values: List[float], 
                                    macd_values: List[float], 
                                    macd_hist: List[float]) -> Dict:
        """تولید خلاصه تحلیل واگرایی"""
        return {
            'total_signals': 0,
            'strong_signals': 0,
            'bullish_signals': 0,
            'bearish_signals': 0,
            'primary_signal': None,
            'signal_confidence': 0.0
        }
    
    def _calculate_signal_strength(self, prices: List[float], 
                                  rsi_values: List[float], 
                                  macd_hist: List[float]) -> Dict:
        """محاسبه قدرت سیگنال کلی"""
        strength = {
            'overall': 0.0,
            'rsi_divergence': 0.0,
            'macd_divergence': 0.0,
            'momentum_alignment': 0.0,
            'volume_confirmation': 0.0,
            'timeframe_confirmation': 0.0
        }
        
        if rsi_values and len(rsi_values) > 10:
            current_rsi = rsi_values[-1]
            if current_rsi < 30:
                strength['rsi_divergence'] = 0.8
            elif current_rsi > 70:
                strength['rsi_divergence'] = 0.8
        
        weights = [0.3, 0.3, 0.2, 0.1, 0.1]
        values = [
            strength['rsi_divergence'],
            strength['macd_divergence'],
            strength['momentum_alignment'],
            strength['volume_confirmation'],
            strength['timeframe_confirmation']
        ]
        
        strength['overall'] = sum(w * v for w, v in zip(weights, values))
        
        return strength
    
    def _validate_results(self, results: Dict) -> bool:
        """اعتبارسنجی نتایج تحلیل"""
        if not results:
            return False
        
        required_fields = ['coin_id', 'current_price', 'regular_divergences', 'hidden_divergences']
        
        for field in required_fields:
            if field not in results:
                return False
        
        return True
    
    # ==================== توابع کاربردی ====================
    
    def format_results_for_display(self, results: Dict) -> str:
        """قالب‌بندی نتایج برای نمایش"""
        if not results:
            return "هیچ نتیجه‌ای برای نمایش وجود ندارد"
        
        output = []
        output.append(f"📈 تحلیل واگرایی‌ها - ارز #{results['coin_id']}")
        output.append(f"⏰ تایم‌فریم: {results.get('timeframe', '5m')}")
        output.append(f"💰 قیمت فعلی: {results['current_price']:.8f}")
        
        if results.get('current_rsi'):
            output.append(f"📊 RSI فعلی: {results['current_rsi']:.2f}")
        
        output.append("")
        
        regular = results.get('regular_divergences', [])
        if regular:
            output.append("🎯 **واگرایی‌های معمولی (بازگشتی):**")
            for i, div in enumerate(regular[:3], 1):
                signal_type = "📈 صعودی" if 'bullish' in div['type'] else "📉 نزولی"
                output.append(f"  {i}. {signal_type} - {div['indicator']}")
                output.append(f"     اعتماد: {div['confidence']:.2%} | قدرت: {div['signal_strength']:.2f}")
        
        hidden = results.get('hidden_divergences', [])
        if hidden:
            output.append("")
            output.append("🎭 **واگرایی‌های مخفی (ادامه روند):**")
            for i, div in enumerate(hidden[:3], 1):
                signal_type = "📈 صعودی" if 'bullish' in div['type'] else "📉 نزولی"
                output.append(f"  {i}. {signal_type} - {div['indicator']}")
                output.append(f"     اعتماد: {div['confidence']:.2%} | قدرت: {div['signal_strength']:.2f}")
        
        strength = results.get('signal_strength', {}).get('overall', 0)
        if strength > 0.7:
            signal_emoji = "✅ قوی"
        elif strength > 0.4:
            signal_emoji = "⚠️ متوسط"
        else:
            signal_emoji = "ℹ️ ضعیف"
        
        output.append("")
        output.append(f"⚡ **قدرت سیگنال کلی:** {signal_emoji} ({strength:.2f}/1.0)")
        
        return "\n".join(output)
    
    def get_strongest_signal(self, results: Dict) -> Optional[Dict]:
        """دریافت قوی‌ترین سیگنال از نتایج"""
        if not results:
            return None
        
        all_signals = []
        all_signals.extend(results.get('regular_divergences', []))
        all_signals.extend(results.get('hidden_divergences', []))
        
        if not all_signals:
            return None
        
        strongest = max(all_signals, key=lambda x: x.get('signal_strength', 0))
        
        return {
            'type': strongest['type'],
            'indicator': strongest['indicator'],
            'confidence': strongest.get('confidence', 0),
            'strength': strongest.get('signal_strength', 0),
            'description': strongest.get('description', ''),
            'entry_price': results['current_price'],
            'signal_time': datetime.now().isoformat()
        }


# ==================== تست ماژول ====================

def run_test():
    """تابع تست مستقل"""
    import sys
    import os
    
    # تنظیم لاگ‌گیری
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    logger = logging.getLogger(__name__)
    
    print("🧪 تست ماژول DivergenceAnalyzer...")
    
    # ایجاد نمونه‌ای از کلاس
    analyzer = DivergenceAnalyzer(logger=logger)
    
    # داده‌های نمونه برای تست واگرایی
    n = 100
    time = np.linspace(0, 10, n)
    
    # قیمت: صعودی با نوسان
    prices = 100 + 0.5 * time + 2 * np.sin(time * 2)
    
    # RSI: ایجاد واگرایی نزولی (قیمت بالا، RSI پایین)
    rsi = 50 + 10 * np.sin(time * 1.5)
    rsi[-20:] = rsi[-20:] - 5  # کاهش RSI در انتها
    
    # کندل‌های نمونه
    sample_candles = []
    for i in range(n):
        candle = {
            'open_price': prices[i] - 0.1,
            'high_price': prices[i] + 0.2,
            'low_price': prices[i] - 0.3,
            'close_price': prices[i],
            'volume': 1000 + i * 10,
            'rsi': rsi[i]
        }
        sample_candles.append(candle)
    
    # اجرای تحلیل
    results = analyzer.analyze_divergences(
        coin_id=1125,  # BTCUSDT
        candles=sample_candles,
        timeframe='5m'
    )
    
    if results:
        print("✅ تست موفقیت‌آمیز بود!")
        print(f"تعداد واگرایی‌های معمولی: {len(results['regular_divergences'])}")
        print(f"تعداد واگرایی‌های مخفی: {len(results['hidden_divergences'])}")
        
        # نمایش فرمت شده
        print("\n📋 خلاصه نتایج:")
        print(analyzer.format_results_for_display(results))
        
        # قوی‌ترین سیگنال
        strongest = analyzer.get_strongest_signal(results)
        if strongest:
            print(f"\n🎯 **قوی‌ترین سیگنال:**")
            print(f"   نوع: {strongest['type']}")
            print(f"   اندیکاتور: {strongest['indicator']}")
            print(f"   اعتماد: {strongest['confidence']:.2%}")
            print(f"   قدرت: {strongest['strength']:.2f}")
    else:
        print("❌ تست ناموفق بود!")
    
    print("\n✅ ماژول DivergenceAnalyzer آماده استفاده است!")


if __name__ == "__main__":
    run_test()