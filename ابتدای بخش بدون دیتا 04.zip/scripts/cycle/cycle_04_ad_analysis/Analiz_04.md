# تحلیل تخصصی سیستم معاملاتی - تکه ۴ (Cycle 04)

## 🎯 **معرفی کلی پروژه**

این پروژه یک **سیستم تحلیل تکنیکال پیشرفته** برای بازار ارزهای دیجیتال است که در تکه ۴ از یک چرخه معاملاتی بزرگتر قرار دارد. سیستم به زبان Python نوشته شده و از معماری ماژولار با قابلیت توسعه‌پذیری بالا استفاده می‌کند.

---

## 📊 **طرح گرافیکی گردش کار (Mermaid)**

```mermaid
flowchart TD
    A[main_cycle_04.py<br>کنترل کننده اصلی] --> B[pattern_detector.py<br>تشخیص الگوهای قیمتی]
    A --> C[divergence_analyzer.py<br>تحلیل واگرایی‌ها]
    A --> D[signal_combiner_complete.py<br>ترکیب سیگنال‌ها]
    A --> E[risk_calculator.py<br>محاسبه ریسک]
    A --> F[technical_levels.py<br>شناسایی سطوح تکنیکال]
    
    B --> G[utils.py<br>ابزارهای کمکی]
    C --> G
    D --> G
    E --> G
    F --> G
    
    G --> H[config.py / config_manager<br>مدیریت تنظیمات]
    G --> I[result_saver.py<br>ذخیره نتایج]
    
    I --> J[(دیتابیس<br>sqlite3)]
    
    H --> K[data/crypto_klines<br>داده‌های بازار]
    H --> L[data/crypto_coins<br>اطلاعات ارزها]
    
    K --> B
    L --> B
    
    style A fill:#ff6b6b
    style J fill:#4ecdc4
    style B fill:#1dd1a1
    style C fill:#54a0ff
    style D fill:#5f27cd
    style E fill:#ff9f43
```

---

## 🏗️ **تحلیل ساختاری فایل‌ها**

### **1. main_cycle_04.py** - کنترل کننده اصلی
```
📁 کلاس‌ها:
└── CompleteCycle04Processor
    ├── __init__() - راه‌اندازی و بارگذاری ماژول‌ها
    ├── process_block() - پردازش یک بلوک از ارزها
    ├── process_coin_complete() - پردازش کامل یک ارز
    └── print_detailed_results() - نمایش نتایج

🔧 وظیفه: هماهنگ‌کننده اصلی تمام تحلیل‌ها - ورودی را دریافت و خروجی را مدیریت می‌کند
```

### **2. pattern_detector.py** - سیستم تشخیص الگوهای قیمتی
```
📁 کلاس‌ها:
└── CompletePatternDetector
    ├── detect_head_shoulders() - الگوی سر و شانه
    ├── detect_double_top_bottom() - الگوی دو قله/دو دره
    ├── detect_triangles() - الگوهای مثلثی
    ├── detect_candlestick_patterns() - الگوهای کندل‌استیک
    └── detect_divergences() - تشخیص واگرایی‌ها

🔧 وظیفه: شناسایی الگوهای قیمتی کلاسیک و ارائه سیگنال‌های معاملاتی
```

### **3. divergence_analyzer.py** - تحلیل‌گر واگرایی‌ها
```
📁 کلاس‌ها:
└── DivergenceAnalyzer
    ├── _find_regular_divergences() - واگرایی‌های معمولی
    ├── _find_hidden_divergences() - واگرایی‌های مخفی
    ├── _find_momentum_divergences() - واگرایی مومنتوم
    └── get_strongest_signal() - استخراج قوی‌ترین سیگنال

🔧 وظیفه: تشخیص واگرایی بین قیمت و اندیکاتورها (RSI, MACD)
```

### **4. signal_combiner_complete.py** - ترکیب‌کننده سیگنال‌ها
```
📁 کلاس‌ها:
├── AdvancedScoringSystem - سیستم امتیازدهی
│   ├── _score_patterns() - امتیاز الگوها
│   ├── _score_divergences() - امتیاز واگرایی‌ها
│   └── calculate_composite_score() - امتیاز ترکیبی
│
└── CompleteSignalCombiner - ترکیب‌کننده اصلی
    ├── combine_for_coin() - ترکیب سیگنال‌های یک ارز
    └── _save_combined_signal() - ذخیره در دیتابیس

🔧 وظیفه: تلفیق سیگنال‌های مختلف و تولید سیگنال نهایی
```

### **5. risk_calculator.py** - مدیریت ریسک و پوزیشن
```
📁 کلاس‌ها:
└── RiskCalculator
    ├── calculate_for_signal() - محاسبه پارامترهای ریسک
    ├── _calculate_stop_loss() - محاسبه حد ضرر
    ├── _calculate_position_size() - محاسبه حجم معامله
    └── format_risk_report() - تولید گزارش ریسک

🔧 وظیفه: مدیریت ریسک، محاسبه حد سود/ضرر، تعیین حجم پوزیشن
```

### **6. technical_levels.py** - شناسایی سطوح تکنیکال
```
📁 کلاس‌ها:
└── TechnicalLevels
    ├── _identify_supports() - شناسایی سطوح حمایت
    ├── _identify_resistances() - شناسایی سطوح مقاومت
    ├── _calculate_pivot_points() - محاسبه پیوت پوینت‌ها
    └── _detect_price_channels() - شناسایی کانال‌های قیمتی

🔧 وظیفه: تشخیص سطوح کلیدی تکنیکال برای تصمیم‌گیری معاملاتی
```

### **7. utils.py** - ابزارهای کمکی و مشترک
```
📁 کلاس‌ها:
├── Cycle04Logger - سیستم لاگ‌گیری اختصاصی
├── DatabaseManager - مدیریت اتصال به دیتابیس
├── DataProcessor - پردازش و تبدیل داده‌ها
└── PerformanceTimer - اندازه‌گیری زمان اجرا

🔧 وظیفه: ارائه سرویس‌های مشترک به تمام ماژول‌ها
```

### **8. result_saver.py** - سیستم ذخیره نتایج
```
📁 کلاس‌ها:
└── ResultSaver
    ├── save_pattern() - ذخیره تحلیل الگو
    ├── save_divergence() - ذخیره تحلیل واگرایی
    └── save_collection_log() - ذخیره لاگ جمع‌آوری

🔧 وظیفه: ذخیره نتایج تحلیل در دیتابیس
```

### **9. config.py / config_manager** - مدیریت تنظیمات
```
📁 توابع:
├── get() - دریافت تنظیمات
├── get_database_path() - دریافت مسیر دیتابیس
└── get_project_root() - دریافت مسیر ریشه پروژه

🔧 وظیفه: مدیریت متمرکز تنظیمات و پارامترهای سیستم
```

---

## 🔄 **فرآیند کامل تحلیل (Flow)**

### **مرحله 1: دریافت و آماده‌سازی داده**
```
📊 main_cycle_04.get_block_coins()
    ↓
🔗 utils.DatabaseManager.get_candles_for_coin()
    ↓
📈 utils.DataProcessor.candles_to_dataframe()
```

### **مرحله 2: تحلیل تکنیکال موازی**
```
📈 pattern_detector.analyze_coin()  → تشخیص الگوهای قیمتی
    ↓
📊 divergence_analyzer.analyze_divergences()  → تحلیل واگرایی‌ها
    ↓
📐 technical_levels.analyze_levels()  → شناسایی سطوح تکنیکال
```

### **مرحله 3: ترکیب و امتیازدهی**
```
🎯 signal_combiner.combine_for_coin()
    ↓
📊 AdvancedScoringSystem.calculate_composite_score()
    ↓
⚖️ وزن‌دهی: الگوها(35%) + واگرایی(25%) + روند(15%) + حجم(10%) + اندیکاتورها(15%)
```

### **مرحله 4: مدیریت ریسک**
```
⚠️ risk_calculator.calculate_for_signal()
    ↓
💰 محاسبه: حجم پوزیشن + حد سود/ضرر + نسبت ریسک/بازده
    ↓
📊 تولید گزارش مدیریت ریسک
```

### **مرحله 5: ذخیره و گزارش‌گیری**
```
💾 result_saver.save_combined_signal()
    ↓
📁 ذخیره در جداول: trading_signals + combined_signals + trading_decisions
    ↓
📄 تولید گزارش‌های تحلیلی
```

---

## 🎨 **معماری سیستم**

### **لایه‌ها:**
1. **لایه داده (Data Layer)**
   - `utils.DatabaseManager`
   - `utils.DataProcessor`
   - اتصال به `crypto_klines` و `crypto_coins`

2. **لایه تحلیل (Analysis Layer)**
   - Pattern Detection (تشخیص الگو)
   - Divergence Analysis (تحلیل واگرایی)
   - Technical Levels (سطوح تکنیکال)

3. **لایه تصمیم‌گیری (Decision Layer)**
   - Signal Combination (ترکیب سیگنال)
   - Risk Management (مدیریت ریسک)
   - Position Sizing (تعیین حجم)

4. **لایه ذخیره و گزارش (Storage & Reporting Layer)**
   - `ResultSaver`
   - Report Generation
   - Database Persistence

### **ویژگی‌های کلیدی معماری:**
- ✅ **ماژولار و مستقل**: هر ماژول به صورت مستقل قابل توسعه است
- ✅ **قابل پیکربندی**: تمام تنظیمات از `config_manager` مدیریت می‌شود
- ✅ **مقاوم در برابر خطا**: سیستم‌های fallback و بازیابی خطا
- ✅ **لاگ‌گیری جامع**: سیستم لاگ‌گیری چندسطحی
- ✅ **کارایی بالا**: استفاده از numpy برای محاسبات سنگین
- ✅ **قابل تست**: توابع تست مستقل برای هر ماژول

---

## 🔍 **نکات فنی مهم**

### **1. منبع داده اصلی**
- استفاده از `crypto_klines` به جای `technical_indicators` (نسخه بهبودیافته)
- جدول شامل اندیکاتورهای پیش‌محاسبه شده: RSI, MACD, Bollinger Bands, Moving Averages

### **2. سیستم امتیازدهی هوشمند**
- وزن‌دهی پویا بر اساس اهمیت هر مؤلفه
- اعمال فیلترهای هوشمند برای جلوگیری از overfitting
- اعتبارسنجی واقع‌بینانه (10-30% نرخ سیگنال واقعی)

### **3. مدیریت ریسک پیشرفته**
- محاسبه حجم پوزیشن بر اساس درصد حساب
- تنظیم حد ضرر/سود بر اساس نوسان (ATR)
- محاسبه نسبت ریسک/بازده و امتیاز ریسک

### **4. قابلیت‌های توسعه**
- پشتیبانی از تحلیل چندزمانه (Multi-timeframe)
- امکان افزودن اندیکاتورهای جدید
- سیستم گزارش‌گیری قابل گسترش

---

## 🚀 **نقش‌های کلیدی در گردش کار**

| نقش | مسئولیت | ماژول‌های مرتبط |
|-----|----------|-----------------|
| **کنترل کننده** | هماهنگی و زمان‌بندی | `main_cycle_04` |
| **شناساگر الگو** | تشخیص الگوهای قیمتی | `pattern_detector` |
| **تحلیل‌گر واگرایی** | تشخیص واگرایی‌ها | `divergence_analyzer` |
| **ترکیب‌کننده** | تلفیق سیگنال‌ها | `signal_combiner` |
| **مدیر ریسک** | محاسبه پارامترهای ریسک | `risk_calculator` |
| **شناساگر سطوح** | یافتن سطوح تکنیکال | `technical_levels` |
| **ذخیره‌کننده** | ثبت نتایج در دیتابیس | `result_saver` |
| **ابزارساز** | ارائه سرویس‌های مشترک | `utils` |
| **تنظیم‌کننده** | مدیریت پارامترها | `config_manager` |

---

## 📈 **نتیجه‌گیری**

این سیستم یک **چارچوب تحلیل تکنیکال کاملاً یکپارچه** ارائه می‌دهد که:

1. **از داده‌های خام تا سیگنال معاملاتی** را پردازش می‌کند
2. **چندین استراتژی تحلیل** را به صورت موازی اجرا می‌کند
3. **سیگنال‌ها را به صورت هوشمند** ترکیب و اولویت‌بندی می‌کند
4. **مدیریت ریسک جامع** را اعمال می‌کند
5. **نتایج را به صورت ساختاریافته** ذخیره و گزارش می‌کند

**نقاط قوت:**
- طراحی ماژولار و قابل توسعه
- سیستم امتیازدهی پویا و هوشمند
- مدیریت ریسک پیشرفته
- لاگ‌گیری و گزارش‌گیری جامع

**کاربردهای عملی:**
- سیستم معاملاتی خودکار (Automated Trading)
- دستیار تحلیل تکنیکال (Technical Analysis Assistant)
- سیستم هشدار معاملاتی (Trading Alert System)
- بک‌تست استراتژی‌ها (Strategy Backtesting)

## 🎯 **فایل اصلی اجرایی: `main_cycle_04.py`**

### **دلایل اصلی بودن:**

1. **کنترل کننده اصلی کل چرخه**:
   ```python
   if __name__ == "__main__":
       main()  # نقطه شروع اجرا
   ```

2. **هماهنگ‌کننده همه ماژول‌ها**:
   ```python
   # بارگذاری و هماهنگی همه ماژول‌ها
   self.pattern_detector = CompletePatternDetector()
   self.signal_combiner = CompleteSignalCombiner()
   ```

3. **ورودی اصلی سیستم**:
   ```python
   # دریافت پارامترهای اجرا از کاربر
   parser.add_argument('--block', type=int, default=1, help='شماره بلوک')
   parser.add_argument('--test', action='store_true', help='حالت تست')
   ```

4. **گردش کار کامل**:
   ```python
   # فرآیند کامل تحلیل
   result = processor.process_block(args.block)
   ```

---

## 🚀 **روش‌های اجرای اصلی:**

### **1. اجرای مستقیم (پیش‌فرض)**:
```bash
python main_cycle_04.py
```
- بلوک 1 را پردازش می‌کند
- حالت سخت‌گیرانه
- پردازش کامل همه ارزهای بلوک

### **2. اجرا با پارامترهای سفارشی**:
```bash
python main_cycle_04.py --block 2 --lenient --test
```
- پردازش بلوک 2
- حالت آسان‌گیر (lenient)
- حالت تست (محدود کردن پردازش)

### **3. گزینه‌های کامل خط فرمان**:
```bash
python main_cycle_04.py \
  --block 3 \
  --lenient \
  --no-patterns \
  --no-combiner \
  --test
```
- `--block`: شماره بلوک (1, 2, 3, ...)
- `--lenient`: حالت آسان‌گیر (کمتر سخت‌گیرانه)
- `--no-patterns`: غیرفعال کردن تشخیص الگوها
- `--no-combiner`: غیرفعال کردن ترکیب سیگنال‌ها
- `--test`: حالت تست (پردازش محدود)

---

## 📁 **فایل‌های قابل اجرای دیگر (ابزاری):**

### **1. `risk_calculator.py`** (تست مستقل ریسک):
```bash
python risk_calculator.py
```
- تست سیستم مدیریت ریسک
- محاسبه پارامترها برای سیگنال‌های نمونه

### **2. `pattern_detector.py`** (تست تشخیص الگو):
```bash
python pattern_detector.py --coin BTC --limit 10
```

### **3. `signal_combiner_complete.py`** (تست ترکیب سیگنال):
```bash
python signal_combiner_complete.py --coin ETH --all
```

### **4. `utils.py`** (تست ابزارها):
```bash
python utils.py
```

### **5. `result_saver.py`** (تست ذخیره‌سازی):
```bash
python result_saver.py
```

---

## 🔄 **گردش کار اجرای اصلی:**

```mermaid
flowchart TD
    Start[شروع: main_cycle_04.py] --> Parse[تجزیه پارامترهای خط فرمان]
    Parse --> LoadConfig[بارگذاری تنظیمات از config_manager]
    LoadConfig --> InitModules[راه‌اندازی ماژول‌ها]
    
    InitModules --> PatternDetector[pattern_detector<br>تشخیص الگو]
    InitModules --> SignalCombiner[signal_combiner<br>ترکیب سیگنال]
    InitModules --> LoadCoins[بارگذاری ارزهای بلوک]
    
    LoadCoins --> ProcessEach[پردازش هر ارز]
    
    ProcessEach --> PatternAnalysis[تحلیل الگوها]
    ProcessEach --> DivergenceAnalysis[تحلیل واگرایی]
    ProcessEach --> TechnicalLevels[تحلیل سطوح]
    
    PatternAnalysis --> CombineSignals[ترکیب سیگنال‌ها]
    DivergenceAnalysis --> CombineSignals
    TechnicalLevels --> CombineSignals
    
    CombineSignals --> RiskCalculation[محاسبه ریسک<br>risk_calculator]
    RiskCalculation --> SaveResults[ذخیره نتایج<br>result_saver]
    
    SaveResults --> GenerateReport[تولید گزارش]
    GenerateReport --> End[پایان]
```

---

## ⚙️ **پیکربندی اجرا:**

### **فایل state:**
```
📁 state/cycle_state.json
├── blocks: لیست بلوک‌های پردازشی
├── cycle_04_processed: وضعیت پردازش
└── cycle_04_status: وضعیت اجرا
```

### **خروجی‌ها:**
```
📁 logs/cycle_04_complete.log        ← لاگ اجرا
📁 reports/cycle_04_complete/        ← گزارش‌های تحلیلی
📁 data/crypto_master.db             ← دیتابیس نتایج
```

---

## 🎯 **نکات مهم اجرایی:**

### **1. وابستگی‌ها:**
```python
# قبل از اجرا حتماً باید موجود باشند:
- config_manager.py
- دیتابیس crypto_master.db
- پوشه‌های logs/, reports/, state/
```

### **2. ترتیب اجرای صحیح:**
```bash
# 1. بررسی تنظیمات
python config.py

# 2. تست ماژول‌های مستقل
python utils.py
python risk_calculator.py

# 3. اجرای اصلی
python main_cycle_04.py --block 1 --test

# 4. اجرای کامل
python main_cycle_04.py --block 1
```

### **3. خطاهای رایج:**
- **خطای ImportError**: مسیرهای پروژه به درستی تنظیم نشده
- **خطای Database**: دیتابیس موجود نیست یا مسیر اشتباه است
- **خطای State**: فایل state/cycle_state.json وجود ندارد

### **4. عیب‌یابی:**
```bash
# اجرای با لاگ دقیق‌تر
python main_cycle_04.py --block 1 2>&1 | tee debug.log

# تست بدون ماژول‌های خاص
python main_cycle_04.py --block 1 --no-patterns --no-combiner
```

---

## 📊 **خروجی‌های اصلی:**

### **1. کنسول (Terminal Output):**
```
🚀 CYCLE 04 COMPLETE - تحلیل پیشرفته کامل
📊 تعداد ارزها در بلوک 1: 15
✅ BTC: STRONG_BUY (75.3%) [complete]
🚫 ETH: فیلتر شد (مؤلفه‌های ناکافی)
📊 نتایج نهایی: 8 سیگنال (53.3%)
```

### **2. فایل گزارش:**
```
📁 reports/cycle_04_complete/block_001_20240115_143022.json
├── success: true
├── signals_generated: 8
├── signal_rate_percent: 53.3
└── results: [لیست کامل سیگنال‌ها]
```

### **3. دیتابیس:**
```
📊 جداول به‌روز شده:
- trading_signals ← سیگنال‌های خام
- combined_signals ← سیگنال‌های ترکیبی  
- trading_decisions ← تصمیمات معاملاتی
- collection_logs ← لاگ پردازش
```

---

**نتیجه**: `main_cycle_04.py` **فایل اصلی اجرایی** است که کل سیستم تحلیل تکنیکال را هماهنگ می‌کند و از طریق خط فرمان قابل کنترل است.