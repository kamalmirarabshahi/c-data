"""
risk_calculator.py - ماژول محاسبه ریسک و مدیریت پوزیشن
نسخه نهایی - بدون تغییر در دیتابیس
همه تنظیمات از config_manager خوانده می‌شود
"""

import math
import json
import logging
from typing import Dict, List, Tuple, Optional
from datetime import datetime

# ==================== تنظیم مسیرها و import ====================
import sys
import os

# اضافه کردن مسیرهای لازم
current_dir = os.path.dirname(os.path.abspath(__file__))
scripts_dir = os.path.dirname(current_dir)
project_root = os.path.dirname(scripts_dir)

sys.path.insert(0, project_root)
sys.path.insert(0, scripts_dir)

try:
    from config_manager import get
    CONFIG_LOADED = True
except ImportError:
    print("⚠️ config_manager وارد نشد. استفاده از تنظیمات پیش‌فرض")
    CONFIG_LOADED = False
    
    # Mock برای config_manager
    class MockConfig:
        @staticmethod
        def get(key, default=None):
            return default
    get = MockConfig.get


class RiskCalculator:
    """
    کلاس محاسبه ریسک و مدیریت پوزیشن
    بدون نیاز به تغییر در دیتابیس
    """
    
    def __init__(self, logger=None):
        """مقداردهی اولیه با تنظیمات از config_manager"""
        self.logger = logger or logging.getLogger(__name__)
        
        # دریافت تنظیمات از config_manager
        self.default_account_balance = get('risk.default_account_balance', 10000.0)
        self.default_risk_per_trade = get('risk.default_risk_percent', 0.01)  # 1%
        self.min_risk_percent = get('risk.min_risk_percent', 0.005)  # 0.5%
        self.max_risk_percent = get('risk.max_risk_percent', 0.02)   # 2%
        
        # تنظیمات استراتژی
        self.default_rr_ratio = get('risk.default_risk_reward_ratio', 3.0)
        self.min_rr_ratio = get('risk.min_risk_reward_ratio', 2.0)
        self.max_position_size_percent = get('risk.max_position_size_percent', 5.0)  # حداکثر 5% از حساب
        
        # تنظیمات حد ضرر/سود
        self.default_stop_loss_percent = get('risk.default_stop_loss_percent', 0.02)  # 2%
        self.min_stop_loss_percent = get('risk.min_stop_loss_percent', 0.01)  # 1%
        self.max_stop_loss_percent = get('risk.max_stop_loss_percent', 0.05)  # 5%
        
        # تنظیمات وابسته به نوسان
        self.atr_multiplier = get('risk.atr_multiplier', 2.0)
        self.volatility_adjustment_enabled = get('risk.volatility_adjustment', True)
        
        self.logger.debug(f"RiskCalculator راه‌اندازی شد. حساب پیش‌فرض: ${self.default_account_balance:,.2f}")
    
    # ==================== توابع اصلی محاسبه ====================
    
    def calculate_for_signal(self, signal_data: Dict, account_balance: float = None) -> Dict:
        """
        محاسبه کامل پارامترهای ریسک برای یک سیگنال
        
        Args:
            signal_data: داده‌های سیگنال (باید شامل entry_price باشد)
            account_balance: موجودی حساب (اگر None، از تنظیمات استفاده می‌شود)
            
        Returns:
            دیکشنری حاوی تمام پارامترهای ریسک
        """
        try:
            # اعتبارسنجی داده‌های ورودی
            if 'entry_price' not in signal_data or signal_data['entry_price'] <= 0:
                raise ValueError("قیمت ورود نامعتبر است")
            
            entry_price = signal_data['entry_price']
            signal_type = signal_data.get('signal_type', 'buy').lower()
            current_price = signal_data.get('current_price', entry_price)
            confidence = signal_data.get('confidence_score', 50) / 100.0  # تبدیل به 0-1
            
            # تنظیم موجودی حساب
            if account_balance is None or account_balance <= 0:
                account_balance = self.default_account_balance
            
            # 1. محاسبه حد ضرر
            stop_loss = self._calculate_stop_loss(
                entry_price=entry_price,
                signal_type=signal_type,
                current_price=current_price,
                confidence=confidence,
                additional_data=signal_data
            )
            
            # 2. محاسبه ریسک به دلار
            risk_amount_usd = self._calculate_risk_amount(
                account_balance=account_balance,
                entry_price=entry_price,
                stop_loss=stop_loss,
                signal_type=signal_type,
                confidence=confidence
            )
            
            # 3. محاسبه حد سود
            take_profit_1, take_profit_2, take_profit_3 = self._calculate_take_profit_levels(
                entry_price=entry_price,
                stop_loss=stop_loss,
                signal_type=signal_type,
                confidence=confidence
            )
            
            # 4. محاسبه نسبت ریسک به بازده
            risk_reward_ratio = self._calculate_risk_reward_ratio(
                entry_price=entry_price,
                stop_loss=stop_loss,
                take_profit=take_profit_1,
                signal_type=signal_type
            )
            
            # 5. محاسبه سایز پوزیشن
            position_size_percent, position_size_usd, position_units = self._calculate_position_size(
                account_balance=account_balance,
                entry_price=entry_price,
                stop_loss=stop_loss,
                risk_amount_usd=risk_amount_usd,
                confidence=confidence
            )
            
            # 6. محاسبه امتیاز ریسک
            risk_score = self._calculate_risk_score(
                risk_reward_ratio=risk_reward_ratio,
                confidence=confidence,
                volatility=signal_data.get('volatility', 0),
                position_size_percent=position_size_percent
            )
            
            # 7. جمع‌آوری نتایج
            risk_params = {
                # فیلدهای مستقیم برای ذخیره در دیتابیس
                'stop_loss': stop_loss,
                'take_profit_1': take_profit_1,
                'take_profit_2': take_profit_2,
                'take_profit_3': take_profit_3,
                'risk_reward_ratio': risk_reward_ratio,
                'position_size_percent': position_size_percent,
                
                # داده‌های اضافی برای ذخیره در JSON
                'risk_calculations': {
                    'risk_amount_usd': round(risk_amount_usd, 2),
                    'position_size_usd': round(position_size_usd, 2),
                    'position_units': round(position_units, 6),
                    'risk_score': round(risk_score, 3),
                    'risk_level': self._get_risk_level(risk_score),
                    'account_balance_used': round(account_balance, 2),
                    'entry_price': entry_price,
                    'signal_type': signal_type,
                    'confidence_original': signal_data.get('confidence_score', 50),
                    'calculated_at': datetime.now().isoformat(),
                    'risk_parameters': {
                        'stop_loss_percent': round(abs(stop_loss - entry_price) / entry_price * 100, 2),
                        'take_profit_percent': round(abs(take_profit_1 - entry_price) / entry_price * 100, 2),
                        'position_size_percent': round(position_size_percent, 2),
                        'risk_reward_ratio': round(risk_reward_ratio, 2)
                    }
                }
            }
            
            self.logger.info(f"محاسبه ریسک کامل شد: ریسک ${risk_amount_usd:,.2f}, امتیاز {risk_score:.2f}")
            return risk_params
            
        except Exception as e:
            self.logger.error(f"خطا در محاسبه ریسک: {e}")
            return self._get_default_risk_params(signal_data)
    
    # ==================== توابع محاسباتی ====================
    
    def _calculate_stop_loss(self, entry_price: float, signal_type: str, 
                            current_price: float, confidence: float, 
                            additional_data: Dict) -> float:
        """محاسبه حد ضرر"""
        # روش 1: بر اساس درصد ثابت
        base_stop_percent = self.default_stop_loss_percent
        
        # تنظیم بر اساس اعتماد سیگنال
        if confidence > 0.7:  # سیگنال قوی
            stop_percent = base_stop_percent * 0.8  # حد ضرر کوچک‌تر
        elif confidence < 0.3:  # سیگنال ضعیف
            stop_percent = base_stop_percent * 1.5  # حد ضرر بزرگ‌تر
        else:
            stop_percent = base_stop_percent
        
        # محدود کردن به بازه مجاز
        stop_percent = max(self.min_stop_loss_percent, 
                          min(stop_percent, self.max_stop_loss_percent))
        
        # محاسبه قیمت حد ضرر
        if signal_type == 'buy':
            stop_loss = entry_price * (1 - stop_percent)
        else:  # sell
            stop_loss = entry_price * (1 + stop_percent)
        
        # گرد کردن به تعداد اعشار مناسب
        stop_loss = self._round_price(stop_loss)
        
        return stop_loss
    
    def _calculate_risk_amount(self, account_balance: float, entry_price: float,
                              stop_loss: float, signal_type: str, 
                              confidence: float) -> float:
        """محاسبه مقدار ریسک به دلار"""
        # درصد ریسک بر اساس اعتماد
        base_risk_percent = self.default_risk_per_trade
        risk_percent = base_risk_percent * confidence
        
        # محدود کردن به بازه مجاز
        risk_percent = max(self.min_risk_percent, 
                          min(risk_percent, self.max_risk_percent))
        
        # محاسبه ریسک به دلار
        risk_amount = account_balance * risk_percent
        
        return round(risk_amount, 2)
    
    def _calculate_take_profit_levels(self, entry_price: float, stop_loss: float,
                                     signal_type: str, confidence: float) -> Tuple[float, float, float]:
        """محاسبه سطوح حد سود"""
        # محاسبه فاصله ریسک
        if signal_type == 'buy':
            risk_distance = abs(entry_price - stop_loss)
        else:  # sell
            risk_distance = abs(stop_loss - entry_price)
        
        # سطح ۱: نسبت ریسک به بازده استاندارد
        rr_ratio = self.default_rr_ratio
        if signal_type == 'buy':
            take_profit_1 = entry_price + (risk_distance * rr_ratio)
        else:
            take_profit_1 = entry_price - (risk_distance * rr_ratio)
        
        # سطح ۲ و ۳: برای استراتژی‌های پیچیده‌تر
        take_profit_2 = None
        take_profit_3 = None
        
        if confidence > 0.6:  # فقط برای سیگنال‌های با اعتماد بالا
            if signal_type == 'buy':
                take_profit_2 = entry_price + (risk_distance * (rr_ratio * 1.5))
                take_profit_3 = entry_price + (risk_distance * (rr_ratio * 2.0))
            else:
                take_profit_2 = entry_price - (risk_distance * (rr_ratio * 1.5))
                take_profit_3 = entry_price - (risk_distance * (rr_ratio * 2.0))
        
        # گرد کردن
        take_profit_1 = self._round_price(take_profit_1)
        if take_profit_2:
            take_profit_2 = self._round_price(take_profit_2)
        if take_profit_3:
            take_profit_3 = self._round_price(take_profit_3)
        
        return take_profit_1, take_profit_2, take_profit_3
    
    def _calculate_risk_reward_ratio(self, entry_price: float, stop_loss: float,
                                    take_profit: float, signal_type: str) -> float:
        """محاسبه نسبت ریسک به بازده"""
        if signal_type == 'buy':
            risk = entry_price - stop_loss
            reward = take_profit - entry_price
        else:  # sell
            risk = stop_loss - entry_price
            reward = entry_price - take_profit
        
        if risk <= 0:
            return self.min_rr_ratio
        
        rr_ratio = reward / risk
        return max(self.min_rr_ratio, round(rr_ratio, 2))
    
    def _calculate_position_size(self, account_balance: float, entry_price: float,
                                stop_loss: float, risk_amount_usd: float,
                                confidence: float) -> Tuple[float, float, float]:
        """محاسبه سایز پوزیشن"""
        # محاسبه ریسک به ازای هر واحد
        risk_per_unit = abs(entry_price - stop_loss)
        
        if risk_per_unit <= 0:
            # حالت fallback
            position_size_percent = min(self.max_position_size_percent, 
                                       self.default_risk_per_trade * 100 * confidence)
            position_size_usd = account_balance * (position_size_percent / 100)
            position_units = position_size_usd / entry_price if entry_price > 0 else 0
        else:
            # محاسبه تعداد واحدها
            position_units = risk_amount_usd / risk_per_unit
            
            # محاسبه سایز به دلار و درصد
            position_size_usd = position_units * entry_price
            position_size_percent = (position_size_usd / account_balance) * 100
            
            # محدود کردن به حداکثر مجاز
            if position_size_percent > self.max_position_size_percent:
                position_size_percent = self.max_position_size_percent
                position_size_usd = account_balance * (position_size_percent / 100)
                position_units = position_size_usd / entry_price
        
        return (
            round(position_size_percent, 2),
            round(position_size_usd, 2),
            round(position_units, 6)
        )
    
    def _calculate_risk_score(self, risk_reward_ratio: float, confidence: float,
                             volatility: float, position_size_percent: float) -> float:
        """محاسبه امتیاز ریسک (0-1، بالاتر بهتر)"""
        score = 0.0
        
        # مؤلفه ۱: نسبت ریسک به بازده (وزن 40%)
        rr_score = min(risk_reward_ratio / 5.0, 1.0)  # نرمال‌سازی به 0-1
        score += rr_score * 0.4
        
        # مؤلفه ۲: اعتماد سیگنال (وزن 30%)
        score += confidence * 0.3
        
        # مؤلفه ۳: نوسان (وزن 20%)
        volatility_score = 1.0 - min(volatility, 0.1) / 0.1  # نوسان 0-10%
        score += volatility_score * 0.2
        
        # مؤلفه ۴: سایز پوزیشن (وزن 10%)
        size_score = 1.0 - (position_size_percent / self.max_position_size_percent)
        score += size_score * 0.1
        
        return max(0.0, min(score, 1.0))
    
    def _get_risk_level(self, risk_score: float) -> str:
        """تعیین سطح ریسک بر اساس امتیاز"""
        if risk_score >= 0.8:
            return "LOW"
        elif risk_score >= 0.6:
            return "MODERATE"
        elif risk_score >= 0.4:
            return "MEDIUM"
        else:
            return "HIGH"
    
    def _round_price(self, price: float) -> float:
        """گرد کردن قیمت به تعداد اعشار مناسب"""
        if price >= 1000:
            return round(price, 2)
        elif price >= 1:
            return round(price, 4)
        elif price >= 0.01:
            return round(price, 6)
        else:
            return round(price, 8)
    
    def _get_default_risk_params(self, signal_data: Dict) -> Dict:
        """پارامترهای پیش‌فرض در صورت خطا"""
        entry_price = signal_data.get('entry_price', 0)
        
        return {
            'stop_loss': entry_price * 0.98,
            'take_profit_1': entry_price * 1.03,
            'take_profit_2': None,
            'take_profit_3': None,
            'risk_reward_ratio': 3.0,
            'position_size_percent': 1.0,
            'risk_calculations': {
                'risk_amount_usd': 100.0,
                'position_size_usd': 100.0,
                'position_units': 0.0,
                'risk_score': 0.5,
                'risk_level': 'MODERATE',
                'account_balance_used': self.default_account_balance,
                'entry_price': entry_price,
                'calculated_at': datetime.now().isoformat(),
                'note': 'محاسبه با پارامترهای پیش‌فرض'
            }
        }
    
    # ==================== توابع کاربردی ====================
    
    def format_risk_report(self, risk_params: Dict) -> str:
        """قالب‌بندی گزارش ریسک برای نمایش"""
        if not risk_params:
            return "⚠️ هیچ داده‌ای برای نمایش وجود ندارد"
        
        calculations = risk_params.get('risk_calculations', {})
        
        report = []
        report.append("📊 **گزارش مدیریت ریسک**")
        report.append("=" * 50)
        
        # اطلاعات کلی
        if 'entry_price' in calculations:
            report.append(f"💰 قیمت ورود: {calculations['entry_price']:.8f}")
        
        if 'signal_type' in calculations:
            report.append(f"🎯 نوع سیگنال: {calculations['signal_type'].upper()}")
        
        # پارامترهای اصلی
        report.append(f"\n🛡️ **پارامترهای اصلی:**")
        report.append(f"  • حد ضرر: {risk_params.get('stop_loss', 0):.8f}")
        report.append(f"  • حد سود: {risk_params.get('take_profit_1', 0):.8f}")
        report.append(f"  • نسبت ریسک: {risk_params.get('risk_reward_ratio', 0):.2f}:1")
        report.append(f"  • سایز پوزیشن: {risk_params.get('position_size_percent', 0):.2f}%")
        
        # محاسبات ریسک
        report.append(f"\n📈 **محاسبات ریسک:**")
        if 'risk_amount_usd' in calculations:
            report.append(f"  • مقدار ریسک: ${calculations['risk_amount_usd']:,.2f}")
        
        if 'position_size_usd' in calculations:
            report.append(f"  • سایز پوزیشن: ${calculations['position_size_usd']:,.2f}")
        
        if 'risk_score' in calculations:
            report.append(f"  • امتیاز ریسک: {calculations['risk_score']:.2f}/1.0")
        
        if 'risk_level' in calculations:
            report.append(f"  • سطح ریسک: {calculations['risk_level']}")
        
        # شرایط حساب
        if 'account_balance_used' in calculations:
            report.append(f"\n🏦 **شرایط حساب:**")
            report.append(f"  • موجودی استفاده شده: ${calculations['account_balance_used']:,.2f}")
        
        # زمان محاسبه
        if 'calculated_at' in calculations:
            time_str = calculations['calculated_at'][:19].replace('T', ' ')
            report.append(f"\n⏰ **زمان محاسبه:** {time_str}")
        
        # توصیه
        risk_level = calculations.get('risk_level', 'MODERATE')
        if risk_level == 'LOW':
            recommendation = "✅ ریسک پایین - مناسب برای معامله"
        elif risk_level == 'MODERATE':
            recommendation = "⚠️ ریسک متوسط - با احتیاط معامله کنید"
        elif risk_level == 'HIGH':
            recommendation = "❌ ریسک بالا - از معامله خودداری کنید"
        else:
            recommendation = "ℹ️ ریسک قابل قبول"
        
        report.append(f"\n💡 **توصیه:** {recommendation}")
        
        return "\n".join(report)
    
    def save_risk_to_signal_data(self, signal_data: Dict, risk_params: Dict) -> Dict:
        """
        ادغام داده‌های ریسک با داده‌های سیگنال
        برای آماده‌سازی ذخیره در دیتابیس
        """
        if not signal_data or not risk_params:
            return signal_data
        
        # کپی از داده‌های اصلی
        result = signal_data.copy()
        
        # اضافه کردن فیلدهای مستقیم
        result['stop_loss'] = risk_params.get('stop_loss')
        result['take_profit_1'] = risk_params.get('take_profit_1')
        result['take_profit_2'] = risk_params.get('take_profit_2')
        result['take_profit_3'] = risk_params.get('take_profit_3')
        result['risk_reward_ratio'] = risk_params.get('risk_reward_ratio')
        result['position_size_percent'] = risk_params.get('position_size_percent')
        
        # ادغام indicators_json
        existing_indicators = {}
        if 'indicators_json' in result and result['indicators_json']:
            try:
                existing_indicators = json.loads(result['indicators_json'])
            except:
                existing_indicators = {}
        
        # اضافه کردن محاسبات ریسک
        if 'risk_calculations' in risk_params:
            existing_indicators['risk_analysis'] = risk_params['risk_calculations']
        
        # ذخیره به عنوان JSON
        result['indicators_json'] = json.dumps(existing_indicators, ensure_ascii=False)
        
        return result


# ==================== تست ماژول ====================

def run_test():
    """تابع تست مستقل"""
    import logging
    
    # تنظیم لاگ‌گیری
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    print("\n🧪 **تست RiskCalculator**")
    print("=" * 60)
    
    # ایجاد نمونه
    calculator = RiskCalculator()
    
    # تست ۱: سیگنال خرید
    print("\n📈 **تست ۱: سیگنال خرید BTC**")
    buy_signal = {
        'entry_price': 50000.0,
        'current_price': 50200.0,
        'signal_type': 'buy',
        'confidence_score': 75,  # 75%
        'volatility': 0.015
    }
    
    risk_params = calculator.calculate_for_signal(
        signal_data=buy_signal,
        account_balance=10000.0
    )
    
    print(calculator.format_risk_report(risk_params))
    
    # تست ۲: سیگنال فروش
    print("\n📉 **تست ۲: سیگنال فروش ETH**")
    sell_signal = {
        'entry_price': 3000.0,
        'current_price': 2950.0,
        'signal_type': 'sell',
        'confidence_score': 60,  # 60%
        'volatility': 0.025
    }
    
    risk_params = calculator.calculate_for_signal(
        signal_data=sell_signal,
        account_balance=5000.0
    )
    
    print(calculator.format_risk_report(risk_params))
    
    # تست ۳: آماده‌سازی برای ذخیره
    print("\n💾 **تست ۳: آماده‌سازی برای ذخیره در دیتابیس**")
    prepared_data = calculator.save_risk_to_signal_data(buy_signal, risk_params)
    
    print("📋 فیلدهای آماده برای ذخیره:")
    for key in ['stop_loss', 'take_profit_1', 'risk_reward_ratio', 'position_size_percent']:
        if key in prepared_data:
            print(f"  • {key}: {prepared_data[key]}")
    
    print("\n" + "=" * 60)
    print("✅ **تست RiskCalculator کامل شد**")
    print("\n🎯 **آماده یکپارچه‌سازی با:**")
    print("  • main_cycle_04.py - برای محاسبه ریسک در چرخه اصلی")
    print("  • result_saver.py - برای ذخیره پارامترهای ریسک")
    print("  • trading_signals table - بدون نیاز به تغییر ساختار")


if __name__ == "__main__":
    run_test()