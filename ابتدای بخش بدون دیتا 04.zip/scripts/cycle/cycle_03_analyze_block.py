# scripts/cycle/cycle_03_analyze_block.py (نسخه اصلاح شده)
"""
تکه 03: تحلیل اولیه داده‌های کندل جمع‌آوری شده
نسخه اصلاح شده برای ساختار واقعی دیتابیس
"""

import sys
import os
import json
import pandas as pd
import numpy as np
from datetime import datetime
from pathlib import Path
import warnings
warnings.filterwarnings('ignore')

# اضافه کردن مسیر پروژه به sys.path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

try:
    from scripts.config_manager import get, get_database_path
    from scripts.database_manager import DatabaseManager
except ImportError as e:
    print(f"❌ خطا در وارد کردن ماژول‌ها: {e}")
    sys.exit(1)

class DataAnalyzer:
    """کلاس تحلیل اولیه داده‌های کندل"""
    
    def __init__(self, cycle_id=None):
        self.cycle_id = cycle_id or self._get_current_cycle_id()
        self.db_path = get_database_path()
        self.current_block = self._get_current_block()
        
        # نتایج تحلیل
        self.results = {
            'cycle_id': self.cycle_id,
            'block_id': self.current_block['block_id'],
            'timestamp': datetime.now().isoformat(),
            'analysis_summary': {},
            'coin_analysis': {},
            'data_issues': [],
            'quality_scores': {}
        }
        
    def _get_current_cycle_id(self):
        """دریافت شناسه چرخه فعلی از state"""
        state_file = Path(get('paths.project_root')) / 'state' / 'cycle_state.json'
        if state_file.exists():
            try:
                with open(state_file, 'r', encoding='utf-8') as f:
                    state = json.load(f)
                return state.get('cycle_id', 'cycle_unknown')
            except Exception as e:
                print(f"⚠️ خطا در خواندن فایل state: {e}")
        return 'cycle_unknown'
    
    def _get_current_block(self):
        """دریافت اطلاعات بلوک فعلی از فایل state"""
        state_file = Path(get('paths.project_root')) / 'state' / 'cycle_state.json'
        
        try:
            with open(state_file, 'r', encoding='utf-8') as f:
                state = json.load(f)
            
            # دریافت بلوک جاری
            current_block_id = state.get('current_block', 1)
            blocks = state.get('blocks', [])
            
            # پیدا کردن بلوک جاری
            current_block = None
            for block in blocks:
                if block.get('block_id') == current_block_id:
                    current_block = block
                    break
            
            if not current_block:
                # اگر بلوک جاری پیدا نشد، اولین بلوک را بگیر
                if blocks:
                    current_block = blocks[0]
                else:
                    raise Exception("❌ هیچ بلوکی در فایل state یافت نشد")
            
            # استخراج لیست نمادها از بلوک
            coins = current_block.get('coins', [])
            symbols = [coin.get('symbol') for coin in coins if coin.get('symbol')]
            
            return {
                'block_id': current_block.get('block_id', 1),
                'coins_count': len(symbols),
                'coins_list': symbols,
                'coins_data': coins  # داده‌های کامل ارزها
            }
            
        except Exception as e:
            print(f"❌ خطا در خواندن فایل state: {e}")
            # حالت fallback: بلوک ساختگی
            return {
                'block_id': 1,
                'coins_count': 0,
                'coins_list': [],
                'coins_data': []
            }
    
    def get_klines_for_coin(self, symbol, limit=200):
        """دریافت کندل‌های یک ارز از دیتابیس (نسخه اصلاح شده برای ساختار واقعی)"""
        try:
            with DatabaseManager(self.db_path) as db:
                # ابتدا باید coin_id را پیدا کنیم
                coin_id_query = "SELECT id FROM crypto_coins WHERE symbol = ?"
                coin_result = db.fetch_one(coin_id_query, (symbol,))
                
                if not coin_result:
                    print(f"  ⚠️ نماد {symbol} در جدول crypto_coins یافت نشد")
                    return None
                
                coin_id = coin_result[0]
                
                # کوئری اصلاح شده با نام ستون‌های واقعی
                query = """
                SELECT 
                    open_time, 
                    open_price,        -- اصلاح: open_price به جای open
                    high_price,        -- اصلاح: high_price به جای high
                    low_price,         -- اصلاح: low_price به جای low
                    close_price,       -- اصلاح: close_price به جای close
                    volume,
                    close_time, 
                    quote_volume,      -- اصلاح: quote_volume به جای quote_asset_volume
                    number_of_trades,
                    taker_buy_volume,
                    taker_sell_volume,   -- ستون اضافه شده در دیتابیس واقعی
                    taker_buy_quote_volume,
                    candle_date
                FROM crypto_klines
                WHERE coin_id = ?
                ORDER BY open_time DESC
                LIMIT ?
                """
                
                klines = db.fetch_all(query, (coin_id, limit))
                
                if not klines:
                    return None
                
                # تبدیل به DataFrame با نام‌های ستون مناسب
                df = pd.DataFrame(klines, columns=[
                    'open_time', 'open', 'high', 'low', 'close', 'volume',
                    'close_time', 'quote_volume', 'number_of_trades',
                    'taker_buy_volume', 'taker_sell_volume', 
                    'taker_buy_quote_volume', 'candle_date'
                ])
                
                # تبدیل نوع داده‌ها
                numeric_columns = ['open', 'high', 'low', 'close', 'volume', 
                                 'quote_volume', 'taker_buy_volume', 
                                 'taker_sell_volume', 'taker_buy_quote_volume']
                
                for col in numeric_columns:
                    df[col] = pd.to_numeric(df[col], errors='coerce')
                
                # تبدیل زمان‌ها
                df['open_time'] = pd.to_datetime(df['open_time'])
                df['close_time'] = pd.to_datetime(df['close_time'])
                
                # مرتب‌سازی بر اساس زمان
                df = df.sort_values('open_time')
                
                return df
                
        except Exception as e:
            print(f"❌ خطا در دریافت کندل‌های {symbol}: {e}")
            return None
    
    def analyze_coin_data(self, symbol, df):
        """تحلیل داده‌های یک ارز"""
        analysis = {
            'symbol': symbol,
            'total_candles': len(df),
            'analysis_time': datetime.now().isoformat()
        }
        
        if len(df) == 0:
            analysis['error'] = 'No data available'
            analysis['data_quality_score'] = 0
            analysis['data_quality_level'] = 'very_poor'
            return analysis
        
        # 1. بررسی داده‌های مفقود
        missing_data = df.isnull().sum()
        analysis['missing_values'] = missing_data.to_dict()
        analysis['missing_percentage'] = (missing_data / len(df) * 100).to_dict()
        
        # 2. آمارهای توصیفی قیمت
        price_columns = ['open', 'high', 'low', 'close']
        for col in price_columns:
            if col in df.columns:
                col_data = df[col].dropna()
                if len(col_data) > 0:
                    analysis[f'{col}_stats'] = {
                        'mean': float(col_data.mean()),
                        'std': float(col_data.std()),
                        'min': float(col_data.min()),
                        'max': float(col_data.max()),
                        'median': float(col_data.median()),
                        'q1': float(col_data.quantile(0.25)),
                        'q3': float(col_data.quantile(0.75))
                    }
        
        # 3. محاسبه روند
        if 'close' in df.columns:
            close_prices = df['close'].dropna().values
            if len(close_prices) > 1:
                # روند خطی
                x = np.arange(len(close_prices))
                slope, intercept = np.polyfit(x, close_prices, 1)
                analysis['trend'] = {
                    'slope': float(slope),
                    'intercept': float(intercept),
                    'direction': 'up' if slope > 0 else ('down' if slope < 0 else 'neutral')
                }
                
                # تغییرات درصدی
                price_change = ((close_prices[-1] - close_prices[0]) / close_prices[0]) * 100
                analysis['price_change_percent'] = float(price_change)
        
        # 4. تحلیل حجم
        if 'volume' in df.columns:
            volume_data = df['volume'].dropna()
            if len(volume_data) > 0:
                volume_stats = {
                    'mean_volume': float(volume_data.mean()),
                    'total_volume': float(volume_data.sum()),
                    'volume_trend': float(np.polyfit(np.arange(len(volume_data)), volume_data.values, 1)[0]) if len(volume_data) > 1 else 0
                }
                analysis['volume_analysis'] = volume_stats
        
        # 5. تحلیل حجم خریداران و فروشندگان
        if 'taker_buy_volume' in df.columns and 'taker_sell_volume' in df.columns:
            buy_volume = df['taker_buy_volume'].dropna().sum()
            sell_volume = df['taker_sell_volume'].dropna().sum()
            total_volume = buy_volume + sell_volume
            
            if total_volume > 0:
                buy_ratio = buy_volume / total_volume
                analysis['buy_sell_ratio'] = {
                    'buy_volume': float(buy_volume),
                    'sell_volume': float(sell_volume),
                    'buy_ratio': float(buy_ratio),
                    'dominance': 'buy' if buy_ratio > 0.55 else ('sell' if buy_ratio < 0.45 else 'balanced')
                }
        
        # 6. شناسایی ناهنجاری‌ها (Anomalies)
        if 'close' in df.columns:
            close_series = df['close'].dropna()
            if len(close_series) > 0:
                mean = close_series.mean()
                std = close_series.std()
                
                if std > 0:
                    # نقاط خارج از 3 انحراف معیار
                    anomalies = close_series[(close_series > mean + 3*std) | (close_series < mean - 3*std)]
                    analysis['anomalies_count'] = len(anomalies)
                    analysis['anomalies_percentage'] = (len(anomalies) / len(close_series)) * 100
                else:
                    analysis['anomalies_count'] = 0
                    analysis['anomalies_percentage'] = 0
        
        # 7. کیفیت داده
        quality_score = 100
        
        # جریمه برای داده‌های مفقود
        missing_penalty = analysis['missing_percentage'].get('close', 0)
        quality_score -= min(missing_penalty, 30)  # حداکثر 30 امتیاز جریمه
        
        # جریمه برای ناهنجاری‌ها
        anomaly_penalty = min(analysis.get('anomalies_percentage', 0) * 2, 20)
        quality_score -= anomaly_penalty
        
        # جریمه برای داده‌های ناکافی
        if len(df) < 100:
            quality_score -= (100 - len(df)) * 0.5
        
        analysis['data_quality_score'] = max(quality_score, 0)
        analysis['data_quality_level'] = self._get_quality_level(quality_score)
        
        return analysis
    
    def _get_quality_level(self, score):
        """تعیین سطح کیفیت داده"""
        if score >= 90:
            return 'excellent'
        elif score >= 75:
            return 'good'
        elif score >= 60:
            return 'fair'
        elif score >= 40:
            return 'poor'
        else:
            return 'very_poor'
    
    def check_data_issues(self, symbol, analysis):
        """بررسی مشکلات داده"""
        issues = []
        
        # 1. داده‌های ناکافی
        if analysis['total_candles'] < 50:
            issues.append({
                'symbol': symbol,
                'issue': 'insufficient_data',
                'severity': 'high',
                'details': f'Only {analysis["total_candles"]} candles available (minimum 50 required)'
            })
        
        # 2. داده‌های مفقود زیاد
        if analysis.get('missing_percentage', {}).get('close', 0) > 10:
            issues.append({
                'symbol': symbol,
                'issue': 'high_missing_data',
                'severity': 'medium',
                'details': f'{analysis["missing_percentage"]["close"]:.1f}% missing close prices'
            })
        
        # 3. ناهنجاری‌های زیاد
        if analysis.get('anomalies_percentage', 0) > 5:
            issues.append({
                'symbol': symbol,
                'issue': 'high_anomalies',
                'severity': 'medium',
                'details': f'{analysis["anomalies_percentage"]:.1f}% price anomalies'
            })
        
        # 4. حجم معاملات بسیار کم (اختیاری)
        if analysis.get('volume_analysis', {}).get('mean_volume', 0) < 1000:
            issues.append({
                'symbol': symbol,
                'issue': 'low_volume',
                'severity': 'low',
                'details': f'Low trading volume: {analysis["volume_analysis"]["mean_volume"]:.0f}'
            })
        
        # 5. عدم تعادل شدید بین خریداران و فروشندگان
        if analysis.get('buy_sell_ratio', {}).get('dominance', 'balanced') in ['buy', 'sell']:
            buy_ratio = analysis['buy_sell_ratio']['buy_ratio']
            if buy_ratio > 0.7 or buy_ratio < 0.3:
                issues.append({
                    'symbol': symbol,
                    'issue': 'imbalanced_market',
                    'severity': 'medium',
                    'details': f'Market imbalance: {buy_ratio:.2%} buy ratio'
                })
        
        return issues
    
    def save_analysis_results(self, coin_analysis):
        """ذخیره نتایج تحلیل در دیتابیس"""
        try:
            with DatabaseManager(self.db_path) as db:
                # ایجاد جدول اگر وجود ندارد
                create_table_query = """
                CREATE TABLE IF NOT EXISTS data_quality_analysis (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    cycle_id TEXT NOT NULL,
                    block_id INTEGER NOT NULL,
                    symbol TEXT NOT NULL,
                    analysis_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    total_candles INTEGER,
                    data_quality_score REAL,
                    data_quality_level TEXT,
                    price_change_percent REAL,
                    trend_direction TEXT,
                    volume_mean REAL,
                    anomalies_count INTEGER,
                    missing_percentage REAL,
                    buy_ratio REAL,
                    market_dominance TEXT,
                    analysis_json TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
                """
                db.execute_query(create_table_query)
                
                # ایجاد ایندکس برای جستجوی بهتر
                index_query = """
                CREATE INDEX IF NOT EXISTS idx_quality_analysis_symbol 
                ON data_quality_analysis (symbol, analysis_date)
                """
                db.execute_query(index_query)
                
                # ذخیره تحلیل هر ارز
                saved_count = 0
                for symbol, analysis in coin_analysis.items():
                    # اگر خطا داشت، ذخیره نکن
                    if analysis.get('error'):
                        continue
                    
                    insert_query = """
                    INSERT INTO data_quality_analysis 
                    (cycle_id, block_id, symbol, total_candles, data_quality_score, 
                     data_quality_level, price_change_percent, trend_direction, 
                     volume_mean, anomalies_count, missing_percentage, 
                     buy_ratio, market_dominance, analysis_json)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """
                    
                    buy_ratio = analysis.get('buy_sell_ratio', {}).get('buy_ratio', 0.5)
                    market_dominance = analysis.get('buy_sell_ratio', {}).get('dominance', 'balanced')
                    
                    db.execute_query(insert_query, (
                        self.cycle_id,
                        self.current_block['block_id'],
                        symbol,
                        analysis['total_candles'],
                        analysis['data_quality_score'],
                        analysis['data_quality_level'],
                        analysis.get('price_change_percent', 0),
                        analysis.get('trend', {}).get('direction', 'neutral'),
                        analysis.get('volume_analysis', {}).get('mean_volume', 0),
                        analysis.get('anomalies_count', 0),
                        analysis.get('missing_percentage', {}).get('close', 0),
                        buy_ratio,
                        market_dominance,
                        json.dumps(analysis, default=str)
                    ))
                    
                    saved_count += 1
                
                print(f"✅ نتایج تحلیل برای بلوک {self.current_block['block_id']} ذخیره شد ({saved_count} ارز)")
                
                # آپدیت فایل state
                self._update_state_file()
                
                return True
                
        except Exception as e:
            print(f"❌ خطا در ذخیره نتایج تحلیل: {e}")
            import traceback
            traceback.print_exc()
            return False
    
    def _update_state_file(self):
        """به‌روزرسانی فایل state برای علامت‌گذاری بلوک به عنوان تحلیل شده"""
        try:
            state_file = Path(get('paths.project_root')) / 'state' / 'cycle_state.json'
            
            with open(state_file, 'r', encoding='utf-8') as f:
                state = json.load(f)
            
            # اضافه کردن بلوک فعلی به لیست completed_blocks
            current_block_id = self.current_block['block_id']
            completed_blocks = state.get('completed_blocks', [])
            
            if current_block_id not in completed_blocks:
                completed_blocks.append(current_block_id)
                state['completed_blocks'] = completed_blocks
            
            # به‌روزرسانی بلوک جاری به بلوک بعدی
            pending_blocks = state.get('pending_blocks', [])
            if pending_blocks:
                next_block = pending_blocks[0]
                state['current_block'] = next_block
                state['pending_blocks'] = pending_blocks[1:]
            
            # ذخیره فایل state
            with open(state_file, 'w', encoding='utf-8') as f:
                json.dump(state, f, indent=2, ensure_ascii=False)
            
            print(f"✅ فایل state به‌روزرسانی شد. بلوک {current_block_id} کامل شد.")
            
            if pending_blocks:
                print(f"🔄 بلوک بعدی: {next_block}")
            else:
                print("🎉 تمام بلوک‌ها تحلیل شدند!")
                
        except Exception as e:
            print(f"⚠️ خطا در به‌روزرسانی فایل state: {e}")
    
    def generate_summary_report(self):
        """تولید گزارش خلاصه تحلیل"""
        summary = {
            'total_coins': len(self.results['coin_analysis']),
            'coins_analyzed': len([a for a in self.results['coin_analysis'].values() if not a.get('error')]),
            'coins_with_errors': len([a for a in self.results['coin_analysis'].values() if a.get('error')]),
            'total_issues': len(self.results['data_issues']),
            'quality_distribution': {},
            'average_quality_score': 0,
            'trend_distribution': {'up': 0, 'down': 0, 'neutral': 0},
            'market_dominance_distribution': {'buy': 0, 'sell': 0, 'balanced': 0}
        }
        
        quality_scores = []
        for symbol, analysis in self.results['coin_analysis'].items():
            if analysis.get('error'):
                continue
                
            # توزیع کیفیت
            quality_level = analysis['data_quality_level']
            summary['quality_distribution'][quality_level] = \
                summary['quality_distribution'].get(quality_level, 0) + 1
            
            # میانگین امتیاز کیفیت
            quality_scores.append(analysis['data_quality_score'])
            
            # توزیع روند
            trend = analysis.get('trend', {}).get('direction', 'neutral')
            summary['trend_distribution'][trend] += 1
            
            # توزیع تسلط بازار
            dominance = analysis.get('buy_sell_ratio', {}).get('dominance', 'balanced')
            summary['market_dominance_distribution'][dominance] += 1
        
        if quality_scores:
            summary['average_quality_score'] = sum(quality_scores) / len(quality_scores)
        
        return summary
    
    def run_analysis(self):
        """اجرای تحلیل اصلی"""
        print(f"🔍 شروع تحلیل تکه 03")
        print(f"📊 چرخه: {self.cycle_id}")
        print(f"🎯 بلوک فعلی: {self.current_block['block_id']}")
        print(f"💰 تعداد ارزها در بلوک: {self.current_block['coins_count']}")
        print("=" * 60)
        
        symbols = self.current_block['coins_list']
        if not symbols:
            print("⚠️ هیچ نمادی در بلوک فعلی یافت نشد")
            return False
        
        total_symbols = len(symbols)
        
        for i, symbol in enumerate(symbols, 1):
            print(f"⏳ تحلیل ارز {i}/{total_symbols}: {symbol}")
            
            # دریافت داده‌های کندل
            df = self.get_klines_for_coin(symbol)
            
            if df is None or len(df) == 0:
                print(f"  ⚠️  داده‌ای برای {symbol} یافت نشد")
                self.results['coin_analysis'][symbol] = {
                    'symbol': symbol,
                    'error': 'no_data',
                    'total_candles': 0,
                    'data_quality_score': 0,
                    'data_quality_level': 'very_poor'
                }
                self.results['data_issues'].append({
                    'symbol': symbol,
                    'issue': 'no_data',
                    'severity': 'high',
                    'details': 'No klines data found in database'
                })
                continue
            
            # تحلیل داده‌ها
            coin_analysis = self.analyze_coin_data(symbol, df)
            self.results['coin_analysis'][symbol] = coin_analysis
            
            # بررسی مشکلات
            coin_issues = self.check_data_issues(symbol, coin_analysis)
            self.results['data_issues'].extend(coin_issues)
            
            # امتیاز کیفیت
            self.results['quality_scores'][symbol] = coin_analysis['data_quality_score']
            
            # نمایش خلاصه
            if coin_analysis.get('error'):
                print(f"  ❌ خطا: {coin_analysis['error']}")
            else:
                trend_dir = coin_analysis.get('trend', {}).get('direction', 'neutral')
                trend_symbol = '📈' if trend_dir == 'up' else '📉' if trend_dir == 'down' else '➡️'
                
                print(f"  ✅ تحلیل کامل: {coin_analysis['total_candles']} کندل، "
                      f"کیفیت: {coin_analysis['data_quality_level']} "
                      f"({coin_analysis['data_quality_score']:.1f}/100) {trend_symbol}")
            
            if coin_issues:
                print(f"  ⚠️  {len(coin_issues)} مشکل شناسایی شد")
        
        # تولید گزارش خلاصه
        self.results['analysis_summary'] = self.generate_summary_report()
        
        # ذخیره نتایج
        success = self.save_analysis_results(self.results['coin_analysis'])
        
        if success:
            print("\n" + "=" * 60)
            print("📈 گزارش نهایی تحلیل تکه 03:")
            print(f"   ارزهای تحلیل شده: {self.results['analysis_summary']['coins_analyzed']}")
            print(f"   ارزهای با خطا: {self.results['analysis_summary']['coins_with_errors']}")
            print(f"   میانگین امتیاز کیفیت: {self.results['analysis_summary']['average_quality_score']:.1f}")
            print(f"   مشکلات شناسایی شده: {self.results['analysis_summary']['total_issues']}")
            
            # نمایش توزیع کیفیت
            if self.results['analysis_summary']['quality_distribution']:
                print("\n   توزیع سطح کیفیت:")
                for level, count in sorted(self.results['analysis_summary']['quality_distribution'].items()):
                    percentage = (count / self.results['analysis_summary']['coins_analyzed']) * 100
                    print(f"     {level}: {count} ارز ({percentage:.1f}%)")
            
            # نمایش توزیع روند
            if sum(self.results['analysis_summary']['trend_distribution'].values()) > 0:
                print("\n   توزیع روند:")
                for trend, count in self.results['analysis_summary']['trend_distribution'].items():
                    percentage = (count / self.results['analysis_summary']['coins_analyzed']) * 100
                    trend_icon = '📈' if trend == 'up' else '📉' if trend == 'down' else '➡️'
                    print(f"     {trend_icon} {trend}: {count} ارز ({percentage:.1f}%)")
            
            # نمایش تسلط بازار
            if sum(self.results['analysis_summary']['market_dominance_distribution'].values()) > 0:
                print("\n   تسلط بازار:")
                for dominance, count in self.results['analysis_summary']['market_dominance_distribution'].items():
                    percentage = (count / self.results['analysis_summary']['coins_analyzed']) * 100
                    dominance_icon = '🟢' if dominance == 'buy' else '🔴' if dominance == 'sell' else '⚪'
                    print(f"     {dominance_icon} {dominance}: {count} ارز ({percentage:.1f}%)")
            
            # ذخیره گزارش در فایل
            self.save_report_to_file()
            
            return True
        else:
            print("❌ خطا در ذخیره نتایج تحلیل")
            return False
    
    def save_report_to_file(self):
        """ذخیره گزارش در فایل JSON"""
        try:
            report_dir = Path(get('paths.project_root')) / 'reports'
            report_dir.mkdir(exist_ok=True)
            
            # نام فایل با timestamp
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            report_file = report_dir / f"analysis_report_{self.cycle_id}_block_{self.current_block['block_id']}_{timestamp}.json"
            
            with open(report_file, 'w', encoding='utf-8') as f:
                json.dump(self.results, f, indent=2, default=str)
            
            print(f"📄 گزارش کامل در {report_file} ذخیره شد")
            
        except Exception as e:
            print(f"⚠️  خطا در ذخیره گزارش فایل: {e}")

def main():
    """تابع اصلی اجرای تحلیل"""
    print("=" * 60)
    print("🔍 سیستم تحلیل اولیه داده‌های کریپتو (تکه 03)")
    print("=" * 60)
    
    try:
        # ایجاد نمونه تحلیل‌گر
        analyzer = DataAnalyzer()
        
        # اجرای تحلیل
        success = analyzer.run_analysis()
        
        if success:
            print("\n✅ تحلیل تکه 03 با موفقیت تکمیل شد!")
            print("🔄 آماده برای تکه 04 (محاسبه اندیکاتورها)...")
            return True
        else:
            print("\n❌ تحلیل تکه 03 با خطا مواجه شد")
            return False
            
    except Exception as e:
        print(f"\n❌ خطای غیرمنتظره در تکه 03: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)