"""
اندیکاتورهای مبتنی بر حجم
"""

from typing import List, Optional, Dict, Any
from .base_indicator import BaseIndicator
from .moving_average_indicator import SMAIndicator


class VolumeIndicator(BaseIndicator):
    """اندیکاتورهای حجمی"""
    
    def __init__(self, period: int = 20):
        super().__init__(
            name="Volume MA",
            description=f"Volume Moving Average ({period} period)"
        )
        self.period = period
        self.minimum_data_points = period
        self.requires_minimum_data = True
        self.volume_sma = SMAIndicator(period)
    
    def calculate_history(self, volumes: List[float], **params) -> List[Optional[float]]:
        """محاسبه تاریخچه میانگین متحرک حجم"""
        period = params.get('period', self.period)
        
        if not self.validate_data(volumes):
            return [None] * len(volumes)
        
        return self.volume_sma.calculate_history(volumes, period=period)
    
    def calculate_volume_ratio(self, current_volume: float, volume_ma: float) -> Optional[float]:
        """محاسبه نسبت حجم"""
        if volume_ma is None or volume_ma == 0:
            return None
        return current_volume / volume_ma
    
    def get_volume_signal(self, volume_ratio: float) -> str:
        """دریافت سیگنال بر اساس نسبت حجم"""
        if volume_ratio is None:
            return "NEUTRAL"
        
        if volume_ratio > 2.0:
            return "HIGH_VOLUME"
        elif volume_ratio > 1.5:
            return "ABOVE_AVERAGE"
        elif volume_ratio < 0.5:
            return "LOW_VOLUME"
        elif volume_ratio < 0.8:
            return "BELOW_AVERAGE"
        else:
            return "NORMAL"
    
    def calculate_obv(self, closes: List[float], volumes: List[float]) -> List[Optional[float]]:
        """محاسبه On-Balance Volume (OBV)"""
        if len(closes) != len(volumes) or len(closes) < 2:
            return [None] * len(closes)
        
        obv_values = [0.0] * len(closes)
        
        for i in range(1, len(closes)):
            if closes[i] > closes[i-1]:
                obv_values[i] = obv_values[i-1] + volumes[i]
            elif closes[i] < closes[i-1]:
                obv_values[i] = obv_values[i-1] - volumes[i]
            else:
                obv_values[i] = obv_values[i-1]
        
        # مقدار اولیه None
        obv_values[0] = None
        return obv_values
    
    def get_output_column_name(self) -> str:
        return f"volume_ma_{self.period}"
    
    def get_config_params(self) -> Dict[str, Any]:
        return {'period': self.period}