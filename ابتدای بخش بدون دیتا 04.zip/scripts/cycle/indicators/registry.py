"""
رجیستری برای مدیریت اندیکاتورها
"""

from typing import Dict, Type, List, Any
from .base_indicator import BaseIndicator
from .rsi_indicator import RSIIndicator
from .macd_indicator import MACDIndicator
from .bollinger_indicator import BollingerBandsIndicator
from .moving_average_indicator import SMAIndicator, EMAIndicator
from .volume_indicator import VolumeIndicator


class IndicatorRegistry:
    """سیستم ثبت و مدیریت اندیکاتورها"""
    
    _instance = None
    _indicators: Dict[str, Type[BaseIndicator]] = {}
    _indicator_instances: Dict[str, BaseIndicator] = {}
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(IndicatorRegistry, cls).__new__(cls)
            cls._instance._initialize_registry()
        return cls._instance
    
    def _initialize_registry(self):
        """ثبت اندیکاتورهای پیش‌فرض"""
        self.register('rsi', RSIIndicator)
        self.register('macd', MACDIndicator)
        self.register('bollinger', BollingerBandsIndicator)
        self.register('sma', SMAIndicator)
        self.register('ema', EMAIndicator)
        self.register('volume', VolumeIndicator)
    
    def register(self, name: str, indicator_class: Type[BaseIndicator]):
        """ثبت یک اندیکاتور جدید"""
        self._indicators[name] = indicator_class
        print(f"✅ اندیکاتور '{name}' ثبت شد")
    
    def get_indicator(self, name: str, **params) -> BaseIndicator:
        """دریافت نمونه اندیکاتور با پارامترها"""
        cache_key = f"{name}_{str(params)}"
        
        if cache_key not in self._indicator_instances:
            if name not in self._indicators:
                raise ValueError(f"اندیکاتور '{name}' ثبت نشده است")
            
            indicator_class = self._indicators[name]
            self._indicator_instances[cache_key] = indicator_class(**params)
        
        return self._indicator_instances[cache_key]
    
    def get_available_indicators(self) -> List[str]:
        """دریافت لیست اندیکاتورهای موجود"""
        return list(self._indicators.keys())
    
    def create_from_config(self, config: Dict[str, Any]) -> Dict[str, BaseIndicator]:
        """ایجاد اندیکاتورها از تنظیمات"""
        indicators = {}
        
        # RSI
        if config.get('rsi_enabled', True):
            rsi_period = config.get('rsi_period', 14)
            indicators['rsi'] = self.get_indicator('rsi', period=rsi_period)
        
        # MACD
        if config.get('macd_enabled', True):
            macd_fast = config.get('macd_fast', 12)
            macd_slow = config.get('macd_slow', 26)
            macd_signal = config.get('macd_signal', 9)
            indicators['macd'] = self.get_indicator('macd', 
                fast_period=macd_fast, 
                slow_period=macd_slow, 
                signal_period=macd_signal
            )
        
        # Bollinger Bands
        if config.get('bollinger_enabled', True):
            bb_period = config.get('bollinger_period', 20)
            bb_std = config.get('bollinger_std', 2)
            indicators['bollinger'] = self.get_indicator('bollinger', 
                period=bb_period, 
                std_dev=bb_std
            )
        
        # Moving Averages
        ma_periods = config.get('ma_periods', [5, 10, 20, 50])
        for period in ma_periods:
            key = f"sma_{period}"
            indicators[key] = self.get_indicator('sma', period=period)
        
        ema_periods = config.get('ema_periods', [12, 26])
        for period in ema_periods:
            key = f"ema_{period}"
            indicators[key] = self.get_indicator('ema', period=period)
        
        # Volume
        if config.get('volume_enabled', True):
            volume_period = config.get('volume_period', 20)
            indicators['volume'] = self.get_indicator('volume', period=volume_period)
        
        return indicators