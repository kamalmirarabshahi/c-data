"""
اندیکاتور RSI
"""

import math
from typing import List, Optional, Dict, Any
from .base_indicator import BaseIndicator


class RSIIndicator(BaseIndicator):
    """اندیکاتور RSI با قابلیت محاسبه تاریخچه"""
    
    def __init__(self, period: int = 14):
        super().__init__(
            name="RSI",
            description="Relative Strength Index"
        )
        self.period = period
        self.minimum_data_points = period + 1
        self.requires_minimum_data = True
    
    def calculate_history(self, prices: List[float], **params) -> List[Optional[float]]:
        """محاسبه تاریخچه RSI"""
        if not self.validate_data(prices):
            return [None] * len(prices)
        
        period = params.get('period', self.period)
        
        if len(prices) < period + 1:
            return [None] * len(prices)
        
        deltas = [prices[i] - prices[i-1] for i in range(1, len(prices))]
        
        gains = []
        losses = []
        
        for delta in deltas:
            if delta > 0:
                gains.append(delta)
                losses.append(0)
            else:
                gains.append(0)
                losses.append(abs(delta))
        
        # میانگین اولیه
        avg_gain = sum(gains[:period]) / period
        avg_loss = sum(losses[:period]) / period
        
        rsi_values = []
        
        for i in range(period, len(gains)):
            if i == period:
                current_gain = avg_gain
                current_loss = avg_loss
            else:
                current_gain = (avg_gain * (period - 1) + gains[i]) / period
                current_loss = (avg_loss * (period - 1) + losses[i]) / period
            
            if current_loss == 0:
                rsi = 100
            else:
                rs = current_gain / current_loss
                rsi = 100 - (100 / (1 + rs))
            
            rsi_values.append(rsi)
            avg_gain = current_gain
            avg_loss = current_loss
        
        # اضافه کردن None برای نقاط اولیه
        rsi_history = [None] * period
        rsi_history.extend(rsi_values)
        
        # اطمینان از طول برابر
        if len(rsi_history) < len(prices):
            rsi_history.extend([None] * (len(prices) - len(rsi_history)))
        
        return rsi_history[:len(prices)]
    
    def get_output_column_name(self) -> str:
        return f"rsi_{self.period}"
    
    def get_config_params(self) -> Dict[str, Any]:
        return {'period': self.period}