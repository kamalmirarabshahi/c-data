"""
کلاس پایه برای تمام اندیکاتورها
"""

from abc import ABC, abstractmethod
from typing import List, Optional, Dict, Any


class BaseIndicator(ABC):
    """کلاس پایه انتزاعی برای تمام اندیکاتورها"""
    
    def __init__(self, name: str, description: str = ""):
        self.name = name
        self.description = description
        self.requires_minimum_data = True
        self.minimum_data_points = 0
    
    @abstractmethod
    def calculate_history(self, data: List[float], **params) -> List[Optional[float]]:
        """
        محاسبه تاریخچه کامل اندیکاتور
        
        Args:
            data: لیست مقادیر (مثلاً قیمت‌های بسته)
            **params: پارامترهای اختصاصی اندیکاتور
            
        Returns:
            لیست مقادیر اندیکاتور برای هر نقطه (نقاط اولیه ممکن است None باشند)
        """
        pass
    
    def validate_data(self, data: List[float]) -> bool:
        """اعتبارسنجی داده‌های ورودی"""
        if not data:
            return False
        if self.requires_minimum_data and len(data) < self.minimum_data_points:
            return False
        return True
    
    def get_required_columns(self) -> List[str]:
        """ستون‌های مورد نیاز از دیتابیس"""
        return ['close_price']  # پیش‌فرض
    
    def get_output_column_name(self) -> str:
        """نام ستون خروجی در دیتابیس"""
        return f"{self.name.lower().replace(' ', '_')}"
    
    def get_config_params(self) -> Dict[str, Any]:
        """پارامترهای پیکربندی از تنظیمات"""
        return {}