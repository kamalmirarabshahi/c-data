﻿#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
تکه ۴ ساده شده - تحلیل پیشرفته
نسخه ساده و مطمئن
"""

import os
import sys
import json
import sqlite3
import logging
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional

# اضافه کردن مسیر پروژه
PROJECT_ROOT = r"C:\Users\Kamal\Desktop\py-prg\git\c-data"
sys.path.insert(0, PROJECT_ROOT)

# تنظیم لاگ‌گیری
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(os.path.join(PROJECT_ROOT, "logs", "cycle_04_simple.log")),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)


class SimpleCycle4:
    """نسخه ساده شده تکه ۴"""
    
    def __init__(self):
        self.db_path = os.path.join(PROJECT_ROOT, "data", "crypto_master.db")
        self.state_file = os.path.join(PROJECT_ROOT, "state", "cycle_state.json")
        
        logger.info("🚀 SimpleCycle4 راه‌اندازی شد")
    
    def load_block_coins(self, block_id: int) -> List[Dict[str, Any]]:
        """بارگذاری ارزهای یک بلوک"""
        try:
            with open(self.state_file, 'r', encoding='utf-8') as f:
                state = json.load(f)
            
            # پیدا کردن بلوک مورد نظر
            current_block = None
            for block in state.get("blocks", []):
                if block.get("block_id") == block_id:
                    current_block = block
                    break
            
            if not current_block:
                available_blocks = [b.get("block_id") for b in state.get("blocks", [])]
                logger.error(f"بلوک {block_id} یافت نشد. بلوک‌های موجود: {available_blocks}")
                return []
            
            coins = current_block.get("coins", [])
            logger.info(f"📦 بلوک {block_id}: {len(coins)} ارز بارگذاری شد")
            
            return coins
            
        except Exception as e:
            logger.error(f"❌ خطا در بارگذاری بلوک {block_id}: {e}")
            return []
    
    def get_coin_candles(self, coin_id: int, limit: int = 50) -> List[Dict[str, Any]]:
        """دریافت کندل‌های یک ارز"""
        try:
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            cursor.execute("""
                SELECT * FROM crypto_klines 
                WHERE coin_id = ? 
                ORDER BY open_time DESC 
                LIMIT ?
            """, (coin_id, limit))
            
            candles = [dict(row) for row in cursor.fetchall()]
            conn.close()
            
            # مرتب کردن از قدیم به جدید
            candles.reverse()
            
            return candles
            
        except Exception as e:
            logger.error(f"❌ خطا در دریافت کندل‌ها برای ارز {coin_id}: {e}")
            return []
    
    def analyze_candles(self, candles: List[Dict[str, Any]]) -> Dict[str, Any]:
        """تحلیل ساده کندل‌ها"""
        if not candles:
            return {"error": "داده‌ای وجود ندارد"}
        
        # آخرین کندل
        latest = candles[-1]
        
        # محاسبات ساده
        analysis = {
            "current_price": latest.get("close_price"),
            "rsi": latest.get("rsi"),
            "macd": latest.get("macd"),
            "ma_7": latest.get("ma_7"),
            "ma_25": latest.get("ma_25"),
            "volume": latest.get("volume"),
            "price_change": None,
            "signal": "HOLD",
            "confidence": 0.5
        }
        
        # محاسبه تغییرات قیمت
        if len(candles) >= 2:
            prev_close = candles[-2].get("close_price")
            current_close = latest.get("close_price")
            if prev_close and current_close:
                analysis["price_change"] = current_close - prev_close
                analysis["price_change_percent"] = ((current_close - prev_close) / prev_close) * 100
        
        # تولید سیگنال ساده بر اساس RSI
        rsi = latest.get("rsi")
        if rsi:
            if rsi < 30:
                analysis["signal"] = "BUY"
                analysis["confidence"] = 0.8
                analysis["reason"] = "RSI اشباع فروش"
            elif rsi > 70:
                analysis["signal"] = "SELL"
                analysis["confidence"] = 0.8
                analysis["reason"] = "RSI اشباع خرید"
        
        # بررسی میانگین متحرک
        current_price = latest.get("close_price")
        ma_7 = latest.get("ma_7")
        ma_25 = latest.get("ma_25")
        
        if current_price and ma_7 and ma_25:
            if current_price > ma_7 > ma_25:
                analysis["signal"] = "BUY"
                analysis["confidence"] = max(analysis["confidence"], 0.7)
                analysis["reason"] = "روند صعودی قوی"
            elif current_price < ma_7 < ma_25:
                analysis["signal"] = "SELL"
                analysis["confidence"] = max(analysis["confidence"], 0.7)
                analysis["reason"] = "روند نزولی قوی"
        
        return analysis
    
    def save_signal(self, coin_id: int, symbol: str, analysis: Dict[str, Any]) -> bool:
        """ذخیره سیگنال در دیتابیس"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            current_price = analysis.get("current_price", 0)
            signal = analysis.get("signal")
            
            # محاسبه حد ضرر و حد سود
            if signal == "BUY":
                stop_loss = current_price * 0.97  # 3% حد ضرر
                take_profit = current_price * 1.06  # 6% حد سود
            elif signal == "SELL":
                stop_loss = current_price * 1.03  # 3% حد ضرر
                take_profit = current_price * 0.94  # 6% حد سود
            else:
                stop_loss = current_price
                take_profit = current_price
            
            cursor.execute("""
                INSERT INTO trading_signals 
                (coin_id, symbol, signal_type, confidence, entry_price, 
                 stop_loss, take_profit, generated_at, expires_at, status)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                coin_id,
                symbol,
                signal,
                analysis.get("confidence"),
                current_price,
                stop_loss,
                take_profit,
                datetime.now().isoformat(),
                (datetime.now() + timedelta(hours=4)).isoformat(),
                "ACTIVE"
            ))
            
            signal_id = cursor.lastrowid
            conn.commit()
            conn.close()
            
            logger.info(f"💾 سیگنال {symbol} ذخیره شد (ID: {signal_id})")
            return True
            
        except Exception as e:
            logger.error(f"❌ خطا در ذخیره سیگنال {symbol}: {e}")
            return False
    
    def process_coin(self, coin: Dict[str, Any]) -> Dict[str, Any]:
        """پردازش یک ارز"""
        coin_id = coin.get("id")
        symbol = coin.get("symbol", f"UNKNOWN_{coin_id}")
        
        logger.info(f"🔄 پردازش ارز {symbol}")
        
        # دریافت کندل‌ها
        candles = self.get_coin_candles(coin_id, limit=50)
        
        if not candles:
            logger.warning(f"⚠️ داده‌ای برای {symbol} یافت نشد")
            return {
                "coin_id": coin_id,
                "symbol": symbol,
                "status": "failed",
                "reason": "no_data"
            }
        
        # تحلیل کندل‌ها
        analysis = self.analyze_candles(candles)
        
        # ذخیره سیگنال اگر خرید یا فروش باشد
        saved = False
        if analysis.get("signal") in ["BUY", "SELL"]:
            saved = self.save_signal(coin_id, symbol, analysis)
        
        return {
            "coin_id": coin_id,
            "symbol": symbol,
            "status": "completed",
            "analysis": analysis,
            "saved": saved,
            "candles_analyzed": len(candles)
        }
    
    def process_block(self, block_id: int, max_coins: Optional[int] = None) -> Dict[str, Any]:
        """پردازش کامل یک بلوک"""
        
        logger.info(f"🚀 شروع پردازش بلوک {block_id}")
        start_time = datetime.now()
        
        # بارگذاری ارزهای بلوک
        coins = self.load_block_coins(block_id)
        
        if not coins:
            return {"success": False, "error": "بلوک خالی است یا یافت نشد"}
        
        # محدود کردن برای تست
        if max_coins and max_coins < len(coins):
            coins = coins[:max_coins]
            logger.info(f"🔧 حالت تست: پردازش {max_coins} ارز اول")
        
        # پردازش هر ارز
        results = []
        signals_generated = 0
        
        for i, coin in enumerate(coins, 1):
            logger.info(f"📊 ارز {i}/{len(coins)}: {coin.get('symbol')}")
            
            result = self.process_coin(coin)
            results.append(result)
            
            if result["status"] == "completed" and result.get("analysis", {}).get("signal") in ["BUY", "SELL"]:
                signals_generated += 1
        
        # محاسبه زمان اجرا
        execution_time = (datetime.now() - start_time).total_seconds()
        
        # تولید گزارش
        report = {
            "block_id": block_id,
            "processed_at": datetime.now().isoformat(),
            "execution_time_seconds": execution_time,
            "total_coins": len(coins),
            "successful_coins": sum(1 for r in results if r["status"] == "completed"),
            "failed_coins": sum(1 for r in results if r["status"] == "failed"),
            "signals_generated": signals_generated,
            "results": results
        }
        
        # ذخیره گزارش
        self.save_report(report, block_id)
        
        logger.info(f"🏁 پردازش بلوک {block_id} تکمیل شد")
        logger.info(f"   ✅ موفق: {report['successful_coins']}/{len(coins)}")
        logger.info(f"   ❌ ناموفق: {report['failed_coins']}/{len(coins)}")
        logger.info(f"   🎯 سیگنال‌ها: {signals_generated}")
        logger.info(f"   ⏱️ زمان اجرا: {execution_time:.2f} ثانیه")
        
        return report
    
    def save_report(self, report: Dict[str, Any], block_id: int):
        """ذخیره گزارش در فایل"""
        try:
            reports_dir = os.path.join(PROJECT_ROOT, "reports", "cycle_04_simple")
            os.makedirs(reports_dir, exist_ok=True)
            
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"block_{block_id:03d}_{timestamp}.json"
            filepath = os.path.join(reports_dir, filename)
            
            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump(report, f, indent=2, ensure_ascii=False)
            
            logger.info(f"📄 گزارش ذخیره شد: {filepath}")
            
        except Exception as e:
            logger.error(f"❌ خطا در ذخیره گزارش: {e}")


def main():
    """تابع اصلی اجرا"""
    import argparse
    
    parser = argparse.ArgumentParser(description='تکه ۴ ساده شده - تحلیل پیشرفته')
    parser.add_argument('--block', type=int, default=1, help='شماره بلوک برای پردازش (1-15)')
    parser.add_argument('--test', action='store_true', help='حالت تست (پردازش فقط ۲ ارز اول)')
    parser.add_argument('--max-coins', type=int, help='حداکثر تعداد ارز برای پردازش')
    
    args = parser.parse_args()
    
    print("=" * 60)
    print("🚀 اجرای تکه ۴ ساده شده - تحلیل پیشرفته")
    print("=" * 60)
    
    # ایجاد نمونه
    processor = SimpleCycle4()
    
    # تعیین تعداد ارز برای پردازش
    max_coins = None
    if args.test:
        max_coins = 2
        print("🔧 اجرا در حالت تست (۲ ارز اول)")
    elif args.max_coins:
        max_coins = args.max_coins
        print(f"🔧 محدودیت پردازش: حداکثر {max_coins} ارز")
    
    try:
        # پردازش بلوک
        report = processor.process_block(args.block, max_coins=max_coins)
        
        if report.get("success") is not False:
            print("\n" + "=" * 60)
            print("✅ تکه ۴ با موفقیت اجرا شد!")
            print(f"   بلوک: {args.block}")
            print(f"   ارزهای پردازش شده: {report['total_coins']}")
            print(f"   سیگنال‌های تولید شده: {report['signals_generated']}")
            print(f"   زمان اجرا: {report['execution_time_seconds']:.2f} ثانیه")
            
            # نمایش خلاصه سیگنال‌ها
            if report['signals_generated'] > 0:
                print("\n📊 سیگنال‌های تولید شده:")
                for result in report['results']:
                    if result.get('status') == 'completed' and result.get('analysis', {}).get('signal') in ['BUY', 'SELL']:
                        symbol = result['symbol']
                        signal = result['analysis']['signal']
                        confidence = result['analysis']['confidence']
                        reason = result['analysis'].get('reason', '')
                        print(f"   {symbol}: {signal} ({confidence:.1%}) - {reason}")
            
            print("=" * 60)
        else:
            print(f"\n❌ اجرا ناموفق بود: {report.get('error')}")
            
    except Exception as e:
        print(f"\n❌ خطای غیرمنتظره: {e}")
        import traceback
        traceback.print_exc()
        return 1
    
    return 0


if __name__ == "__main__":
    sys.exit(main())
