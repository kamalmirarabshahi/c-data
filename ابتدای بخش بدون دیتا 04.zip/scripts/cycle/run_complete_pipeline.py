"""
فایل: run_complete_pipeline.py
مسیر: /scripts/cycle/run_complete_pipeline.py
عملکرد: اجرای کامل مراحل 2-5 برای هر بلوک به ترتیب
"""

import os
import sys
import json
import time
import subprocess
import argparse

def run_stage(script_name, block_id=None, stage_name=""):
    """اجرای یک مرحله برای بلوک خاص"""
    current_dir = os.path.dirname(os.path.abspath(__file__))
    script_path = os.path.join(current_dir, script_name)
    
    if not os.path.exists(script_path):
        print(f"   ⏭️ {stage_name} - فایل وجود ندارد: {script_name}")
        return True  # ادامه بده حتی اگر فایل نیست
    
    print(f"   🔄 {stage_name}...")
    
    try:
        # ساخت فرمان
        cmd = [sys.executable, script_path]
        
        # اگر اسکریپت پارامتر بلوک بگیرد، اضافه کن
        if block_id and script_name == "cycle_02_process_block.py":
            cmd.extend(["--block", str(block_id)])
        
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            encoding='utf-8'
        )
        
        # نمایش خروجی مهم
        if result.stdout:
            lines = result.stdout.split('\n')
            for line in lines:
                if '✅' in line or '❌' in line or '🎉' in line or 'خطا' in line:
                    print(f"     {line.strip()}")
        
        if result.stderr and 'error' in result.stderr.lower():
            print(f"     ⚠️ {result.stderr.strip()[:100]}")
        
        return result.returncode == 0
        
    except Exception as e:
        print(f"     ❌ خطا در اجرای {script_name}: {e}")
        return False

def get_cycle_info():
    """دریافت اطلاعات چرخه از state"""
    current_dir = os.path.dirname(os.path.abspath(__file__))
    state_file = os.path.join(current_dir, "..", "..", "state", "cycle_state.json")
    
    if not os.path.exists(state_file):
        print(f"❌ فایل وضعیت یافت نشد: {state_file}")
        return None
    
    try:
        with open(state_file, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception as e:
        print(f"❌ خطا در خواندن فایل state: {e}")
        return None

def main(start_block=1):
    """تابع اصلی اجرای پاپلاین کامل"""
    print("=" * 70)
    print("🔄 اجرای پاپلاین کامل برای هر بلوک")
    print("🎯 هر بلوک: مرحله 2 → 3 → 4 → 5")
    print("=" * 70)
    
    # دریافت اطلاعات چرخه
    print("\n📋 دریافت اطلاعات چرخه...")
    cycle_info = get_cycle_info()
    
    if not cycle_info:
        print("❌ اطلاعات چرخه یافت نشد. ابتدا مرحله 1 را اجرا کنید.")
        return
    
    total_blocks = cycle_info['stats']['total_blocks']
    cycle_id = cycle_info['cycle_id']
    
    print(f"   • شناسه چرخه: {cycle_id}")
    print(f"   • تعداد کل بلوک‌ها: {total_blocks}")
    print(f"   • شروع از بلوک: {start_block}")
    
    # تعریف مراحل
    stages = [
        ("cycle_02_process_block.py", "مرحله 2: جمع‌آوری داده"),
        ("cycle_03_data_analyzer.py", "مرحله 3: تحلیل داده"),
        ("cycle_04_report_generator.py", "مرحله 4: تولید گزارش"),
        ("cycle_05_cleanup.py", "مرحله 5: پاکسازی")
    ]
    
    # پردازش هر بلوک
    for block_id in range(start_block, total_blocks + 1):
        print(f"\n{'='*60}")
        print(f"📦 بلوک {block_id} از {total_blocks}")
        print(f"{'='*60}")
        
        block_start_time = time.time()
        
        # اجرای تمام مراحل برای این بلوک
        all_stages_successful = True
        
        for script, stage_name in stages:
            stage_success = run_stage(script, block_id, stage_name)
            
            if not stage_success and script == "cycle_02_process_block.py":
                print(f"     ⚠️ خطا در مرحله 2 - احتمالاً ارزهای این بلوک مشکل دارند")
                # باز هم ادامه بده به مراحل بعدی
            elif not stage_success:
                print(f"     ⚠️ خطا در {stage_name}")
                all_stages_successful = False
            
            # استراحت کوتاه بین مراحل
            time.sleep(1)
        
        block_time = time.time() - block_start_time
        
        # نمایش نتیجه بلوک
        print(f"\n   📊 نتیجه بلوک {block_id}:")
        print(f"      • زمان کل: {block_time:.1f} ثانیه")
        print(f"      • وضعیت: {'✅ کامل' if all_stages_successful else '⚠️ با خطا'}")
        
        # استراحت بین بلوک‌ها (اگر بلوک آخر نیست)
        if block_id < total_blocks:
            wait_time = 3
            print(f"\n   ⏳ {wait_time} ثانیه تا بلوک بعدی...")
            time.sleep(wait_time)
    
    # نتیجه نهایی
    print("\n" + "=" * 70)
    print("🎉 پاپلاین کامل اجرا شد!")
    print("=" * 70)
    
    print(f"\n📊 آمار نهایی:")
    print(f"   • کل بلوک‌ها: {total_blocks}")
    print(f"   • بلوک‌های پردازش شده: {total_blocks - start_block + 1}")
    print(f"   • شناسه چرخه: {cycle_id}")
    
    # پیشنهاد مرحله بعد
    print(f"\n💡 مرحله بعد:")
    print("   برای شروع چرخه جدید: python scripts/cycle/cycle_01_coin_filter.py")

if __name__ == "__main__":
    # ایجاد پارسر آرگومان
    parser = argparse.ArgumentParser(
        description='اجرای کامل پاپلاین مراحل 2-5 برای هر بلوک',
        epilog='''
مثال:
  %(prog)s              # شروع از بلوک 1
  %(prog)s --start 3    # شروع از بلوک 3
        '''
    )
    
    parser.add_argument(
        '--start', '-s',
        type=int,
        default=1,
        help='شماره بلوک شروع (پیش‌فرض: 1)'
    )
    
    args = parser.parse_args()
    
    try:
        main(args.start)
    except KeyboardInterrupt:
        print("\n\n⏹️ اجرا توسط کاربر متوقف شد")
    except Exception as e:
        print(f"\n❌ خطای غیرمنتظره: {e}")
        