"""
فایل: cycle_01_coin_filter.py
مسیر: /cycle/cycle_01_coin_filter.py
عملکرد: دریافت تمام ارزهای فعال، فیلتر و تقسیم به بخش‌های رندوم
          + دریافت آخرین کندل 15 دقیقه‌ای هر ارز از جدول crypto_klines
          + سورت بر اساس تاریخ کندل (قدیمی‌ترین اول)
          + ذخیره last_updated_readable در جدول crypto_coins
تاریخ: 2024-01-15
ورژن: 2.7 (ذخیره last_updated_readable در crypto_coins)
"""

import os
import sys
import sqlite3
import random
import json
import time
from datetime import datetime
from pathlib import Path

# ==================== CONFIGURATION ====================
def load_config():
    """بارگذاری تنظیمات از config_manager"""
    try:
        # اضافه کردن مسیرهای لازم به sys.path
        current_dir = os.path.dirname(os.path.abspath(__file__))
        scripts_dir = os.path.dirname(current_dir)
        project_root_default = os.path.dirname(scripts_dir)
        
        # اول scripts_dir را اضافه کنیم
        if scripts_dir not in sys.path:
            sys.path.insert(0, scripts_dir)
        
        # سپس project_root_default را اضافه کنیم
        if project_root_default not in sys.path:
            sys.path.insert(0, project_root_default)
        
        print(f"📁 پوشه اسکریپت: {scripts_dir}")
        print(f"📁 ریشه پروژه پیش‌فرض: {project_root_default}")
        
        # import config_manager
        try:
            from config_manager import get, get_database_path
        except ImportError as e:
            return {"success": False, "error": f"خطا در import config_manager: {str(e)}"}
        
        # خواندن project_root از تنظیمات
        project_root = get('paths.project_root', project_root_default)
        
        # اگر مسیر نسبی است، آن را مطلق کنیم
        if not os.path.isabs(project_root):
            project_root = os.path.abspath(project_root)
        
        # اطمینان از فرمت صحیح مسیر
        project_root = project_root.replace('\\', '/')
        
        config = {
            "database_path": get_database_path(),
            "min_block_size": get('collection.min_block_size', 10),
            "max_block_size": get('collection.max_block_size', 50),
            "min_volume_usd": get('filters.min_volume_usd', 0),
            "min_price": get('filters.min_price', 0.001),
            "active_days": get('filters.active_days', 30),
            "kline_timeframe": get('filters.kline_timeframe', '15m'),
            "project_root": project_root
        }
        
        # ایجاد پوشه state در ریشه پروژه (از تنظیمات)
        state_dir = os.path.join(project_root, "state")
        os.makedirs(state_dir, exist_ok=True)
        
        config["state_file"] = os.path.join(state_dir, "cycle_state.json")
        
        print(f"✅ project_root از تنظیمات: {project_root}")
        print(f"📁 پوشه state: {state_dir}")
        print(f"📁 فایل state: {config['state_file']}")
        
        return {"success": True, "config": config}
        
    except Exception as e:
        return {"success": False, "error": f"خطا در بارگذاری تنظیمات: {str(e)}"}

# ==================== UTILITY FUNCTIONS ====================
def convert_to_timestamp_ms(time_value):
    """تبدیل انواع مختلف زمان به timestamp میلی‌ثانیه"""
    if time_value is None:
        return None
    
    try:
        # اگر عدد است (timestamp)
        if isinstance(time_value, (int, float)):
            # تشخیص واحد (ثانیه یا میلی‌ثانیه)
            if time_value < 10000000000:  # اگر کمتر از 2286/11/21 باشد احتمالاً ثانیه است
                return int(time_value * 1000)
            else:
                return int(time_value)
        
        # اگر رشته است
        elif isinstance(time_value, str):
            # حذف فضای خالی اضافی
            time_str = time_value.strip()
            
            # اگر رشته خالی است
            if not time_str:
                return None
            
            # ابتدا سعی کنیم میکروثانیه را حذف کنیم
            if '.' in time_str:
                # فقط قسمت تاریخ/زمان را بگیریم (تا ثانیه)
                base_time = time_str.split('.')[0]
                # فرمت بدون میکروثانیه
                formats = [
                    '%Y-%m-%d %H:%M:%S',     # بدون میکروثانیه
                    '%Y-%m-%dT%H:%M:%S',     # فرمت ISO بدون میکروثانیه
                    '%Y/%m/%d %H:%M:%S',     # فرمت دیگر
                ]
                
                for fmt in formats:
                    try:
                        dt = datetime.strptime(base_time, fmt)
                        return int(dt.timestamp() * 1000)
                    except ValueError:
                        continue
            
            # فرمت‌های کامل
            formats = [
                '%Y-%m-%d %H:%M:%S.%f',      # با میکروثانیه: '2025-12-30 10:44:59.999000'
                '%Y-%m-%d %H:%M:%S',         # بدون میکروثانیه
                '%Y-%m-%dT%H:%M:%S.%f',      # فرمت ISO با میکروثانیه
                '%Y-%m-%dT%H:%M:%S',         # فرمت ISO بدون میکروثانیه
                '%Y/%m/%d %H:%M:%S.%f',      # فرمت دیگر با میکروثانیه
                '%Y/%m/%d %H:%M:%S',         # فرمت دیگر بدون میکروثانیه
                '%Y-%m-%d %H:%M',            # فقط تاریخ و ساعت
                '%Y-%m-%d',                  # فقط تاریخ
            ]
            
            for fmt in formats:
                try:
                    dt = datetime.strptime(time_str, fmt)
                    return int(dt.timestamp() * 1000)
                except ValueError:
                    continue
            
            # اگر هیچکدام جواب نداد، امتحان کنیم شاید timestamp به صورت رشته است
            try:
                num_value = float(time_str)
                if num_value < 10000000000:
                    return int(num_value * 1000)
                else:
                    return int(num_value)
            except:
                pass
            
            print(f"⚠️ فرمت زمان تشخیص داده نشد: {repr(time_str)}")
            return None
        
        # اگر datetime object است
        elif hasattr(time_value, 'timestamp'):
            return int(time_value.timestamp() * 1000)
        
        return None
        
    except Exception as e:
        print(f"⚠️ خطا در تبدیل زمان: {repr(time_value)} - {e}")
        return None

def timestamp_to_iso_date(timestamp_ms):
    """تبدیل timestamp میلی‌ثانیه به تاریخ میلادی ISO format"""
    try:
        if not timestamp_ms:
            return None
        dt = datetime.fromtimestamp(timestamp_ms / 1000)
        return dt.isoformat()  # فرمت: 2024-01-15T10:30:45.123456
    except Exception as e:
        print(f"⚠️ خطا در تبدیل timestamp به تاریخ ISO: {e}")
        return None

def timestamp_to_readable_date(timestamp_ms, format_str='%Y-%m-%d %H:%M:%S'):
    """تبدیل timestamp میلی‌ثانیه به تاریخ قابل خواندن"""
    try:
        if not timestamp_ms:
            return None
        dt = datetime.fromtimestamp(timestamp_ms / 1000)
        return dt.strftime(format_str)
    except Exception as e:
        print(f"⚠️ خطا در تبدیل timestamp به تاریخ قابل خواندن: {e}")
        return None

def format_timestamp(timestamp_ms, format_str='%Y-%m-%d %H:%M'):
    """فرمت کردن timestamp به تاریخ قابل خواندن"""
    try:
        if not timestamp_ms:
            return "بدون داده"
        dt = datetime.fromtimestamp(timestamp_ms / 1000)
        return dt.strftime(format_str)
    except:
        return str(timestamp_ms)

def safe_int(value, default=0):
    """تبدیل ایمن به عدد صحیح"""
    if value is None:
        return default
    try:
        return int(value)
    except:
        return default

def safe_float(value, default=0.0):
    """تبدیل ایمن به عدد اعشاری"""
    if value is None:
        return default
    try:
        return float(value)
    except:
        return default

# ==================== DATABASE FUNCTIONS ====================
def debug_coin_mapping(db_path, symbol):
    """بررسی مپینگ coin_id برای یک symbol"""
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # پیدا کردن coin_id از جدول crypto_coins
        cursor.execute("SELECT id, symbol FROM crypto_coins WHERE symbol = ?", (symbol,))
        coin_row = cursor.fetchone()
        
        if not coin_row:
            print(f"❌ {symbol} در جدول crypto_coins یافت نشد")
            conn.close()
            return None
        
        coin_id, symbol_name = coin_row
        
        # بررسی آیا این coin_id در crypto_klines وجود دارد
        cursor.execute("""
            SELECT COUNT(*) as kline_count, 
                   MAX(close_time) as latest_kline
            FROM crypto_klines 
            WHERE coin_id = ? AND timeframe = '15m'
        """, (coin_id,))
        
        kline_result = cursor.fetchone()
        kline_count = kline_result[0] if kline_result else 0
        latest_kline = kline_result[1] if kline_result else None
        
        conn.close()
        
        print(f"   🔍 مپینگ {symbol}:")
        print(f"      - coin_id در crypto_coins: {coin_id}")
        print(f"      - تعداد کندل‌ها در crypto_klines: {kline_count}")
        print(f"      - آخرین کندل: {latest_kline}")
        
        return {
            "coin_id": coin_id,
            "kline_count": kline_count,
            "latest_kline": latest_kline
        }
        
    except sqlite3.Error as e:
        print(f"⚠️ خطای دیتابیس در بررسی مپینگ {symbol}: {e}")
        return None
    except Exception as e:
        print(f"⚠️ خطا در بررسی مپینگ {symbol}: {e}")
        return None

def get_last_kline_time(db_path, symbol, timeframe='15m'):
    """دریافت آخرین زمان کندل برای یک ارز از جدول crypto_klines"""
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # ابتدا بررسی می‌کنیم جدول crypto_klines وجود دارد
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='crypto_klines'")
        if not cursor.fetchone():
            conn.close()
            return None
        
        # کوئری بهینه‌تر با ORDER BY و LIMIT
        query = """
        SELECT k.close_time
        FROM crypto_klines k
        JOIN crypto_coins c ON k.coin_id = c.id
        WHERE c.symbol = ? AND k.timeframe = ?
        ORDER BY k.close_time DESC
        LIMIT 1
        """
        
        cursor.execute(query, (symbol, timeframe))
        result = cursor.fetchone()
        
        conn.close()
        
        if result and result[0]:
            last_kline = result[0]
            timestamp_ms = convert_to_timestamp_ms(last_kline)
            
            # دیباگ برای ارزهای خاص
            if symbol in ['BTCUSDT', 'ETHUSDT', 'BNBUSDT', 'USD1USDT', 'VIRTUALUSDT']:
                print(f"   🔍 {symbol}: close_time={repr(last_kline)}, timestamp={timestamp_ms}, formatted={format_timestamp(timestamp_ms) if timestamp_ms else 'None'}")
            
            return timestamp_ms
        
        return None
        
    except sqlite3.Error as e:
        print(f"⚠️ خطای دیتابیس در دریافت کندل برای {symbol}: {e}")
        return None
    except Exception as e:
        print(f"⚠️ خطا در دریافت کندل برای {symbol}: {e}")
        return None

def check_kline_table_exists(db_path):
    """بررسی وجود جدول crypto_klines"""
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='crypto_klines'")
        exists = cursor.fetchone() is not None
        conn.close()
        return exists
    except:
        return False

def get_kline_table_stats(db_path, timeframe='15m'):
    """دریافت آمار جدول crypto_klines"""
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # آمار کلی
        cursor.execute("""
            SELECT 
                COUNT(*) as total_klines,
                COUNT(DISTINCT coin_id) as unique_coins,
                MIN(close_time) as oldest_close,
                MAX(close_time) as newest_close
            FROM crypto_klines
            WHERE timeframe = ?
        """, (timeframe,))
        
        result = cursor.fetchone()
        
        stats = {}
        if result:
            stats = {
                "total_klines": result[0],
                "unique_coins": result[1],
                "oldest_close": result[2],
                "newest_close": result[3],
                "oldest_timestamp": convert_to_timestamp_ms(result[2]) if result[2] else None,
                "newest_timestamp": convert_to_timestamp_ms(result[3]) if result[3] else None,
                "oldest_iso": timestamp_to_iso_date(convert_to_timestamp_ms(result[2])) if result[2] else None,
                "newest_iso": timestamp_to_iso_date(convert_to_timestamp_ms(result[3])) if result[3] else None
            }
        
        conn.close()
        return stats
        
    except:
        return {}

def update_last_updated_in_coins_table(db_path, coins_with_kline):
    """ذخیره last_updated_readable در جدول crypto_coins"""
    try:
        if not coins_with_kline:
            print("   ⚠️ هیچ ارزی برای آپدیت last_updated وجود ندارد")
            return {"success": False, "updated_count": 0, "error": "لیست ارزها خالی است"}
        
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        updated_count = 0
        error_count = 0
        
        print(f"   🔄 آپدیت last_updated در جدول crypto_coins برای {len(coins_with_kline)} ارز...")
        
        for coin in coins_with_kline:
            symbol = coin.get('symbol')
            last_updated_readable = coin.get('last_updated_readable')
            
            if not symbol or not last_updated_readable:
                error_count += 1
                continue
            
            try:
                cursor.execute("""
                    UPDATE crypto_coins 
                    SET last_updated = ? 
                    WHERE symbol = ?
                """, (last_updated_readable, symbol))
                
                if cursor.rowcount > 0:
                    updated_count += 1
                    
                    # نمایش برخی نمونه‌ها
                    if updated_count <= 3:
                        print(f"      ✅ {symbol}: last_updated = {last_updated_readable}")
                else:
                    error_count += 1
                    if error_count <= 3:
                        print(f"      ⚠️ {symbol}: آپدیت نشد (ارز پیدا نشد)")
                        
            except sqlite3.Error as e:
                error_count += 1
                if error_count <= 3:
                    print(f"      ❌ {symbol}: خطای دیتابیس - {e}")
        
        conn.commit()
        conn.close()
        
        print(f"   📊 نتیجه آپدیت:")
        print(f"      - موفق: {updated_count}")
        print(f"      - ناموفق: {error_count}")
        print(f"      - کل ارزها: {len(coins_with_kline)}")
        
        return {"success": True, "updated_count": updated_count, "error_count": error_count}
        
    except sqlite3.Error as e:
        print(f"   ❌ خطای دیتابیس در آپدیت last_updated: {e}")
        return {"success": False, "updated_count": 0, "error": f"خطای دیتابیس: {str(e)}"}
    except Exception as e:
        print(f"   ❌ خطای ناشناخته در آپدیت last_updated: {e}")
        return {"success": False, "updated_count": 0, "error": f"خطای ناشناخته: {str(e)}"}

def get_all_active_coins(db_path, timeframe='15m'):
    """دریافت تمام ارزهای فعال از دیتابیس + آخرین کندل"""
    try:
        if not os.path.exists(db_path):
            return {"success": False, "error": f"فایل دیتابیس یافت نشد: {db_path}"}
        
        conn = sqlite3.connect(db_path)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        
        # بررسی وجود جدول crypto_coins
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='crypto_coins'")
        if not cursor.fetchone():
            conn.close()
            return {"success": False, "error": "جدول crypto_coins وجود ندارد"}
        
        # بررسی وجود جدول crypto_klines
        kline_table_exists = check_kline_table_exists(db_path)
        if not kline_table_exists:
            print("   ⚠️ هشدار: جدول crypto_klines وجود ندارد - last_kline_update و last_updated_ts همیشه None خواهد بود")
        
        # دریافت آمار کلی
        cursor.execute("SELECT COUNT(*) as total_coins FROM crypto_coins")
        total_coins = cursor.fetchone()[0]
        
        # دریافت آمار کندل‌ها برای لاگ
        if kline_table_exists:
            kline_stats = get_kline_table_stats(db_path, timeframe)
            if kline_stats:
                print(f"   📊 آمار جدول crypto_klines ({timeframe}):")
                print(f"      - کل کندل‌ها: {kline_stats.get('total_klines', 0):,}")
                print(f"      - ارزهای منحصر به فرد: {kline_stats.get('unique_coins', 0)}")
                print(f"      - قدیمی‌ترین: {kline_stats.get('oldest_close', 'N/A')}")
                print(f"      - جدیدترین: {kline_stats.get('newest_close', 'N/A')}")
                print(f"      - قدیمی‌ترین (ISO): {kline_stats.get('oldest_iso', 'N/A')}")
                print(f"      - جدیدترین (ISO): {kline_stats.get('newest_iso', 'N/A')}")
                
                newest_ts = kline_stats.get('newest_timestamp')
                if newest_ts:
                    age_minutes = (int(time.time() * 1000) - newest_ts) / (1000 * 60)
                    print(f"      - سن جدیدترین داده: {age_minutes:.1f} دقیقه")
        
        # بررسی مپینگ برای ارزهای اصلی
        if kline_table_exists:
            print(f"   🔍 بررسی مپینگ ارزهای اصلی:")
            for symbol in ['BTCUSDT', 'ETHUSDT', 'BNBUSDT', 'USD1USDT', 'VIRTUALUSDT']:
                debug_coin_mapping(db_path, symbol)
        
        # دریافت تمام ارزهای فعال (با قیمت مثبت)
        query = """
        SELECT 
            id, symbol, base_asset, coin_name,
            current_price, volume_24h, market_cap,
            price_change_24h, price_change_percent_24h,
            high_24h, low_24h, market_cap_rank,
            last_updated, created_at
        FROM crypto_coins
        WHERE current_price > 0 AND is_active < 5
        """
        
        cursor.execute(query)
        
        all_active_coins = []
        coins_with_kline = []
        coins_without_kline = []
        
        # شمارنده برای نمایش پیشرفت
        total_fetched = 0
        batch_size = 50
        print(f"   🔄 دریافت اطلاعات کندل برای ارزها...")
        
        for row in cursor.fetchall():
            coin_dict = dict(row)
            total_fetched += 1
            
            # نمایش پیشرفت هر 50 ارز
            if total_fetched % batch_size == 0:
                print(f"      📊 پردازش {total_fetched} ارز...")
            
            # ✅ دریافت آخرین زمان کندل از جدول crypto_klines برای last_updated_ts
            last_kline_time = None
            if kline_table_exists:
                last_kline_time = get_last_kline_time(db_path, coin_dict['symbol'], timeframe)
            
            # ✅ تغییر مهم: استفاده از close_time از crypto_klines برای last_updated_ts
            coin_dict['last_kline_update'] = last_kline_time
            coin_dict['last_updated_ts'] = last_kline_time  # اکنون از close_time استفاده می‌کند
            
            # ✅ اضافه کردن تاریخ میلادی به فرمت‌های مختلف
            if last_kline_time:
                coin_dict['last_updated_iso'] = timestamp_to_iso_date(last_kline_time)
                coin_dict['last_updated_readable'] = timestamp_to_readable_date(last_kline_time)
            else:
                coin_dict['last_updated_iso'] = None
                coin_dict['last_updated_readable'] = None
            
            # افزودن timestamp فعلی برای مقایسه
            coin_dict['current_timestamp'] = int(time.time() * 1000)  # میلی‌ثانیه
            
            # ذخیره last_updated اصلی از crypto_coins
            coin_dict['last_updated_original'] = coin_dict.get('last_updated')
            
            # استفاده از توابع ایمن برای تبدیل مقادیر
            coin_dict['volume_24h'] = safe_float(coin_dict.get('volume_24h'), 0)
            coin_dict['current_price'] = safe_float(coin_dict.get('current_price'), 0)
            coin_dict['market_cap_rank'] = safe_int(coin_dict.get('market_cap_rank'), 999999)
            coin_dict['name'] = coin_dict.get('coin_name', coin_dict.get('symbol', 'Unknown'))
            coin_dict['is_active'] = 1
            
            # جداسازی ارزهای با و بدون کندل
            if last_kline_time:
                coins_with_kline.append(coin_dict)
            else:
                coins_without_kline.append(coin_dict)
        
        conn.close()
        
        # ✅ سورت ارزها بر اساس last_updated_ts (که اکنون از close_time می‌آید) - قدیمی‌ترین اول
        print(f"   🔄 سورت ارزها بر اساس last_updated_ts (از close_time کندل)...")
        print(f"      - ارزهای دارای کندل: {len(coins_with_kline)}")
        print(f"      - ارزهای بدون کندل: {len(coins_without_kline)}")
        
        # سورت ارزهای دارای کندل بر اساس last_updated_ts (صعودی = قدیمی‌ترین اول)
        # ارزهای با last_updated_ts = None به انتها می‌روند
        coins_with_kline.sort(key=lambda x: x['last_updated_ts'] if x['last_updated_ts'] is not None else float('inf'))
        
        # سورت ارزهای بدون کندل بر اساس market_cap_rank (کوچک‌تر = بهتر)
        coins_without_kline.sort(key=lambda x: x.get('market_cap_rank', 999999))
        
        # ترکیب لیست‌ها: اول ارزهای با کندل (قدیمی‌ترین اول)، سپس ارزهای بدون کندل
        all_active_coins = coins_with_kline + coins_without_kline
        
        # محاسبه آمار last_updated_ts (که اکنون از close_time می‌آید)
        kline_time_stats = {}
        if coins_with_kline:
            kline_times = [c['last_updated_ts'] for c in coins_with_kline if c.get('last_updated_ts')]
            if kline_times:
                current_time = int(time.time() * 1000)
                kline_time_stats = {
                    'oldest_kline': min(kline_times),
                    'newest_kline': max(kline_times),
                    'oldest_kline_iso': timestamp_to_iso_date(min(kline_times)),
                    'newest_kline_iso': timestamp_to_iso_date(max(kline_times)),
                    'oldest_kline_readable': timestamp_to_readable_date(min(kline_times)),
                    'newest_kline_readable': timestamp_to_readable_date(max(kline_times)),
                    'avg_kline_age': (current_time - (sum(kline_times) / len(kline_times))) / (1000 * 60 * 60),  # ساعت
                    'timeframe': timeframe,
                    'total_coins_with_kline': len(kline_times)
                }
        
        return {
            "success": True, 
            "all_active_coins": all_active_coins,
            "coins_with_kline": coins_with_kline,  # اضافه شده برای آپدیت جدول
            "total_coins_in_db": total_coins,
            "active_coins_count": len(all_active_coins),
            "count": len(all_active_coins),
            "kline_stats": {
                "coins_with_kline": len(coins_with_kline),
                "coins_without_kline": len(coins_without_kline),
                "percentage_with_kline": f"{(len(coins_with_kline)/len(all_active_coins)*100):.1f}%" if all_active_coins else "0%",
                "time_stats": kline_time_stats,
                "kline_table_exists": kline_table_exists,
                "source_for_last_updated_ts": "crypto_klines.close_time"
            }
        }
        
    except sqlite3.Error as e:
        return {"success": False, "error": f"خطای دیتابیس: {str(e)}"}
    except Exception as e:
        return {"success": False, "error": f"خطای ناشناخته: {str(e)}"}

def apply_filters(coins, filters):
    """اعمال فیلترها بر روی لیست ارزها"""
    try:
        filtered_coins = []
        
        for coin in coins:
            volume_ok = coin.get('volume_24h', 0) >= filters["min_volume_usd"]
            price_ok = coin.get('current_price', 0) >= filters["min_price"]
            
            if volume_ok and price_ok:
                filtered_coins.append(coin)
        
        return filtered_coins
        
    except Exception as e:
        print(f"⚠️ خطا در اعمال فیلترها: {e}")
        return coins

# ==================== BLOCK CREATION ====================
def create_priority_blocks(coins, min_size, max_size):
    """
    ایجاد بلوک‌ها با حفظ ترتیب اولویت
    ارزهای قدیمی‌تر (بر اساس last_updated_ts از close_time) در بلوک‌های اول قرار می‌گیرند
    """
    try:
        if not coins:
            return {"success": False, "error": "لیست ارزها خالی است"}
        
        total_coins = len(coins)
        blocks = []
        remaining_coins = coins.copy()  # لیست از قبل سورت شده بر اساس last_updated_ts
        
        print(f"   🔄 ایجاد بلوک‌ها با اولویت زمانی (بر اساس last_updated_ts از close_time)...")
        print(f"   📊 ارزهای موجود: {total_coins} ارز (از قبل سورت شده)")
        
        block_number = 1
        while remaining_coins:
            current_max = min(max_size, len(remaining_coins))
            if current_max < min_size:
                block_size = len(remaining_coins)
            else:
                # اندازه بلوک را تصادفی انتخاب می‌کنیم اما ترتیب را حفظ می‌کنیم
                block_size = random.randint(min_size, current_max)
            
            # ایجاد بلوک از ابتدای لیست (قدیمی‌ترین ارزها بر اساس close_time)
            block_coins = remaining_coins[:block_size]
            remaining_coins = remaining_coins[block_size:]
            
            # محاسبه آمار بلوک
            total_volume = sum(safe_float(coin.get('volume_24h', 0)) for coin in block_coins)
            avg_price = sum(safe_float(coin.get('current_price', 0)) for coin in block_coins) / len(block_coins) if block_coins else 0
            
            # محاسبه آمار last_updated_ts برای این بلوک (که از close_time می‌آید)
            block_kline_times = [c.get('last_updated_ts') for c in block_coins if c.get('last_updated_ts')]
            block_kline_stats = {}
            if block_kline_times:
                current_time = int(time.time() * 1000)
                avg_age_hours = (current_time - (sum(block_kline_times) / len(block_kline_times))) / (1000 * 60 * 60)
                
                # تبدیل قدیمی‌ترین و جدیدترین به تاریخ میلادی
                oldest_iso = timestamp_to_iso_date(min(block_kline_times))
                newest_iso = timestamp_to_iso_date(max(block_kline_times))
                
                block_kline_stats = {
                    "oldest_kline_in_block": min(block_kline_times),
                    "newest_kline_in_block": max(block_kline_times),
                    "oldest_kline_iso": oldest_iso,
                    "newest_kline_iso": newest_iso,
                    "oldest_kline_readable": timestamp_to_readable_date(min(block_kline_times)) if oldest_iso else None,
                    "newest_kline_readable": timestamp_to_readable_date(max(block_kline_times)) if newest_iso else None,
                    "coins_with_kline": len(block_kline_times),
                    "coins_without_kline": len(block_coins) - len(block_kline_times),
                    "avg_kline_age_hours": round(avg_age_hours, 1)
                }
            
            blocks.append({
                "block_id": block_number,
                "coins": block_coins,
                "size": len(block_coins),
                "symbols": [coin['symbol'] for coin in block_coins],
                "total_volume": total_volume,
                "avg_price": avg_price,
                "kline_stats": block_kline_stats,
                "priority_info": {
                    "is_priority_block": block_number <= 3,  # 3 بلوک اول اولویت بالاتری دارند
                    "avg_data_age_hours": block_kline_stats.get("avg_kline_age_hours", 0) if block_kline_stats else 0,
                    "contains_oldest_data": block_number == 1,  # بلوک اول حاوی قدیمی‌ترین داده‌هاست
                    "sorting_field": "last_updated_ts (from crypto_klines.close_time)"
                },
                "created_at": datetime.now().isoformat()
            })
            
            block_number += 1
        
        return {"success": True, "blocks": blocks, "total_blocks": len(blocks)}
        
    except Exception as e:
        return {"success": False, "error": f"خطا در ایجاد بلوک‌ها: {str(e)}"}

# ==================== STATE MANAGEMENT ====================
def save_cycle_state(state_file, state_data):
    """ذخیره وضعیت چرخه فعلی"""
    try:
        # اطمینان از وجود پوشه parent
        state_dir = os.path.dirname(state_file)
        if state_dir and not os.path.exists(state_dir):
            os.makedirs(state_dir, exist_ok=True)
            
        with open(state_file, 'w', encoding='utf-8') as f:
            json.dump(state_data, f, indent=2, ensure_ascii=False)
        
        print(f"   ✅ وضعیت در {state_file} ذخیره شد")
        return True
    except Exception as e:
        print(f"   ❌ خطا در ذخیره وضعیت: {e}")
        return False

# ==================== MAIN FUNCTION ====================
def run_coin_filter():
    """
    تابع اصلی: دریافت تمام ارزهای فعال، فیلتر و تقسیم به بلوک‌ها
    + سورت بر اساس last_updated_ts (که از close_time کندل می‌آید) - قدیمی‌ترین اول
    + استفاده از جدول crypto_klines برای داده‌های کندل
    + ذخیره last_updated_readable در جدول crypto_coins
    """
    print("=" * 70)
    print("🔄 تکه 01: سیستم فیلتر و تقسیم ارزها (نسخه 2.7)")
    print("📋 ویژه: ذخیره last_updated_readable در جدول crypto_coins")
    print("=" * 70)
    
    start_time = time.time()
    
    # 1. بارگذاری تنظیمات
    print("\n1️⃣ بارگذاری تنظیمات...")
    config_result = load_config()
    if not config_result["success"]:
        print(f"❌ {config_result['error']}")
        return config_result
    
    config = config_result["config"]
    print(f"   ✅ تنظیمات بارگذاری شد")
    print(f"   📁 دیتابیس: {Path(config['database_path']).name}")
    print(f"   📦 اندازه بلوک‌ها: {config['min_block_size']}-{config['max_block_size']}")
    print(f"   🎯 فیلتر حجم: >= ${config['min_volume_usd']:,}")
    print(f"   💰 فیلتر قیمت: >= ${config['min_price']}")
    print(f"   📊 تایم‌فرم کندل: {config['kline_timeframe']}")
    
    # بررسی وجود جدول crypto_klines
    kline_table_exists = check_kline_table_exists(config["database_path"])
    print(f"   📋 جدول crypto_klines: {'✅ موجود' if kline_table_exists else '⚠️ وجود ندارد'}")
    print(f"   🔄 منبع last_updated_ts: {'crypto_klines.close_time' if kline_table_exists else 'بدون منبع'}")
    
    # 2. دریافت تمام ارزهای فعال + آخرین کندل
    print(f"\n2️⃣ دریافت تمام ارزهای فعال از دیتابیس + last_updated_ts از close_time کندل...")
    coins_result = get_all_active_coins(config["database_path"], config["kline_timeframe"])
    if not coins_result["success"]:
        print(f"❌ {coins_result['error']}")
        return coins_result
    
    all_active_coins = coins_result["all_active_coins"]
    coins_with_kline = coins_result["coins_with_kline"]  # ارزهای دارای کندل
    total_coins_in_db = coins_result["total_coins_in_db"]
    active_coins_count = coins_result["active_coins_count"]
    kline_stats = coins_result["kline_stats"]
    
    print(f"   📊 آمار دیتابیس:")
    print(f"      - کل ارزها در دیتابیس: {total_coins_in_db}")
    print(f"      - ارزهای فعال (با قیمت > 0): {active_coins_count}")
    print(f"      - ارزهای فعال دریافت شده: {len(all_active_coins)}")
    print(f"   📈 آمار کندل‌ها:")
    print(f"      - ارزهای دارای کندل {config['kline_timeframe']}: {kline_stats['coins_with_kline']}")
    print(f"      - ارزهای بدون کندل: {kline_stats['coins_without_kline']}")
    print(f"      - درصد دارای داده: {kline_stats['percentage_with_kline']}")
    print(f"      - منبع last_updated_ts: {kline_stats.get('source_for_last_updated_ts', 'نامشخص')}")
    
    if kline_stats.get('time_stats'):
        ts = kline_stats['time_stats']
        print(f"      - قدیمی‌ترین last_updated_ts: {format_timestamp(ts['oldest_kline'])}")
        print(f"      - جدیدترین last_updated_ts: {format_timestamp(ts['newest_kline'])}")
        print(f"      - قدیمی‌ترین (ISO): {ts.get('oldest_kline_iso', 'N/A')}")
        print(f"      - جدیدترین (ISO): {ts.get('newest_kline_iso', 'N/A')}")
        print(f"      - میانگین سن داده: {ts['avg_kline_age']:.1f} ساعت")
    
    # نمایش نمونه از ارزهای سورت شده
    if len(all_active_coins) > 0:
        print(f"\n   🎯 نمونه‌ای از ارزهای سورت شده (بر اساس last_updated_ts از close_time - قدیمی‌ترین اول):")
        # ابتدا ارزهای با کندل
        for i, coin in enumerate(all_active_coins[:3]):
            if i < len(all_active_coins):
                kline_time = format_timestamp(coin.get('last_updated_ts')) if coin.get('last_updated_ts') else "بدون کندل"
                iso_time = coin.get('last_updated_iso', 'N/A')
                rank = safe_int(coin.get('market_cap_rank'), 0)
                print(f"      {i+1}. {coin['symbol']:8s} - رتبه: {rank:4d} - last_updated_ts: {kline_time}")
                print(f"           (ISO: {iso_time})")
                if coin.get('last_updated_original'):
                    print(f"           (last_updated اصلی از crypto_coins: {coin['last_updated_original']})")
        
        # سپس ارزهای بدون کندل (اولین‌ها)
        no_kline_count = 0
        for i, coin in enumerate(all_active_coins):
            if not coin.get('last_updated_ts') and no_kline_count < 2:
                rank = safe_int(coin.get('market_cap_rank'), 0)
                print(f"      ... {coin['symbol']:8s} - رتبه: {rank:4d} - بدون کندل (last_updated_ts = None)")
                print(f"           (ISO: {coin.get('last_updated_iso', 'N/A')})")
                if coin.get('last_updated_original'):
                    print(f"           (last_updated اصلی از crypto_coins: {coin['last_updated_original']})")
                no_kline_count += 1
                if no_kline_count >= 2:
                    break
    
    if len(all_active_coins) == 0:
        print("❌ هیچ ارز فعالی در دیتابیس وجود ندارد")
        return {"success": False, "error": "هیچ ارز فعالی یافت نشد"}
    
    # 3. اعمال فیلترها
    print("\n3️⃣ اعمال فیلترها...")
    filters = {
        "min_volume_usd": config["min_volume_usd"],
        "min_price": config["min_price"]
    }
    
    filtered_coins = apply_filters(all_active_coins, filters)
    
    print(f"   📊 نتیجه فیلتر:")
    print(f"      - ارزهای قبل از فیلتر: {len(all_active_coins)}")
    print(f"      - ارزهای بعد از فیلتر: {len(filtered_coins)}")
    print(f"      - حذف شده توسط فیلتر: {len(all_active_coins) - len(filtered_coins)}")
    
    # آمار کندل برای ارزهای فیلتر شده
    filtered_with_kline = [c for c in filtered_coins if c.get('last_updated_ts')]
    filtered_without_kline = [c for c in filtered_coins if not c.get('last_updated_ts')]
    
    # نمایش برخی آمار فیلتر شده‌ها
    if filtered_coins:
        # محاسبه آمار کلی
        total_volume = sum(safe_float(coin.get('volume_24h', 0)) for coin in filtered_coins)
        avg_price = sum(safe_float(coin.get('current_price', 0)) for coin in filtered_coins) / len(filtered_coins)
        
        print(f"   📈 آمار ارزهای فیلتر شده:")
        print(f"      - حجم کل 24h: ${total_volume:,.0f}")
        print(f"      - میانگین قیمت: ${avg_price:.4f}")
        print(f"      - دارای کندل (last_updated_ts): {len(filtered_with_kline)}")
        print(f"      - بدون کندل: {len(filtered_without_kline)}")
        
        if filtered_with_kline:
            kline_times = [c['last_updated_ts'] for c in filtered_with_kline]
            oldest_filtered_val = min(kline_times)
            newest_filtered_val = max(kline_times)
            oldest_iso = timestamp_to_iso_date(oldest_filtered_val)
            newest_iso = timestamp_to_iso_date(newest_filtered_val)
            oldest_readable = timestamp_to_readable_date(oldest_filtered_val)
            newest_readable = timestamp_to_readable_date(newest_filtered_val)
            avg_age_hours = (int(time.time() * 1000) - (sum(kline_times) / len(kline_times))) / (1000 * 60 * 60)
            
            print(f"      - قدیمی‌ترین last_updated_ts: {format_timestamp(oldest_filtered_val)}")
            print(f"      - قدیمی‌ترین (ISO): {oldest_iso}")
            print(f"      - قدیمی‌ترین (قابل خواندن): {oldest_readable}")
            print(f"      - جدیدترین last_updated_ts: {format_timestamp(newest_filtered_val)}")
            print(f"      - جدیدترین (ISO): {newest_iso}")
            print(f"      - جدیدترین (قابل خواندن): {newest_readable}")
            print(f"      - میانگین سن داده: {avg_age_hours:.1f} ساعت")
    
    # 4. ذخیره last_updated_readable در جدول crypto_coins
    print(f"\n4️⃣ ذخیره last_updated_readable در جدول crypto_coins...")
    if coins_with_kline:
        update_result = update_last_updated_in_coins_table(config["database_path"], coins_with_kline)
        
        if update_result["success"]:
            print(f"   ✅ last_updated_readable برای {update_result['updated_count']} ارز ذخیره شد")
            if update_result['error_count'] > 0:
                print(f"   ⚠️ {update_result['error_count']} ارز با خطا مواجه شدند")
        else:
            print(f"   ❌ خطا در ذخیره last_updated_readable: {update_result.get('error', 'نامشخص')}")
    else:
        print(f"   ⚠️ هیچ ارزی با last_updated_readable یافت نشد")
    
    # 5. ایجاد بلوک‌ها با حفظ اولویت زمانی بر اساس last_updated_ts
    print(f"\n5️⃣ ایجاد بلوک‌ها با اولویت زمانی (بر اساس last_updated_ts از close_time)...")
    blocks_result = create_priority_blocks(
        filtered_coins,
        config["min_block_size"],
        config["max_block_size"]
    )
    
    if not blocks_result["success"]:
        print(f"❌ {blocks_result['error']}")
        return blocks_result
    
    blocks = blocks_result["blocks"]
    total_blocks = blocks_result["total_blocks"]
    
    print(f"   ✅ {total_blocks} بلوک ایجاد شد")
    
    # نمایش خلاصه بلوک‌ها
    if blocks:
        total_coins_in_blocks = sum(block['size'] for block in blocks)
        print(f"\n   📦 ساختار بلوک‌ها (با اولویت زمانی بر اساس last_updated_ts):")
        print(f"      - کل ارزها در بلوک‌ها: {total_coins_in_blocks}")
        if total_blocks > 0:
            avg_block_size = total_coins_in_blocks // total_blocks
            print(f"      - میانگین اندازه بلوک: {avg_block_size}")
        
        print(f"\n   🎯 جزئیات بلوک‌ها (قدیمی‌ترین last_updated_ts در بلوک‌های اول):")
        for block in blocks[:8]:  # نمایش 8 بلوک اول
            kline_info = ""
            age_info = ""
            iso_info = ""
            if block.get('kline_stats'):
                ks = block['kline_stats']
                kline_info = f" | last_updated_ts: {ks['coins_with_kline']}/{block['size']}"
                if ks.get('avg_kline_age_hours'):
                    age_info = f" | سن میانگین: {ks['avg_kline_age_hours']}h"
                if ks.get('oldest_kline_iso'):
                    iso_info = f" | قدیمی‌ترین: {ks['oldest_kline_iso'][:16]}"
            
            priority_tag = "🔥" if block['priority_info']['is_priority_block'] else "  "
            oldest_tag = "🏁" if block['priority_info']['contains_oldest_data'] else "  "
            
            if block['symbols']:
                first_coin = block['symbols'][0]
                last_coin = block['symbols'][-1]
                volume_str = f"${block['total_volume']:,.0f}" if block['total_volume'] > 0 else "نامشخص"
                print(f"      {priority_tag}{oldest_tag} بلوک {block['block_id']:2d}: {block['size']:3d} ارز - "
                      f"{first_coin:6s} تا {last_coin:6s} - حجم: {volume_str:15s}{kline_info}{age_info}{iso_info}")
        
        if total_blocks > 8:
            print(f"      ... و {total_blocks - 8} بلوک دیگر")
    
    # 6. ایجاد وضعیت چرخه
    print("\n6️⃣ ایجاد وضعیت چرخه...")
    cycle_id = f"cycle_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
    
    # یافتن ارزهای نمونه برای oldest/newest
    oldest_coin = None
    newest_coin = None
    oldest_filtered_val = None
    newest_filtered_val = None
    
    if filtered_with_kline:
        kline_times = [c['last_updated_ts'] for c in filtered_with_kline]
        oldest_filtered_val = min(kline_times) if kline_times else None
        newest_filtered_val = max(kline_times) if kline_times else None
        
        for coin in filtered_coins:
            if oldest_filtered_val and coin.get('last_updated_ts') == oldest_filtered_val:
                oldest_coin = coin
            if newest_filtered_val and coin.get('last_updated_ts') == newest_filtered_val:
                newest_coin = coin
            if oldest_coin and newest_coin:
                break
    
    # تبدیل مقادیر timestamp به تاریخ میلادی
    oldest_iso = timestamp_to_iso_date(oldest_filtered_val) if oldest_filtered_val else None
    newest_iso = timestamp_to_iso_date(newest_filtered_val) if newest_filtered_val else None
    oldest_readable = timestamp_to_readable_date(oldest_filtered_val) if oldest_filtered_val else None
    newest_readable = timestamp_to_readable_date(newest_filtered_val) if newest_filtered_val else None
    
    cycle_state = {
        "cycle_id": cycle_id,
        "start_time": datetime.now().isoformat(),
        "stats": {
            "total_coins_in_db": total_coins_in_db,
            "active_coins_before_filter": len(all_active_coins),
            "active_coins_after_filter": len(filtered_coins),
            "removed_by_filters": len(all_active_coins) - len(filtered_coins),
            "total_blocks": total_blocks,
            "total_coins_in_blocks": total_coins_in_blocks,
            # آمار کندل‌ها
            "coins_with_last_updated_ts": len(filtered_with_kline),
            "coins_without_last_updated_ts": len(filtered_without_kline),
            "percentage_with_last_updated_ts": f"{(len(filtered_with_kline)/len(filtered_coins)*100):.1f}%" if filtered_coins else "0%",
            
            # ذخیره هم timestamp و هم تاریخ میلادی
            "oldest_last_updated_ts": oldest_filtered_val,
            "newest_last_updated_ts": newest_filtered_val,
            "oldest_last_updated_iso": oldest_iso,
            "newest_last_updated_iso": newest_iso,
            "oldest_last_updated_readable": oldest_readable,
            "newest_last_updated_readable": newest_readable,
            
            "kline_table_exists": kline_table_exists,
            "last_updated_ts_source": "crypto_klines.close_time" if kline_table_exists else "none"
        },
        "sorting_info": {
            "method": "بر اساس last_updated_ts (از crypto_klines.close_time) - قدیمی‌ترین اول",
            "priority_levels": "بلوک‌های ۱-۳ اولویت بالا دارند",
            "contains_shuffle": False,
            "preserves_temporal_order": True,
            "kline_source": "crypto_klines" if kline_table_exists else "none",
            "sorting_field": "last_updated_ts",
            "field_source": "crypto_klines.close_time"
        },
        "database_update_info": {
            "last_updated_field_updated": True if coins_with_kline else False,
            "last_updated_field_count": len(coins_with_kline) if coins_with_kline else 0,
            "last_updated_field_source": "crypto_klines.close_time -> last_updated_readable",
            "last_updated_field_target": "crypto_coins.last_updated"
        },
        "filters_applied": filters,
        "block_config": {
            "min_block_size": config["min_block_size"],
            "max_block_size": config["max_block_size"],
            "blocks_created": total_blocks,
            "block_creation_method": "priority_based (قدیمی‌ترین last_updated_ts اول)",
            "sorting_field_for_priority": "last_updated_ts (from crypto_klines.close_time)"
        },
        "current_block": 1,
        "completed_blocks": [],
        "pending_blocks": [block["block_id"] for block in blocks],
        "blocks": blocks,
        "status": "running",
        "last_updated": datetime.now().isoformat(),
        "config": {
            "project_root": config["project_root"],
            "state_file": config["state_file"],
            "database_path": config["database_path"],
            "kline_timeframe": config["kline_timeframe"],
            "kline_table_exists": kline_table_exists,
            "last_updated_ts_source": "crypto_klines.close_time"
        }
    }
    
    # ذخیره وضعیت
    if save_cycle_state(config["state_file"], cycle_state):
        print(f"   ✅ وضعیت در {config['state_file']} ذخیره شد")
    else:
        print(f"   ⚠️ خطا در ذخیره وضعیت")
    
    # 7. نتیجه نهایی
    execution_time = time.time() - start_time
    print("\n" + "=" * 70)
    print("📋 نتیجه تکه 01 (نسخه 2.7):")
    print("🎯 ویژه: ذخیره last_updated_readable در جدول crypto_coins")
    print("-" * 70)
    print(f"   🆔 شناسه چرخه: {cycle_state['cycle_id']}")
    print(f"   🕒 زمان شروع: {cycle_state['start_time'][11:19]}")
    print(f"   ⏱️  زمان اجرا: {execution_time:.2f} ثانیه")
    print(f"\n   📊 آمار ارزها:")
    print(f"      - کل ارزها در دیتابیس: {cycle_state['stats']['total_coins_in_db']}")
    print(f"      - ارزهای فعال (قبل از فیلتر): {cycle_state['stats']['active_coins_before_filter']}")
    print(f"      - ارزهای فعال (بعد از فیلتر): {cycle_state['stats']['active_coins_after_filter']}")
    print(f"      - حذف شده توسط فیلتر: {cycle_state['stats']['removed_by_filters']}")
    print(f"\n   📦 آمار بلوک‌ها:")
    print(f"      - تعداد بلوک‌ها: {cycle_state['stats']['total_blocks']}")
    print(f"      - کل ارزها در بلوک‌ها: {cycle_state['stats']['total_coins_in_blocks']}")
    print(f"      - بلوک فعلی: {cycle_state['current_block']}")
    print(f"      - روش بلوک‌بندی: {cycle_state['block_config']['block_creation_method']}")
    print(f"\n   📈 آمار last_updated_ts (از crypto_klines.close_time):")
    print(f"      - ارزهای دارای last_updated_ts: {cycle_state['stats']['coins_with_last_updated_ts']}")
    print(f"      - ارزهای بدون last_updated_ts: {cycle_state['stats']['coins_without_last_updated_ts']}")
    print(f"      - درصد دارای داده: {cycle_state['stats']['percentage_with_last_updated_ts']}")
    print(f"      - منبع فیلد: {cycle_state['stats']['last_updated_ts_source']}")
    print(f"\n   💾 آپدیت دیتابیس:")
    print(f"      - last_updated آپدیت شد: {'✅ بله' if cycle_state['database_update_info']['last_updated_field_updated'] else '❌ خیر'}")
    print(f"      - تعداد رکوردهای آپدیت شده: {cycle_state['database_update_info']['last_updated_field_count']}")
    print(f"      - منبع داده: {cycle_state['database_update_info']['last_updated_field_source']}")
    print(f"      - فیلد هدف: {cycle_state['database_update_info']['last_updated_field_target']}")
    
    if cycle_state['stats']['oldest_last_updated_readable']:
        print(f"\n   🕐 اطلاعات زمانی (به تاریخ میلادی):")
        print(f"      - قدیمی‌ترین داده: {cycle_state['stats']['oldest_last_updated_readable']}")
        print(f"      - (ISO): {cycle_state['stats']['oldest_last_updated_iso']}")
        print(f"      - (timestamp): {cycle_state['stats']['oldest_last_updated_ts']}")
        print(f"      - جدیدترین داده: {cycle_state['stats']['newest_last_updated_readable']}")
        print(f"      - (ISO): {cycle_state['stats']['newest_last_updated_iso']}")
        print(f"      - (timestamp): {cycle_state['stats']['newest_last_updated_ts']}")
        print(f"      - منبع داده: {cycle_state['stats']['last_updated_ts_source']}")
    
    # نمایش اولین ارزهای هر بلوک برای تأیید اولویت‌بندی
    print(f"\n   🎯 تأیید اولویت‌بندی (اولین ارز هر بلوک - بر اساس last_updated_ts):")
    for i, block in enumerate(blocks[:5]):
        if block['symbols']:
            first_symbol = block['symbols'][0]
            # پیدا کردن ارز مربوطه برای نمایش تاریخ last_updated_ts
            for coin in block['coins']:
                if coin['symbol'] == first_symbol:
                    kline_time = format_timestamp(coin.get('last_updated_ts')) if coin.get('last_updated_ts') else "بدون last_updated_ts"
                    iso_time = coin.get('last_updated_iso', 'N/A')
                    priority_tag = "🔥 " if i < 3 else "   "
                    print(f"      {priority_tag}بلوک {i+1}: {first_symbol:8s} - last_updated_ts: {kline_time}")
                    print(f"           (ISO: {iso_time})")
                    if coin.get('last_updated_original'):
                        print(f"           (last_updated اصلی: {coin['last_updated_original']})")
                    break
    
    print("\n🔗 اطلاعات برای تکه بعدی:")
    if blocks and blocks[0]['symbols']:
        print(f"   - بلوک فعلی: {cycle_state['current_block']} (اولویت بالا)")
        print(f"   - ارزهای این بلوک: {blocks[0]['size']}")
        print(f"   - اولین ارز بلوک: {blocks[0]['symbols'][0]} (قدیمی‌ترین last_updated_ts)")
        print(f"   - منبع last_updated_ts: crypto_klines.close_time")
    
    print("\n💡 دستور بعدی:")
    print("   'python scripts/cycle/cycle_02_process_block.py'")
    print("=" * 70)
    
    return {
        "success": True,
        "cycle_state": cycle_state,
        "message": f"تکه 01 کامل شد. {len(filtered_coins)} ارز در {total_blocks} بلوک سازماندهی شدند.",
        "database_updated": cycle_state['database_update_info']['last_updated_field_updated'],
        "database_update_count": cycle_state['database_update_info']['last_updated_field_count'],
        "sorting_method": "بر اساس last_updated_ts (از crypto_klines.close_time) - قدیمی‌ترین اول",
        "kline_table_used": kline_table_exists,
        "last_updated_ts_source": "crypto_klines.close_time"
    }

# ==================== EXECUTION ====================
if __name__ == "__main__":
    result = run_coin_filter()
    
    # خروجی مناسب برای خط فرمان
    if result["success"]:
        print(f"\n✅ {result['message']}")
        print(f"📋 روش سورت: {result.get('sorting_method', 'نامشخص')}")
        print(f"📊 منبع داده last_updated_ts: {result.get('last_updated_ts_source', 'نامشخص')}")
        print(f"💾 آپدیت دیتابیس: {'✅ موفق' if result.get('database_updated') else '❌ ناموفق'}")
        if result.get('database_updated'):
            print(f"   - تعداد رکوردهای آپدیت شده: {result.get('database_update_count', 0)}")
        
        if result.get('cycle_state', {}).get('stats', {}).get('total_blocks', 0) > 0:
            print(f"📌 مرحله بعد: پردازش بلوک 1 از {result['cycle_state']['stats']['total_blocks']}")
            print(f"🎯 بلوک اول دارای قدیمی‌ترین last_updated_ts (از close_time) است")
            print(f"🚀 دستور: python scripts/cycle/cycle_02_process_block.py")
    else:
        print(f"\n❌ خطا: {result.get('error', 'خطای ناشناخته')}")
        sys.exit(1)