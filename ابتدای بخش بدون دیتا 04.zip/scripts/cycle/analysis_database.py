"""
analysis_database.py - مدیریت دیتابیس برای تحلیل تکنیکال
تاریخ: 2025-12-21
هدف: لایه تخصصی برای عملیات دیتابیس تحلیل تکنیکال
"""

import json
from typing import List, Dict, Any, Optional, Tuple
from datetime import datetime
from database_manager import DatabaseManager


class AnalysisDatabase:
    """مدیریت تخصصی دیتابیس برای تحلیل تکنیکال"""
    
    def __init__(self, db_path: Optional[str] = None):
        """
        مقداردهی اولیه AnalysisDatabase
        
        Args:
            db_path: مسیر دیتابیس (اختیاری - اگر نباشد از تنظیمات می‌گیرد)
        """
        self.db_manager = DatabaseManager(db_path)
    
    # ==================== عملیات خواندن برای تحلیل ====================
    
    def get_candles_for_analysis(self, coin_id: int, timeframe: str, 
                                limit: int = 200) -> List[Dict[str, Any]]:
        """
        دریافت داده‌های کندل برای تحلیل تکنیکال
        
        Args:
            coin_id: شناسه ارز در دیتابیس
            timeframe: تایم‌فریم (مثلاً '5m', '15m', '1h')
            limit: تعداد کندل‌های مورد نیاز
            
        Returns:
            لیست کندل‌ها با فرمت استاندارد
        """
        try:
            query = """
            SELECT 
                id, open_time, close_time,
                open_price, high_price, low_price, close_price,
                volume, quote_volume, number_of_trades
            FROM crypto_klines
            WHERE coin_id = ? 
              AND timeframe = ?
              AND close_price IS NOT NULL
              AND close_price > 0
            ORDER BY open_time ASC
            LIMIT ?
            """
            
            results = self.db_manager.fetch_all(query, (coin_id, timeframe, limit))
            
            # فرمت‌دهی کندل‌ها
            candles = []
            for row in results:
                candles.append({
                    'id': row['id'],
                    'open_time': row['open_time'],
                    'close_time': row['close_time'],
                    'open': float(row['open_price']),
                    'high': float(row['high_price']),
                    'low': float(row['low_price']),
                    'close': float(row['close_price']),
                    'volume': float(row['volume']),
                    'quote_volume': float(row['quote_volume']),
                    'trades': row['number_of_trades']
                })
            
            return candles
            
        except Exception as e:
            print(f"❌ خطا در دریافت کندل‌ها برای تحلیل: {e}")
            return []
    
    def get_coins_from_symbols(self, symbols: List[str]) -> List[Dict[str, Any]]:
        """
        دریافت اطلاعات ارزها از روی نمادها
        
        Args:
            symbols: لیست نمادهای ارزها
            
        Returns:
            لیست اطلاعات ارزها
        """
        try:
            if not symbols:
                return []
            
            # تبدیل نمادها به فرمت استاندارد
            formatted_symbols = []
            for symbol in symbols:
                if not symbol.upper().endswith('USDT'):
                    formatted_symbols.append(f"{symbol.upper()}USDT")
                else:
                    formatted_symbols.append(symbol.upper())
            
            # ساخت query با پارامترهای پویا
            placeholders = ','.join(['?' for _ in formatted_symbols])
            query = f"""
            SELECT id, symbol, base_asset, coin_name
            FROM crypto_coins
            WHERE symbol IN ({placeholders})
            ORDER BY symbol
            """
            
            results = self.db_manager.fetch_all(query, tuple(formatted_symbols))
            
            coins = []
            for row in results:
                coins.append({
                    'coin_id': row['id'],
                    'symbol': row['symbol'],
                    'base_asset': row['base_asset'],
                    'name': row['coin_name']
                })
            
            return coins
            
        except Exception as e:
            print(f"❌ خطا در دریافت اطلاعات ارزها: {e}")
            return []
    
    def get_coin_id_from_symbol(self, symbol: str) -> Optional[int]:
        """
        دریافت شناسه ارز از روی نماد
        
        Args:
            symbol: نماد ارز (مثلاً BTCUSDT یا BTC)
            
        Returns:
            شناسه ارز یا None
        """
        try:
            # فرمت‌دهی نماد
            if not symbol.upper().endswith('USDT'):
                clean_symbol = f"{symbol.upper()}USDT"
            else:
                clean_symbol = symbol.upper()
            
            query = "SELECT id FROM crypto_coins WHERE symbol = ?"
            result = self.db_manager.fetch_one(query, (clean_symbol,))
            
            if result:
                return result['id']
            return None
            
        except Exception as e:
            print(f"❌ خطا در دریافت شناسه ارز: {e}")
            return None
    
    def get_available_timeframes(self, coin_id: int) -> List[str]:
        """
        دریافت تایم‌فریم‌های موجود برای یک ارز
        
        Args:
            coin_id: شناسه ارز
            
        Returns:
            لیست تایم‌فریم‌های موجود
        """
        try:
            query = """
            SELECT DISTINCT timeframe
            FROM crypto_klines
            WHERE coin_id = ?
            ORDER BY timeframe
            """
            
            results = self.db_manager.fetch_all(query, (coin_id,))
            return [row['timeframe'] for row in results]
            
        except Exception as e:
            print(f"❌ خطا در دریافت تایم‌فریم‌ها: {e}")
            return []
    
    def get_candle_count(self, coin_id: int, timeframe: str) -> int:
        """
        تعداد کندل‌های موجود برای یک ارز و تایم‌فریم
        
        Args:
            coin_id: شناسه ارز
            timeframe: تایم‌فریم
            
        Returns:
            تعداد کندل‌ها
        """
        try:
            query = """
            SELECT COUNT(*) as count
            FROM crypto_klines
            WHERE coin_id = ? AND timeframe = ?
              AND close_price IS NOT NULL
              AND close_price > 0
            """
            
            result = self.db_manager.fetch_one(query, (coin_id, timeframe))
            return result['count'] if result else 0
            
        except Exception as e:
            print(f"❌ خطا در شمارش کندل‌ها: {e}")
            return 0
    
    # ==================== عملیات نوشتن برای تحلیل ====================
    
    def create_indicators_table(self):
        """
        ایجاد جدول technical_indicators اگر وجود نداشته باشد
        """
        try:
            # بررسی وجود جدول
            if self.db_manager.table_exists('technical_indicators'):
                print("✅ جدول technical_indicators از قبل وجود دارد")
                return True
            
            print("📁 در حال ایجاد جدول technical_indicators...")
            
            create_table_query = """
            CREATE TABLE IF NOT EXISTS technical_indicators (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                coin_id INTEGER NOT NULL,
                timeframe TEXT NOT NULL,
                timestamp TIMESTAMP NOT NULL,
                
                -- اندیکاتورهای پایه
                rsi_14 REAL,
                macd REAL,
                macd_signal REAL,
                macd_histogram REAL,
                bollinger_upper REAL,
                bollinger_middle REAL,
                bollinger_lower REAL,
                
                -- میانگین‌های متحرک
                sma_5 REAL,
                sma_10 REAL,
                sma_20 REAL,
                sma_50 REAL,
                ema_12 REAL,
                ema_26 REAL,
                
                -- اندیکاتورهای حجمی
                volume_ma_20 REAL,
                volume_ratio REAL,
                
                -- سیگنال‌ها
                signal_score INTEGER,
                signal_hint TEXT,
                trend_direction TEXT,
                trend_strength REAL,
                
                -- داده‌های ترکیبی
                composite_data TEXT,
                
                -- متادیتا
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                
                -- کلیدهای یکتا و خارجی
                UNIQUE(coin_id, timeframe, timestamp),
                FOREIGN KEY (coin_id) REFERENCES crypto_coins (id)
            )
            """
            
            # ایجاد جدول اصلی
            self.db_manager.execute_query(create_table_query)
            
            # ایجاد ایندکس‌ها برای عملکرد بهتر
            index_queries = [
                "CREATE INDEX IF NOT EXISTS idx_coin_timeframe ON technical_indicators (coin_id, timeframe)",
                "CREATE INDEX IF NOT EXISTS idx_timestamp ON technical_indicators (timestamp)",
                "CREATE INDEX IF NOT EXISTS idx_signal_score ON technical_indicators (signal_score)",
                "CREATE INDEX IF NOT EXISTS idx_trend_direction ON technical_indicators (trend_direction)"
            ]
            
            for query in index_queries:
                self.db_manager.execute_query(query)
            
            print("✅ جدول technical_indicators با موفقیت ایجاد شد")
            return True
            
        except Exception as e:
            print(f"❌ خطا در ایجاد جدول technical_indicators: {e}")
            return False
    
    def save_indicators_batch(self, indicators_data: List[Dict[str, Any]]) -> bool:
        """
        ذخیره دسته‌ای اندیکاتورها
        
        Args:
            indicators_data: لیست دیکشنری‌های حاوی داده اندیکاتورها
            
        Returns:
            موفقیت یا شکست عملیات
        """
        if not indicators_data:
            print("⚠️ هیچ داده‌ای برای ذخیره وجود ندارد")
            return False
        
        try:
            # اطمینان از وجود جدول
            self.create_indicators_table()
            
            insert_query = """
            INSERT OR REPLACE INTO technical_indicators 
            (coin_id, timeframe, timestamp, 
             rsi_14, macd, macd_signal, macd_histogram,
             bollinger_upper, bollinger_middle, bollinger_lower,
             sma_5, sma_10, sma_20, sma_50,
             ema_12, ema_26, volume_ma_20, volume_ratio,
             signal_score, signal_hint, trend_direction, trend_strength,
             composite_data)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """
            
            # آماده‌سازی داده‌ها
            batch_data = []
            for data in indicators_data:
                # تبدیل داده‌های ترکیبی به JSON
                composite_json = None
                if 'composite_data' in data and data['composite_data']:
                    try:
                        composite_json = json.dumps(data['composite_data'], ensure_ascii=False)
                    except:
                        composite_json = None
                
                batch_data.append((
                    data.get('coin_id'),
                    data.get('timeframe'),
                    data.get('timestamp'),
                    data.get('rsi_14'),
                    data.get('macd'),
                    data.get('macd_signal'),
                    data.get('macd_histogram'),
                    data.get('bollinger_upper'),
                    data.get('bollinger_middle'),
                    data.get('bollinger_lower'),
                    data.get('sma_5'),
                    data.get('sma_10'),
                    data.get('sma_20'),
                    data.get('sma_50'),
                    data.get('ema_12'),
                    data.get('ema_26'),
                    data.get('volume_ma_20'),
                    data.get('volume_ratio'),
                    data.get('signal_score', 50),
                    data.get('signal_hint', 'NEUTRAL'),
                    data.get('trend_direction', 'UNKNOWN'),
                    data.get('trend_strength', 0.0),
                    composite_json
                ))
            
            # اجرای دسته‌ای
            self.db_manager.cursor.executemany(insert_query, batch_data)
            self.db_manager.connection.commit()
            
            print(f"✅ {len(batch_data)} اندیکاتور ذخیره شد")
            return True
            
        except Exception as e:
            print(f"❌ خطا در ذخیره دسته‌ای اندیکاتورها: {e}")
            return False
    
    def log_analysis_result(self, cycle_id: str, block_id: int, 
                           coin_id: int, symbol: str, timeframe: str,
                           indicators_count: int, status: str, 
                           error: Optional[str] = None,
                           processing_time: Optional[float] = None):
        """
        ثبت نتیجه تحلیل در لاگ
        
        Args:
            cycle_id: شناسه چرخه
            block_id: شماره بلوک
            coin_id: شناسه ارز
            symbol: نماد ارز
            timeframe: تایم‌فریم
            indicators_count: تعداد اندیکاتورهای محاسبه شده
            status: وضعیت (SUCCESS, ERROR, etc.)
            error: پیغام خطا (اگر وجود دارد)
            processing_time: زمان پردازش (ثانیه)
        """
        try:
            # بررسی وجود جدول لاگ
            if not self.db_manager.table_exists('analysis_logs'):
                self._create_analysis_logs_table()
            
            insert_query = """
            INSERT INTO analysis_logs 
            (cycle_id, block_id, coin_id, symbol, timeframe, 
             indicators_count, status, error_message, processing_time, timestamp)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """
            
            self.db_manager.execute_query(
                insert_query,
                (cycle_id, block_id, coin_id, symbol, timeframe,
                 indicators_count, status, error, processing_time, 
                 datetime.now().isoformat())
            )
            
        except Exception as e:
            print(f"⚠️ خطا در ثبت لاگ تحلیل: {e}")
    
    def _create_analysis_logs_table(self):
        """ایجاد جدول لاگ تحلیل"""
        try:
            create_query = """
            CREATE TABLE IF NOT EXISTS analysis_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                cycle_id TEXT NOT NULL,
                block_id INTEGER NOT NULL,
                coin_id INTEGER NOT NULL,
                symbol TEXT NOT NULL,
                timeframe TEXT NOT NULL,
                indicators_count INTEGER DEFAULT 0,
                status TEXT NOT NULL,
                error_message TEXT,
                processing_time REAL,
                timestamp TIMESTAMP NOT NULL,
                
                -- ایندکس‌ها
                INDEX idx_cycle_block (cycle_id, block_id),
                INDEX idx_symbol_timeframe (symbol, timeframe),
                INDEX idx_timestamp (timestamp)
            )
            """
            
            self.db_manager.execute_query(create_query)
            print("✅ جدول analysis_logs ایجاد شد")
            
        except Exception as e:
            print(f"❌ خطا در ایجاد جدول لاگ: {e}")
    
    # ==================== عملیات کمکی ====================
    
    def get_analysis_stats(self, cycle_id: str) -> Dict[str, Any]:
        """
        دریافت آمار تحلیل برای یک چرخه
        
        Args:
            cycle_id: شناسه چرخه
            
        Returns:
            دیکشنری آمار
        """
        try:
            if not self.db_manager.table_exists('analysis_logs'):
                return {}
            
            # آمار کلی
            stats_query = """
            SELECT 
                COUNT(DISTINCT coin_id) as total_coins,
                COUNT(*) as total_analyses,
                SUM(indicators_count) as total_indicators,
                AVG(processing_time) as avg_processing_time,
                SUM(CASE WHEN status = 'SUCCESS' THEN 1 ELSE 0 END) as successful,
                SUM(CASE WHEN status != 'SUCCESS' THEN 1 ELSE 0 END) as failed
            FROM analysis_logs
            WHERE cycle_id = ?
            """
            
            stats = self.db_manager.fetch_one(stats_query, (cycle_id,))
            
            # آمار تایم‌فریم‌ها
            timeframe_query = """
            SELECT timeframe, COUNT(*) as count
            FROM analysis_logs
            WHERE cycle_id = ?
            GROUP BY timeframe
            ORDER BY timeframe
            """
            
            timeframes = self.db_manager.fetch_all(timeframe_query, (cycle_id,))
            
            return {
                'total_coins': stats['total_coins'] if stats else 0,
                'total_analyses': stats['total_analyses'] if stats else 0,
                'total_indicators': stats['total_indicators'] if stats else 0,
                'avg_processing_time': stats['avg_processing_time'] if stats else 0,
                'successful': stats['successful'] if stats else 0,
                'failed': stats['failed'] if stats else 0,
                'timeframes': {tf['timeframe']: tf['count'] for tf in timeframes}
            }
            
        except Exception as e:
            print(f"❌ خطا در دریافت آمار تحلیل: {e}")
            return {}
    
    def cleanup_old_indicators(self, days_old: int = 30):
        """
        پاکسازی اندیکاتورهای قدیمی
        
        Args:
            days_old: تعداد روزهای گذشته برای نگهداری
        """
        try:
            cutoff_date = (datetime.now() - timedelta(days=days_old)).isoformat()
            
            delete_query = """
            DELETE FROM technical_indicators 
            WHERE timestamp < ?
            """
            
            self.db_manager.execute_query(delete_query, (cutoff_date,))
            
            count = self.db_manager.cursor.rowcount
            print(f"✅ {count} اندیکاتور قدیمی پاک شد")
            
        except Exception as e:
            print(f"❌ خطا در پاکسازی اندیکاتورهای قدیمی: {e}")
    
    def check_indicator_exists(self, coin_id: int, timeframe: str, 
                              timestamp: str) -> bool:
        """
        بررسی وجود اندیکاتور برای یک کندل خاص
        
        Args:
            coin_id: شناسه ارز
            timeframe: تایم‌فریم
            timestamp: زمان کندل
            
        Returns:
            وجود دارد یا خیر
        """
        try:
            query = """
            SELECT COUNT(*) as count
            FROM technical_indicators
            WHERE coin_id = ? AND timeframe = ? AND timestamp = ?
            """
            
            result = self.db_manager.fetch_one(query, (coin_id, timeframe, timestamp))
            return result['count'] > 0 if result else False
            
        except Exception as e:
            print(f"❌ خطا در بررسی وجود اندیکاتور: {e}")
            return False
    
    def get_latest_indicators(self, coin_id: int, timeframe: str, 
                             limit: int = 10) -> List[Dict[str, Any]]:
        """
        دریافت آخرین اندیکاتورهای یک ارز
        
        Args:
            coin_id: شناسه ارز
            timeframe: تایم‌فریم
            limit: تعداد مورد نیاز
            
        Returns:
            لیست آخرین اندیکاتورها
        """
        try:
            query = """
            SELECT *
            FROM technical_indicators
            WHERE coin_id = ? AND timeframe = ?
            ORDER BY timestamp DESC
            LIMIT ?
            """
            
            results = self.db_manager.fetch_all(query, (coin_id, timeframe, limit))
            return results
            
        except Exception as e:
            print(f"❌ خطا در دریافت آخرین اندیکاتورها: {e}")
            return []
    
    def close(self):
        """
        بستن اتصال دیتابیس
        """
        self.db_manager.close()
    
    def __enter__(self):
        """
        برای استفاده با with statement
        """
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """
        برای استفاده با with statement
        """
        self.close()


# تست کلاس
if __name__ == "__main__":
    print("🧪 تست AnalysisDatabase")
    print("=" * 50)
    
    try:
        # ایجاد نمونه
        analysis_db = AnalysisDatabase()
        
        # تست دریافت اطلاعات ارز
        print("1. تست دریافت شناسه ارز...")
        btc_id = analysis_db.get_coin_id_from_symbol("BTC")
        if btc_id:
            print(f"   ✅ شناسه BTC: {btc_id}")
            
            # تست دریافت کندل‌ها
            print("\n2. تست دریافت کندل‌ها...")
            candles = analysis_db.get_candles_for_analysis(btc_id, "5m", 10)
            print(f"   ✅ تعداد کندل‌ها: {len(candles)}")
            
            if candles:
                print(f"   📊 نمونه کندل:")
                print(f"      زمان: {candles[0]['close_time']}")
                print(f"      قیمت بسته: {candles[0]['close']}")
                print(f"      حجم: {candles[0]['volume']}")
        
        # تست ایجاد جدول اندیکاتورها
        print("\n3. تست ایجاد جدول اندیکاتورها...")
        success = analysis_db.create_indicators_table()
        print(f"   ✅ نتیجه: {'موفق' if success else 'ناموفق'}")
        
        # بستن اتصال
        analysis_db.close()
        
        print("\n✅ همه تست‌ها با موفقیت انجام شد")
        
    except Exception as e:
        print(f"❌ خطا در تست: {e}")
    
    print("=" * 50)