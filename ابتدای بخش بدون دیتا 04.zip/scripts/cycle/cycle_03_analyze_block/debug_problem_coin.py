"""
🐛 دیباگ ارزهای مشکل‌دار
"""

import sqlite3
import pandas as pd
import numpy as np
from datetime import datetime
import sys
import os

sys.path.append(os.path.dirname(os.path.abspath(__file__)))

# Import the calculator to test
from indicator_calculator import calculator

def debug_coin_1938():
    """دیباگ دقیق ارز 1938"""
    
    db_path = "../../../data/crypto_master.db"
    conn = sqlite3.connect(db_path)
    
    print("🐛 دیباگ ارز 1938 (نمونه مشکل‌دار)")
    print("=" * 70)
    
    coin_id = "1938"
    
    # بررسی همه تایم‌فریم‌ها
    query_tf = f"""
    SELECT timeframe, COUNT(*) as count
    FROM crypto_klines 
    WHERE coin_id = '{coin_id}'
    GROUP BY timeframe
    """
    
    df_tf = pd.read_sql_query(query_tf, conn)
    print("📊 تایم‌فریم‌های موجود:")
    print(df_tf.to_string(index=False))
    
    for _, row in df_tf.iterrows():
        timeframe = row['timeframe']
        print(f"\n🔍 بررسی تایم‌فریم: {timeframe}")
        
        # دریافت ۲۰ کندل اول
        query_candles = f"""
        SELECT 
            id, open_time, open_price, high_price, low_price, 
            close_price, volume, rsi, obv, atr, price_change
        FROM crypto_klines 
        WHERE coin_id = '{coin_id}' AND timeframe = '{timeframe}'
        ORDER BY open_time ASC
        LIMIT 20
        """
        
        df_candles = pd.read_sql_query(query_candles, conn)
        
        print(f"📈 ۵ کندل اول:")
        print(df_candles[['open_time', 'close_price', 'volume', 'rsi', 'obv', 'atr']].head(5).to_string(index=False))
        
        # بررسی داده‌های حجم
        print(f"\n📊 آمار حجم:")
        print(f"  • میانگین حجم: {df_candles['volume'].mean():.2f}")
        print(f"  • حجم NULL: {df_candles['volume'].isna().sum()}")
        print(f"  • حجم صفر: {(df_candles['volume'] == 0).sum()}")
        print(f"  • حجم منفی: {(df_candles['volume'] < 0).sum()}")
        
        # تست محاسبه دستی OBV
        if len(df_candles) >= 2:
            print("\n🧪 تست محاسبه دستی OBV:")
            
            # محاسبه OBV ساده
            obv_simple = 0.0
            obv_values = []
            
            for i in range(len(df_candles)):
                if i == 0:
                    obv = float(df_candles.iloc[i]['volume']) if not pd.isna(df_candles.iloc[i]['volume']) else 0.0
                else:
                    prev_close = float(df_candles.iloc[i-1]['close_price'])
                    curr_close = float(df_candles.iloc[i]['close_price'])
                    volume = float(df_candles.iloc[i]['volume']) if not pd.isna(df_candles.iloc[i]['volume']) else 0.0
                    
                    if curr_close > prev_close:
                        obv += volume
                    elif curr_close < prev_close:
                        obv -= volume
                    # اگر مساوی باشد، تغییر نمی‌کند
                
                obv_values.append(obv)
            
            print(f"  • OBV محاسبه شده: {obv_values[-1]:.2f}")
            print(f"  • OBV در دیتابیس: {df_candles.iloc[-1]['obv']}")
            
            # تست با indicator_calculator
            print("\n🧪 تست با indicator_calculator:")
            
            try:
                # آماده‌سازی داده برای ماشین حساب
                current_candle = {
                    'open_price': float(df_candles.iloc[-1]['open_price']),
                    'high_price': float(df_candles.iloc[-1]['high_price']),
                    'low_price': float(df_candles.iloc[-1]['low_price']),
                    'close_price': float(df_candles.iloc[-1]['close_price']),
                    'volume': float(df_candles.iloc[-1]['volume']) if not pd.isna(df_candles.iloc[-1]['volume']) else 0.0,
                    'symbol': coin_id
                }
                
                previous_candles = []
                for i in range(len(df_candles)-1):
                    prev_candle = {
                        'open_price': float(df_candles.iloc[i]['open_price']),
                        'high_price': float(df_candles.iloc[i]['high_price']),
                        'low_price': float(df_candles.iloc[i]['low_price']),
                        'close_price': float(df_candles.iloc[i]['close_price']),
                        'volume': float(df_candles.iloc[i]['volume']) if not pd.isna(df_candles.iloc[i]['volume']) else 0.0
                    }
                    previous_candles.append(prev_candle)
                
                # محاسبه
                indicators = calculator.calculate_all_indicators(
                    current_candle=current_candle,
                    previous_candles=previous_candles,
                    timeframe=timeframe
                )
                
                print(f"  ✅ OBV محاسبه شده: {indicators.get('obv', 'N/A')}")
                print(f"  ✅ ATR محاسبه شده: {indicators.get('atr', 'N/A')}")
                print(f"  ✅ Price Change: {indicators.get('price_change', 'N/A')}")
                
                # مقایسه
                if indicators.get('obv') is not None and indicators.get('obv') != 0:
                    print(f"  🔴 مشکل: ماشین حساب OBV می‌دهد ولی دیتابیس ندارد!")
                else:
                    print(f"  🔴 مشکل: ماشین حساب هم OBV نمی‌دهد!")
                    
            except Exception as e:
                print(f"  ❌ خطا در ماشین حساب: {e}")
                import traceback
                traceback.print_exc()
    
    conn.close()
    
    return df_candles

def fix_specific_problem(coin_id="1938", timeframe="15m"):
    """ترمیم یک ارز و تایم‌فریم خاص"""
    
    print(f"\n🔧 ترمیم ارز {coin_id} - تایم‌فریم {timeframe}")
    print("=" * 70)
    
    db_path = "../../../data/crypto_master.db"
    conn = sqlite3.connect(db_path)
    
    # دریافت تمام کندل‌های این ارز
    query = f"""
    SELECT id, open_time, open_price, high_price, low_price, 
           close_price, volume, rsi
    FROM crypto_klines 
    WHERE coin_id = '{coin_id}' AND timeframe = '{timeframe}'
    ORDER BY open_time ASC
    """
    
    df_all = pd.read_sql_query(query, conn)
    print(f"📊 تعداد کندل‌ها: {len(df_all)}")
    
    if len(df_all) == 0:
        print("❌ هیچ کندلی یافت نشد")
        return
    
    # بررسی و ترمیم هر کندل
    fixed_count = 0
    
    for i in range(len(df_all)):
        candle = df_all.iloc[i]
        
        # فقط کندل‌های بدون OBV را ترمیم کن
        cursor = conn.cursor()
        cursor.execute(f"SELECT obv FROM crypto_klines WHERE id = {candle['id']}")
        current_obv = cursor.fetchone()[0]
        
        if current_obv is not None and current_obv != 0:
            continue  # اگر OBV دارد، ردش کن
        
        # محاسبه OBV ساده
        if i == 0:
            # اولین کندل: OBV = حجم آن
            obv = float(candle['volume']) if not pd.isna(candle['volume']) else 0.0
        else:
            prev_candle = df_all.iloc[i-1]
            prev_close = float(prev_candle['close_price'])
            curr_close = float(candle['close_price'])
            volume = float(candle['volume']) if not pd.isna(candle['volume']) else 0.0
            
            # OBV قبلی را بگیر
            cursor.execute(f"SELECT obv FROM crypto_klines WHERE id = {prev_candle['id']}")
            prev_obv_result = cursor.fetchone()
            prev_obv = float(prev_obv_result[0]) if prev_obv_result and prev_obv_result[0] is not None else 0.0
            
            if curr_close > prev_close:
                obv = prev_obv + volume
            elif curr_close < prev_close:
                obv = prev_obv - volume
            else:
                obv = prev_obv  # بدون تغییر
        
        # محاسبه ATR ساده (True Range)
        if i == 0:
            atr = 0.0
        else:
            high = float(candle['high_price'])
            low = float(candle['low_price'])
            prev_close = float(df_all.iloc[i-1]['close_price'])
            
            tr = max(
                high - low,
                abs(high - prev_close),
                abs(low - prev_close)
            )
            
            # میانگین ساده برای ۱۴ کندل
            if i < 14:
                atr = tr
            else:
                # محاسبه میانگین True Rangeهای قبلی
                tr_values = []
                for j in range(max(0, i-13), i+1):
                    h = float(df_all.iloc[j]['high_price'])
                    l = float(df_all.iloc[j]['low_price'])
                    if j == 0:
                        pc = h  # تخمین
                    else:
                        pc = float(df_all.iloc[j-1]['close_price'])
                    
                    tr_val = max(h - l, abs(h - pc), abs(l - pc))
                    tr_values.append(tr_val)
                
                atr = sum(tr_values) / len(tr_values)
        
        # محاسبه Price Change
        if i == 0:
            price_change = 0.0
            price_change_percent = 0.0
        else:
            prev_close = float(df_all.iloc[i-1]['close_price'])
            curr_close = float(candle['close_price'])
            price_change = curr_close - prev_close
            if prev_close != 0:
                price_change_percent = (price_change / prev_close) * 100
            else:
                price_change_percent = 0.0
        
        # بروزرسانی دیتابیس
        try:
            update_query = f"""
            UPDATE crypto_klines 
            SET 
                obv = {obv},
                atr = {atr},
                price_change = {price_change},
                price_change_percent = {price_change_percent},
                updated_at = CURRENT_TIMESTAMP
            WHERE id = {candle['id']}
            """
            
            cursor.execute(update_query)
            fixed_count += 1
            
            if fixed_count % 100 == 0:
                print(f"  📈 {fixed_count} کندل ترمیم شد...")
                
        except Exception as e:
            print(f"  ❌ خطا در کندل {candle['id']}: {e}")
    
    conn.commit()
    conn.close()
    
    print(f"\n✅ ترمیم کامل شد: {fixed_count} کندل ترمیم شدند")
    
    # تأیید
    conn = sqlite3.connect(db_path)
    query_check = f"""
    SELECT 
        COUNT(*) as total,
        SUM(CASE WHEN obv IS NULL OR obv = 0 THEN 1 ELSE 0 END) as missing_obv,
        SUM(CASE WHEN atr IS NULL OR atr = 0 THEN 1 ELSE 0 END) as missing_atr
    FROM crypto_klines 
    WHERE coin_id = '{coin_id}' AND timeframe = '{timeframe}'
    """
    
    df_check = pd.read_sql_query(query_check, conn)
    conn.close()
    
    total = df_check.iloc[0]['total']
    missing_obv = df_check.iloc[0]['missing_obv']
    missing_atr = df_check.iloc[0]['missing_atr']
    
    print(f"\n📊 نتایج پس از ترمیم:")
    print(f"  • کل کندل‌ها: {total}")
    print(f"  • فاقد OBV: {missing_obv} ({missing_obv/total*100:.1f}%)")
    print(f"  • فاقد ATR: {missing_atr} ({missing_atr/total*100:.1f}%)")
    
    if missing_obv == 0 and missing_atr == 0:
        print("🎉 مشکل کاملاً حل شد!")
    else:
        print("⚠️ هنوز برخی مشکلات باقی مانده")

def bulk_fix_problematic_coins():
    """ترمیم دسته‌ای ارزهای مشکل‌دار"""
    
    db_path = "../../../data/crypto_master.db"
    conn = sqlite3.connect(db_path)
    
    print("🔧 ترمیم دسته‌ای ارزهای مشکل‌دار")
    print("=" * 70)
    
    # دریافت ۱۰ ارز با بیشترین مشکل
    query = """
    SELECT 
        coin_id,
        COUNT(*) as total,
        SUM(CASE WHEN obv IS NULL OR obv = 0 THEN 1 ELSE 0 END) as missing_obv,
        ROUND(SUM(CASE WHEN obv IS NULL OR obv = 0 THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 1) as percent_missing
    FROM crypto_klines
    GROUP BY coin_id
    HAVING percent_missing > 90  -- بیش از 90% مشکل
    ORDER BY percent_missing DESC
    LIMIT 10
    """
    
    df_problematic = pd.read_sql_query(query, conn)
    conn.close()
    
    print(f"🔴 {len(df_problematic)} ارز با مشکل شدید یافت شد")
    
    for idx, row in df_problematic.iterrows():
        coin_id = row['coin_id']
        percent = row['percent_missing']
        
        print(f"\n{idx+1}. ارز {coin_id}: {percent}% مشکل")
        print("-" * 40)
        
        # ترمیم برای تمام تایم‌فریم‌ها
        fix_specific_problem(coin_id, "15m")
        fix_specific_problem(coin_id, "1h")
        fix_specific_problem(coin_id, "4h")
        
        print(f"✅ ارز {coin_id} ترمیم شد")

if __name__ == "__main__":
    print("🐛 دیباگ و ترمیم ارزهای مشکل‌دار")
    print("=" * 70)
    
    # ۱. ابتدا دیباگ
    debug_coin_1938()
    
    # ۲. ترمیم تست
    print("\n" + "=" * 70)
    response = input("آیا می‌خواهید ارز 1938 را ترمیم کنید؟ (y/n): ")
    
    if response.lower() == 'y':
        fix_specific_problem("1938", "15m")
        
        # ۳. ترمیم دسته‌ای
        print("\n" + "=" * 70)
        response2 = input("آیا می‌خواهید سایر ارزهای مشکل‌دار را ترمیم کنید؟ (y/n): ")
        
        if response2.lower() == 'y':
            bulk_fix_problematic_coins()