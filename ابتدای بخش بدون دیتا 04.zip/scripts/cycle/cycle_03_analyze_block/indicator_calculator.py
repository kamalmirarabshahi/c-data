"""
🧮 ماشین حساب اندیکاتورهای تکنیکال - نسخه پایدار
نسخه برگشت به نسخه کارکرده با اصلاحات جزئی
"""

import numpy as np
import pandas as pd
from typing import List, Dict, Any, Optional, Tuple
import logging
from datetime import datetime, timedelta
import math
import sys
import os
import json
from collections import defaultdict

# اضافه کردن مسیر scripts به sys.path
current_file_dir = os.path.dirname(os.path.abspath(__file__))
scripts_dir = os.path.dirname(os.path.dirname(current_file_dir))

if scripts_dir not in sys.path:
    sys.path.insert(0, scripts_dir)

# تلاش برای ایمپورت config_manager
try:
    from config_manager import get_database_path, get, get_timeframes
    CONFIG_MANAGER_AVAILABLE = True
except ImportError:
    CONFIG_MANAGER_AVAILABLE = False

logger = logging.getLogger(__name__)

class QualityControlSystem:
    """سیستم کنترل کیفیت برای اندیکاتورها"""
    
    def __init__(self):
        self.problems = []
        self.problem_summary = defaultdict(int)
        self.recalculation_count = 0
        self.start_time = datetime.now()
        
        # اندیکاتورهای ضروری
        self.required_indicators = [
            'price_change', 'price_change_percent', 'obv', 'volume_ma_20',
            'volume_ratio', 'atr', 'rsi', 'macd', 'macd_signal', 'macd_histogram',
            'ma_7', 'ma_25', 'ma_99', 'bollinger_upper', 'bollinger_middle',
            'bollinger_lower', 'volatility', 'trend_strength'
        ]
        
        # تنظیمات کنترل کیفیت
        self.max_recalculation_attempts = 3
        self.acceptable_null_percentage = 5.0  # حداکثر 5% می‌تواند None باشد
        
        # مقادیر ایمن پیش‌فرض
        self.safe_defaults = {
            'rsi': 50.0,
            'macd': 0.0,
            'macd_signal': 0.0,
            'macd_histogram': 0.0,
            'price_change': 0.0,
            'price_change_percent': 0.0,
            'obv': 0.0,
            'volume_ma_20': 0.0,
            'volume_ratio': 1.0,
            'atr': 0.0,
            'volatility': 0.0,
            'trend_strength': 0.0,
            'ma_7': 0.0,
            'ma_25': 0.0,
            'ma_99': 0.0,
            'bollinger_upper': 0.0,
            'bollinger_middle': 0.0,
            'bollinger_lower': 0.0
        }
        
        logger.info("✅ سیستم کنترل کیفیت راه‌اندازی شد")
    
    def check_quality(self, indicators: Dict[str, Any], 
                     coin_id: int, timeframe: str) -> Dict[str, Any]:
        """بررسی کیفیت اندیکاتورهای محاسبه شده"""
        null_fields = []
        
        for indicator in self.required_indicators:
            if indicator in indicators:
                value = indicators[indicator]
                if value is None or (isinstance(value, float) and math.isnan(value)):
                    null_fields.append(indicator)
        
        null_count = len(null_fields)
        total_indicators = len(self.required_indicators)
        null_percentage = (null_count / total_indicators * 100) if total_indicators > 0 else 100
        
        is_acceptable = null_percentage <= self.acceptable_null_percentage
        quality_score = 100 - null_percentage
        
        report = {
            'coin_id': coin_id,
            'timeframe': timeframe,
            'null_count': null_count,
            'null_percentage': round(null_percentage, 2),
            'null_fields': null_fields,
            'is_acceptable': is_acceptable,
            'quality_score': round(quality_score, 2),
            'total_checked': total_indicators,
            'check_timestamp': datetime.now().isoformat()
        }
        
        if not is_acceptable:
            logger.warning(f"🔴 کیفیت پایین برای Coin {coin_id}: {null_count}/{total_indicators} فیلد خالی")
            self._record_problem(coin_id, timeframe, 'LOW_QUALITY', report)
        
        return report
    
    def ensure_no_none_values(self, indicators: Dict[str, Any]):
        """تضمین می‌کند هیچ فیلدی None نباشد"""
        for key, value in indicators.items():
            if value is None:
                if key in self.safe_defaults:
                    indicators[key] = self.safe_defaults[key]
                    logger.debug(f"   ⚠️  {key}: None → {indicators[key]}")
                elif isinstance(value, (int, float)):
                    if math.isnan(value) or math.isinf(value):
                        indicators[key] = 0.0
                        logger.debug(f"   ⚠️  {key}: NaN/Inf → 0.0")
    
    def _record_problem(self, coin_id: int, timeframe: str, 
                       problem_type: str, details: Any):
        """ثبت مشکل"""
        problem_record = {
            'timestamp': datetime.now().isoformat(),
            'coin_id': coin_id,
            'timeframe': timeframe,
            'problem_type': problem_type,
            'details': str(details)[:500]
        }
        
        self.problems.append(problem_record)
        self.problem_summary[problem_type] += 1
        
        # محدود کردن تعداد رکوردها
        if len(self.problems) > 10000:
            self.problems = self.problems[-5000:]
    
    def increment_recalculation(self):
        """افزایش شمارنده بازمحاسبه"""
        self.recalculation_count += 1
    
    def save_report(self, filepath: str = None):
        """ذخیره گزارش"""
        if filepath is None:
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            filepath = f"quality_report_{timestamp}.json"
        
        report = {
            'generated_at': datetime.now().isoformat(),
            'duration_seconds': (datetime.now() - self.start_time).total_seconds(),
            'total_problems': len(self.problems),
            'recalculations': self.recalculation_count,
            'problem_summary': dict(self.problem_summary),
            'recent_problems': self.problems[-1000:] if self.problems else [],
            'statistics': {
                'problems_per_hour': len(self.problems) / ((datetime.now() - self.start_time).total_seconds() / 3600)
                if (datetime.now() - self.start_time).total_seconds() > 0 else 0
            }
        }
        
        try:
            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump(report, f, ensure_ascii=False, indent=2)
            
            logger.info(f"💾 گزارش کیفیت در {filepath} ذخیره شد")
            return filepath
        except Exception as e:
            logger.error(f"❌ خطا در ذخیره گزارش: {e}")
            return None
    
    def print_summary(self):
        """چاپ خلاصه"""
        print("\n" + "="*80)
        print("📊 گزارش کنترل کیفیت")
        print("="*80)
        
        print(f"\n⏰ زمان اجرا: {(datetime.now() - self.start_time).total_seconds():.1f} ثانیه")
        print(f"📈 تعداد کل مشکلات: {len(self.problems):,}")
        print(f"🔄 بازمحاسبه‌ها: {self.recalculation_count:,}")
        
        if self.problems:
            print(f"\n🔍 خلاصه مشکلات:")
            for problem_type, count in sorted(self.problem_summary.items(), key=lambda x: x[1], reverse=True):
                print(f"  • {problem_type}: {count:,}")
            
            if self.problems:
                print(f"\n🚨 نمونه‌هایی از مشکلات (آخرین 5 مورد):")
                recent = self.problems[-5:] if len(self.problems) >= 5 else self.problems
                for i, problem in enumerate(recent, 1):
                    print(f"  {i}. Coin {problem['coin_id']} | {problem['timeframe']} | "
                          f"{problem['problem_type']} | {problem['timestamp']}")
        
        print("="*80)


class IndicatorCalculator:
    """ماشین حساب کامل اندیکاتورها - نسخه پایدار"""
    
    def __init__(self):
        logger.info("🧮 IndicatorCalculator (نسخه پایدار) راه‌اندازی شد")
        
        # بارگذاری پیشرفته تنظیمات از config_manager
        self._load_configuration()
        
        # تنظیمات وابسته به تایم‌فریم
        self.timeframe_settings = self._get_timeframe_settings()
        
        # سیستم کنترل کیفیت
        self.quality_system = QualityControlSystem()
        
        # سیستم کش برای جلوگیری از محاسبات تکراری
        self.calculation_cache = {}
        self.cache_stats = {'hits': 0, 'misses': 0}
        
        logger.info("✅ ماشین حساب با سیستم کنترل کیفیت راه‌اندازی شد")
    
    def _load_configuration(self):
        """بارگذاری پیشرفته تنظیمات از config_manager"""
        try:
            if CONFIG_MANAGER_AVAILABLE:
                from config_manager import get
                
                # ✅ بخش ۱: تنظیمات پایه اندیکاتورها
                self.rsi_period = get('analysis.rsi_period', 14)
                self.macd_fast = get('analysis.macd_fast', 12)
                self.macd_slow = get('analysis.macd_slow', 26)
                self.macd_signal = get('analysis.macd_signal', 9)
                self.bollinger_period = get('analysis.bollinger_period', 20)
                self.bollinger_std = get('analysis.bollinger_std', 2.0)
                self.atr_period = get('analysis.atr_period', 14)
                self.volume_ma_period = get('analysis.volume_ma_period', 20)
                
                # ✅ بخش ۲: تنظیمات کیفی
                self.min_data_points = get('analysis.min_data_points', 100)
                self.data_quality_threshold = get('analysis.data_quality_threshold', 70)
                self.max_price_deviation = get('analysis.max_price_deviation', 0.5)
                
                # ✅ بخش ۳: تنظیمات الگوهای کندلی
                self.doji_threshold = get('analysis.patterns.doji_threshold', 0.1)
                self.hammer_shadow_ratio = get('analysis.patterns.hammer_shadow_ratio', 2.0)
                self.shooting_star_threshold = get('analysis.patterns.shooting_star_threshold', 2.0)
                
                # ✅ بخش ۴: تنظیمات حجم
                self.avg_trade_size = get('analysis.volume.avg_trade_size', 1000)
                self.min_volume_threshold = get('analysis.volume.min_volume_threshold', 100)
                
                # ✅ بخش ۵: تنظیمات تایم‌فریم‌ها
                self.valid_timeframes = get('analysis.valid_timeframes', 
                                           ['1m', '5m', '15m', '30m', '1h', '4h', '1d', '1w'])
                
                logger.info("✅ تنظیمات پیشرفته اندیکاتورها از کانفیگ بارگذاری شد")
            else:
                logger.warning("⚠️ config_manager در دسترس نیست - استفاده از مقادیر پیش‌فرض")
                self._set_default_configuration()
                
        except Exception as e:
            logger.error(f"❌ خطا در بارگذاری تنظیمات: {e}")
            self._set_default_configuration()
    
    def _set_default_configuration(self):
        """تنظیمات پیش‌فرض در صورت عدم دسترسی به config_manager"""
        # تنظیمات پایه
        self.rsi_period = 14
        self.macd_fast = 12
        self.macd_slow = 26
        self.macd_signal = 9
        self.bollinger_period = 20
        self.bollinger_std = 2.0
        self.atr_period = 14
        self.volume_ma_period = 20
        
        # تنظیمات کیفی
        self.min_data_points = 100
        self.data_quality_threshold = 70
        self.max_price_deviation = 0.5
        
        # تنظیمات الگوها
        self.doji_threshold = 0.1
        self.hammer_shadow_ratio = 2.0
        self.shooting_star_threshold = 2.0
        
        # تنظیمات حجم
        self.avg_trade_size = 1000
        self.min_volume_threshold = 100
        
        # تنظیمات تایم‌فریم‌ها
        self.valid_timeframes = ['1m', '5m', '15m', '30m', '1h', '4h', '1d', '1w']
    
    def _get_timeframe_settings(self):
        """دریافت تنظیمات وابسته به تایم‌فریم"""
        return {
            '1m': {'atr_multiplier': 1.0, 'volatility_factor': 5.0},
            '5m': {'atr_multiplier': 1.5, 'volatility_factor': 4.0},
            '15m': {'atr_multiplier': 2.0, 'volatility_factor': 3.0},
            '30m': {'atr_multiplier': 2.5, 'volatility_factor': 2.5},
            '1h': {'atr_multiplier': 3.0, 'volatility_factor': 2.0},
            '4h': {'atr_multiplier': 4.0, 'volatility_factor': 1.5},
            '1d': {'atr_multiplier': 5.0, 'volatility_factor': 1.0},
            '1w': {'atr_multiplier': 6.0, 'volatility_factor': 0.8}
        }
    
    # ========== تابع اصلی با کنترل کیفیت ==========
    
    def calculate_all_indicators(self, current_candle: Dict[str, Any], 
                               previous_candles: List[Dict[str, Any]],
                               timeframe: str = '5m') -> Dict[str, Any]:
        """
        محاسبه کامل تمام اندیکاتورها با سیستم کنترل کیفیت و بازمحاسبه خودکار
        """
        coin_id = current_candle.get('coin_id')
        calculation_key = f"{coin_id}_{timeframe}_{current_candle.get('open_time', '')}"
        
        # بررسی کش
        if calculation_key in self.calculation_cache:
            self.cache_stats['hits'] += 1
            logger.debug(f"💾 استفاده از کش برای Coin {coin_id}")
            return self.calculation_cache[calculation_key]
        
        self.cache_stats['misses'] += 1
        
        logger.info(f"🔍 محاسبه اندیکاتورها برای Coin {coin_id} در {timeframe}")
        
        # اعتبارسنجی اولیه
        validation_result = self._validate_input(current_candle, previous_candles, timeframe)
        if not validation_result['is_valid']:
            logger.warning(f"❌ داده‌های ورودی معتبر نیستند برای Coin {coin_id}")
            result = self._get_safe_default_indicators(current_candle, timeframe, validation_result)
            return result
        
        # محاسبه با کنترل کیفیت
        final_result = None
        quality_report = None
        
        for attempt in range(self.quality_system.max_recalculation_attempts):
            logger.debug(f"   تلاش {attempt + 1} از {self.quality_system.max_recalculation_attempts}")
            
            # محاسبه اصلی
            indicators = self._compute_all_indicators_with_quality(
                current_candle, previous_candles, timeframe, coin_id, attempt
            )
            
            # بررسی کیفیت
            quality_report = self.quality_system.check_quality(indicators, coin_id, timeframe)
            
            if quality_report['is_acceptable']:
                # کیفیت قابل قبول
                final_result = indicators
                final_result['quality_score'] = quality_report['quality_score']
                final_result['calculation_attempts'] = attempt + 1
                final_result['quality_report'] = quality_report
                break
            else:
                # کیفیت پایین - ثبت مشکل
                logger.warning(f"⚠️  کیفیت پایین برای Coin {coin_id} در تلاش {attempt + 1}")
                
                # اگر آخرین تلاش است، از مقادیر ایمن استفاده کن
                if attempt == self.quality_system.max_recalculation_attempts - 1:
                    logger.error(f"❌ نتوانستیم کیفیت قابل قبول برای Coin {coin_id} بدست آوریم")
                    final_result = self._get_safe_indicators_with_quality_report(
                        current_candle, timeframe, coin_id, quality_report
                    )
                else:
                    # آماده‌سازی برای بازمحاسبه
                    logger.info(f"🔄 آماده‌سازی برای بازمحاسبه Coin {coin_id}...")
                    self.quality_system.increment_recalculation()
        
        # ذخیره در کش اگر نتیجه قابل قبول است
        if final_result and final_result.get('quality_score', 0) >= 80:
            self.calculation_cache[calculation_key] = final_result
            # محدودیت اندازه کش
            if len(self.calculation_cache) > 1000:
                self.calculation_cache.pop(next(iter(self.calculation_cache)))
        
        # اضافه کردن متادیتا
        if final_result:
            final_result.update(self._add_calculation_metadata(timeframe, len(previous_candles) + 1))
            final_result['coin_id'] = coin_id
            
            # اگر کیفیت پایین بود، علامت بزن
            if quality_report and not quality_report['is_acceptable']:
                final_result['requires_review'] = True
                final_result['review_reason'] = 'low_quality_indicators'
        
        logger.debug(f"✅ محاسبه برای Coin {coin_id} تکمیل شد")
        return final_result or self._get_safe_default_indicators(
            current_candle, timeframe, {'error': 'Calculation failed completely'}
        )
    
    def _compute_all_indicators_with_quality(self, current_candle: Dict[str, Any],
                                           previous_candles: List[Dict[str, Any]],
                                           timeframe: str,
                                           coin_id: int,
                                           attempt: int = 0) -> Dict[str, Any]:
        """محاسبه با در نظر گرفتن تلاش و کیفیت"""
        try:
            # ترکیب داده‌ها
            all_candles = previous_candles + [current_candle]
            candles = self._clean_and_prepare_data(all_candles, timeframe)
            
            # استخراج آرایه‌های پاک شده
            close_prices = np.array([c.get('close_price', 0) for c in candles if c.get('close_price')])
            open_prices = np.array([c.get('open_price', 0) for c in candles if c.get('open_price')])
            high_prices = np.array([c.get('high_price', 0) for c in candles if c.get('high_price')])
            low_prices = np.array([c.get('low_price', 0) for c in candles if c.get('low_price')])
            volumes = np.array([c.get('volume', 0) for c in candles if c.get('volume')])
            
            indicators = {'timeframe': timeframe, 'coin_id': coin_id}
            
            tf_settings = self.timeframe_settings.get(timeframe, {})
            
            # محاسبات با ایمنی بالا
            indicators.update(self._calculate_price_indicators(
                candles[-1], candles, close_prices, open_prices, high_prices, low_prices, tf_settings
            ))
            
            indicators.update(self._calculate_volume_indicators(
                candles[-1], candles, volumes, close_prices, tf_settings
            ))
            
            indicators.update(self._calculate_technical_indicators(
                candles, close_prices, tf_settings
            ))
            
            indicators.update(self._calculate_candle_patterns(candles[-1], timeframe))
            indicators.update(self._calculate_data_quality(candles))
            indicators.update(self._calculate_pattern_fields(candles[-1], candles))
            indicators.update(self._calculate_metadata(candles[-1], timeframe))
            
            # تضمین عدم وجود None
            self.quality_system.ensure_no_none_values(indicators)
            
            return indicators
            
        except Exception as e:
            logger.error(f"❌ خطا در محاسبه برای Coin {coin_id} (تلاش {attempt}): {e}")
            return self._get_minimal_safe_indicators(current_candle, timeframe, coin_id, str(e))
    
    def _get_minimal_safe_indicators(self, candle: Dict[str, Any], timeframe: str,
                                   coin_id: int, error_message: str) -> Dict[str, Any]:
        """حداقل اندیکاتورهای ایمن"""
        indicators = {
            'timeframe': timeframe,
            'coin_id': coin_id,
            'calculation_status': 'FAILED',
            'calculation_timestamp': datetime.now().isoformat(),
            'error_message': error_message,
            'requires_review': True,
            'review_reason': 'calculation_failed'
        }
        
        # اضافه کردن مقادیر ایمن
        for indicator, default_value in self.quality_system.safe_defaults.items():
            indicators[indicator] = default_value
        
        return indicators
    
    def _get_safe_indicators_with_quality_report(self, candle: Dict[str, Any], timeframe: str,
                                               coin_id: int, quality_report: Dict[str, Any]) -> Dict[str, Any]:
        """اندیکاتورهای ایمن با گزارش کیفیت"""
        indicators = self._get_minimal_safe_indicators(
            candle, timeframe, coin_id, 'Low quality - using safe defaults'
        )
        
        # اضافه کردن اطلاعات کیفیت
        indicators['quality_report'] = quality_report
        indicators['calculation_status'] = 'LOW_QUALITY'
        indicators['used_safe_defaults'] = True
        
        return indicators
    
    # ========== اصلاحات ضروری برای OBV و حجم ==========
    
    def _calculate_obv(self, close_prices: np.ndarray, volumes: np.ndarray) -> float:
        """محاسبه On-Balance Volume - نسخه اصلاح شده"""
        if len(close_prices) == 0 or len(volumes) == 0:
            return 0.0
        
        try:
            # اگر فقط یک کندل داریم، OBV = حجم آن
            if len(close_prices) == 1:
                return float(volumes[0]) if volumes[0] else 0.0
            
            # محاسبه OBV از اول به آخر (قدیمی به جدید)
            obv = float(volumes[0]) if volumes[0] else 0.0
            
            for i in range(1, len(close_prices)):
                if i >= len(volumes):
                    continue
                    
                if close_prices[i] > close_prices[i-1]:
                    # قیمت افزایش یافته: حجم را اضافه کن
                    obv += float(volumes[i]) if volumes[i] else 0
                elif close_prices[i] < close_prices[i-1]:
                    # قیمت کاهش یافته: حجم را کم کن
                    obv -= float(volumes[i]) if volumes[i] else 0
                # اگر قیمت مساوی باشد، OBV تغییر نمی‌کند
            
            return float(obv)
        except Exception as e:
            logger.warning(f"خطا در محاسبه OBV: {e}")
            # اگر خطا رخ داد، حجم کندل فعلی را برگردان
            if len(volumes) > 0:
                return float(volumes[-1]) if volumes[-1] else 0.0
            return 0.0
    
    def _calculate_volume_indicators(self, current_candle: Dict[str, Any], 
                                   candles: List[Dict[str, Any]],
                                   volumes: np.ndarray,
                                   close_prices: np.ndarray,
                                   timeframe_settings: Dict[str, Any]) -> Dict[str, Any]:
        """محاسبه اندیکاتورهای حجم - نسخه اصلاح شده"""
        indicators = {}
        
        try:
            current_volume = current_candle.get('volume', 0)
            
            # میانگین حجم متحرک - با انعطاف بیشتر
            if len(volumes) > 0:
                # حداقل ۵ کندل برای محاسبه معقول
                min_for_ma = 5
                if len(volumes) >= min_for_ma:
                    lookback = min(len(volumes), self.volume_ma_period)
                    volume_ma = np.mean(volumes[-lookback:])
                    indicators['volume_ma_20'] = float(volume_ma)
                    
                    # نسبت حجم
                    if volume_ma != 0 and current_volume != 0:
                        volume_ratio = current_volume / volume_ma
                        indicators['volume_ratio'] = float(max(0, min(10, volume_ratio)))  # حداکثر ۱۰ برابر
                    else:
                        indicators['volume_ratio'] = 1.0
                else:
                    # اگر کمتر از ۵ کندل، میانگین ساده
                    indicators['volume_ma_20'] = float(np.mean(volumes)) if len(volumes) > 0 else float(current_volume)
                    indicators['volume_ratio'] = 1.0
            
            # OBV اصلاح شده
            if len(close_prices) > 0 and len(volumes) > 0:
                indicators['obv'] = self._calculate_obv(close_prices, volumes)
            else:
                indicators['obv'] = float(current_volume)  # اگر داده‌ای نیست، حجم فعلی
            
            # حجم خریدار/فروشنده
            if 'taker_buy_volume' in current_candle and 'taker_sell_volume' in current_candle:
                indicators['taker_buy_volume'] = float(current_candle.get('taker_buy_volume', 0))
                indicators['taker_sell_volume'] = float(current_candle.get('taker_sell_volume', 0))
            
            # حجم نقل‌قول
            if 'quote_volume' in current_candle:
                indicators['quote_volume'] = float(current_candle.get('quote_volume', 0))
            else:
                # محاسبه تخمینی دقیق‌تر
                avg_price = np.mean([
                    current_candle.get('high_price', 0), 
                    current_candle.get('low_price', 0), 
                    current_candle.get('close_price', 0)
                ])
                indicators['quote_volume'] = float(current_candle.get('volume', 0) * avg_price)
            
        except Exception as e:
            logger.warning(f"خطا در محاسبه اندیکاتورهای حجم: {e}")
            # مقادیر ایمن بهتر
            indicators.update({
                'volume_ma_20': float(current_candle.get('volume', 0)),
                'volume_ratio': 1.0,
                'obv': float(current_candle.get('volume', 0)),
                'taker_buy_volume': 0.0,
                'taker_sell_volume': 0.0,
                'quote_volume': 0.0
            })
        
        return indicators
    
    def _calculate_atr(self, high_prices: np.ndarray, low_prices: np.ndarray, 
                      close_prices: np.ndarray, period: int = 14) -> float:
        """محاسبه Average True Range - نسخه اصلاح شده"""
        if len(high_prices) < 2 or len(low_prices) < 2:
            # اگر داده کافی نیست، True Range ساده را برگردان
            if len(high_prices) > 0 and len(low_prices) > 0:
                return float(high_prices[-1] - low_prices[-1])
            return 0.0
        
        try:
            # از حداقل داده موجود استفاده کن
            lookback = min(len(high_prices), len(low_prices), len(close_prices), period)
            
            tr_values = []
            for i in range(1, lookback + 1):
                if i < len(close_prices):
                    high_low = high_prices[-i] - low_prices[-i]
                    high_close = abs(high_prices[-i] - close_prices[-i-1])
                    low_close = abs(low_prices[-i] - close_prices[-i-1])
                    true_range = max(high_low, high_close, low_close)
                    tr_values.append(true_range)
            
            return float(np.mean(tr_values)) if tr_values else 0.0
        except Exception as e:
            logger.warning(f"خطا در محاسبه ATR: {e}")
            if len(high_prices) > 0 and len(low_prices) > 0:
                return float(high_prices[-1] - low_prices[-1])
            return 0.0
    
    # ========== توابع اصلی (بدون تغییر) ==========
    
    def _validate_input(self, current_candle: Dict[str, Any], 
                       previous_candles: List[Dict[str, Any]],
                       timeframe: str) -> Dict[str, Any]:
        """اعتبارسنجی جامع داده‌های ورودی"""
        errors = []
        warnings = []
        
        # ۱. بررسی تایم‌فریم
        if timeframe not in self.valid_timeframes:
            errors.append(f"تایم‌فریم نامعتبر: {timeframe}")
        
        # ۲. بررسی کندل فعلی
        required_fields = ['open_price', 'high_price', 'low_price', 'close_price', 'volume']
        for field in required_fields:
            if field not in current_candle or current_candle[field] is None:
                errors.append(f"فیلد ضروری {field} در کندل فعلی وجود ندارد")
        
        # ۳. بررسی مقادیر معقول
        ohlc_fields = ['open_price', 'high_price', 'low_price', 'close_price']
        for field in ohlc_fields:
            value = current_candle.get(field)
            if value is not None:
                if value <= 0:
                    errors.append(f"مقدار {field} نامعتبر (منفی یا صفر): {value}")
                elif value > 1e10:
                    errors.append(f"مقدار {field} غیرمنطقی: {value}")
        
        # ۴. بررسی consistency قیمت‌ها
        high = current_candle.get('high_price')
        low = current_candle.get('low_price')
        close = current_candle.get('close_price')
        open_price = current_candle.get('open_price')
        
        if all(v is not None for v in [high, low, close, open_price]):
            if high < low:
                errors.append(f"high_price ({high}) < low_price ({low})")
            if close > high or close < low:
                warnings.append(f"close_price ({close}) خارج از محدوده high/low")
            if abs(close - open_price) > open_price * self.max_price_deviation:
                warnings.append(f"اختلاف زیاد open/close: {abs(close - open_price):.2f}")
        
        # ۵. بررسی حجم
        volume = current_candle.get('volume', 0)
        if volume < self.min_volume_threshold:
            warnings.append(f"حجم کم: {volume}")
        
        # ۶. بررسی داده‌های تاریخی
        if len(previous_candles) < self.min_data_points // 2:
            warnings.append(f"داده‌های تاریخی کم: {len(previous_candles)} کندل")
        
        result = {
            'is_valid': len(errors) == 0,
            'errors': errors,
            'warnings': warnings,
            'has_enough_data': len(previous_candles) >= self.min_data_points,
            'data_points': len(previous_candles) + 1
        }
        
        if warnings:
            logger.debug(f"⚠️ هشدارهای ورودی: {warnings}")
        
        return result
    
    def _clean_and_prepare_data(self, candles: List[Dict[str, Any]], 
                               timeframe: str) -> List[Dict[str, Any]]:
        """پاکسازی و آماده‌سازی داده‌ها"""
        cleaned_candles = []
        
        for candle in candles:
            cleaned_candle = candle.copy()
            
            # حذف مقادیر نامعقول
            for field in ['open_price', 'high_price', 'low_price', 'close_price']:
                value = cleaned_candle.get(field)
                if value is not None:
                    if value <= 0 or value > 1e10 or math.isnan(value) or math.isinf(value):
                        cleaned_candle[field] = None
            
            if cleaned_candle.get('close_price') is None:
                continue
            
            # محاسبه تخمینی فیلدهای مفقود
            if cleaned_candle.get('volume') is None:
                cleaned_candle['volume'] = self._estimate_missing_value(candles, 'volume', 0)
            
            cleaned_candles.append(cleaned_candle)
        
        # مرتب‌سازی بر اساس زمان
        cleaned_candles.sort(key=lambda x: x.get('open_time', ''))
        
        logger.debug(f"📊 داده‌های پاکسازی شده: {len(cleaned_candles)} کندل")
        return cleaned_candles[-500:]  # محدودیت به ۵۰۰ کندل برای کارایی
    
    def _estimate_missing_value(self, candles: List[Dict[str, Any]], 
                               field: str, default_value: Any) -> Any:
        """تخمین مقدار فیلد مفقود بر اساس میانگین"""
        values = [c.get(field) for c in candles[-50:] if c.get(field) is not None]
        if values:
            return sum(values) / len(values)
        return default_value
    
    def _compute_all_indicators(self, candles: List[Dict[str, Any]], 
                               timeframe: str) -> Dict[str, Any]:
        """محاسبه اصلی تمام اندیکاتورها"""
        indicators = {}
        
        # استخراج آرایه‌های پاک شده
        close_prices = np.array([c.get('close_price', 0) for c in candles if c.get('close_price')])
        open_prices = np.array([c.get('open_price', 0) for c in candles if c.get('open_price')])
        high_prices = np.array([c.get('high_price', 0) for c in candles if c.get('high_price')])
        low_prices = np.array([c.get('low_price', 0) for c in candles if c.get('low_price')])
        volumes = np.array([c.get('volume', 0) for c in candles if c.get('volume')])
        
        indicators['timeframe'] = timeframe
        
        tf_settings = self.timeframe_settings.get(timeframe, {})
        
        # محاسبات با اصلاحات
        indicators.update(self._calculate_price_indicators(
            candles[-1], candles, close_prices, open_prices, high_prices, low_prices, tf_settings
        ))
        
        indicators.update(self._calculate_volume_indicators(
            candles[-1], candles, volumes, close_prices, tf_settings
        ))
        
        indicators.update(self._calculate_technical_indicators(
            candles, close_prices, tf_settings
        ))
        
        indicators.update(self._calculate_candle_patterns(candles[-1], timeframe))
        indicators.update(self._calculate_data_quality(candles))
        indicators.update(self._calculate_pattern_fields(candles[-1], candles))
        indicators.update(self._calculate_metadata(candles[-1], timeframe))
        
        return indicators
    
    def _calculate_price_indicators(self, current_candle: Dict[str, Any], 
                                   candles: List[Dict[str, Any]],
                                   close_prices: np.ndarray,
                                   open_prices: np.ndarray,
                                   high_prices: np.ndarray,
                                   low_prices: np.ndarray,
                                   timeframe_settings: Dict[str, Any]) -> Dict[str, Any]:
        """محاسبه اندیکاتورهای قیمت"""
        indicators = {}
        
        try:
            # تغییرات قیمت
            if len(close_prices) >= 2:
                prev_close = close_prices[-2]
                curr_close = close_prices[-1]
                indicators['price_change'] = float(curr_close - prev_close)
                if prev_close != 0:
                    change_percent = ((curr_close - prev_close) / prev_close) * 100
                    indicators['price_change_percent'] = float(max(-100, min(1000, change_percent)))
                else:
                    indicators['price_change_percent'] = 0.0
            
            # میانگین‌های متحرک
            indicators['ma_7'] = float(self._calculate_sma(close_prices, 7)) if len(close_prices) >= 7 else 0.0
            indicators['ma_25'] = float(self._calculate_sma(close_prices, 25)) if len(close_prices) >= 25 else 0.0
            indicators['ma_99'] = float(self._calculate_sma(close_prices, 99)) if len(close_prices) >= 99 else 0.0
            
            # باندهای بولینگر
            bb_upper, bb_middle, bb_lower = self._calculate_bollinger_bands(
                close_prices, self.bollinger_period, self.bollinger_std
            )
            indicators['bollinger_upper'] = float(bb_upper) if bb_upper else 0.0
            indicators['bollinger_middle'] = float(bb_middle) if bb_middle else 0.0
            indicators['bollinger_lower'] = float(bb_lower) if bb_lower else 0.0
            
            # RSI
            indicators['rsi'] = float(self._calculate_rsi(close_prices, self.rsi_period))
            
            # MACD
            macd, signal, histogram = self._calculate_macd(
                close_prices, self.macd_fast, self.macd_slow, self.macd_signal
            )
            indicators['macd'] = float(macd) if macd else 0.0
            indicators['macd_signal'] = float(signal) if signal else 0.0
            indicators['macd_histogram'] = float(histogram) if histogram else 0.0
            
            # ATR با ضریب تایم‌فریم
            atr = self._calculate_atr(high_prices, low_prices, close_prices, self.atr_period)
            atr_multiplier = timeframe_settings.get('atr_multiplier', 1.0)
            indicators['atr'] = float(atr * atr_multiplier)
            
            # نوسان با فاکتور تایم‌فریم
            if len(close_prices) >= 20:
                volatility = np.std(close_prices[-20:]) / np.mean(close_prices[-20:]) if np.mean(close_prices[-20:]) != 0 else 0.0
                volatility_factor = timeframe_settings.get('volatility_factor', 1.0)
                indicators['volatility'] = float(volatility * volatility_factor)
            
            # قدرت روند
            if len(close_prices) >= 50:
                short_ma = np.mean(close_prices[-10:])
                long_ma = np.mean(close_prices[-50:])
                if long_ma != 0:
                    trend_strength = abs((short_ma - long_ma) / long_ma) * 100
                    indicators['trend_strength'] = float(min(trend_strength, 100))
            
        except Exception as e:
            logger.warning(f"خطا در محاسبه اندیکاتورهای قیمت: {e}")
            indicators.update(self._get_safe_price_indicators(current_candle))
        
        return indicators
    
    def _get_safe_price_indicators(self, candle: Dict[str, Any]) -> Dict[str, Any]:
        """مقادیر ایمن برای اندیکاتورهای قیمت در صورت خطا"""
        close_price = candle.get('close_price', 0)
        return {
            'price_change': 0.0,
            'price_change_percent': 0.0,
            'ma_7': float(close_price),
            'ma_25': float(close_price),
            'ma_99': float(close_price),
            'bollinger_upper': float(close_price),
            'bollinger_middle': float(close_price),
            'bollinger_lower': float(close_price),
            'rsi': 50.0,
            'macd': 0.0,
            'macd_signal': 0.0,
            'macd_histogram': 0.0,
            'atr': 0.0,
            'volatility': 0.0,
            'trend_strength': 0.0
        }
    
    def _calculate_technical_indicators(self, candles: List[Dict[str, Any]], 
                                       close_prices: np.ndarray,
                                       timeframe_settings: Dict[str, Any]) -> Dict[str, Any]:
        """محاسبه اندیکاتورهای تکنیکال پیچیده"""
        indicators = {}
        
        try:
            # شاخص قدرت نسبی (RSI)
            if len(close_prices) >= self.rsi_period:
                rsi_value = self._calculate_rsi(close_prices, self.rsi_period)
                indicators['rsi'] = float(max(0, min(100, rsi_value)))
            
            # MACD کامل
            if len(close_prices) >= self.macd_slow:
                macd, signal, histogram = self._calculate_macd(
                    close_prices, self.macd_fast, self.macd_slow, self.macd_signal
                )
                if macd:
                    indicators['macd'] = float(macd)
                    indicators['macd_signal'] = float(signal)
                    indicators['macd_histogram'] = float(histogram)
            
        except Exception as e:
            logger.warning(f"خطا در محاسبه اندیکاتورهای تکنیکال: {e}")
            indicators['rsi'] = 50.0
            indicators['macd'] = 0.0
            indicators['macd_signal'] = 0.0
            indicators['macd_histogram'] = 0.0
        
        return indicators
    
    def _calculate_candle_patterns(self, candle: Dict[str, Any], 
                                  timeframe: str) -> Dict[str, Any]:
        """تشخیص الگوهای کندلی"""
        indicators = {}
        
        try:
            open_price = candle.get('open_price', 0)
            close_price = candle.get('close_price', 0)
            high_price = candle.get('high_price', 0)
            low_price = candle.get('low_price', 0)
            body_size = abs(close_price - open_price)
            total_range = high_price - low_price
            
            if total_range == 0:
                indicators.update({
                    'is_doji': False,
                    'is_hammer': False,
                    'is_shooting_star': False,
                    'candle_pattern': 'FLAT'
                })
                return indicators
            
            # دوجی
            is_doji = body_size <= (total_range * self.doji_threshold)
            indicators['is_doji'] = bool(is_doji)
            
            # چکش
            is_hammer = self._is_hammer_candle(candle)
            indicators['is_hammer'] = bool(is_hammer)
            
            # ستاره ثاقب
            is_shooting_star = self._is_shooting_star_candle(candle)
            indicators['is_shooting_star'] = bool(is_shooting_star)
            
            # نام الگوی کندلی
            pattern = self._detect_candle_pattern_name(candle)
            indicators['candle_pattern'] = pattern
            
        except Exception as e:
            logger.debug(f"خطا در تشخیص الگوهای کندلی: {e}")
            indicators.update({
                'is_doji': False,
                'is_hammer': False,
                'is_shooting_star': False,
                'candle_pattern': 'UNKNOWN'
            })
        
        return indicators
    
    def _is_hammer_candle(self, candle: Dict[str, Any]) -> bool:
        """تشخیص کندل چکش"""
        try:
            open_price = candle.get('open_price', 0)
            close_price = candle.get('close_price', 0)
            high_price = candle.get('high_price', 0)
            low_price = candle.get('low_price', 0)
            
            body_size = abs(close_price - open_price)
            upper_shadow = high_price - max(open_price, close_price)
            lower_shadow = min(open_price, close_price) - low_price
            
            if body_size == 0:
                return False
            
            is_bullish_hammer = (lower_shadow >= body_size * self.hammer_shadow_ratio and 
                               upper_shadow <= body_size * 0.3)
            
            return is_bullish_hammer
        except:
            return False
    
    def _is_shooting_star_candle(self, candle: Dict[str, Any]) -> bool:
        """تشخیص کندل ستاره ثاقب"""
        try:
            open_price = candle.get('open_price', 0)
            close_price = candle.get('close_price', 0)
            high_price = candle.get('high_price', 0)
            low_price = candle.get('low_price', 0)
            
            body_size = abs(close_price - open_price)
            upper_shadow = high_price - max(open_price, close_price)
            lower_shadow = min(open_price, close_price) - low_price
            
            if body_size == 0:
                return False
            
            is_shooting_star = (upper_shadow >= body_size * self.shooting_star_threshold and 
                              lower_shadow <= body_size * 0.3)
            
            return is_shooting_star
        except:
            return False
    
    def _detect_candle_pattern_name(self, candle: Dict[str, Any]) -> str:
        """تشخیص نام الگوی کندلی"""
        try:
            if self._is_hammer_candle(candle):
                return "HAMMER"
            elif self._is_shooting_star_candle(candle):
                return "SHOOTING_STAR"
            elif self._is_doji_candle(candle):
                return "DOJI"
            else:
                return "NORMAL"
        except:
            return "UNKNOWN"
    
    def _is_doji_candle(self, candle: Dict[str, Any]) -> bool:
        """تشخیص کندل دوجی"""
        try:
            open_price = candle.get('open_price', 0)
            close_price = candle.get('close_price', 0)
            high_price = candle.get('high_price', 0)
            low_price = candle.get('low_price', 0)
            
            body_size = abs(close_price - open_price)
            total_range = high_price - low_price
            
            if total_range == 0:
                return False
            
            return body_size <= (total_range * self.doji_threshold)
        except:
            return False
    
    def _calculate_data_quality(self, candles: List[Dict[str, Any]]) -> Dict[str, Any]:
        """محاسبه کیفیت داده"""
        indicators = {}
        
        try:
            missing_count = 0
            invalid_count = 0
            total_fields = 0
            
            for candle in candles[-50:]:
                for field in ['open_price', 'high_price', 'low_price', 'close_price', 'volume']:
                    total_fields += 1
                    value = candle.get(field)
                    
                    if value is None:
                        missing_count += 1
                    elif isinstance(value, (int, float)):
                        if field.endswith('_price') and (value <= 0 or value > 1e10):
                            invalid_count += 1
                        elif field == 'volume' and value < 0:
                            invalid_count += 1
            
            total_issues = missing_count + invalid_count
            quality_percentage = ((total_fields - total_issues) / total_fields * 100) if total_fields > 0 else 0
            
            indicators['missing_data_points'] = int(missing_count)
            indicators['invalid_data_points'] = int(invalid_count)
            indicators['data_quality'] = int(max(0, min(100, quality_percentage)))
            indicators['is_interpolated'] = bool(missing_count > 0)
            
        except Exception as e:
            logger.debug(f"خطا در محاسبه کیفیت داده: {e}")
            indicators.update({
                'missing_data_points': 0,
                'invalid_data_points': 0,
                'data_quality': 0,
                'is_interpolated': False
            })
        
        return indicators
    
    def _calculate_pattern_fields(self, current_candle: Dict[str, Any], 
                                 candles: List[Dict[str, Any]]) -> Dict[str, Any]:
        """محاسبه فیلدهای مربوط به Pattern"""
        indicators = {}
        
        try:
            indicators['pattern_markers'] = ''
            indicators['pattern_confidence'] = 0.0
            
            if len(candles) >= 50:
                close_prices = [c.get('close_price', 0) for c in candles[-50:]]
                if len(close_prices) >= 20:
                    short_ma = np.mean(close_prices[-10:])
                    long_ma = np.mean(close_prices[-20:])
                    if long_ma != 0:
                        trend_strength = abs((short_ma - long_ma) / long_ma) * 100
                        indicators['trend_strength'] = float(min(trend_strength, 100))
                    else:
                        indicators['trend_strength'] = 0.0
            else:
                indicators['trend_strength'] = 0.0
            
            if len(candles) >= 20:
                close_prices = [c.get('close_price', 0) for c in candles[-20:]]
                indicators['support_resistance_level'] = float(np.mean(close_prices))
            else:
                indicators['support_resistance_level'] = float(current_candle.get('close_price', 0))
            
        except Exception as e:
            logger.debug(f"خطا در محاسبه فیلدهای Pattern: {e}")
            indicators.update({
                'pattern_markers': '',
                'pattern_confidence': 0.0,
                'trend_strength': 0.0,
                'support_resistance_level': float(current_candle.get('close_price', 0))
            })
        
        return indicators
    
    def _calculate_metadata(self, current_candle: Dict[str, Any], 
                           timeframe: str) -> Dict[str, Any]:
        """محاسبه متادیتا"""
        indicators = {}
        
        try:
            open_time = current_candle.get('open_time')
            if open_time:
                try:
                    if isinstance(open_time, str):
                        date_part = open_time.split(' ')[0] if ' ' in open_time else open_time.split('T')[0]
                        indicators['candle_date'] = date_part
                except:
                    pass
            
            if timeframe in ['1d', '1w']:
                indicators['aggregation_level'] = 3
            elif timeframe in ['4h', '12h']:
                indicators['aggregation_level'] = 2
            else:
                indicators['aggregation_level'] = 1
            
            volume = current_candle.get('volume', 0)
            if volume > 0 and self.avg_trade_size > 0:
                indicators['number_of_trades'] = int(volume / self.avg_trade_size)
            else:
                indicators['number_of_trades'] = 0
            
        except Exception as e:
            logger.debug(f"خطا در محاسبه متادیتا: {e}")
            indicators.update({
                'candle_date': '',
                'aggregation_level': 1,
                'number_of_trades': 0
            })
        
        return indicators
    
    def _validate_results(self, indicators: Dict[str, Any]) -> List[str]:
        """اعتبارسنجی نتایج محاسبات"""
        errors = []
        
        try:
            # بررسی محدوده RSI
            rsi = indicators.get('rsi')
            if rsi is not None and not (0 <= rsi <= 100):
                errors.append(f"RSI خارج از محدوده: {rsi}")
            
            # بررسی consistency قیمت‌ها
            ma7 = indicators.get('ma_7')
            ma25 = indicators.get('ma_25')
            if ma7 and ma25 and abs(ma7 - ma25) > ma25 * 2:
                errors.append(f"اختلاف زیاد میانگین‌ها: MA7={ma7}, MA25={ma25}")
            
            # بررسی مقادیر NaN
            for key, value in indicators.items():
                if isinstance(value, float) and (math.isnan(value) or math.isinf(value)):
                    errors.append(f"مقدار NaN/Infinity در {key}")
        
        except Exception as e:
            logger.debug(f"خطا در اعتبارسنجی دستی: {e}")
        
        return errors
    
    def _calculate_final_data_quality(self, indicators: Dict[str, Any], 
                                     validation_result: Dict[str, Any]) -> int:
        """محاسبه کیفیت نهایی داده"""
        try:
            base_quality = indicators.get('data_quality', 100)
            
            if validation_result.get('warnings'):
                warning_penalty = min(len(validation_result['warnings']) * 2, 20)
                base_quality -= warning_penalty
            
            if 'validation_errors' in indicators:
                error_penalty = min(len(indicators['validation_errors']) * 5, 50)
                base_quality -= error_penalty
            
            if not validation_result.get('has_enough_data'):
                base_quality -= 20
            
            return max(0, min(100, int(base_quality)))
        except:
            return 50
    
    def _add_calculation_metadata(self, timeframe: str, data_points: int) -> Dict[str, Any]:
        """اضافه کردن متادیتای محاسبات"""
        return {
            'calculation_timestamp': datetime.now().isoformat(),
            'timeframe': timeframe,
            'data_points_used': data_points,
            'calculator_version': '3.0-QC',
            'config_used': {
                'rsi_period': self.rsi_period,
                'macd_fast': self.macd_fast,
                'macd_slow': self.macd_slow,
                'bollinger_period': self.bollinger_period,
                'atr_period': self.atr_period
            }
        }
    
    def _get_safe_default_indicators(self, current_candle: Dict[str, Any], 
                                    timeframe: str, 
                                    validation_result: Dict[str, Any]) -> Dict[str, Any]:
        """مقادیر پیش‌فرض ایمن با اطلاعات خطا"""
        indicators = self._get_default_indicators(current_candle, timeframe)
        
        indicators['calculation_status'] = 'FAILED'
        indicators['validation_result'] = validation_result
        indicators['data_quality'] = 0
        indicators['is_interpolated'] = True
        
        logger.warning(f"استفاده از مقادیر پیش‌فرض ایمن برای {timeframe}")
        return indicators
    
    # ========== توابع محاسباتی پایه ==========
    
    def _calculate_sma(self, prices: np.ndarray, period: int) -> float:
        """محاسبه میانگین متحرک ساده"""
        if len(prices) < period:
            return 0.0
        return float(np.mean(prices[-period:]))
    
    def _calculate_ema(self, prices: np.ndarray, period: int) -> float:
        """محاسبه میانگین متحرک نمایی"""
        if len(prices) < period:
            return 0.0
        
        try:
            weights = np.exp(np.linspace(-1., 0., period))
            weights /= weights.sum()
            
            ema = np.convolve(prices, weights, mode='valid')[:1]
            return float(ema[0]) if len(ema) > 0 else 0.0
        except:
            return float(np.mean(prices[-period:]))
    
    def _calculate_rsi(self, prices: np.ndarray, period: int = 14) -> float:
        """محاسبه شاخص قدرت نسبی"""
        if len(prices) < period + 1:
            return 50.0
        
        try:
            deltas = np.diff(prices)
            seed = deltas[:period+1]
            
            up = seed[seed >= 0].sum() / period
            down = -seed[seed < 0].sum() / period
            
            if down == 0:
                return 100.0
            
            rs = up / down
            rsi = 100.0 - (100.0 / (1.0 + rs))
            
            return max(0.0, min(100.0, float(rsi)))
        except:
            return 50.0
    
    def _calculate_macd(self, prices: np.ndarray, fast: int = 12, 
                       slow: int = 26, signal: int = 9) -> Tuple[Optional[float], Optional[float], Optional[float]]:
        """محاسبه MACD"""
        if len(prices) < slow:
            return None, None, None
        
        try:
            ema_fast = self._calculate_ema(prices, fast)
            ema_slow = self._calculate_ema(prices, slow)
            
            macd_line = ema_fast - ema_slow
            
            if len(prices) >= slow + signal:
                macd_values = []
                for i in range(signal):
                    start_idx = max(0, len(prices) - slow - i)
                    end_idx = len(prices) - i
                    if end_idx - start_idx >= slow:
                        segment = prices[start_idx:end_idx]
                        ema_fast_seg = self._calculate_ema(segment, fast)
                        ema_slow_seg = self._calculate_ema(segment, slow)
                        macd_values.append(ema_fast_seg - ema_slow_seg)
                
                if len(macd_values) >= signal:
                    signal_line = np.mean(macd_values[-signal:])
                    histogram = macd_line - signal_line
                    return macd_line, signal_line, histogram
            
            return macd_line, 0.0, macd_line
        except:
            return None, None, None
    
    def _calculate_bollinger_bands(self, prices: np.ndarray, period: int = 20, 
                                  std_dev: float = 2.0) -> Tuple[Optional[float], Optional[float], Optional[float]]:
        """محاسبه باندهای بولینگر"""
        if len(prices) < period:
            return None, None, None
        
        try:
            sma = np.mean(prices[-period:])
            std = np.std(prices[-period:])
            
            upper_band = sma + (std * std_dev)
            middle_band = sma
            lower_band = sma - (std * std_dev)
            
            return float(upper_band), float(middle_band), float(lower_band)
        except:
            return None, None, None
    
    def _get_default_indicators(self, current_candle: Dict[str, Any], 
                               timeframe: str = '5m') -> Dict[str, Any]:
        """مقادیر پیش‌فرض وقتی داده کافی نیست"""
        indicators = {}
        
        indicators['timeframe'] = timeframe
        
        indicators['price_change'] = 0.0
        indicators['price_change_percent'] = 0.0
        
        close_price = current_candle.get('close_price', 0)
        indicators['ma_7'] = float(close_price)
        indicators['ma_25'] = float(close_price)
        indicators['ma_99'] = float(close_price)
        
        indicators['bollinger_upper'] = float(close_price)
        indicators['bollinger_middle'] = float(close_price)
        indicators['bollinger_lower'] = float(close_price)
        
        indicators['rsi'] = 50.0
        
        indicators['macd'] = 0.0
        indicators['macd_signal'] = 0.0
        indicators['macd_histogram'] = 0.0
        
        indicators['atr'] = 0.0
        indicators['volatility'] = 0.0
        
        indicators['volume_ma_20'] = float(current_candle.get('volume', 0))
        indicators['volume_ratio'] = 1.0
        indicators['obv'] = 0.0
        
        indicators['is_doji'] = False
        indicators['is_hammer'] = False
        indicators['is_shooting_star'] = False
        indicators['candle_pattern'] = "NORMAL"
        
        indicators['data_quality'] = 50
        indicators['is_interpolated'] = True
        indicators['missing_data_points'] = 999
        
        indicators['pattern_markers'] = ''
        indicators['pattern_confidence'] = 0.0
        indicators['trend_strength'] = 0.0
        indicators['support_resistance_level'] = float(close_price)
        
        indicators['aggregation_level'] = 1
        indicators['number_of_trades'] = 0
        indicators['candle_date'] = ''
        
        indicators['quote_volume'] = 0.0
        indicators['taker_buy_volume'] = 0.0
        indicators['taker_sell_volume'] = 0.0
        
        indicators['calculation_status'] = 'DEFAULT'
        
        return indicators
    
    # ========== سیستم گزارش‌گیری ==========
    
    def save_quality_report(self, filepath: str = None):
        """ذخیره گزارش کیفیت"""
        return self.quality_system.save_report(filepath)
    
    def print_quality_summary(self):
        """چاپ خلاصه کیفیت"""
        self.quality_system.print_summary()
        
        # آمار کش
        total_cache = self.cache_stats['hits'] + self.cache_stats['misses']
        hit_rate = (self.cache_stats['hits'] / total_cache * 100) if total_cache > 0 else 0
        
        print(f"\n📊 آمار کش:")
        print(f"  • Hits: {self.cache_stats['hits']:,}")
        print(f"  • Misses: {self.cache_stats['misses']:,}")
        print(f"  • Hit Rate: {hit_rate:.1f}%")
        print(f"  • Cache Size: {len(self.calculation_cache):,}")
        print("="*80)


# Singleton برای استفاده آسان
calculator = IndicatorCalculator()