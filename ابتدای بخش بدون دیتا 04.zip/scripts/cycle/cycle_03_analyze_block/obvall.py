"""
📊 محاسبه‌گر OBV برای دیتابیس crypto_master.db
محاسبه OBV برای 300 کندل آخر هر سکه و تایم‌فریم
"""

import sqlite3
import logging
from datetime import datetime
from typing import List, Tuple, Dict, Any
import time
import os

# تنظیمات لاگ
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(f'obv_calculator_{datetime.now().strftime("%Y%m%d_%H%M%S")}.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class OBVCalculator:
    """ماشین حساب OBV"""
    
    def __init__(self):
        """مقداردهی اولیه"""
        self.db_path = r"C:\Users\Kamal\Desktop\py-prg\git\c-data\data\crypto_master.db"
        self.conn = None
        self.cursor = None
        
        # گزارش‌گیری
        self.report = {
            'start_time': datetime.now(),
            'total_coins_processed': 0,
            'total_timeframes_processed': 0,
            'candles_with_missing_obv': 0,
            'obv_calculated': 0,
            'errors': [],
            'failed_calculations': []
        }
    
    def connect(self):
        """اتصال به دیتابیس"""
        try:
            # بررسی وجود فایل
            if not os.path.exists(self.db_path):
                logger.error(f"❌ فایل دیتابیس یافت نشد: {self.db_path}")
                return False
            
            self.conn = sqlite3.connect(self.db_path)
            self.cursor = self.conn.cursor()
            
            # بررسی وجود جدول
            self.cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='crypto_klines'")
            if not self.cursor.fetchone():
                logger.error("❌ جدول crypto_klines در دیتابیس وجود ندارد")
                return False
            
            logger.info(f"✅ اتصال به دیتابیس موفق: {self.db_path}")
            return True
            
        except Exception as e:
            logger.error(f"❌ خطا در اتصال به دیتابیس: {e}")
            return False
    
    def disconnect(self):
        """قطع اتصال"""
        if self.conn:
            self.conn.close()
            logger.info("🔌 اتصال قطع شد")
    
    def check_obv_column(self):
        """بررسی وجود ستون obv و اضافه کردن آن اگر لازم باشد"""
        try:
            # دریافت لیست ستون‌ها
            self.cursor.execute("PRAGMA table_info(crypto_klines)")
            columns = self.cursor.fetchall()
            
            column_names = [col[1] for col in columns]
            
            if 'obv' in column_names:
                logger.info("✅ ستون obv وجود دارد")
                return True
            else:
                logger.info("➕ اضافه کردن ستون obv...")
                self.cursor.execute("ALTER TABLE crypto_klines ADD COLUMN obv REAL")
                self.conn.commit()
                logger.info("✅ ستون obv اضافه شد")
                return True
                
        except Exception as e:
            logger.error(f"❌ خطا در بررسی/اضافه کردن ستون obv: {e}")
            return False
    
    def get_all_coins_timeframes(self) -> List[Tuple[int, str]]:
        """
        دریافت تمام جفت‌های coin_id و timeframe منحصربه‌فرد
        بدون هیچ فیلتری
        """
        query = """
        SELECT DISTINCT coin_id, timeframe 
        FROM crypto_klines 
        ORDER BY coin_id, timeframe
        """
        
        try:
            self.cursor.execute(query)
            results = self.cursor.fetchall()
            logger.info(f"📊 تعداد جفت‌های coin/timeframe یافت شده: {len(results)}")
            return results
        except Exception as e:
            logger.error(f"❌ خطا در دریافت لیست سکه‌ها و تایم‌فریم‌ها: {e}")
            return []
    
    def get_candle_count(self, coin_id: int, timeframe: str) -> int:
        """تعداد کندل‌های یک سکه در تایم‌فریم خاص"""
        query = "SELECT COUNT(*) FROM crypto_klines WHERE coin_id = ? AND timeframe = ?"
        
        try:
            self.cursor.execute(query, (coin_id, timeframe))
            return self.cursor.fetchone()[0]
        except Exception as e:
            logger.error(f"❌ خطا در شمارش کندل‌ها: {e}")
            return 0
    
    def get_candles_needing_obv(self, coin_id: int, timeframe: str, limit: int = 300) -> List[Tuple]:
        """
        دریافت کندل‌هایی که OBV ندارند (NULL یا 0)
        
        Returns:
            لیست (id, open_time, close_price, volume)
        """
        query = """
        SELECT id, open_time, close_price, volume, obv
        FROM crypto_klines 
        WHERE coin_id = ? AND timeframe = ? 
        ORDER BY open_time ASC
        LIMIT ?
        """
        
        try:
            self.cursor.execute(query, (coin_id, timeframe, limit))
            candles = self.cursor.fetchall()
            
            # فیلتر کردن کندل‌هایی که OBV ندارند
            candles_needing_obv = []
            for candle in candles:
                candle_id, open_time, close_price, volume, obv = candle
                
                # اگر OBV صفر، None، یا خالی است
                if obv is None or obv == 0 or obv == 0.0:
                    candles_needing_obv.append((candle_id, open_time, close_price, volume))
            
            logger.debug(f"  برای coin_id={coin_id}, timeframe={timeframe}: {len(candles_needing_obv)} کندل نیاز به OBV دارد")
            return candles_needing_obv
            
        except Exception as e:
            logger.error(f"❌ خطا در دریافت کندل‌های بدون OBV: {e}")
            return []
    
    def calculate_obv(self, candles: List[Tuple]) -> List[Tuple[int, float]]:
        """
        محاسبه OBV برای لیست کندل‌ها
        
        Args:
            candles: لیست (id, open_time, close_price, volume)
            
        Returns:
            لیست (id, obv_value)
        """
        if not candles:
            return []
        
        results = []
        obv_accumulator = 0.0
        
        try:
            for i, (candle_id, open_time, close_price, volume) in enumerate(candles):
                # تبدیل به float با کنترل خطا
                try:
                    close_float = float(close_price) if close_price is not None else 0.0
                    volume_float = float(volume) if volume is not None else 0.0
                except (ValueError, TypeError):
                    close_float = 0.0
                    volume_float = 0.0
                
                # اگر اولین کندل است
                if i == 0:
                    obv_accumulator = volume_float
                else:
                    # کندل قبلی
                    prev_candle = candles[i-1]
                    prev_close = prev_candle[2]
                    
                    try:
                        prev_close_float = float(prev_close) if prev_close is not None else 0.0
                    except (ValueError, TypeError):
                        prev_close_float = 0.0
                    
                    # محاسبه OBV
                    if close_float > prev_close_float:
                        obv_accumulator += volume_float
                    elif close_float < prev_close_float:
                        obv_accumulator -= volume_float
                    # اگر قیمت برابر باشد، تغییر نمی‌کند
                
                results.append((candle_id, float(obv_accumulator)))
            
            logger.info(f"📈 OBV برای {len(results)} کندل محاسبه شد")
            return results
            
        except Exception as e:
            logger.error(f"❌ خطا در محاسبه OBV: {e}")
            return []
    
    def update_obv_values(self, obv_results: List[Tuple[int, float]]) -> int:
        """
        بروزرسانی مقادیر OBV در دیتابیس
        
        Returns:
            تعداد رکوردهای بروزرسانی شده
        """
        if not obv_results:
            return 0
        
        updated_count = 0
        
        try:
            update_query = """
            UPDATE crypto_klines 
            SET obv = ?, 
                updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
            """
            
            for candle_id, obv_value in obv_results:
                try:
                    self.cursor.execute(update_query, (float(obv_value), candle_id))
                    updated_count += 1
                    
                    # Commit هر 100 رکورد برای کارایی
                    if updated_count % 100 == 0:
                        self.conn.commit()
                        logger.debug(f"  ✅ {updated_count} رکورد commit شد")
                        
                except Exception as e:
                    logger.warning(f"⚠️ خطا در بروزرسانی رکورد {candle_id}: {e}")
            
            # Commit نهایی
            self.conn.commit()
            logger.info(f"✅ مجموع {updated_count} رکورد بروزرسانی شد")
            return updated_count
            
        except Exception as e:
            logger.error(f"❌ خطا در بروزرسانی دیتابیس: {e}")
            self.conn.rollback()
            return 0
    
    def process_coin_timeframe(self, coin_id: int, timeframe: str) -> Dict[str, Any]:
        """
        پردازش یک سکه و تایم‌فریم
        
        Returns:
            آمار پردازش
        """
        stats = {
            'coin_id': coin_id,
            'timeframe': timeframe,
            'total_candles': 0,
            'candles_needing_obv': 0,
            'obv_calculated': 0,
            'success': False,
            'error': None
        }
        
        try:
            logger.info(f"🔄 پردازش coin_id={coin_id}, timeframe={timeframe}")
            
            # تعداد کل کندل‌ها
            total_candles = self.get_candle_count(coin_id, timeframe)
            stats['total_candles'] = total_candles
            
            if total_candles == 0:
                logger.info(f"  ⚠️  هیچ کندلی برای این جفت وجود ندارد")
                stats['success'] = True
                return stats
            
            # دریافت کندل‌های نیازمند OBV (حداکثر 300 کندل آخر)
            candles_needing_obv = self.get_candles_needing_obv(coin_id, timeframe, 300)
            stats['candles_needing_obv'] = len(candles_needing_obv)
            
            if not candles_needing_obv:
                logger.info(f"  ✅ تمام کندل‌ها دارای OBV هستند")
                stats['success'] = True
                return stats
            
            # محاسبه OBV
            obv_results = self.calculate_obv(candles_needing_obv)
            
            if not obv_results:
                error_msg = "محاسبه OBV ناموفق بود"
                stats['error'] = error_msg
                logger.error(f"  ❌ {error_msg}")
                return stats
            
            # بروزرسانی دیتابیس
            updated_count = self.update_obv_values(obv_results)
            stats['obv_calculated'] = updated_count
            
            if updated_count > 0:
                stats['success'] = True
                logger.info(f"  ✅ {updated_count} OBV محاسبه و ذخیره شد")
            else:
                error_msg = "بروزرسانی دیتابیس ناموفق بود"
                stats['error'] = error_msg
                logger.error(f"  ❌ {error_msg}")
            
            return stats
            
        except Exception as e:
            error_msg = f"خطای عمومی: {str(e)}"
            stats['error'] = error_msg
            logger.error(f"❌ {error_msg}")
            return stats
    
    def run(self):
        """اجرای اصلی برنامه"""
        logger.info("🚀 شروع محاسبه OBV برای crypto_master.db")
        
        # اتصال به دیتابیس
        if not self.connect():
            return
        
        # بررسی/اضافه کردن ستون obv
        if not self.check_obv_column():
            self.disconnect()
            return
        
        # دریافت تمام جفت‌های coin/timeframe
        coin_timeframes = self.get_all_coins_timeframes()
        
        if not coin_timeframes:
            logger.error("❌ هیچ سکه/تایم‌فریمی یافت نشد")
            self.disconnect()
            return
        
        total_pairs = len(coin_timeframes)
        logger.info(f"🔢 تعداد کل جفت‌ها برای پردازش: {total_pairs}")
        
        # پردازش هر جفت
        successful = 0
        failed = 0
        
        for i, (coin_id, timeframe) in enumerate(coin_timeframes, 1):
            logger.info(f"📊 پردازش {i}/{total_pairs}: coin_id={coin_id}, timeframe={timeframe}")
            
            stats = self.process_coin_timeframe(coin_id, timeframe)
            
            # جمع‌آوری آمار
            if stats['success']:
                successful += 1
                self.report['obv_calculated'] += stats['obv_calculated']
                self.report['candles_with_missing_obv'] += stats['candles_needing_obv']
            else:
                failed += 1
                self.report['failed_calculations'].append({
                    'coin_id': coin_id,
                    'timeframe': timeframe,
                    'error': stats['error']
                })
            
            # وقفه کوتاه هر 10 پردازش
            if i % 10 == 0:
                time.sleep(0.1)
                logger.info(f"📊 پیشرفت: {i}/{total_pairs} ({i/total_pairs*100:.1f}%)")
        
        # جمع‌بندی
        self.report['total_coins_processed'] = successful + failed
        self.report['total_timeframes_processed'] = total_pairs
        
        # قطع اتصال
        self.disconnect()
        
        # نمایش گزارش
        self.print_report()
    
    def print_report(self):
        """چاپ گزارش نهایی"""
        print("\n" + "="*80)
        print("📊 گزارش نهایی محاسبه OBV")
        print("="*80)
        
        duration = datetime.now() - self.report['start_time']
        
        print(f"⏰ زمان اجرا: {duration.total_seconds():.1f} ثانیه")
        print(f"📁 دیتابیس: crypto_master.db")
        print(f"🔢 تعداد جفت‌های پردازش شده: {self.report['total_timeframes_processed']}")
        print(f"✅ پردازش موفق: {self.report['total_coins_processed'] - len(self.report['failed_calculations'])}")
        print(f"❌ پردازش ناموفق: {len(self.report['failed_calculations'])}")
        print(f"📈 کندل‌های نیازمند OBV: {self.report['candles_with_missing_obv']:,}")
        print(f"🧮 OBV محاسبه شده: {self.report['obv_calculated']:,}")
        
        if self.report['failed_calculations']:
            print(f"\n🚫 خطاها (5 مورد اول):")
            for error in self.report['failed_calculations'][:5]:
                print(f"  • coin_id={error['coin_id']}, timeframe={error['timeframe']}: {error['error']}")
        
        print("="*80)
        
        # ذخیره گزارش
        self.save_report()
    
    def save_report(self):
        """ذخیره گزارش در فایل"""
        try:
            filename = f"obv_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
            
            with open(filename, 'w', encoding='utf-8') as f:
                f.write("="*80 + "\n")
                f.write("گزارش محاسبه OBV\n")
                f.write("="*80 + "\n\n")
                
                duration = datetime.now() - self.report['start_time']
                
                f.write(f"تاریخ اجرا: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
                f.write(f"مدت زمان: {duration.total_seconds():.1f} ثانیه\n")
                f.write(f"دیتابیس: crypto_master.db\n")
                f.write(f"تعداد جفت‌های پردازش شده: {self.report['total_timeframes_processed']}\n")
                f.write(f"پردازش موفق: {self.report['total_coins_processed'] - len(self.report['failed_calculations'])}\n")
                f.write(f"پردازش ناموفق: {len(self.report['failed_calculations'])}\n")
                f.write(f"کندل‌های نیازمند OBV: {self.report['candles_with_missing_obv']:,}\n")
                f.write(f"OBV محاسبه شده: {self.report['obv_calculated']:,}\n\n")
                
                if self.report['failed_calculations']:
                    f.write("خطاها:\n")
                    for error in self.report['failed_calculations']:
                        f.write(f"  • coin_id={error['coin_id']}, timeframe={error['timeframe']}: {error['error']}\n")
            
            logger.info(f"💾 گزارش در {filename} ذخیره شد")
            
        except Exception as e:
            logger.error(f"❌ خطا در ذخیره گزارش: {e}")


def main():
    """تابع اصلی"""
    print("🧮 محاسبه OBV برای دیتابیس crypto_master.db")
    print("="*80)
    
    calculator = OBVCalculator()
    calculator.run()
    
    print("\n🎉 عملیات به پایان رسید!")


if __name__ == "__main__":
    main()