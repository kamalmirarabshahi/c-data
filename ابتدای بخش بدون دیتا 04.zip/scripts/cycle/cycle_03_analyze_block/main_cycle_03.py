﻿"""
🎪 ماژول اصلی تکه ۳ - تحلیل کندل‌ها و محاسبه اندیکاتورها
نویسنده: سیستم تحلیل کریپتو
تاریخ: ۲۰۲۵-۱۲-۲۳
نسخه: ۲.۰.۱ (استفاده از توابع موجود config_manager)
"""

import sys
import os
import json
import sqlite3
import logging
from datetime import datetime
import argparse
import time

# FIX: اضافه کردن مسیر scripts به sys.path
current_file_dir = os.path.dirname(os.path.abspath(__file__))
scripts_dir = os.path.dirname(os.path.dirname(current_file_dir))  # دو سطح بالا!

if scripts_dir not in sys.path:
    sys.path.insert(0, scripts_dir)

# حالا importهای دیگه
from config_manager import get_database_path, get, get_timeframes, get_path_config, get_logs_dir

# تنظیمات لاگ‌گیری
def setup_logging():
    """تنظیمات لاگ‌گیری با استفاده از config_manager"""
    try:
        # دریافت مسیر لاگ از config_manager
        logs_dir = get_logs_dir()
        log_file = os.path.join(logs_dir, 'cycle_03.log')
        
        # ایجاد پوشه لاگ اگر وجود ندارد
        os.makedirs(os.path.dirname(log_file), exist_ok=True)
        
        # دریافت سطح لاگ از تنظیمات
        log_level = get('logging.level', 'INFO')
        level_map = {
            'DEBUG': logging.DEBUG,
            'INFO': logging.INFO,
            'WARNING': logging.WARNING,
            'ERROR': logging.ERROR,
            'CRITICAL': logging.CRITICAL
        }
        log_level_value = level_map.get(log_level.upper(), logging.INFO)
        
        # پیکربندی لاگ‌گیری
        logging.basicConfig(
            level=log_level_value,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler(log_file, encoding='utf-8'),
                logging.StreamHandler()
            ]
        )
        
        # تنظیم سطح لاگ برای root logger
        logging.getLogger().setLevel(log_level_value)
        
        return logging.getLogger(__name__)
    except Exception as e:
        # فال‌بک به تنظیمات پیش‌فرض
        print(f"⚠️ خطا در تنظیمات لاگ‌گیری: {e}. استفاده از تنظیمات پیش‌فرض")
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            handlers=[
                logging.StreamHandler()
            ]
        )
        return logging.getLogger(__name__)

logger = setup_logging()

def import_modules():
    """وارد کردن ماژول‌های مورد نیاز"""
    try:
        current_dir = os.path.dirname(os.path.abspath(__file__))
        sys.path.append(current_dir)
        
        from indicator_calculator import IndicatorCalculator
        from validator import Validator
        from candle_processor import CandleProcessor
        from database_updater import DatabaseUpdater
        from report_generator import ReportGenerator
        
        logger.info("✅ همه ماژول‌ها با موفقیت import شدند")
        return {
            'indicator_calculator': IndicatorCalculator,
            'validator': Validator,
            'candle_processor': CandleProcessor,
            'database_updater': DatabaseUpdater,
            'report_generator': ReportGenerator
        }
    except ImportError as e:
        logger.error(f"❌ خطا در import ماژول‌ها: {e}")
        logger.error("📁 فایل‌های موجود در پوشه:")
        for f in os.listdir(os.path.dirname(__file__)):
            logger.error(f"  - {f}")
        raise

class MainCoordinator:
    """هماهنگ کننده اصلی تکه ۳"""
    
    def __init__(self):
        logger.info("🚀 ایجاد MainCoordinator")
        
        # بارگذاری تنظیمات
        self.load_configuration()
        
        modules = import_modules()
        
        self.indicator_calculator = modules['indicator_calculator']()
        self.validator = modules['validator']()
        self.candle_processor = modules['candle_processor']()
        self.database_updater = modules['database_updater']()
        self.report_generator = modules['report_generator']()
        
        logger.info("✅ همه ماژول‌ها نمونه‌سازی شدند")
    
    def load_configuration(self):
        """بارگذاری تنظیمات از config_manager"""
        try:
            # دریافت تنظیمات مسیرها
            path_config = get_path_config()
            
            # مسیرها
            self.project_root = path_config.get('project_root', 'C:/Users/Kamal/Desktop/py-prg/git/c-data')
            self.state_dir = path_config.get('state_dir', os.path.join(self.project_root, 'state'))
            
            # تنظیمات cycle
            self.max_coins_per_block = get('cycle.max_coins_per_block', 
                                          get('collection.max_coins_per_cycle', 20))
            self.state_file_name = get('cycle.state_file', 'cycle_state.json')
            
            # تنظیمات تحلیل
            self.min_candles_for_analysis = get('collection.min_candles_for_analysis', 25)
            self.timeframes = get_timeframes()  # استفاده از تابع موجود
            
            # تنظیمات تاخیر
            self.delay_between_timeframes = get('cycle.delay_between_timeframes', 0.05)
            self.delay_between_coins = get('cycle.delay_between_coins', 0.1)
            
            # ارزهای پیش‌فرض
            self.default_symbols = get('analysis.default_symbols', ['BTCUSDT', 'ETHUSDT', 'BNBUSDT'])
            
            logger.info("✅ تنظیمات از config_manager بارگذاری شد")
            logger.info(f"  📁 مسیر state: {self.state_dir}")
            logger.info(f"  📊 حداکثر ارزها: {self.max_coins_per_block}")
            logger.info(f"  🕯️ حداقل کندل‌ها: {self.min_candles_for_analysis}")
            logger.info(f"  ⏰ تایم‌فریم‌ها: {self.timeframes}")
            
        except Exception as e:
            logger.warning(f"⚠️ خطا در بارگذاری تنظیمات: {e}. استفاده از مقادیر پیش‌فرض")
            self.set_default_configuration()
    
    def set_default_configuration(self):
        """تنظیمات پیش‌فرض در صورت خطا"""
        self.project_root = 'C:/Users/Kamal/Desktop/py-prg/git/c-data'
        self.state_dir = os.path.join(self.project_root, 'state')
        self.max_coins_per_block = 20
        self.state_file_name = 'cycle_state.json'
        self.min_candles_for_analysis = 25
        self.timeframes = ["5m", "15m", "1h", "4h"]
        self.delay_between_timeframes = 0.05
        self.delay_between_coins = 0.1
        self.default_symbols = ['BTCUSDT', 'ETHUSDT', 'BNBUSDT']
    
    def get_state_path(self):
        """دریافت مسیر کامل فایل state"""
        return os.path.join(self.state_dir, self.state_file_name)
    
    def get_block_coins(self, block_id):
        """دریافت ارزهای یک بلوک از cycle_state.json"""
        try:
            state_path = self.get_state_path()
            
            logger.info(f"🔍 جستجوی فایل وضعیت: {state_path}")
            
            if not os.path.exists(state_path):
                logger.error(f"❌ فایل {state_path} پیدا نشد")
                return self._get_default_coins()
            
            with open(state_path, 'r', encoding='utf-8') as f:
                state = json.load(f)
            
            logger.info(f"✅ فایل وضعیت خوانده شد. cycle_id: {state.get('cycle_id', 'Unknown')}")
            
            blocks = state.get('blocks', [])
            logger.info(f"📊 تعداد بلوک‌های موجود: {len(blocks)}")
            
            if not blocks:
                logger.error("❌ هیچ بلوکی در فایل وجود ندارد")
                return self._get_default_coins()
            
            # پیدا کردن بلوک مورد نظر
            target_block = None
            for block in blocks:
                if block.get('block_id') == block_id:
                    target_block = block
                    break
            
            if not target_block:
                logger.error(f"❌ بلوک {block_id} پیدا نشد. بلوک‌های موجود: {[b.get('block_id') for b in blocks]}")
                return self._get_default_coins()
            
            # گرفتن لیست ارزها
            coins = target_block.get('coins', [])
            logger.info(f"📦 بلوک {block_id}: {len(coins)} ارز پیدا شد")
            
            # تبدیل ساختار اگر لازم باشد
            processed_coins = []
            for coin in coins:
                # coin می‌تواند یک string (نماد) یا dict باشد
                if isinstance(coin, str):
                    processed_coins.append({"symbol": coin, "name": coin})
                elif isinstance(coin, dict):
                    # اگر coin دیکشنری است
                    symbol = coin.get('symbol', '')
                    if not symbol:
                        # شاید کلید 'id' یا چیز دیگری باشد
                        symbol = str(coin.get('id', '')) or str(coin.get('coin_id', ''))
                    
                    name = coin.get('name', symbol)
                    processed_coins.append({"symbol": symbol, "name": name})
                else:
                    logger.warning(f"⚠️ فرمت نامشخص برای coin: {coin}")
            
            # اگر coins خالی بود، از symbols استفاده کن
            if not processed_coins and 'symbols' in target_block:
                symbols = target_block.get('symbols', [])
                for symbol in symbols:
                    processed_coins.append({"symbol": symbol, "name": symbol})
                logger.info(f"📝 استفاده از لیست symbols: {len(processed_coins)} ارز")
            
            if not processed_coins:
                logger.warning("⚠️ هیچ ارزی در بلوک پیدا نشد، استفاده از لیست پیش‌فرض")
                return self._get_default_coins()
            
            # نمایش ارزها
            for i, coin in enumerate(processed_coins[:5], 1):
                logger.info(f"   {i}. {coin.get('symbol', 'Unknown')} - {coin.get('name', '')}")
            
            if len(processed_coins) > 5:
                logger.info(f"   ... و {len(processed_coins) - 5} ارز دیگر")
            
            # محدود کردن تعداد ارزها بر اساس تنظیمات
            max_coins = min(self.max_coins_per_block, len(processed_coins))
            return processed_coins[:max_coins]
            
        except Exception as e:
            logger.error(f"❌ خطا در دریافت ارزهای بلوک {block_id}: {e}")
            return self._get_default_coins()
    
    def _get_default_coins(self):
        """دریافت لیست پیش‌فرض ارزها از تنظیمات"""
        return [
            {"symbol": sym, "name": sym.replace('USDT', '')} 
            for sym in self.default_symbols
        ]
    
    def process_single_coin_timeframe(self, coin_symbol: str, timeframe: str):
        """پردازش کامل یک ارز برای یک تایم‌فریم مشخص"""
        try:
            logger.info(f"🔄 شروع پردازش ارز: {coin_symbol} ({timeframe})")
            
            # ۱. دریافت کندل‌ها برای تایم‌فریم مشخص
            candles = self.candle_processor.get_candles_for_coin_timeframe(coin_symbol, timeframe)
            
            if not candles:
                logger.warning(f"⚠️ هیچ کندلی برای {coin_symbol} ({timeframe}) پیدا نشد")
                return {
                    'symbol': coin_symbol, 
                    'timeframe': timeframe, 
                    'status': 'NO_DATA', 
                    'processed': 0
                }
            
            # استفاده از حداقل کندل‌های تنظیم شده
            if len(candles) < self.min_candles_for_analysis:
                logger.warning(f"⚠️ کندل کافی برای {coin_symbol} ({timeframe}) نیست: {len(candles)} کندل (حداقل: {self.min_candles_for_analysis})")
                return {
                    'symbol': coin_symbol, 
                    'timeframe': timeframe, 
                    'status': 'INSUFFICIENT_DATA', 
                    'processed': 0
                }
            
            logger.info(f"📊 {coin_symbol} ({timeframe}): {len(candles)} کندل دریافت شد")
            
            # ۲. پردازش هر کندل
            processed_count = 0
            total_candles = len(candles)
            
            for i in range(total_candles):
                try:
                    current_candle = candles[i]
                    previous_candles = candles[:i]
                    
                    # محاسبه اندیکاتورها
                    indicators = self.indicator_calculator.calculate_all_indicators(
                        current_candle, 
                        previous_candles
                    )
                    
                    # اعتبارسنجی
                    errors = self.validator.validate_indicators(indicators)
                    if errors:
                        if i > 20:
                            logger.debug(f"خطا در کندل {i} از {coin_symbol} ({timeframe}): {errors[:1]}")
                        continue
                    
                    # محاسبه کیفیت داده
                    quality = self.validator.calculate_data_quality(indicators)
                    indicators['data_quality'] = quality
                    
                    # اضافه کردن تایم‌فریم به اندیکاتورها
                    indicators['timeframe'] = timeframe
                    
                    # ذخیره در دیتابیس
                    success = self.database_updater.update_candle_indicators(
                        current_candle['id'], 
                        indicators
                    )
                    
                    if success:
                        processed_count += 1
                    
                    # نمایش پیشرفت
                    if (i + 1) % 50 == 0 or (i + 1) == total_candles:
                        progress = ((i + 1) / total_candles) * 100
                        logger.info(f"📈 {coin_symbol} ({timeframe}): {i + 1}/{total_candles} ({progress:.1f}%)")
                        
                except Exception as e:
                    logger.debug(f"خطا در کندل {i} از {coin_symbol} ({timeframe}): {str(e)[:100]}")
                    continue
            
            # ۳. نتیجه‌گیری
            success_rate = (processed_count / total_candles) * 100 if total_candles > 0 else 0
            
            result = {
                'symbol': coin_symbol,
                'timeframe': timeframe,
                'status': 'COMPLETED',
                'total_candles': total_candles,
                'processed_candles': processed_count,
                'success_rate': success_rate,
                'timestamp': datetime.now().isoformat()
            }
            
            logger.info(f"✅ {coin_symbol} ({timeframe}): {processed_count}/{total_candles} کندل پردازش شد ({success_rate:.1f}%)")
            return result
            
        except Exception as e:
            logger.error(f"❌ خطا در پردازش {coin_symbol} ({timeframe}): {e}")
            return {
                'symbol': coin_symbol,
                'timeframe': timeframe,
                'status': 'FAILED',
                'error': str(e),
                'timestamp': datetime.now().isoformat()
            }
    
    def process_single_coin(self, coin_symbol):
        """پردازش کامل یک ارز برای تمام تایم‌فریم‌های موجود"""
        try:
            logger.info(f"🔄 شروع پردازش ارز: {coin_symbol}")
            
            # ۱. دریافت تایم‌فریم‌های موجود برای این ارز
            timeframes = self.candle_processor.get_available_timeframes_for_coin(coin_symbol)
            
            if not timeframes:
                logger.warning(f"⚠️ هیچ تایم‌فریمی برای {coin_symbol} پیدا نشد")
                return {
                    'symbol': coin_symbol, 
                    'status': 'NO_TIMEFRAMES', 
                    'processed': 0,
                    'timestamp': datetime.now().isoformat()
                }
            
            logger.info(f"📅 {coin_symbol}: {len(timeframes)} تایم‌فریم برای پردازش: {timeframes}")
            
            # ۲. پردازش هر تایم‌فریم
            timeframe_results = []
            for timeframe in timeframes:
                result = self.process_single_coin_timeframe(coin_symbol, timeframe)
                timeframe_results.append(result)
                
                # تاخیر کوتاه بین تایم‌فریم‌ها (از تنظیمات)
                if timeframe != timeframes[-1]:
                    time.sleep(self.delay_between_timeframes)
            
            # ۳. جمع‌بندی نتایج
            total_candles = sum(r.get('total_candles', 0) for r in timeframe_results)
            processed_candles = sum(r.get('processed_candles', 0) for r in timeframe_results)
            
            # بررسی وضعیت کلی
            completed_results = [r for r in timeframe_results if r.get('status') == 'COMPLETED']
            failed_results = [r for r in timeframe_results if r.get('status') == 'FAILED']
            
            if failed_results:
                overall_status = 'PARTIAL'
            elif len(completed_results) == len(timeframe_results):
                overall_status = 'COMPLETED'
            else:
                overall_status = 'MIXED'
            
            result = {
                'symbol': coin_symbol,
                'status': overall_status,
                'timeframes_processed': len(timeframe_results),
                'timeframe_results': timeframe_results,
                'total_candles': total_candles,
                'processed_candles': processed_candles,
                'success_rate': (processed_candles / total_candles * 100) if total_candles > 0 else 0,
                'timestamp': datetime.now().isoformat()
            }
            
            logger.info(f"✅ {coin_symbol}: {processed_candles}/{total_candles} کندل در {len(timeframe_results)} تایم‌فریم پردازش شد")
            return result
            
        except Exception as e:
            logger.error(f"❌ خطا در پردازش {coin_symbol}: {e}")
            return {
                'symbol': coin_symbol,
                'status': 'FAILED',
                'error': str(e),
                'timestamp': datetime.now().isoformat()
            }
    
    def process_block(self, block_id):
        """پردازش کامل یک بلوک"""
        start_time = datetime.now()
        logger.info(f"🚀 شروع پردازش بلوک {block_id}")
        
        # ۱. دریافت ارزهای بلوک
        coins = self.get_block_coins(block_id)
        
        if not coins:
            logger.error(f"❌ هیچ ارزی در بلوک {block_id} پیدا نشد")
            return None
        
        logger.info(f"📊 بلوک {block_id}: {len(coins)} ارز برای پردازش")
        
        # ۲. پردازش هر ارز
        results = []
        for i, coin in enumerate(coins, 1):
            coin_symbol = coin.get('symbol', f'coin_{i}')
            logger.info(f"🔄 [{i}/{len(coins)}] پردازش ارز: {coin_symbol}")
            
            result = self.process_single_coin(coin_symbol)
            results.append(result)
            
            # تاخیر کوتاه برای جلوگیری از overload (از تنظیمات)
            if i < len(coins):
                time.sleep(self.delay_between_coins)
        
        # ۳. محاسبه آمار
        end_time = datetime.now()
        duration = (end_time - start_time).total_seconds()
        
        completed = sum(1 for r in results if r.get('status') in ['COMPLETED', 'PARTIAL'])
        failed = sum(1 for r in results if r.get('status') == 'FAILED')
        no_data = sum(1 for r in results if r.get('status') in ['NO_TIMEFRAMES', 'NO_DATA', 'INSUFFICIENT_DATA'])
        
        total_candles = sum(r.get('total_candles', 0) for r in results)
        processed_candles = sum(r.get('processed_candles', 0) for r in results)
        
        # ۴. تولید گزارش
        report = {
            'block_id': block_id,
            'start_time': start_time.isoformat(),
            'end_time': end_time.isoformat(),
            'duration_seconds': duration,
            'summary': {
                'total_coins': len(coins),
                'coins_completed': completed,
                'coins_failed': failed,
                'coins_no_data': no_data,
                'total_candles': total_candles,
                'processed_candles': processed_candles,
                'success_rate': (processed_candles / total_candles * 100) if total_candles > 0 else 0
            },
            'coin_results': results,
            'status': 'COMPLETED' if failed == 0 else 'PARTIAL'
        }
        
        # ۵. ذخیره گزارش
        self.report_generator.save_report(report, block_id)
        
        # ۶. نمایش نتیجه
        logger.info(f"✅ پردازش بلوک {block_id} کامل شد")
        logger.info(f"⏱️  زمان اجرا: {duration:.2f} ثانیه")
        logger.info(f"📊 نتایج: {completed} موفق، {failed} ناموفق، {no_data} بدون داده")
        logger.info(f"🕯️  کندل‌ها: {processed_candles}/{total_candles} پردازش شد")
        
        return report
    
    def test_modules(self):
        """تست ماژول‌های سیستم"""
        logger.info("🧪 شروع تست ماژول‌ها")
        
        tests_passed = 0
        tests_failed = 0
        
        # تست ۱: اتصال به دیتابیس
        try:
            # استفاده از تابع get_database_path به جای مسیر نسبی
            db_path = get_database_path()
            
            logger.info(f"🔍 [DEBUG] تست ۱ - مسیر دیتابیس: {db_path}")
            logger.info(f"🔍 [DEBUG] تست ۱ - آیا وجود دارد: {os.path.exists(db_path)}")
            
            if os.path.exists(db_path):
                conn = sqlite3.connect(db_path)
                conn.close()
                logger.info("✅ تست ۱: اتصال به دیتابیس - موفق")
                tests_passed += 1
            else:
                logger.error(f"❌ تست ۱: دیتابیس پیدا نشد - مسیر: {db_path}")
                tests_failed += 1
        except Exception as e:
            logger.error(f"❌ تست ۱: خطا در اتصال دیتابیس - {e}")
            tests_failed += 1
        
        # تست ۲: فایل وضعیت
        try:
            # استفاده از تابع get_state_path جدید
            state_path = self.get_state_path()
            
            logger.info(f"🔍 [DEBUG] تست ۲ - مسیر فایل وضعیت: {state_path}")
            logger.info(f"🔍 [DEBUG] تست ۲ - آیا وجود دارد: {os.path.exists(state_path)}")
            
            if os.path.exists(state_path):
                with open(state_path, 'r', encoding='utf-8') as f:
                    json.load(f)
                logger.info("✅ تست ۲: فایل وضعیت - موفق")
                tests_passed += 1
            else:
                logger.error(f"❌ تست ۲: فایل وضعیت پیدا نشد - مسیر: {state_path}")
                logger.error(f"🔍 [DEBUG] آیا پوشه state وجود دارد: {os.path.exists(os.path.dirname(state_path))}")
                tests_failed += 1
        except Exception as e:
            logger.error(f"❌ تست ۲: خطا در خواندن وضعیت - {e}")
            tests_failed += 1
        
        # تست ۳: ماژول indicator_calculator
        try:
            sample_candle = {
                'open_price': 100,
                'high_price': 105,
                'low_price': 95,
                'close_price': 102,
                'volume': 1000
            }
            
            sample_history = [{
                'open_price': 99 + i,
                'high_price': 104 + i,
                'low_price': 94 + i,
                'close_price': 101 + i,
                'volume': 900 + i*10
            } for i in range(20)]
            
            indicators = self.indicator_calculator.calculate_all_indicators(
                sample_candle, 
                sample_history
            )
            
            if indicators:
                logger.info(f"✅ تست ۳: محاسبه اندیکاتورها - موفق ({len(indicators)} اندیکاتور)")
                tests_passed += 1
            else:
                logger.error("❌ تست ۳: هیچ اندیکاتوری محاسبه نشد")
                tests_failed += 1
                
        except Exception as e:
            logger.error(f"❌ تست ۳: خطا در محاسبه اندیکاتورها - {e}")
            tests_failed += 1
        
        # تست ۴: دریافت تایم‌فریم‌ها
        try:
            timeframes = self.candle_processor.get_available_timeframes_for_coin("BTCUSDT")
            logger.info(f"✅ تست ۴: دریافت تایم‌فریم‌ها - موفق (پاسخ: {timeframes})")
            tests_passed += 1
        except Exception as e:
            logger.error(f"❌ تست ۴: خطا در دریافت تایم‌فریم‌ها - {e}")
            tests_failed += 1
        
        # نتیجه تست
        logger.info(f"\n📊 نتیجه تست: {tests_passed} موفق، {tests_failed} ناموفق")
        
        if tests_failed == 0:
            logger.info("🎉 همه تست‌ها موفق بودند!")
            return True
        else:
            logger.warning(f"⚠️ {tests_failed} تست ناموفق بود")
            return False

def main():
    """تابع اصلی اجرا"""
    parser = argparse.ArgumentParser(description='سیستم تحلیل کندل‌ها و اندیکاتورها (تکه ۳)')
    parser.add_argument('--block', type=int, help='شماره بلوک برای تحلیل')
    parser.add_argument('--test', action='store_true', help='اجرای تست ماژول‌ها')
    parser.add_argument('--real', action='store_true', help='اجرای تحلیل واقعی')
    
    args = parser.parse_args()
    
    print("\n" + "=" * 60)
    print("🚀 سیستم تحلیل تکنیکال - تکه ۳")
    print("=" * 60)
    
    try:
        coordinator = MainCoordinator()
        
        if args.test:
            print("🧪 حالت تست ماژول‌ها")
            success = coordinator.test_modules()
            if success:
                print("✅ تست‌ها موفق بودند. سیستم آماده اجراست.")
            else:
                print("⚠️ برخی تست‌ها ناموفق بودند. قبل از اجرای واقعی بررسی کنید.")
        
        elif args.block:
            print(f"🎯 تحلیل بلوک {args.block}")
            report = coordinator.process_block(args.block)
            if report:
                print(f"✅ تحلیل بلوک {args.block} با موفقیت کامل شد")
                print(f"📊 نتایج: {report['summary']['coins_completed']} ارز موفق")
                print(f"📅 تایم‌فریم‌ها: تحلیل روی تمام تایم‌فریم‌های موجود انجام شد")
            else:
                print(f"❌ تحلیل بلوک {args.block} ناموفق بود")
        
        elif args.real:
            print("🎯 تحلیل واقعی بلوک ۱")
            report = coordinator.process_block(1)
            if report:
                print(f"✅ تحلیل واقعی با موفقیت کامل شد")
                print(f"📊 {report['summary']['processed_candles']} کندل پردازش شد")
                print(f"📅 تحلیل روی تمام تایم‌فریم‌های موجود انجام شد")
            else:
                print("❌ تحلیل واقعی ناموفق بود")
        
        else:
            print("🔍 حالت پیش‌فرض: تست ماژول‌ها")
            success = coordinator.test_modules()
            if success:
                print("\n💡 برای تحلیل بلوک ۱ اجرا کنید:")
                print("   python main.py --real")
                print("   یا")
                print("   python main.py --block 1")
                print("\n📅 توجه: سیستم اکنون روی تمام تایم‌فریم‌های موجود تحلیل می‌کند")
    
    except Exception as e:
        print(f"❌ خطای اصلی: {e}")
        import traceback
        traceback.print_exc()
        return 1
    
    print("\n" + "=" * 60)
    print("🏁 پایان اجرا")
    print("=" * 60)
    
    return 0

if __name__ == "__main__":
    sys.exit(main())