﻿"""
💾 ذخیره‌کننده بانک - بروزرسانی اندیکاتورها در جدول crypto_klines
نسخه بهبود یافته با پشتیبانی کامل از 49 فیلد و تایم‌فریم‌ها
"""

from typing import Dict, List, Any, Optional
import sqlite3
from datetime import datetime
import logging
import sys
import os

# FIX: اضافه کردن مسیر scripts به sys.path
current_file_dir = os.path.dirname(os.path.abspath(__file__))
scripts_dir = os.path.dirname(os.path.dirname(current_file_dir))  # دو سطح بالا!

if scripts_dir not in sys.path:
    sys.path.insert(0, scripts_dir)

# حالا importهای دیگه
from config_manager import get_database_path, get, get_timeframes
# تنظیم لاگر
logger = logging.getLogger('database_updater')

class DatabaseUpdater:
    """بروزرسانی دیتابیس - نسخه بهبود یافته با پشتیبانی کامل 49 فیلد و تایم‌فریم‌ها"""
    
    def __init__(self):
        logger.info("DatabaseUpdater (نسخه کامل با تایم‌فریم) راه‌اندازی شد")
        
        try:
            # تلاش برای import config_manager
            from config_manager import get_database_path, get
            self.db_path = get_database_path()
            logger.info(f"✅ مسیر دیتابیس از config_manager دریافت شد: {self.db_path}")
            
        except ImportError as e:
            logger.error(f"❌ خطا در import config_manager: {e}")
            # استفاده از مسیر پیش‌فرض
            try:
                # پیدا کردن مسیر پروژه به صورت خودکار
                current_dir = os.path.dirname(os.path.abspath(__file__))
                
                # ساختار پوشه‌ها را بر اساس مسیر فعلی پیدا کن
                if 'cycle' in current_dir:
                    # اگر در پوشه cycle هستیم
                    scripts_dir = os.path.dirname(current_dir)
                    project_root = os.path.dirname(scripts_dir)
                else:
                    # اگر در جای دیگری هستیم
                    project_root = current_dir
                    while project_root and not os.path.exists(os.path.join(project_root, 'config', 'settings.json')):
                        project_root = os.path.dirname(project_root)
                
                if project_root:
                    self.db_path = os.path.join(project_root, "data", "crypto_master.db")
                else:
                    # آخرین تلاش: مسیر پیش‌فرض
                    self.db_path = os.path.join(os.path.expanduser("~"), "c-data", "data", "crypto_master.db")
                
                logger.info(f"📁 مسیر دیتابیس (پیش‌فرض): {self.db_path}")
                
            except Exception as inner_e:
                logger.error(f"❌ خطا در تعیین مسیر دیتابیس: {inner_e}")
                self.db_path = "data/crypto_master.db"  # آخرین حالت
                logger.info(f"📁 مسیر دیتابیس (نهایی): {self.db_path}")
        
        # لیست کامل 49 فیلد برای crypto_klines
        self.complete_field_mappings = self._get_complete_field_mappings()
    
    def _get_complete_field_mappings(self) -> Dict[str, str]:
        """
        ایجاد نگاشت کامل برای 49 فیلد جدول crypto_klines
        این تابع فقط برای مرجع است و استفاده نمی‌شود
        """
        return {
            # ========== شناسه‌ها و متادیتا ==========
            'id': 'id',
            'coin_id': 'coin_id',
            'timeframe': 'timeframe',  # ✅ مهم: تایم‌فریم
            'aggregation_level': 'aggregation_level',
            
            # ========== زمان‌ها ==========
            'open_time': 'open_time',
            'close_time': 'close_time',
            'candle_date': 'candle_date',
            'created_at': 'created_at',
            'updated_at': 'updated_at',
            
            # ========== قیمت‌های OHLC ==========
            'open_price': 'open_price',
            'high_price': 'high_price',
            'low_price': 'low_price',
            'close_price': 'close_price',
            
            # ========== تغییرات قیمت ==========
            'price_change': 'price_change',
            'price_change_percent': 'price_change_percent',
            
            # ========== حجم‌ها ==========
            'volume': 'volume',
            'quote_volume': 'quote_volume',
            'taker_buy_volume': 'taker_buy_volume',
            'taker_sell_volume': 'taker_sell_volume',
            'taker_buy_quote_volume': 'taker_buy_quote_volume',
            
            # ========== اطلاعات معاملات ==========
            'number_of_trades': 'number_of_trades',
            
            # ========== اندیکاتورهای تکنیکال ==========
            'rsi': 'rsi',
            'macd': 'macd',
            'macd_signal': 'macd_signal',
            'macd_histogram': 'macd_histogram',
            
            # ========== باندهای بولینگر ==========
            'bollinger_upper': 'bollinger_upper',
            'bollinger_middle': 'bollinger_middle',
            'bollinger_lower': 'bollinger_lower',
            
            # ========== میانگین‌های متحرک ==========
            'ma_7': 'ma_7',
            'ma_25': 'ma_25',
            'ma_99': 'ma_99',
            
            # ========== حجم میانگین متحرک ==========
            'volume_ma_20': 'volume_ma_20',
            
            # ========== شاخص‌های نوسان ==========
            'atr': 'atr',
            'volatility': 'volatility',
            
            # ========== شاخص حجم ==========
            'volume_ratio': 'volume_ratio',
            'obv': 'obv',
            
            # ========== الگوهای کندلی ==========
            'candle_pattern': 'candle_pattern',
            'is_doji': 'is_doji',
            'is_hammer': 'is_hammer',
            'is_shooting_star': 'is_shooting_star',
            
            # ========== کیفیت داده ==========
            'data_quality': 'data_quality',
            'is_interpolated': 'is_interpolated',
            'missing_data_points': 'missing_data_points',
            
            # ========== متادیتا ==========
            'source_exchange': 'source_exchange',
            'is_verified': 'is_verified',
            
            # ========== فیلدهای Pattern (جدید) ==========
            'pattern_markers': 'pattern_markers',
            'pattern_confidence': 'pattern_confidence',
            'trend_strength': 'trend_strength',
            'support_resistance_level': 'support_resistance_level'
        }
    
    def _get_connection(self):
        """ایجاد اتصال به دیتابیس"""
        try:
            # بررسی وجود دیتابیس
            if not os.path.exists(self.db_path):
                # بررسی اگر مسیر نسبی است
                if not os.path.isabs(self.db_path):
                    # سعی کن مسیر کامل بسازی
                    current_dir = os.path.dirname(os.path.abspath(__file__))
                    potential_path = os.path.join(current_dir, self.db_path)
                    if os.path.exists(potential_path):
                        self.db_path = potential_path
                    else:
                        logger.error(f"❌ دیتابیس در مسیر {self.db_path} پیدا نشد")
                        # لاگ مسیرهای احتمالی
                        logger.debug(f"   مسیر جاری: {current_dir}")
                        logger.debug(f"   مسیر مطلق: {os.path.abspath(self.db_path)}")
                        return None
                else:
                    logger.error(f"❌ دیتابیس در مسیر {self.db_path} پیدا نشد")
                    return None
            
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row  # برگرداندن نتایج به صورت دیکشنری
            return conn
        except Exception as e:
            logger.error(f"❌ خطا در اتصال به دیتابیس: {e}")
            logger.debug(f"   مسیر دیتابیس: {self.db_path}")
            logger.debug(f"   مسیر مطلق: {os.path.abspath(self.db_path) if not os.path.isabs(self.db_path) else self.db_path}")
            return None
    
    # بقیه توابع بدون تغییر می‌مانند...
    def _check_table_exists(self, conn, table_name):
        """بررسی وجود جدول در دیتابیس"""
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name=?", (table_name,))
            result = cursor.fetchone()
            exists = result is not None
            
            if not exists:
                logger.error(f"❌ جدول '{table_name}' در دیتابیس وجود ندارد")
            
            return exists
        except Exception as e:
            logger.error(f"❌ خطا در بررسی وجود جدول '{table_name}': {e}")
            return False
    
    def _check_column_exists(self, conn, table_name, column_name):
        """بررسی وجود ستون در جدول"""
        try:
            cursor = conn.cursor()
            cursor.execute(f"PRAGMA table_info({table_name})")
            columns = [col[1] for col in cursor.fetchall()]
            exists = column_name in columns
            
            if not exists:
                logger.debug(f"⚠️ ستون '{column_name}' در جدول '{table_name}' وجود ندارد")
            
            return exists
        except Exception as e:
            logger.debug(f"⚠️ خطا در بررسی وجود ستون '{column_name}' در جدول '{table_name}': {e}")
            return False
    
    def _get_table_columns(self, conn, table_name):
        """دریافت لیست ستون‌های یک جدول"""
        try:
            cursor = conn.cursor()
            cursor.execute(f"PRAGMA table_info({table_name})")
            columns = {}
            for col in cursor.fetchall():
                columns[col[1]] = col[2]  # نام ستون و نوع
            return columns
        except Exception as e:
            logger.error(f"❌ خطا در دریافت ستون‌های جدول '{table_name}': {e}")
            return {}
    
    def update_candle_indicators(self, candle_id: int, indicators: Dict[str, Any]) -> bool:
        """
        آپدیت اندیکاتورهای یک کندل خاص در جدول crypto_klines
        نسخه بهبود یافته با پشتیبانی از فیلدهای جدید و تایم‌فریم
        """
        try:
            if not indicators:
                logger.warning(f"⚠️ هیچ اندیکاتوری برای آپدیت کندل {candle_id} وجود ندارد")
                return False
            
            # اتصال به دیتابیس
            conn = self._get_connection()
            if not conn:
                return False
            
            # بررسی وجود جدول crypto_klines
            if not self._check_table_exists(conn, 'crypto_klines'):
                conn.close()
                return False
            
            # دریافت ستون‌های موجود در جدول
            available_columns = self._get_table_columns(conn, 'crypto_klines')
            if not available_columns:
                logger.error(f"❌ نتوانست ستون‌های جدول crypto_klines را بخواند")
                conn.close()
                return False
            
            # دریافت تایم‌فریم‌های معتبر از config_manager
            valid_timeframes = ['1m', '5m', '15m', '30m', '1h', '4h', '1d', '1w']
            try:
                from scripts.config_manager import get
                valid_timeframes = get('analysis.valid_timeframes', valid_timeframes)
            except ImportError:
                pass  # از پیش‌فرض استفاده کن
            
            # ساخت کوئری UPDATE دینامیک
            set_clauses = []
            params = []
            
            # لیست کامل نگاشت فیلدها (49 فیلد) - با اولویت‌بندی
            field_mappings = [
                # ========== فیلدهای حیاتی (اولویت ۱) ==========
                ('timeframe', 'timeframe'),  # ✅ تایم‌فریم اضافه شد
                
                # ========== اندیکاتورهای اصلی (اولویت ۲) ==========
                ('rsi', 'rsi'),
                ('macd', 'macd'),
                ('macd_signal', 'macd_signal'),
                ('macd_histogram', 'macd_histogram'),
                
                # ========== میانگین‌های متحرک (اولویت ۳) ==========
                ('ma_7', 'ma_7'),
                ('ma_25', 'ma_25'),
                ('ma_99', 'ma_99'),
                
                # ========== باندهای بولینگر (اولویت ۴) ==========
                ('bollinger_upper', 'bollinger_upper'),
                ('bollinger_middle', 'bollinger_middle'),
                ('bollinger_lower', 'bollinger_lower'),
                
                # ========== تغییرات قیمت (اولویت ۵) ==========
                ('price_change', 'price_change'),
                ('price_change_percent', 'price_change_percent'),
                
                # ========== اندیکاتورهای نوسان (اولویت ۶) ==========
                ('atr', 'atr'),
                ('volatility', 'volatility'),
                
                # ========== شاخص‌های حجم (اولویت ۷) ==========
                ('volume_ratio', 'volume_ratio'),
                ('obv', 'obv'),
                
                # ========== حجم میانگین متحرک (اولویت ۸) ==========
                ('volume_ma_20', 'volume_ma_20'),
                
                # ========== حجم‌های خاص (اولویت ۹) ==========
                ('quote_volume', 'quote_volume'),
                ('taker_buy_volume', 'taker_buy_volume'),
                ('taker_sell_volume', 'taker_sell_volume'),
                ('taker_buy_quote_volume', 'taker_buy_quote_volume'),
                
                # ========== اطلاعات معاملات (اولویت ۱۰) ==========
                ('number_of_trades', 'number_of_trades'),
                
                # ========== الگوهای کندلی (اولویت ۱۱) ==========
                ('candle_pattern', 'candle_pattern'),
                ('is_doji', 'is_doji'),
                ('is_hammer', 'is_hammer'),
                ('is_shooting_star', 'is_shooting_star'),
                
                # ========== کیفیت داده (اولویت ۱۲) ==========
                ('data_quality', 'data_quality'),
                ('is_interpolated', 'is_interpolated'),
                ('missing_data_points', 'missing_data_points'),
                
                # ========== level تجمیع و تاریخ (اولویت ۱۳) ==========
                ('aggregation_level', 'aggregation_level'),
                ('candle_date', 'candle_date'),
                
                # ========== فیلدهای Pattern (اولویت ۱۴) ==========
                ('pattern_markers', 'pattern_markers'),
                ('pattern_confidence', 'pattern_confidence'),
                ('trend_strength', 'trend_strength'),
                ('support_resistance_level', 'support_resistance_level'),
            ]
            
            # فقط فیلدهایی که ستون مربوطه وجود دارد و مقدار دارند
            processed_fields = []
            for indicator_name, column_name in field_mappings:
                if column_name in available_columns and indicator_name in indicators:
                    value = indicators[indicator_name]
                    if value is not None:
                        # تبدیل مقادیر بولین به عدد
                        if isinstance(value, bool):
                            set_clauses.append(f"{column_name} = ?")
                            params.append(1 if value else 0)
                            processed_fields.append(indicator_name)
                        elif isinstance(value, (int, float, str)):
                            # اعتبارسنجی مقادیر عددی
                            if isinstance(value, float):
                                # جلوگیری از مقادیر نامعقول
                                if abs(value) > 1e10:  # عدد خیلی بزرگ
                                    value = 0.0
                                elif abs(value) < 1e-10 and value != 0:  # عدد خیلی کوچک
                                    value = 0.0
                            
                            # برای تایم‌فریم، مطمئن شویم مقدار معتبر است
                            if indicator_name == 'timeframe':
                                if str(value) not in valid_timeframes:
                                    logger.warning(f"⚠️ تایم‌فریم نامعتبر: {value} - معتبر: {valid_timeframes}")
                                    continue  # این فیلد را ذخیره نکن
                            
                            set_clauses.append(f"{column_name} = ?")
                            params.append(value)
                            processed_fields.append(indicator_name)
            
            # اگر هیچ فیلدی برای آپدیت نبود
            if not set_clauses:
                logger.warning(f"⚠️ هیچ فیلد معتبری برای آپدیت کندل {candle_id} وجود ندارد")
                logger.debug(f"   ستون‌های موجود: {list(available_columns.keys())[:10]}...")
                logger.debug(f"   اندیکاتورهای دریافتی: {list(indicators.keys())[:10]}...")
                conn.close()
                return False
            
            # اضافه کردن زمان آپدیت اگر ستون وجود دارد
            if 'updated_at' in available_columns:
                set_clauses.append("updated_at = CURRENT_TIMESTAMP")
            
            # اضافه کردن ID کندل به پارامترها
            params.append(candle_id)
            
            # ساخت کوئری کامل
            query = f"""
                UPDATE crypto_klines 
                SET {', '.join(set_clauses)}
                WHERE id = ?
            """
            
            # اجرای کوئری
            cursor = conn.cursor()
            cursor.execute(query, tuple(params))
            conn.commit()
            
            # بررسی تعداد ردیف‌های آپدیت شده
            changes = cursor.rowcount
            conn.close()
            
            if changes > 0:
                logger.debug(f"✅ کندل {candle_id}: {len(set_clauses)} فیلد به‌روزرسانی شد")
                
                # لاگ تایم‌فریم اگر وجود دارد
                if 'timeframe' in indicators:
                    logger.debug(f"   📅 تایم‌فریم: {indicators['timeframe']}")
                
                # لاگ فیلدهای پردازش شده
                if logger.isEnabledFor(logging.DEBUG):
                    timeframe_info = f" (تایم‌فریم: {indicators.get('timeframe', 'نامشخص')})"
                    logger.debug(f"   فیلدهای پردازش شده: {', '.join(processed_fields[:5])}{timeframe_info}")
                    if len(processed_fields) > 5:
                        logger.debug(f"   ... و {len(processed_fields) - 5} فیلد دیگر")
                
                return True
            else:
                logger.warning(f"⚠️ هیچ تغییری در کندل {candle_id} ایجاد نشد (ممکن است وجود نداشته باشد)")
                return False
                
        except sqlite3.Error as e:
            logger.error(f"❌ خطای SQLite در آپدیت کندل {candle_id}: {e}")
            return False
        except Exception as e:
            logger.error(f"❌ خطا در آپدیت اندیکاتورهای کندل {candle_id}: {e}")
            return False
        finally:
            if 'conn' in locals():
                try:
                    conn.close()
                except:
                    pass

    # بقیه توابع بدون تغییر اصلی باقی می‌مانند
    # فقط سازگاری با config_manager اضافه شده
    
    def get_timeframe_statistics(self) -> Dict[str, Any]:
        """دریافت آمار تایم‌فریم‌ها از جدول crypto_klines"""
        # همین تابع باقی می‌ماند اما config_manager را برای valid_timeframes اضافه کن
        try:
            conn = self._get_connection()
            if not conn:
                return {'error': 'اتصال به دیتابیس ناموفق'}
            
            if not self._check_table_exists(conn, 'crypto_klines'):
                conn.close()
                return {'error': 'جدول crypto_klines وجود ندارد'}
            
            # دریافت تایم‌فریم‌های معتبر از config_manager
            valid_timeframes = ['1m', '5m', '15m', '30m', '1h', '4h', '1d', '1w']
            try:
                from scripts.config_manager import get
                valid_timeframes = get('analysis.valid_timeframes', valid_timeframes)
            except ImportError:
                pass
            
            cursor = conn.cursor()
            
            # ۱. تعداد تایم‌فریم‌های مختلف
            # ساخت CASE statement دینامیک برای ترتیب دهی
            case_when = "CASE timeframe\n"
            for i, tf in enumerate(valid_timeframes, 1):
                case_when += f"    WHEN '{tf}' THEN {i}\n"
            case_when += f"    ELSE 99\n  END"
            
            cursor.execute(f"""
                SELECT timeframe, COUNT(*) as count
                FROM crypto_klines
                WHERE timeframe IS NOT NULL
                GROUP BY timeframe
                ORDER BY {case_when}
            """)
            
            timeframe_stats = []
            total_candles = 0
            rows = cursor.fetchall()
            
            for row in rows:
                timeframe_stats.append({
                    'timeframe': row[0],
                    'count': row[1],
                    'percentage': 0  # بعداً پر می‌شود
                })
                total_candles += row[1]
            
            # محاسبه درصدها
            for stat in timeframe_stats:
                if total_candles > 0:
                    stat['percentage'] = round((stat['count'] / total_candles) * 100, 2)
            
            conn.close()
            
            result = {
                'success': True,
                'total_candles': total_candles,
                'unique_timeframes': len(timeframe_stats),
                'timeframe_distribution': timeframe_stats,
                'valid_timeframes': valid_timeframes,
                'summary': {
                    'most_common_timeframe': max(timeframe_stats, key=lambda x: x['count'])['timeframe'] if timeframe_stats else 'N/A',
                    'least_common_timeframe': min(timeframe_stats, key=lambda x: x['count'])['timeframe'] if timeframe_stats else 'N/A'
                }
            }
            
            logger.info(f"📊 آمار تایم‌فریم‌ها: {len(timeframe_stats)} تایم‌فریم، {total_candles} کندل")
            
            return result
            
        except Exception as e:
            logger.error(f"❌ خطا در دریافت آمار تایم‌فریم‌ها: {e}")
            return {'error': str(e), 'success': False}

# Singleton برای استفاده آسان
database_updater = DatabaseUpdater()