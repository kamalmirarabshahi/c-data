"""
اسکریپت بررسی نهایی و آنالیز نتایج VOLATILITY
"""

import sqlite3
import pandas as pd
import numpy as np
from datetime import datetime
import os

def analyze_volatility_results(db_path: str):
    """آنالیز نهایی نتایج محاسبات VOLATILITY"""
    
    print("\n" + "="*80)
    print("🔍 آنالیز نهایی نتایج VOLATILITY (نوسان)")
    print("="*80)
    
    if not os.path.exists(db_path):
        print("❌ فایل دیتابیس یافت نشد!")
        return
    
    try:
        conn = sqlite3.connect(db_path)
        
        # 1. آمار کلی
        print("\n📊 آمار کلی جدول crypto_klines:")
        print("-"*40)
        
        df_stats = pd.read_sql_query("""
            SELECT 
                COUNT(*) as total_records,
                COUNT(CASE WHEN volatility IS NOT NULL THEN 1 END) as calculated,
                COUNT(CASE WHEN volatility IS NULL THEN 1 END) as not_calculated,
                AVG(volatility) as avg_volatility,
                MIN(volatility) as min_volatility,
                MAX(volatility) as max_volatility,
                STDDEV(volatility) as std_volatility,
                PERCENTILE_DISC(0.25) WITHIN GROUP (ORDER BY volatility) as q1,
                PERCENTILE_DISC(0.5) WITHIN GROUP (ORDER BY volatility) as median,
                PERCENTILE_DISC(0.75) WITHIN GROUP (ORDER BY volatility) as q3,
                SUM(CASE WHEN volatility > 0.1 THEN 1 ELSE 0 END) as high_volatility,
                SUM(CASE WHEN volatility <= 0.1 AND volatility > 0.01 THEN 1 ELSE 0 END) as medium_volatility,
                SUM(CASE WHEN volatility <= 0.01 AND volatility > 0 THEN 1 ELSE 0 END) as low_volatility,
                SUM(CASE WHEN volatility = 0 THEN 1 ELSE 0 END) as zero_volatility
            FROM crypto_klines
            WHERE volatility IS NOT NULL
        """, conn)
        
        print(f"✅ تعداد کل رکوردها: {df_stats['total_records'].iloc[0]:,}")
        print(f"✅ رکوردهای محاسبه شده: {df_stats['calculated'].iloc[0]:,}")
        print(f"✅ رکوردهای محاسبه نشده: {df_stats['not_calculated'].iloc[0]:,}")
        
        if df_stats['calculated'].iloc[0] > 0:
            percentage = (df_stats['calculated'].iloc[0] / df_stats['total_records'].iloc[0]) * 100
            print(f"✅ درصد پر شدن: {percentage:.1f}%")
        
        print(f"\n📈 آمار نوسان:")
        print(f"  • میانگین نوسان: {df_stats['avg_volatility'].iloc[0]:.6f}")
        print(f"  • کمترین نوسان: {df_stats['min_volatility'].iloc[0]:.6f}")
        print(f"  • بیشترین نوسان: {df_stats['max_volatility'].iloc[0]:.6f}")
        print(f"  • انحراف معیار نوسان: {df_stats['std_volatility'].iloc[0]:.6f}")
        
        print(f"\n📊 چارک‌های نوسان:")
        print(f"  • چارک اول (Q1): {df_stats['q1'].iloc[0]:.6f}")
        print(f"  • میانه (Q2): {df_stats['median'].iloc[0]:.6f}")
        print(f"  • چارک سوم (Q3): {df_stats['q3'].iloc[0]:.6f}")
        
        print(f"\n📈 سطوح نوسان:")
        total_calculated = df_stats['calculated'].iloc[0]
        if total_calculated > 0:
            high_pct = (df_stats['high_volatility'].iloc[0] / total_calculated) * 100
            medium_pct = (df_stats['medium_volatility'].iloc[0] / total_calculated) * 100
            low_pct = (df_stats['low_volatility'].iloc[0] / total_calculated) * 100
            zero_pct = (df_stats['zero_volatility'].iloc[0] / total_calculated) * 100
            
            print(f"  • نوسان بالا (>0.1): {df_stats['high_volatility'].iloc[0]:,} ({high_pct:.1f}%)")
            print(f"  • نوسان متوسط (0.01-0.1): {df_stats['medium_volatility'].iloc[0]:,} ({medium_pct:.1f}%)")
            print(f"  • نوسان پایین (0-0.01): {df_stats['low_volatility'].iloc[0]:,} ({low_pct:.1f}%)")
            print(f"  • نوسان صفر: {df_stats['zero_volatility'].iloc[0]:,} ({zero_pct:.1f}%)")
        
        # 2. آمار تفکیکی بر اساس تایم‌فریم
        print("\n📈 آمار بر اساس تایم‌فریم:")
        print("-"*40)
        
        df_timeframe = pd.read_sql_query("""
            SELECT 
                timeframe,
                COUNT(*) as total,
                COUNT(CASE WHEN volatility IS NOT NULL THEN 1 END) as calculated,
                AVG(volatility) as avg_volatility,
                MIN(volatility) as min_volatility,
                MAX(volatility) as max_volatility,
                STDDEV(volatility) as std_volatility,
                SUM(CASE WHEN volatility > 0.1 THEN 1 ELSE 0 END) as high_vol,
                SUM(CASE WHEN volatility <= 0.1 AND volatility > 0 THEN 1 ELSE 0 END) as normal_vol
            FROM crypto_klines
            WHERE volatility IS NOT NULL
            GROUP BY timeframe
            ORDER BY timeframe
        """, conn)
        
        print(df_timeframe.to_string(index=False))
        
        # 3. بررسی توزیع مقادیر
        print("\n📊 توزیع مقادیر volatility:")
        print("-"*40)
        
        df_distribution = pd.read_sql_query("""
            SELECT 
                CASE 
                    WHEN volatility IS NULL THEN 'NULL'
                    WHEN volatility = 0 THEN 'ZERO'
                    WHEN volatility > 0 AND volatility <= 0.001 THEN '0-0.001'
                    WHEN volatility > 0.001 AND volatility <= 0.01 THEN '0.001-0.01'
                    WHEN volatility > 0.01 AND volatility <= 0.05 THEN '0.01-0.05'
                    WHEN volatility > 0.05 AND volatility <= 0.1 THEN '0.05-0.1'
                    WHEN volatility > 0.1 AND volatility <= 0.2 THEN '0.1-0.2'
                    WHEN volatility > 0.2 AND volatility <= 0.5 THEN '0.2-0.5'
                    WHEN volatility > 0.5 THEN '>0.5'
                END as volatility_range,
                COUNT(*) as count,
                ROUND(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM crypto_klines WHERE volatility IS NOT NULL), 2) as percentage
            FROM crypto_klines
            WHERE volatility IS NOT NULL
            GROUP BY volatility_range
            ORDER BY 
                CASE volatility_range
                    WHEN 'NULL' THEN 0
                    WHEN 'ZERO' THEN 1
                    WHEN '0-0.001' THEN 2
                    WHEN '0.001-0.01' THEN 3
                    WHEN '0.01-0.05' THEN 4
                    WHEN '0.05-0.1' THEN 5
                    WHEN '0.1-0.2' THEN 6
                    WHEN '0.2-0.5' THEN 7
                    WHEN '>0.5' THEN 8
                END
        """, conn)
        
        print(df_distribution.to_string(index=False))
        
        # 4. بررسی ارزهای با بیشترین/کمترین نوسان
        print("\n🏆 10 ارز با بیشترین نوسان:")
        print("-"*40)
        
        df_top_volatile = pd.read_sql_query("""
            WITH coin_avg_volatility AS (
                SELECT 
                    k.coin_id,
                    c.symbol,
                    c.coin_name,
                    AVG(k.volatility) as avg_volatility,
                    COUNT(*) as sample_count
                FROM crypto_klines k
                JOIN crypto_coins c ON k.coin_id = c.id
                WHERE k.volatility IS NOT NULL
                GROUP BY k.coin_id, c.symbol, c.coin_name
                HAVING COUNT(*) >= 10
            )
            SELECT 
                symbol,
                coin_name,
                avg_volatility,
                sample_count
            FROM coin_avg_volatility
            ORDER BY avg_volatility DESC
            LIMIT 10
        """, conn)
        
        print(df_top_volatile.to_string(index=False))
        
        print("\n📉 10 ارز با کمترین نوسان:")
        print("-"*40)
        
        df_lowest_volatile = pd.read_sql_query("""
            WITH coin_avg_volatility AS (
                SELECT 
                    k.coin_id,
                    c.symbol,
                    c.coin_name,
                    AVG(k.volatility) as avg_volatility,
                    COUNT(*) as sample_count
                FROM crypto_klines k
                JOIN crypto_coins c ON k.coin_id = c.id
                WHERE k.volatility IS NOT NULL AND k.volatility > 0
                GROUP BY k.coin_id, c.symbol, c.coin_name
                HAVING COUNT(*) >= 10
            )
            SELECT 
                symbol,
                coin_name,
                avg_volatility,
                sample_count
            FROM coin_avg_volatility
            ORDER BY avg_volatility ASC
            LIMIT 10
        """, conn)
        
        print(df_lowest_volatile.to_string(index=False))
        
        # 5. بررسی ارتباط بین volatility و سایر اندیکاتورها
        print("\n🔗 بررسی ارتباط‌ها:")
        print("-"*40)
        
        df_correlations = pd.read_sql_query("""
            SELECT 
                CORR(volatility, price_change_percent) as corr_price_change_percent,
                CORR(volatility, price_change) as corr_price_change,
                CORR(volatility, volume) as corr_volume,
                CORR(volatility, rsi) as corr_rsi,
                CORR(volatility, atr) as corr_atr
            FROM crypto_klines
            WHERE volatility IS NOT NULL 
              AND price_change_percent IS NOT NULL
              AND price_change IS NOT NULL
              AND volume IS NOT NULL
              AND rsi IS NOT NULL
              AND atr IS NOT NULL
            LIMIT 1
        """, conn)
        
        print(f"  • همبستگی با درصد تغییر قیمت: {df_correlations['corr_price_change_percent'].iloc[0]:.4f}")
        print(f"  • همبستگی با تغییر مطلق قیمت: {df_correlations['corr_price_change'].iloc[0]:.4f}")
        print(f"  • همبستگی با حجم: {df_correlations['corr_volume'].iloc[0]:.4f}")
        print(f"  • همبستگی با RSI: {df_correlations['corr_rsi'].iloc[0]:.4f}")
        print(f"  • همبستگی با ATR: {df_correlations['corr_atr'].iloc[0]:.4f}")
        
        # 6. بررسی نوسان بر اساس زمان
        print("\n⏰ بررسی نوسان بر اساس زمان:")
        print("-"*40)
        
        df_time_volatility = pd.read_sql_query("""
            SELECT 
                strftime('%Y-%m', open_time) as month,
                AVG(volatility) as avg_volatility,
                COUNT(*) as record_count
            FROM crypto_klines
            WHERE volatility IS NOT NULL 
              AND open_time IS NOT NULL
            GROUP BY strftime('%Y-%m', open_time)
            ORDER BY month
            LIMIT 12
        """, conn)
        
        print(df_time_volatility.to_string(index=False))
        
        # 7. بررسی نمونه‌های خاص
        print("\n🔍 بررسی نمونه‌های خاص:")
        print("-"*40)
        
        # نوسان‌های بسیار بالا
        df_extreme_vol = pd.read_sql_query("""
            SELECT 
                c.symbol,
                k.timeframe,
                k.open_time,
                k.close_price,
                k.volatility,
                k.price_change_percent
            FROM crypto_klines k
            JOIN crypto_coins c ON k.coin_id = c.id
            WHERE k.volatility IS NOT NULL 
              AND k.volatility > 1.0  -- نوسان بیشتر از 100%
            ORDER BY k.volatility DESC
            LIMIT 5
        """, conn)
        
        if len(df_extreme_vol) > 0:
            print(f"⚠️  نمونه‌های با نوسان بسیار بالا (>100%):")
            print(df_extreme_vol.to_string(index=False))
        else:
            print(f"✅ هیچ نمونه با نوسان بیشتر از 100% یافت نشد")
        
        # 8. خلاصه نهایی
        print("\n" + "="*80)
        print("✅ خلاصه نهایی آنالیز VOLATILITY")
        print("="*80)
        
        total_records = df_stats['total_records'].iloc[0]
        calculated = df_stats['calculated'].iloc[0]
        completion_rate = (calculated / total_records) * 100
        
        print(f"\n📊 وضعیت کامل بودن:")
        print(f"  • تکمیل شده: {completion_rate:.1f}%")
        
        if calculated > 0:
            avg_volatility = df_stats['avg_volatility'].iloc[0]
            print(f"\n📈 میانگین نوسان: {avg_volatility:.6f}")
            
            # تفسیر نوسان
            if avg_volatility < 0.01:
                print(f"  📊 تفسیر: نوسان بسیار پایین (بازار آرام)")
            elif avg_volatility < 0.05:
                print(f"  📊 تفسیر: نوسان پایین (بازار معمولی)")
            elif avg_volatility < 0.1:
                print(f"  📊 تفسیر: نوسان متوسط (بازار متلاطم)")
            elif avg_volatility < 0.2:
                print(f"  📊 تفسیر: نوسان بالا (بازار پرنوسان)")
            else:
                print(f"  📊 تفسیر: نوسان بسیار بالا (بازار بسیار پرنوسان)")
        
        print(f"\n✅ آنالیز کامل شد!")
        print("="*80)
        
        conn.close()
        
    except Exception as e:
        print(f"❌ خطا در آنالیز نتایج: {e}")


def main():
    """تابع اصلی"""
    db_path = r"C:\Users\Kamal\Desktop\py-prg\git\c-data\data\crypto_master.db"
    
    print("\n" + "="*80)
    print("🔍 آنالیز نتایج VOLATILITY")
    print("="*80)
    
    if not os.path.exists(db_path):
        print(f"❌ فایل دیتابیس یافت نشد: {db_path}")
        return
    
    analyze_volatility_results(db_path)


if __name__ == "__main__":
    main()