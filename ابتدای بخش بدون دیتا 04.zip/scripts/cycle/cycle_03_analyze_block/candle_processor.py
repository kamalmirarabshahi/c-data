﻿"""
🕯️ پردازشگر کندل‌ها - دریافت و آماده‌سازی کندل‌های هر ارز
"""

import sqlite3
import logging
from typing import List, Dict, Any, Optional
import sys
import os

# FIX: اضافه کردن مسیر scripts به sys.path
current_file_dir = os.path.dirname(os.path.abspath(__file__))
scripts_dir = os.path.dirname(os.path.dirname(current_file_dir))  # دو سطح بالا!

if scripts_dir not in sys.path:
    sys.path.insert(0, scripts_dir)

# حالا importهای دیگه
from config_manager import get_database_path, get, get_timeframes
logger = logging.getLogger(__name__)

class CandleProcessor:
    """پردازشگر کندل‌ها - دریافت کندل‌های هر ارز از بانک"""
    
    def __init__(self):
        logger.info("CandleProcessor آماده")
        
        # ❌ مشکل: مسیر سخت‌کد شده
        # self.db_path = "data/crypto_master.db"  # این خط باید حذف شود
        
        # ✅ اصلاح: استفاده از config_manager
        try:
            from config_manager import get_database_path
            self.db_path = get_database_path()
            logger.info(f"📁 مسیر دیتابیس (از config_manager): {self.db_path}")
        except ImportError:
            logger.error("❌ config_manager import نشد")
            # در حالت اضطراری، از مسیر نسبی استفاده می‌کنیم
            import os
            project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
            self.db_path = os.path.join(project_root, "data", "crypto_master.db")
            logger.warning(f"⚠️ استفاده از مسیر پیش‌فرض: {self.db_path}")
    
    def get_available_timeframes_for_coin(self, coin_symbol: str) -> List[str]:
        """
        دریافت لیست تایم‌فریم‌های موجود برای یک ارز
        """
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            query = """
                SELECT DISTINCT k.timeframe
                FROM crypto_klines k
                JOIN crypto_coins c ON k.coin_id = c.id
                WHERE c.symbol = ?
                ORDER BY 
                    CASE k.timeframe
                        WHEN '1m' THEN 1
                        WHEN '3m' THEN 2
                        WHEN '5m' THEN 3
                        WHEN '15m' THEN 4
                        WHEN '30m' THEN 5
                        WHEN '1h' THEN 6
                        WHEN '2h' THEN 7
                        WHEN '4h' THEN 8
                        WHEN '6h' THEN 9
                        WHEN '8h' THEN 10
                        WHEN '12h' THEN 11
                        WHEN '1d' THEN 12
                        WHEN '3d' THEN 13
                        WHEN '1w' THEN 14
                        WHEN '1M' THEN 15
                        ELSE 99
                    END
            """
            
            cursor.execute(query, (coin_symbol,))
            rows = cursor.fetchall()
            conn.close()
            
            timeframes = [row[0] for row in rows]
            logger.info(f"📅 {coin_symbol}: {len(timeframes)} تایم‌فریم یافت شد: {timeframes}")
            return timeframes
            
        except sqlite3.Error as e:
            logger.error(f"❌ خطای SQLite در دریافت تایم‌فریم‌های {coin_symbol}: {e}")
            return []
        except Exception as e:
            logger.error(f"❌ خطا در دریافت تایم‌فریم‌های {coin_symbol}: {e}")
            return []
    
    def get_candles_for_coin_timeframe(self, coin_symbol: str, timeframe: str, limit: int = 200) -> List[Dict[str, Any]]:
        """
        دریافت کندل‌های یک ارز برای تایم‌فریم مشخص از دیتابیس
        """
        try:
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            query = """
                SELECT 
                    k.id,
                    k.coin_id,
                    k.timeframe,
                    k.open_time,
                    k.close_time,
                    k.open_price,
                    k.high_price,
                    k.low_price,
                    k.close_price,
                    k.volume,
                    k.quote_volume,
                    c.symbol as coin_symbol
                FROM crypto_klines k
                JOIN crypto_coins c ON k.coin_id = c.id
                WHERE c.symbol = ? 
                AND k.timeframe = ?
                ORDER BY k.open_time ASC
                LIMIT ?
            """
            
            cursor.execute(query, (coin_symbol, timeframe, limit))
            rows = cursor.fetchall()
            conn.close()
            
            candles = []
            for row in rows:
                candles.append(dict(row))
            
            logger.info(f"📊 {coin_symbol} ({timeframe}): {len(candles)} کندل دریافت شد")
            return candles
            
        except sqlite3.Error as e:
            logger.error(f"❌ خطای SQLite در دریافت کندل‌های {coin_symbol} ({timeframe}): {e}")
            return []
        except Exception as e:
            logger.error(f"❌ خطا در دریافت کندل‌های {coin_symbol} ({timeframe}): {e}")
            return []
    
    def get_candles_for_coin(self, coin_symbol: str, timeframe: Optional[str] = None, limit: int = 200) -> List[Dict[str, Any]]:
        """
        دریافت کندل‌های یک ارز (سازگار با نسخه قبلی)
        """
        if timeframe is None:
            timeframe = '5m'
        
        return self.get_candles_for_coin_timeframe(coin_symbol, timeframe, limit)
    
    def get_available_candle_count(self, coin_symbol: str, timeframe: Optional[str] = None) -> int:
        """دریافت تعداد کندل‌های موجود برای یک ارز و تایم‌فریم"""
        try:
            if timeframe is None:
                timeframe = '5m'
            
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            query = """
                SELECT COUNT(*) 
                FROM crypto_klines k
                JOIN crypto_coins c ON k.coin_id = c.id
                WHERE c.symbol = ? 
                AND k.timeframe = ?
            """
            
            cursor.execute(query, (coin_symbol, timeframe))
            count = cursor.fetchone()[0]
            conn.close()
            
            return count
            
        except Exception as e:
            logger.error(f"❌ خطا در شمارش کندل‌های {coin_symbol} ({timeframe}): {e}")
            return 0
    
    def prepare_candles_for_analysis(self, candles: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """آماده‌سازی کندل‌ها برای تحلیل"""
        if not candles:
            return []
        
        for candle in candles:
            candle['open_price'] = float(candle['open_price'])
            candle['high_price'] = float(candle['high_price'])
            candle['low_price'] = float(candle['low_price'])
            candle['close_price'] = float(candle['close_price'])
            candle['volume'] = float(candle['volume'])
        
        return candles