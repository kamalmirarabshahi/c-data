"""
🔄 پردازش گروهی اندیکاتورها - نسخه نهایی برای ۱۰۰۰۰ رکورد
"""

import sqlite3
import logging
import time
import sys
import os
from datetime import datetime
from typing import List, Dict, Any

# تنظیم logging - فقط خطاهای مهم
logging.basicConfig(
    level=logging.ERROR,  # فقط ERROR نمایش داده شود
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# اضافه کردن مسیر جاری برای import
current_dir = os.path.dirname(os.path.abspath(__file__))
if current_dir not in sys.path:
    sys.path.insert(0, current_dir)

# Import indicator calculator
try:
    from indicator_calculator import calculator
    print("✅ ماشین حساب اندیکاتورها import شد")
except ImportError as e:
    print(f"❌ خطا در import ماشین حساب: {e}")
    raise


class BatchProcessorFinal:
    """پردازشگر نهایی برای ۱۰۰۰۰ رکورد"""
    
    def __init__(self, db_path: str = None):
        self.db_path = db_path or self._find_database()
        print(f"📁 دیتابیس: {self.db_path}")
        
        # اتصال به دیتابیس
        self.conn = self._connect_db()
        
        # آمار
        self.stats = {
            'total': 0,
            'success': 0,
            'failed': 0,
            'skipped': 0,
            'start': None,
            'end': None,
            'errors': []  # ذخیره خطاهای مهم
        }
    
    def _find_database(self) -> str:
        """جستجوی فایل دیتابیس"""
        search_paths = [
            '../data/crypto_master.db',
            '../../data/crypto_master.db',
            '../../../data/crypto_master.db',
        ]
        
        for path in search_paths:
            full_path = os.path.abspath(path)
            if os.path.exists(full_path):
                print(f"✅ دیتابیس پیدا شد: {full_path}")
                return full_path
        
        raise FileNotFoundError("❌ فایل دیتابیس پیدا نشد")
    
    def _connect_db(self) -> sqlite3.Connection:
        """اتصال به دیتابیس"""
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        print("✅ اتصال به دیتابیس برقرار شد")
        return conn
    
    def check_table_structure(self):
        """بررسی ساختار جدول"""
        cursor = self.conn.cursor()
        cursor.execute("PRAGMA table_info(crypto_klines)")
        columns = [row[1] for row in cursor.fetchall()]
        
        print(f"📊 جدول دارای {len(columns)} ستون است")
        
        # بررسی ستون‌های ضروری
        required_columns = ['id', 'coin_id', 'timeframe', 'open_time', 
                           'open_price', 'high_price', 'low_price', 'close_price', 'volume']
        
        missing = [col for col in required_columns if col not in columns]
        if missing:
            print(f"⚠️ ستون‌های مفقود: {missing}")
        
        return columns
    
    def get_records_batch(self, limit: int = 20000) -> List[sqlite3.Row]:
        """دریافت دسته‌ای از رکوردها"""
        cursor = self.conn.cursor()
        
        # شرط ساده: رکوردهایی که rsi ندارند
        query = """
        SELECT id, coin_id, timeframe, open_time, 
               open_price, high_price, low_price, close_price, volume
        FROM crypto_klines 
        WHERE rsi IS NULL OR rsi = 0
        ORDER BY open_time ASC
        LIMIT ?
        """
        
        print(f"🔍 دریافت حداکثر {limit} رکورد...")
        cursor.execute(query, (limit,))
        records = cursor.fetchall()
        
        print(f"📊 {len(records)} رکورد برای پردازش پیدا شد")
        return records
    
    def get_previous_candles_simple(self, coin_id: str, timeframe: str, 
                                  current_time: str, count: int = 100) -> List[Dict]:
        """دریافت ساده تاریخچه"""
        cursor = self.conn.cursor()
        
        query = """
        SELECT open_price, high_price, low_price, close_price, volume
        FROM crypto_klines 
        WHERE coin_id = ? AND timeframe = ? AND open_time < ?
        ORDER BY open_time DESC
        LIMIT ?
        """
        
        try:
            cursor.execute(query, (coin_id, timeframe, current_time, count))
            rows = cursor.fetchall()
            
            # تبدیل به لیست دیکشنری
            candles = []
            for row in rows[::-1]:  # قدیمی به جدید
                candles.append({
                    'open_price': row[0],
                    'high_price': row[1],
                    'low_price': row[2],
                    'close_price': row[3],
                    'volume': row[4]
                })
            
            return candles
        except:
            return []
    
    def calculate_safe(self, candle: sqlite3.Row) -> Dict[str, Any]:
        """محاسبه ایمن اندیکاتورها"""
        try:
            # داده‌های اصلی
            candle_dict = {
                'open_price': float(candle['open_price']) if candle['open_price'] else 0,
                'high_price': float(candle['high_price']) if candle['high_price'] else 0,
                'low_price': float(candle['low_price']) if candle['low_price'] else 0,
                'close_price': float(candle['close_price']) if candle['close_price'] else 0,
                'volume': float(candle['volume']) if candle['volume'] else 0,
                'symbol': str(candle['coin_id'])
            }
            
            # بررسی داده‌های معتبر
            if candle_dict['close_price'] <= 0:
                raise ValueError("قیمت close نامعتبر")
            
            coin_id = str(candle['coin_id'])
            timeframe = str(candle['timeframe'])
            open_time = str(candle['open_time'])
            
            # دریافت تاریخچه
            history = self.get_previous_candles_simple(coin_id, timeframe, open_time, 150)
            
            # محاسبه
            indicators = calculator.calculate_all_indicators(
                current_candle=candle_dict,
                previous_candles=history,
                timeframe=timeframe
            )
            
            return indicators
            
        except Exception as e:
            error_msg = f"خطا در رکورد {candle['id']}: {str(e)}"
            self.stats['errors'].append(error_msg)
            
            # بازگشت مقادیر پیش‌فرض
            return calculator._get_default_indicators(candle_dict, timeframe)
    
    def update_candle_simple(self, candle_id: int, indicators: Dict) -> bool:
        """بروزرسانی ساده"""
        try:
            cursor = self.conn.cursor()
            
            # فقط فیلدهای اصلی
            query = """
            UPDATE crypto_klines SET
                rsi = ?,
                macd = ?,
                macd_signal = ?,
                macd_histogram = ?,
                bollinger_upper = ?,
                bollinger_middle = ?,
                bollinger_lower = ?,
                ma_7 = ?,
                ma_25 = ?,
                ma_99 = ?,
                data_quality = ?,
                updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
            """
            
            values = (
                indicators.get('rsi', 50),
                indicators.get('macd', 0),
                indicators.get('macd_signal', 0),
                indicators.get('macd_histogram', 0),
                indicators.get('bollinger_upper', indicators.get('close_price', 0)),
                indicators.get('bollinger_middle', indicators.get('close_price', 0)),
                indicators.get('bollinger_lower', indicators.get('close_price', 0)),
                indicators.get('ma_7', indicators.get('close_price', 0)),
                indicators.get('ma_25', indicators.get('close_price', 0)),
                indicators.get('ma_99', indicators.get('close_price', 0)),
                indicators.get('data_quality', 50),
                candle_id
            )
            
            cursor.execute(query, values)
            self.conn.commit()
            return True
            
        except Exception as e:
            print(f"❌ خطا در بروزرسانی {candle_id}: {e}")
            self.conn.rollback()
            return False
    
    def process_10000(self):
        """پردازش ۱۰۰۰۰ رکورد"""
        print("=" * 60)
        print("🚀 شروع پردازش ۱۰۰۰۰ رکورد")
        print("=" * 60)
        
        self.stats['start'] = datetime.now()
        
        # بررسی ساختار
        self.check_table_structure()
        
        # دریافت رکوردها
        records = self.get_records_batch(10000)
        self.stats['total'] = len(records)
        
        if self.stats['total'] == 0:
            print("✅ همه رکوردها از قبل پردازش شده‌اند")
            return
        
        print(f"\n📊 پردازش {self.stats['total']} رکورد شروع شد...")
        print("⏳ لطفا منتظر بمانید...")
        
        # شاخص پیشرفت
        progress_interval = max(1, self.stats['total'] // 20)  # هر 5% نمایش
        
        for i, candle in enumerate(records):
            try:
                # نمایش پیشرفت
                if i % progress_interval == 0 or i == self.stats['total'] - 1:
                    percent = (i + 1) / self.stats['total'] * 100
                    print(f"📈 {i+1}/{self.stats['total']} ({percent:.1f}%)")
                
                # محاسبه
                indicators = self.calculate_safe(candle)
                
                # بروزرسانی
                if self.update_candle_simple(candle['id'], indicators):
                    self.stats['success'] += 1
                else:
                    self.stats['failed'] += 1
                
                # ذخیره موقت هر ۵۰۰ رکورد
                if i % 500 == 0 and i > 0:
                    print(f"💾 ذخیره موقت در رکورد {i+1}")
                
            except Exception as e:
                self.stats['failed'] += 1
                if len(self.stats['errors']) < 10:  # فقط ۱۰ خطای اول
                    self.stats['errors'].append(f"رکورد {candle['id']}: {str(e)}")
        
        # نهایی
        self.conn.commit()
        self.stats['end'] = datetime.now()
        
        # نمایش گزارش
        self.print_final_report()
    
    def print_final_report(self):
        """گزارش نهایی"""
        duration = (self.stats['end'] - self.stats['start']).total_seconds()
        
        print("\n" + "=" * 60)
        print("🎯 گزارش نهایی پردازش ۱۰۰۰۰ رکورد")
        print("=" * 60)
        print(f"🕐 زمان شروع: {self.stats['start'].strftime('%H:%M:%S')}")
        print(f"🕐 زمان پایان: {self.stats['end'].strftime('%H:%M:%S')}")
        print(f"⏱️ مدت زمان کل: {duration:.1f} ثانیه ({duration/60:.1f} دقیقه)")
        print("-" * 60)
        print(f"📊 تعداد کل رکوردها: {self.stats['total']:,}")
        print(f"✅ موفق: {self.stats['success']:,} ({self.stats['success']/self.stats['total']*100:.1f}%)")
        print(f"❌ ناموفق: {self.stats['failed']:,} ({self.stats['failed']/self.stats['total']*100:.1f}%)")
        
        if duration > 0:
            speed = self.stats['total'] / duration
            print(f"⚡ سرعت: {speed:.1f} رکورد/ثانیه")
            print(f"⏱️ میانگین زمان: {duration/self.stats['total']:.3f} ثانیه/رکورد")
        
        # نمایش خطاهای مهم
        if self.stats['errors']:
            print("-" * 60)
            print(f"⚠️ خطاهای مهم ({len(self.stats['errors'])} مورد):")
            for i, error in enumerate(self.stats['errors'][:5]):  # فقط ۵ خطای اول
                print(f"  {i+1}. {error}")
            if len(self.stats['errors']) > 5:
                print(f"  ... و {len(self.stats['errors']) - 5} خطای دیگر")
        
        # تخمین زمان برای کل دیتابیس
        cursor = self.conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM crypto_klines WHERE rsi IS NULL OR rsi = 0")
        remaining = cursor.fetchone()[0]
        
        if remaining > 0 and duration > 0:
            est_time = (remaining / self.stats['total']) * duration
            print("-" * 60)
            print(f"📈 رکوردهای باقی‌مانده: {remaining:,}")
            print(f"⏳ زمان تخمینی باقی‌مانده: {est_time:.1f} ثانیه ({est_time/60:.1f} دقیقه)")
        
        print("=" * 60)
        
        # ذخیره گزارش در فایل
        self.save_report()
    
    def save_report(self):
        """ذخیره گزارش در فایل"""
        report = []
        report.append("=" * 60)
        report.append("گزارش پردازش اندیکاتورها")
        report.append("=" * 60)
        report.append(f"تاریخ: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        report.append(f"دیتابیس: {self.db_path}")
        report.append(f"کل رکوردها: {self.stats['total']:,}")
        report.append(f"موفق: {self.stats['success']:,}")
        report.append(f"ناموفق: {self.stats['failed']:,}")
        report.append(f"نرخ موفقیت: {self.stats['success']/self.stats['total']*100:.1f}%")
        report.append(f"زمان کل: {(self.stats['end'] - self.stats['start']).total_seconds():.1f} ثانیه")
        
        if self.stats['errors']:
            report.append("\nخطاهای مهم:")
            for error in self.stats['errors']:
                report.append(f"  - {error}")
        
        report.append("=" * 60)
        
        filename = f"batch_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
        with open(filename, 'w', encoding='utf-8') as f:
            f.write('\n'.join(report))
        
        print(f"📄 گزارش در {filename} ذخیره شد")
    
    def close(self):
        """بستن اتصال"""
        if self.conn:
            self.conn.close()
            print("🔌 اتصال دیتابیس بسته شد")


def main():
    """تابع اصلی"""
    print("🔄 پردازش گروهی اندیکاتورها - ۱۰۰۰۰ رکورد")
    print("-" * 50)
    
    processor = None
    try:
        processor = BatchProcessorFinal()
        processor.process_10000()
        
    except KeyboardInterrupt:
        print("\n⏹️ پردازش توسط کاربر متوقف شد")
        if processor:
            processor.print_final_report()
    except Exception as e:
        print(f"\n❌ خطای غیرمنتظره: {e}")
        import traceback
        traceback.print_exc()
    finally:
        if processor:
            processor.close()


if __name__ == "__main__":
    main()