# scripts/cycle/cycle_03_analyze_block/__init__.py
"""
پکیج تحلیل کندل‌ها و محاسبه اندیکاتورها - تکه ۳
"""

import sys
import os

# ========== FIX برای importهای داخل پکیج ==========
# این کد تضمین می‌کند که همه ماژول‌های این پکیج بتوانند config_manager را import کنند

# مسیر فعلی: scripts/cycle/cycle_03_analyze_block/
current_dir = os.path.dirname(os.path.abspath(__file__))

# دو سطح بالا: c-data/
parent_dir = os.path.dirname(os.path.dirname(current_dir))

# اضافه کردن scripts: c-data/scripts/
scripts_dir = os.path.join(parent_dir, "scripts")

# اضافه کردن به sys.path اگر وجود ندارد
if scripts_dir not in sys.path:
    sys.path.insert(0, scripts_dir)

# ========== import ماژول‌های داخلی ==========

from .utils import CommonUtils, logger
from .coin_manager import CoinManager, coin_manager
from .candle_processor import CandleProcessor, candle_processor
from .indicator_calculator import IndicatorCalculator, indicator_calculator
from .validator import Validator, validator
from .database_updater import DatabaseUpdater, database_updater
from .hourly_updater import TwentyFourHourUpdater, hourly_updater
from .report_generator import ReportGenerator, report_generator
from .main_cycle_03 import MainCoordinator, main

__all__ = [
    'CommonUtils',
    'logger',
    'CoinManager',
    'coin_manager',
    'CandleProcessor',
    'candle_processor',
    'IndicatorCalculator',
    'indicator_calculator',
    'Validator',
    'validator',
    'DatabaseUpdater',
    'database_updater',
    'TwentyFourHourUpdater',
    'hourly_updater',
    'ReportGenerator',
    'report_generator',
    'MainCoordinator',
    'main'
]

__version__ = '1.0.0'