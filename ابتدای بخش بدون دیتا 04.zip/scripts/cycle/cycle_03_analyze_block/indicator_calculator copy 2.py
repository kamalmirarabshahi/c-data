# backend/indicator.py - گزارش جامع وضعیت اندیکاتورها

import sqlite3
from pathlib import Path
from datetime import datetime, timedelta
import math

##############################################################################
# تنظیمات مرکزی گزارش اندیکاتورها - تمام مقادیر از اینجا کنترل می‌شوند
##############################################################################

INDICATOR_REPORT_CONFIG = {
    # ⚙️ تعداد کندل‌های آخر هر تایم‌فریم برای تحلیل
    # می‌توانید این مقدار را تغییر دهید: 1000, 500, 200
    'CANDLE_LIMIT_PER_TIMEFRAME': 1000,
    
    # ⚙️ آستانه‌های کیفیت داده
    'MIN_CANDLES_FOR_ANALYSIS': 200,     # حداقل کندل برای تحلیل معتبر
    'SUFFICIENT_CANDLES': 150,           # تعداد کافی برای تولید سیگنال
    'EXCELLENT_THRESHOLD': 200,          # آستانه وضعیت عالی
    'GOOD_THRESHOLD': 150,               # آستانه وضعیت خوب
    'AVERAGE_THRESHOLD': 100,            # آستانه وضعیت متوسط
    
    # ⚙️ تایم‌فریم‌های اصلی برای تحلیل
    'MAIN_TIMEFRAMES': ['15m', '1h', '4h'],
    
    # ⚙️ اندیکاتورهای حیاتی
    'VITAL_INDICATORS': ['rsi', 'macd', 'ma_7', 'bollinger_upper', 'bollinger_lower', 'obv'],
}

# متغیرهای سریع‌دسترس
CANDLE_LIMIT = INDICATOR_REPORT_CONFIG['CANDLE_LIMIT_PER_TIMEFRAME']
MIN_CANDLES = INDICATOR_REPORT_CONFIG['MIN_CANDLES_FOR_ANALYSIS']
SUFFICIENT_CANDLES = INDICATOR_REPORT_CONFIG['SUFFICIENT_CANDLES']
EXCELLENT_THRESHOLD = INDICATOR_REPORT_CONFIG['EXCELLENT_THRESHOLD']
GOOD_THRESHOLD = INDICATOR_REPORT_CONFIG['GOOD_THRESHOLD']
AVERAGE_THRESHOLD = INDICATOR_REPORT_CONFIG['AVERAGE_THRESHOLD']
MAIN_TIMEFRAMES = INDICATOR_REPORT_CONFIG['MAIN_TIMEFRAMES']
VITAL_INDICATORS = INDICATOR_REPORT_CONFIG['VITAL_INDICATORS']

##############################################################################
# توابع گزارش‌گیری
##############################################################################

def get_indicator_report(config, coin_symbol: str = None):
    """
    دریافت گزارش واقعی اندیکاتورها از دیتابیس
    """
    print(f"📊 دریافت گزارش وضعیت اندیکاتورها از دیتابیس (تنظیمات: {CANDLE_LIMIT} کندل آخر)...")
    
    try:
        db_path = getattr(config, 'DB_PATH', Path('data/crypto_master.db'))
        
        if not db_path or not db_path.exists():
            print(f"❌ دیتابیس یافت نشد: {db_path}")
            return {
                'success': False,
                'error': f'دیتابیس یافت نشد: {db_path}',
                'db_exists': False
            }
        
        conn = sqlite3.connect(str(db_path))
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        
        print(f"✅ اتصال به دیتابیس برقرار شد: {db_path}")
        
        # گزارش کلی
        if not coin_symbol:
            report = get_comprehensive_report(cursor)
        else:
            # اگر نماد ارز داده شده، گزارش تک ارز تولید کن
            report = get_coin_report(cursor, coin_symbol)
        
        conn.close()
        
        # اضافه کردن متادیتا
        report.update({
            'success': True,
            'generated_at': datetime.now().isoformat(),
            'coin_filter': coin_symbol,
            'report_type': 'single_coin' if coin_symbol else 'comprehensive',
            'db_path': str(db_path),
            'report_config': INDICATOR_REPORT_CONFIG,  # اضافه کردن تنظیمات
            'analysis_based_on': f'{CANDLE_LIMIT} کندل آخر هر تایم‌فریم'
        })
        
        print(f"✅ گزارش اندیکاتورها آماده شد (تحلیل بر اساس {CANDLE_LIMIT} کندل آخر)")
        return report
        
    except Exception as e:
        print(f"❌ خطا در get_indicator_report: {e}")
        import traceback
        traceback.print_exc()
        return {
            'success': False,
            'error': str(e),
            'generated_at': datetime.now().isoformat()
        }

def get_comprehensive_report(cursor):
    """
    گزارش جامع برای تمام ارزهای فعال - بر اساس CANDLE_LIMIT کندل آخر
    """
    print(f"🔍 در حال تحلیل داده‌های واقعی از دیتابیس (بر اساس {CANDLE_LIMIT} کندل آخر)...")
    
    # 1. آمار کلی ارزها
    cursor.execute("""
        SELECT 
            COUNT(*) as total_coins,
            SUM(CASE WHEN is_active < 5 THEN 1 ELSE 0 END) as active_coins,
            SUM(CASE WHEN is_active >= 5 THEN 1 ELSE 0 END) as inactive_coins
        FROM crypto_coins
    """)
    coins_stats = cursor.fetchone()
    
    # 2. ارزهای دارای داده کندل
    cursor.execute("""
        SELECT COUNT(DISTINCT c.id) as coins_with_candle_data
        FROM crypto_coins c
        JOIN crypto_klines k ON c.id = k.coin_id
        WHERE c.is_active < 5
    """)
    coins_with_data = cursor.fetchone()
    
    # 3. تحلیل اندیکاتورهای کل (بر اساس CANDLE_LIMIT کندل آخر)
    indicator_analysis = analyze_all_indicators(cursor)
    
    # 4. تحلیل تایم‌فریم‌ها (بر اساس CANDLE_LIMIT کندل آخر)
    timeframe_analysis = analyze_timeframes(cursor)
    
    # 5. تحلیل ارزهای برتر (بر اساس CANDLE_LIMIT کندل آخر)
    top_coins = analyze_top_coins(cursor)
    
    # 6. محاسبه نمره کلی سیستم
    system_score = calculate_system_score(indicator_analysis, timeframe_analysis)
    
    # 7. تحلیل کیفیت داده
    data_quality = analyze_data_quality(cursor)
    
    # 8. تحلیل وضعیت بروزرسانی
    update_status = analyze_update_status(cursor)
    
    return {
        'overall_stats': {
            'total_coins': coins_stats['total_coins'] if coins_stats else 0,
            'active_coins': coins_stats['active_coins'] if coins_stats else 0,
            'inactive_coins': coins_stats['inactive_coins'] if coins_stats else 0,
            'coins_with_candle_data': coins_with_data['coins_with_candle_data'] if coins_with_data else 0,
            'coins_analyzed': len(top_coins) if top_coins else 0
        },
        'aggregate_stats': {
            'avg_overall_score': system_score,
            'ready_for_signal': calculate_ready_coins(cursor),
            'ready_percentage': calculate_ready_percentage(cursor),
            'status_distribution': calculate_status_distribution(cursor),
            'top_coins': top_coins[:10] if top_coins else []
        },
        'indicator_analysis': indicator_analysis,
        'timeframe_analysis': timeframe_analysis,
        'data_quality': data_quality,
        'update_status': update_status,
        'report_config': INDICATOR_REPORT_CONFIG
    }

def get_coin_report(cursor, coin_symbol: str):
    """
    گزارش برای یک ارز خاص - بر اساس CANDLE_LIMIT کندل آخر
    """
    print(f"🔍 در حال تحلیل ارز {coin_symbol} (بر اساس {CANDLE_LIMIT} کندل آخر)...")
    
    # پیدا کردن coin_id
    cursor.execute("""
        SELECT id, symbol, coin_name, market_cap_rank, is_active
        FROM crypto_coins 
        WHERE symbol = ? AND is_active < 5
    """, (coin_symbol.upper(),))
    
    coin = cursor.fetchone()
    
    if not coin:
        return {
            'success': False,
            'error': f'ارز {coin_symbol} یافت نشد یا غیرفعال است'
        }
    
    coin_id = coin['id']
    
    # تحلیل ارز
    coin_analysis = analyze_single_coin(cursor, coin_id, coin_symbol)
    
    return {
        'coin_info': {
            'id': coin_id,
            'symbol': coin['symbol'],
            'name': coin['coin_name'],
            'market_cap_rank': coin['market_cap_rank'],
            'is_active': coin['is_active']
        },
        'coin_analysis': coin_analysis,
        'success': True,
        'analysis_based_on': f'{CANDLE_LIMIT} کندل آخر هر تایم‌فریم'
    }

def analyze_single_coin(cursor, coin_id: int, symbol: str):
    """
    تحلیل کامل یک ارز خاص - بر اساس CANDLE_LIMIT کندل آخر
    """
    print(f"📊 تحلیل ارز {symbol} (ID: {coin_id}) - بر اساس {CANDLE_LIMIT} کندل آخر")
    
    # 1. اطلاعات پایه
    cursor.execute("""
        SELECT 
            COUNT(*) as total_candles,
            COUNT(DISTINCT timeframe) as timeframe_count,
            MIN(close_time) as first_candle,
            MAX(close_time) as last_candle
        FROM crypto_klines 
        WHERE coin_id = ?
    """, (coin_id,))
    
    basic_info = cursor.fetchone()
    
    # 2. تحلیل تایم‌فریم‌ها
    timeframe_analysis = {}
    cursor.execute("""
        SELECT timeframe, COUNT(*) as candle_count,
               MIN(close_time) as first_candle,
               MAX(close_time) as last_candle
        FROM crypto_klines 
        WHERE coin_id = ?
        GROUP BY timeframe
        ORDER BY CASE timeframe
            WHEN '15m' THEN 1
            WHEN '1h' THEN 2
            WHEN '4h' THEN 3
            WHEN '1d' THEN 4
            WHEN '1w' THEN 5
            ELSE 6
        END
    """, (coin_id,))
    
    for row in cursor.fetchall():
        timeframe_analysis[row['timeframe']] = {
            'candle_count': row['candle_count'],
            'first_candle': row['first_candle'],
            'last_candle': row['last_candle'],
            'has_sufficient_data': row['candle_count'] >= SUFFICIENT_CANDLES,
            'missing_candles': max(0, MIN_CANDLES - row['candle_count'])
        }
    
    # 3. تحلیل اندیکاتورها (بر اساس CANDLE_LIMIT کندل آخر)
    indicator_coverage = analyze_coin_indicators_detailed(cursor, coin_id)
    
    # 4. کیفیت داده
    data_quality = analyze_coin_data_quality(cursor, coin_id)
    
    # 5. محاسبه نمره کلی (بر اساس MIN_CANDLES)
    overall_score = calculate_coin_overall_score(timeframe_analysis, indicator_coverage, data_quality)
    
    # 6. وضعیت آمادگی برای سیگنال (بر اساس SUFFICIENT_CANDLES)
    signal_readiness = check_coin_signal_readiness(timeframe_analysis, indicator_coverage)
    
    # 7. تولید توصیه‌ها
    recommendations = generate_coin_recommendations(timeframe_analysis, indicator_coverage, data_quality)
    
    return {
        'basic_info': {
            'total_candles': basic_info['total_candles'] if basic_info else 0,
            'timeframe_count': basic_info['timeframe_count'] if basic_info else 0,
            'first_candle': basic_info['first_candle'] if basic_info else None,
            'last_candle': basic_info['last_candle'] if basic_info else None,
            'analysis_based_on': f'{CANDLE_LIMIT} کندل آخر'
        },
        'timeframe_analysis': timeframe_analysis,
        'indicator_coverage': indicator_coverage,
        'data_quality': data_quality,
        'overall_score': overall_score,
        'signal_readiness': signal_readiness,
        'recommendations': recommendations,
        'config_used': {
            'candle_limit': CANDLE_LIMIT,
            'min_candles': MIN_CANDLES,
            'sufficient_candles': SUFFICIENT_CANDLES,
            'main_timeframes': MAIN_TIMEFRAMES
        }
    }

def analyze_coin_indicators_detailed(cursor, coin_id: int):
    """
    تحلیل دقیق اندیکاتورهای یک ارز - بر اساس CANDLE_LIMIT کندل آخر
    """
    indicators = [
        'rsi', 'macd', 'macd_signal', 'macd_histogram',
        'ma_7', 'ma_25', 'ma_99', 
        'bollinger_upper', 'bollinger_middle', 'bollinger_lower',
        'obv', 'volume_ma_20', 'volume_ratio',
        'atr', 'volatility',
        'price_change', 'price_change_percent'
    ]
    
    results = {}
    
    for indicator in indicators:
        coverage_by_timeframe = {}
        
        for tf in MAIN_TIMEFRAMES:
            cursor.execute(f"""
                SELECT 
                    COUNT(*) as total,
                    SUM(CASE WHEN {indicator} IS NOT NULL THEN 1 ELSE 0 END) as populated
                FROM (
                    SELECT {indicator}
                    FROM crypto_klines 
                    WHERE coin_id = ? AND timeframe = ?
                    ORDER BY close_time DESC 
                    LIMIT {CANDLE_LIMIT}
                )
            """, (coin_id, tf))
            
            result = cursor.fetchone()
            total = result['total'] if result else 0
            populated = result['populated'] if result else 0
            
            percentage = round((populated / total * 100), 1) if total > 0 else 0
            
            coverage_by_timeframe[tf] = {
                'total': total,
                'populated': populated,
                'percentage': percentage,
                'limit_used': CANDLE_LIMIT,
                'is_sufficient': total >= CANDLE_LIMIT
            }
        
        # میانگین بین تایم‌فریم‌ها
        percentages = [data['percentage'] for data in coverage_by_timeframe.values() if data['total'] > 0]
        avg_percentage = round(sum(percentages) / len(percentages), 1) if percentages else 0
        
        results[indicator] = {
            'by_timeframe': coverage_by_timeframe,
            'avg_percentage': avg_percentage,
            'status': get_indicator_status(avg_percentage),
            'config': {
                'candle_limit': CANDLE_LIMIT,
                'timeframes_analyzed': list(coverage_by_timeframe.keys())
            }
        }
    
    return results

def analyze_coin_data_quality(cursor, coin_id: int):
    """
    تحلیل کیفیت داده یک ارز
    """
    cursor.execute("""
        SELECT 
            AVG(data_quality) as avg_data_quality,
            COUNT(CASE WHEN is_interpolated = 1 THEN 1 END) as interpolated_count,
            COUNT(CASE WHEN missing_data_points > 0 THEN 1 END) as missing_data_count,
            COUNT(*) as total_candles
        FROM crypto_klines 
        WHERE coin_id = ?
    """, (coin_id,))
    
    result = cursor.fetchone()
    
    if not result or result['total_candles'] == 0:
        return {
            'avg_data_quality': 0,
            'interpolated_percentage': 0,
            'missing_data_percentage': 0,
            'quality_level': 'نامشخص'
        }
    
    avg_quality = result['avg_data_quality'] or 0
    interpolated_pct = (result['interpolated_count'] / result['total_candles'] * 100) if result['total_candles'] > 0 else 0
    missing_pct = (result['missing_data_count'] / result['total_candles'] * 100) if result['total_candles'] > 0 else 0
    
    # سطح کیفیت
    if avg_quality >= 90:
        quality_level = 'عالی'
        quality_color = 'success'
    elif avg_quality >= 75:
        quality_level = 'خوب'
        quality_color = 'info'
    elif avg_quality >= 60:
        quality_level = 'متوسط'
        quality_color = 'warning'
    else:
        quality_level = 'ضعیف'
        quality_color = 'danger'
    
    return {
        'avg_data_quality': round(avg_quality, 1),
        'interpolated_percentage': round(interpolated_pct, 1),
        'missing_data_percentage': round(missing_pct, 1),
        'quality_level': quality_level,
        'quality_color': quality_color
    }

def calculate_coin_overall_score(timeframe_analysis, indicator_coverage, data_quality):
    """
    محاسبه نمره کلی یک ارز - استفاده از مقادیر پیکربندی شده
    """
    # نمره تعداد کندل‌ها (40%) - بر اساس MIN_CANDLES
    candle_scores = []
    for tf, data in timeframe_analysis.items():
        candle_count = data['candle_count']
        # استفاده از MIN_CANDLES به جای مقدار ثابت 200
        score = min(100, (candle_count / MIN_CANDLES) * 100) if MIN_CANDLES > 0 else 0
        candle_scores.append(score)
    
    candle_score = sum(candle_scores) / len(candle_scores) if candle_scores else 0
    
    # نمره پوشش اندیکاتورها (40%)
    indicator_percentages = [data['avg_percentage'] for data in indicator_coverage.values()]
    indicator_score = sum(indicator_percentages) / len(indicator_percentages) if indicator_percentages else 0
    
    # نمره کیفیت داده (20%)
    quality_score = data_quality['avg_data_quality']
    
    # محاسبه نمره نهایی
    overall_score = round((candle_score * 0.4) + (indicator_score * 0.4) + (quality_score * 0.2), 1)
    
    # تعیین سطح
    if overall_score >= 85:
        level = 'عالی'
        color = 'success'
    elif overall_score >= 70:
        level = 'خوب'
        color = 'info'
    elif overall_score >= 50:
        level = 'متوسط'
        color = 'warning'
    else:
        level = 'ضعیف'
        color = 'danger'
    
    return {
        'score': overall_score,
        'level': level,
        'color': color,
        'components': {
            'candle_score': round(candle_score, 1),
            'indicator_score': round(indicator_score, 1),
            'quality_score': round(quality_score, 1)
        },
        'config_used': {
            'min_candles': MIN_CANDLES,
            'sufficient_candles': SUFFICIENT_CANDLES,
            'candle_limit': CANDLE_LIMIT
        }
    }

def check_coin_signal_readiness(timeframe_analysis, indicator_coverage):
    """
    بررسی آمادگی ارز برای تولید سیگنال - استفاده از مقادیر پیکربندی شده
    """
    # حداقل 2 تایم‌فریم با داده کافی (بر اساس SUFFICIENT_CANDLES)
    sufficient_timeframes = sum(1 for data in timeframe_analysis.values() 
                               if data.get('candle_count', 0) >= SUFFICIENT_CANDLES)
    
    # اندیکاتورهای حیاتی (از VITAL_INDICATORS استفاده می‌کند)
    vital_coverage = []
    
    for indicator in VITAL_INDICATORS:
        if indicator in indicator_coverage:
            coverage = indicator_coverage[indicator]
            vital_coverage.append(coverage['avg_percentage'])
    
    avg_vital_coverage = sum(vital_coverage) / len(vital_coverage) if vital_coverage else 0
    
    # شرایط آمادگی
    is_ready = (sufficient_timeframes >= 2 and avg_vital_coverage >= 80)
    
    missing_requirements = []
    if sufficient_timeframes < 2:
        missing_requirements.append(f'نیاز به {2 - sufficient_timeframes} تایم‌فریم دیگر با حداقل {SUFFICIENT_CANDLES} کندل')
    if avg_vital_coverage < 80:
        missing_requirements.append(f'پوشش اندیکاتورهای حیاتی {avg_vital_coverage:.1f}% (حداقل 80% مورد نیاز)')
    
    return {
        'ready': is_ready,
        'sufficient_timeframes': sufficient_timeframes,
        'required_timeframes': 2,
        'vital_coverage': round(avg_vital_coverage, 1),
        'missing_requirements': missing_requirements,
        'config_used': {
            'sufficient_candles': SUFFICIENT_CANDLES,
            'vital_indicators': VITAL_INDICATORS
        },
        'recommendation': 'آماده برای تولید سیگنال' if is_ready else 'نیاز به بهبود داده‌ها'
    }

def generate_coin_recommendations(timeframe_analysis, indicator_coverage, data_quality):
    """
    تولید توصیه‌ها برای بهبود یک ارز - استفاده از مقادیر پیکربندی شده
    """
    recommendations = []
    
    # بررسی تایم‌فریم‌ها (بر اساس MIN_CANDLES)
    for tf, data in timeframe_analysis.items():
        if data['candle_count'] < MIN_CANDLES:
            missing = MIN_CANDLES - data['candle_count']
            recommendations.append(f"⏳ تایم‌فریم {tf}: {missing} کندل دیگر نیاز دارید (فعلاً {data['candle_count']} کندل، حداقل {MIN_CANDLES})")
    
    # بررسی اندیکاتورها
    for indicator, data in indicator_coverage.items():
        if data['avg_percentage'] < 70:
            recommendations.append(f"📊 اندیکاتور {indicator}: فقط {data['avg_percentage']}% پوشش دارد (بر اساس {CANDLE_LIMIT} کندل آخر)")
    
    # بررسی کیفیت داده
    if data_quality['avg_data_quality'] < 80:
        recommendations.append(f"🧪 کیفیت داده: {data_quality['avg_data_quality']}% (حداقل 80% توصیه می‌شود)")
    
    if data_quality['interpolated_percentage'] > 10:
        recommendations.append(f"⚠️ {data_quality['interpolated_percentage']}% داده درون‌یابی شده (حداکثر 10% قابل قبول)")
    
    if not recommendations:
        recommendations.append(f"✅ داده‌ها در وضعیت مطلوب هستند (تحلیل بر اساس {CANDLE_LIMIT} کندل آخر). می‌توانید تحلیل سیگنال را آغاز کنید.")
    
    return recommendations

# بقیه توابع...

def analyze_all_indicators(cursor):
    """
    تحلیل واقعی اندیکاتورها از دیتابیس - بر اساس CANDLE_LIMIT کندل آخر
    """
    print(f"📈 تحلیل اندیکاتورهای واقعی (بر اساس {CANDLE_LIMIT} کندل آخر هر ارز)...")
    
    indicators = [
        'rsi', 'macd', 'macd_signal', 'macd_histogram',
        'ma_7', 'ma_25', 'ma_99', 
        'bollinger_upper', 'bollinger_middle', 'bollinger_lower',
        'obv', 'volume_ma_20', 'volume_ratio',
        'atr', 'volatility',
        'price_change', 'price_change_percent'
    ]
    
    results = {}
    
    for indicator in indicators:
        try:
            # فقط CANDLE_LIMIT کندل آخر هر ارز
            cursor.execute(f"""
                SELECT 
                    COUNT(*) as total_candles,
                    SUM(CASE WHEN {indicator} IS NOT NULL THEN 1 ELSE 0 END) as populated_candles
                FROM (
                    SELECT {indicator}
                    FROM crypto_klines 
                    WHERE timeframe IN ({','.join(['?']*len(MAIN_TIMEFRAMES))})
                    ORDER BY close_time DESC
                    LIMIT ?
                )
            """, (*MAIN_TIMEFRAMES, CANDLE_LIMIT * 100))  # ضریب برای اطمینان از دریافت کافی
            
            result = cursor.fetchone()
            total = result['total_candles'] if result else 0
            populated = result['populated_candles'] if result else 0
            
            percentage = round((populated / total * 100), 1) if total > 0 else 0
            
            results[indicator] = {
                'total': total,
                'populated': populated,
                'percentage': percentage,
                'status': get_indicator_status(percentage),
                'note': f'بر اساس {CANDLE_LIMIT} کندل آخر',
                'config_used': {
                    'candle_limit': CANDLE_LIMIT,
                    'timeframes': MAIN_TIMEFRAMES
                }
            }
            
            print(f"  {indicator}: {populated}/{total} ({percentage}%) - {CANDLE_LIMIT} کندل آخر")
            
        except Exception as e:
            print(f"⚠️ خطا در تحلیل {indicator}: {e}")
            results[indicator] = {
                'total': 0,
                'populated': 0,
                'percentage': 0,
                'status': 'error',
                'note': 'خطا در محاسبه'
            }
    
    return results

def get_indicator_status(percentage):
    if percentage >= 90:
        return 'excellent'
    elif percentage >= 70:
        return 'good'
    elif percentage >= 50:
        return 'average'
    else:
        return 'poor'

def analyze_timeframes(cursor):
    timeframes = ['15m', '1h', '4h', '1d', '1w']
    results = {}
    
    for timeframe in timeframes:
        try:
            # تعداد ارزهای فعال در این تایم‌فریم
            cursor.execute("""
                SELECT COUNT(DISTINCT coin_id) as coins_count
                FROM crypto_klines 
                WHERE timeframe = ?
            """, (timeframe,))
            coins_count = cursor.fetchone()['coins_count']
            
            # تحلیل بر اساس CANDLE_LIMIT کندل آخر
            cursor.execute("""
                SELECT 
                    COUNT(*) as total_candles,
                    AVG(
                        CASE WHEN rsi IS NOT NULL THEN 1 ELSE 0 END +
                        CASE WHEN macd IS NOT NULL THEN 1 ELSE 0 END +
                        CASE WHEN ma_7 IS NOT NULL THEN 1 ELSE 0 END
                    ) / 3 * 100 as avg_coverage
                FROM (
                    SELECT rsi, macd, ma_7
                    FROM crypto_klines 
                    WHERE timeframe = ?
                    ORDER BY close_time DESC
                    LIMIT ?
                )
            """, (timeframe, CANDLE_LIMIT * 50))  # ضریب برای اطمینان
            
            result = cursor.fetchone()
            total_candles = result['total_candles'] if result else 0
            avg_coverage = round(result['avg_coverage'], 1) if result and result['avg_coverage'] else 0
            
            results[timeframe] = {
                'coins_count': coins_count,
                'total_candles': total_candles,
                'avg_indicator_coverage': avg_coverage,
                'status': 'active' if coins_count > 0 else 'inactive',
                'analysis_based_on': f'{CANDLE_LIMIT} کندل آخر'
            }
            
            print(f"  تایم‌فریم {timeframe}: {coins_count} ارز، {total_candles} کندل (آخرین {CANDLE_LIMIT})، پوشش: {avg_coverage}%")
            
        except Exception as e:
            print(f"⚠️ خطا در تحلیل تایم‌فریم {timeframe}: {e}")
            results[timeframe] = {
                'coins_count': 0,
                'total_candles': 0,
                'avg_indicator_coverage': 0,
                'status': 'error'
            }
    
    return results

def analyze_top_coins(cursor, limit=20):
    try:
        cursor.execute(f"""
            SELECT c.id, c.symbol, c.coin_name, c.market_cap_rank,
                   COUNT(k.id) as candle_count,
                   MAX(k.close_time) as last_candle_time
            FROM crypto_coins c
            LEFT JOIN crypto_klines k ON c.id = k.coin_id AND k.timeframe = '4h'
            WHERE c.is_active < 5
            GROUP BY c.id, c.symbol, c.coin_name, c.market_cap_rank
            HAVING candle_count >= {SUFFICIENT_CANDLES}
            ORDER BY candle_count DESC, c.market_cap_rank
            LIMIT ?
        """, (limit,))
        
        coins = cursor.fetchall()
        
        top_coins = []
        for coin in coins:
            coin_id = coin['id']
            symbol = coin['symbol']
            
            # تحلیل ساده برای تست
            candle_count = coin['candle_count']
            indicator_score = 80 if candle_count > SUFFICIENT_CANDLES * 1.5 else 60
            quality_score = 85
            
            overall_score = round((candle_count / MIN_CANDLES * 100 * 0.4) + (indicator_score * 0.4) + (quality_score * 0.2), 1)
            
            if overall_score >= 85:
                level = 'عالی'
            elif overall_score >= 70:
                level = 'خوب'
            elif overall_score >= 50:
                level = 'متوسط'
            else:
                level = 'ضعیف'
            
            signal_ready = overall_score >= 70 and candle_count >= SUFFICIENT_CANDLES
            
            top_coins.append({
                'symbol': symbol,
                'name': coin['coin_name'] or symbol,
                'market_cap_rank': coin['market_cap_rank'] or 9999,
                'candle_count': candle_count,
                'last_candle_time': coin['last_candle_time'],
                'overall_score': {
                    'score': overall_score,
                    'level': level
                },
                'signal_readiness': {
                    'ready': signal_ready,
                    'reason': 'کیفیت داده مناسب' if signal_ready else 'نیاز به بهبود داده'
                },
                'quality_score': quality_score,
                'indicator_score': indicator_score,
                'analysis_based_on': f'{CANDLE_LIMIT} کندل آخر'
            })
        
        print(f"✅ {len(top_coins)} ارز برتر تحلیل شدند (بر اساس {CANDLE_LIMIT} کندل آخر)")
        return top_coins
        
    except Exception as e:
        print(f"❌ خطا در تحلیل ارزهای برتر: {e}")
        return []

def calculate_system_score(indicator_analysis, timeframe_analysis):
    try:
        indicator_percentages = [data['percentage'] for data in indicator_analysis.values()]
        avg_indicator_coverage = sum(indicator_percentages) / len(indicator_percentages) if indicator_percentages else 0
        
        timeframe_percentages = [data['avg_indicator_coverage'] for data in timeframe_analysis.values()]
        avg_timeframe_coverage = sum(timeframe_percentages) / len(timeframe_percentages) if timeframe_percentages else 0
        
        system_score = (avg_indicator_coverage * 0.6 + avg_timeframe_coverage * 0.4)
        
        return round(system_score, 1)
        
    except:
        return 0

def calculate_ready_coins(cursor):
    try:
        cursor.execute(f"""
            SELECT COUNT(DISTINCT coin_id) as ready_coins
            FROM crypto_klines 
            WHERE timeframe = '4h'
            AND rsi IS NOT NULL 
            AND macd IS NOT NULL 
            AND ma_7 IS NOT NULL
            AND (
                SELECT COUNT(*) 
                FROM crypto_klines k2 
                WHERE k2.coin_id = crypto_klines.coin_id 
                AND k2.timeframe = '4h'
            ) >= {SUFFICIENT_CANDLES}
        """)
        
        result = cursor.fetchone()
        return result['ready_coins'] if result else 0
        
    except:
        return 0

def calculate_ready_percentage(cursor):
    try:
        cursor.execute("SELECT COUNT(*) as total FROM crypto_coins WHERE is_active < 5")
        total_coins = cursor.fetchone()['total']
        
        ready_coins = calculate_ready_coins(cursor)
        
        percentage = (ready_coins / total_coins * 100) if total_coins > 0 else 0
        
        return round(percentage, 1)
        
    except:
        return 0

def calculate_status_distribution(cursor):
    try:
        cursor.execute(f"""
            SELECT 
                COUNT(CASE WHEN candle_count >= {EXCELLENT_THRESHOLD} THEN 1 END) as excellent,
                COUNT(CASE WHEN candle_count >= {GOOD_THRESHOLD} AND candle_count < {EXCELLENT_THRESHOLD} THEN 1 END) as good,
                COUNT(CASE WHEN candle_count >= {AVERAGE_THRESHOLD} AND candle_count < {GOOD_THRESHOLD} THEN 1 END) as average,
                COUNT(CASE WHEN candle_count < {AVERAGE_THRESHOLD} THEN 1 END) as poor
            FROM (
                SELECT c.id, COUNT(k.id) as candle_count
                FROM crypto_coins c
                LEFT JOIN crypto_klines k ON c.id = k.coin_id AND k.timeframe = '4h'
                WHERE c.is_active < 5
                GROUP BY c.id
            ) as coin_stats
        """)
        
        result = cursor.fetchone()
        
        return {
            'excellent': result['excellent'] if result else 0,
            'good': result['good'] if result else 0,
            'average': result['average'] if result else 0,
            'poor': result['poor'] if result else 0
        }
        
    except:
        return {'excellent': 0, 'good': 0, 'average': 0, 'poor': 0}

def analyze_data_quality(cursor):
    try:
        cursor.execute("""
            SELECT 
                AVG(data_quality) as avg_data_quality,
                COUNT(CASE WHEN is_interpolated = 1 THEN 1 END) as interpolated_count,
                COUNT(CASE WHEN missing_data_points > 0 THEN 1 END) as missing_data_count,
                COUNT(*) as total_candles
            FROM crypto_klines
        """)
        
        result = cursor.fetchone()
        
        if not result:
            return {'avg_data_quality': 0, 'interpolated_percentage': 0, 'missing_data_percentage': 0}
        
        avg_quality = result['avg_data_quality'] or 0
        interpolated_pct = (result['interpolated_count'] / result['total_candles'] * 100) if result['total_candles'] > 0 else 0
        missing_pct = (result['missing_data_count'] / result['total_candles'] * 100) if result['total_candles'] > 0 else 0
        
        if avg_quality >= 90:
            quality_level = 'عالی'
        elif avg_quality >= 75:
            quality_level = 'خوب'
        elif avg_quality >= 60:
            quality_level = 'متوسط'
        else:
            quality_level = 'ضعیف'
        
        return {
            'avg_data_quality': round(avg_quality, 1),
            'interpolated_percentage': round(interpolated_pct, 1),
            'missing_data_percentage': round(missing_pct, 1),
            'quality_level': quality_level
        }
        
    except:
        return {'avg_data_quality': 0, 'interpolated_percentage': 0, 'missing_data_percentage': 0, 'quality_level': 'نامشخص'}

def analyze_update_status(cursor):
    try:
        cursor.execute("""
            SELECT 
                MAX(close_time) as last_update,
                COUNT(CASE WHEN datetime(close_time) >= datetime('now', '-1 hour') THEN 1 END) as updated_last_hour,
                COUNT(CASE WHEN datetime(close_time) < datetime('now', '-24 hours') THEN 1 END) as outdated_24h
            FROM crypto_klines
        """)
        
        result = cursor.fetchone()
        
        return {
            'last_update': result['last_update'] if result else None,
            'updated_last_hour': result['updated_last_hour'] if result else 0,
            'outdated_24h': result['outdated_24h'] if result else 0,
            'update_status': 'به‌روز' if result and result['updated_last_hour'] > 0 else 'نیاز به بروزرسانی'
        }
        
    except:
        return {'last_update': None, 'update_status': 'نامشخص'}


# ================================
# ماشین حساب اندیکاتورهای تکنیکال - نسخه کامل با استفاده از config_manager
# نسخه بهبود یافته با خواندن تنظیمات از فایل مرکزی
# ================================

import numpy as np
import pandas as pd
from typing import List, Dict, Any, Optional, Tuple
import logging
import sys
import os
import json
from collections import defaultdict

# اضافه کردن مسیر scripts به sys.path
current_file_dir = os.path.dirname(os.path.abspath(__file__))
scripts_dir = os.path.dirname(os.path.dirname(current_file_dir))

if scripts_dir not in sys.path:
    sys.path.insert(0, scripts_dir)

# حالا می‌توانیم config_manager را import کنیم
try:
    from config_manager import (
        get_analysis_settings,
        get_quality_control_settings,
        get_volume_settings,
        get_pattern_settings,
        get_timeframe_settings,
        get_min_data_points,
        get_strict_mode,
        get_min_volume_threshold,
        get_data_quality_threshold,
        get_max_price_deviation,
        get_acceptable_null_percentage,
        get
    )
    CONFIG_MANAGER_AVAILABLE = True
    logger = logging.getLogger(__name__)
    logger.info("✅ config_manager با موفقیت import شد")
except ImportError as e:
    logger = logging.getLogger(__name__)
    logger.error(f"❌ خطا در import config_manager: {e}")
    CONFIG_MANAGER_AVAILABLE = False
    # تعریف توابع جایگزین
    def get_analysis_settings():
        return {
            'min_data_points': 30,
            'strict_mode': False,
            'rsi_period': 14,
            'macd_fast': 12,
            'macd_slow': 26,
            'macd_signal': 9,
            'bollinger_period': 20,
            'bollinger_std': 2.0,
            'atr_period': 14,
            'volume_ma_period': 20,
            'data_quality_threshold': 30,
            'max_price_deviation': 1.0,
            'acceptable_null_percentage': 15.0,
            'valid_timeframes': ['1m', '5m', '15m', '30m', '1h', '4h', '1d', '1w']
        }
    
    def get_quality_control_settings():
        return {
            'acceptable_null_percentage': 15.0,
            'max_recalculation_attempts': 3,
            'strict_mode': False
        }
    
    def get_volume_settings():
        return {
            'avg_trade_size': 1000,
            'min_volume_threshold': 10,
            'volume_ma_period': 20
        }
    
    def get_pattern_settings():
        return {
            'doji_threshold': 0.1,
            'hammer_shadow_ratio': 2.0,
            'shooting_star_threshold': 2.0
        }
    
    def get_timeframe_settings(timeframe=None):
        default_settings = {
            '1m': {'atr_multiplier': 1.0, 'volatility_factor': 5.0},
            '5m': {'atr_multiplier': 1.5, 'volatility_factor': 4.0},
            '15m': {'atr_multiplier': 2.0, 'volatility_factor': 3.0},
            '30m': {'atr_multiplier': 2.5, 'volatility_factor': 2.5},
            '1h': {'atr_multiplier': 3.0, 'volatility_factor': 2.0},
            '4h': {'atr_multiplier': 4.0, 'volatility_factor': 1.5},
            '1d': {'atr_multiplier': 5.0, 'volatility_factor': 1.0},
            '1w': {'atr_multiplier': 6.0, 'volatility_factor': 0.8}
        }
        
        if timeframe:
            return default_settings.get(timeframe, {'atr_multiplier': 1.0, 'volatility_factor': 1.0})
        
        return default_settings
    
    def get(key_path, default=None):
        return default


class QualityControlSystem:
    """سیستم کنترل کیفیت برای اندیکاتورها - نسخه سازگار با config_manager"""
    
    def __init__(self):
        self.problems = []
        self.problem_summary = defaultdict(int)
        self.recalculation_count = 0
        self.start_time = datetime.now()
        
        try:
            # دریافت تنظیمات از config_manager
            quality_settings = get_quality_control_settings()
            
            # 🔽 تنظیمات از config_manager
            self.acceptable_null_percentage = quality_settings.get('acceptable_null_percentage', 15.0)
            self.max_recalculation_attempts = quality_settings.get('max_recalculation_attempts', 3)
            self.strict_mode = quality_settings.get('strict_mode', False)
            
            logger.info(f"✅ سیستم کنترل کیفیت راه‌اندازی شد (null tolerance: {self.acceptable_null_percentage}%, strict: {self.strict_mode})")
        except Exception as e:
            logger.error(f"❌ خطا در دریافت تنظیمات کنترل کیفیت: {e}")
            # مقادیر پیش‌فرض
            self.acceptable_null_percentage = 15.0
            self.max_recalculation_attempts = 3
            self.strict_mode = False
            logger.info("✅ سیستم کنترل کیفیت با تنظیمات پیش‌فرض راه‌اندازی شد")
        
        # اندیکاتورهای ضروری (کاهش‌یافته برای انعطاف بیشتر)
        self.required_indicators = [
            'price_change', 'price_change_percent', 'obv', 'volume_ma_20',
            'volume_ratio', 'rsi', 'macd', 'macd_histogram',
            'ma_7', 'ma_25', 'bollinger_upper', 'bollinger_lower'
        ]
        
        # مقادیر ایمن پیش‌فرض
        self.safe_defaults = {
            'rsi': 50.0,
            'macd': 0.0,
            'macd_signal': 0.0,
            'macd_histogram': 0.0,
            'price_change': 0.0,
            'price_change_percent': 0.0,
            'obv': 0.0,
            'volume_ma_20': 0.0,
            'volume_ratio': 1.0,
            'atr': 0.0,
            'volatility': 0.0,
            'trend_strength': 0.0,
            'ma_7': 0.0,
            'ma_25': 0.0,
            'ma_99': 0.0,
            'bollinger_upper': 0.0,
            'bollinger_middle': 0.0,
            'bollinger_lower': 0.0
        }
    
    def check_quality(self, indicators: Dict[str, Any], 
                     coin_id: int, timeframe: str) -> Dict[str, Any]:
        """بررسی کیفیت اندیکاتورهای محاسبه شده"""
        # اگر strict_mode غیرفعال است، همیشه قبول کن
        if not self.strict_mode:
            return {
                'coin_id': coin_id,
                'timeframe': timeframe,
                'null_count': 0,
                'null_percentage': 0.0,
                'null_fields': [],
                'is_acceptable': True,
                'quality_score': 100.0,
                'total_checked': len(self.required_indicators),
                'check_timestamp': datetime.now().isoformat()
            }
        
        null_fields = []
        
        for indicator in self.required_indicators:
            if indicator in indicators:
                value = indicators[indicator]
                if value is None or (isinstance(value, float) and math.isnan(value)):
                    null_fields.append(indicator)
        
        null_count = len(null_fields)
        total_indicators = len(self.required_indicators)
        null_percentage = (null_count / total_indicators * 100) if total_indicators > 0 else 100
        
        is_acceptable = null_percentage <= self.acceptable_null_percentage
        quality_score = 100 - null_percentage
        
        report = {
            'coin_id': coin_id,
            'timeframe': timeframe,
            'null_count': null_count,
            'null_percentage': round(null_percentage, 2),
            'null_fields': null_fields,
            'is_acceptable': is_acceptable,
            'quality_score': round(quality_score, 2),
            'total_checked': total_indicators,
            'check_timestamp': datetime.now().isoformat()
        }
        
        if not is_acceptable:
            logger.warning(f"🔴 کیفیت پایین برای Coin {coin_id}: {null_count}/{total_indicators} فیلد خالی")
            self._record_problem(coin_id, timeframe, 'LOW_QUALITY', report)
        
        return report
    
    def ensure_no_none_values(self, indicators: Dict[str, Any]):
        """تضمین می‌کند هیچ فیلدی None نباشد"""
        for key, value in indicators.items():
            if value is None:
                if key in self.safe_defaults:
                    indicators[key] = self.safe_defaults[key]
                    logger.debug(f"   ⚠️  {key}: None → {indicators[key]}")
                elif isinstance(value, (int, float)):
                    if math.isnan(value) or math.isinf(value):
                        indicators[key] = 0.0
                        logger.debug(f"   ⚠️  {key}: NaN/Inf → 0.0")
    
    def _record_problem(self, coin_id: int, timeframe: str, 
                       problem_type: str, details: Any):
        """ثبت مشکل"""
        problem_record = {
            'timestamp': datetime.now().isoformat(),
            'coin_id': coin_id,
            'timeframe': timeframe,
            'problem_type': problem_type,
            'details': str(details)[:500]
        }
        
        self.problems.append(problem_record)
        self.problem_summary[problem_type] += 1
        
        # محدود کردن تعداد رکوردها
        if len(self.problems) > 10000:
            self.problems = self.problems[-5000:]
    
    def increment_recalculation(self):
        """افزایش شمارنده بازمحاسبه"""
        self.recalculation_count += 1
    
    def save_report(self, filepath: str = None):
        """ذخیره گزارش"""
        if filepath is None:
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            filepath = f"quality_report_{timestamp}.json"
        
        report = {
            'generated_at': datetime.now().isoformat(),
            'duration_seconds': (datetime.now() - self.start_time).total_seconds(),
            'total_problems': len(self.problems),
            'recalculations': self.recalculation_count,
            'problem_summary': dict(self.problem_summary),
            'recent_problems': self.problems[-1000:] if self.problems else [],
            'statistics': {
                'problems_per_hour': len(self.problems) / ((datetime.now() - self.start_time).total_seconds() / 3600)
                if (datetime.now() - self.start_time).total_seconds() > 0 else 0
            }
        }
        
        try:
            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump(report, f, ensure_ascii=False, indent=2)
            
            logger.info(f"💾 گزارش کیفیت در {filepath} ذخیره شد")
            return filepath
        except Exception as e:
            logger.error(f"❌ خطا در ذخیره گزارش: {e}")
            return None
    
    def print_summary(self):
        """چاپ خلاصه"""
        print("\n" + "="*80)
        print("📊 گزارش کنترل کیفیت")
        print("="*80)
        
        print(f"\n⏰ زمان اجرا: {(datetime.now() - self.start_time).total_seconds():.1f} ثانیه")
        print(f"📈 تعداد کل مشکلات: {len(self.problems):,}")
        print(f"🔄 بازمحاسبه‌ها: {self.recalculation_count:,}")
        print(f"🎯 strict_mode: {self.strict_mode}")
        print(f"📊 acceptable_null_percentage: {self.acceptable_null_percentage}%")
        
        if self.problems:
            print(f"\n🔍 خلاصه مشکلات:")
            for problem_type, count in sorted(self.problem_summary.items(), key=lambda x: x[1], reverse=True):
                print(f"  • {problem_type}: {count:,}")
            
            if self.problems:
                print(f"\n🚨 نمونه‌هایی از مشکلات (آخرین 5 مورد):")
                recent = self.problems[-5:] if len(self.problems) >= 5 else self.problems
                for i, problem in enumerate(recent, 1):
                    print(f"  {i}. Coin {problem['coin_id']} | {problem['timeframe']} | "
                          f"{problem['problem_type']} | {problem['timestamp']}")
        
        print("="*80)


class IndicatorCalculator:
    """ماشین حساب کامل اندیکاتورها - نسخه سازگار با config_manager"""
    
    def __init__(self):
        logger.info("🧮 IndicatorCalculator (نسخه سازگار با config_manager) راه‌اندازی شد")
        
        # بارگذاری تنظیمات از config_manager
        self._load_config_from_manager()
        
        # سیستم کنترل کیفیت
        self.quality_system = QualityControlSystem()
        
        # سیستم کش برای جلوگیری از محاسبات تکراری
        self.calculation_cache = {}
        self.cache_stats = {'hits': 0, 'misses': 0}
        
        logger.info("✅ ماشین حساب با تنظیمات config_manager راه‌اندازی شد")
    
    def _load_config_from_manager(self):
        """بارگذاری تنظیمات از config_manager"""
        try:
            # دریافت تمام تنظیمات
            analysis_settings = get_analysis_settings()
            volume_settings = get_volume_settings()
            pattern_settings = get_pattern_settings()
            
            # 🔽 تنظیمات اصلی از config_manager
            self.min_data_points = analysis_settings.get('min_data_points', 30)
            self.data_quality_threshold = analysis_settings.get('data_quality_threshold', 30)
            self.max_price_deviation = analysis_settings.get('max_price_deviation', 1.0)
            self.strict_mode = analysis_settings.get('strict_mode', False)
            
            # اندیکاتورهای تکنیکال
            self.rsi_period = analysis_settings.get('rsi_period', 14)
            self.macd_fast = analysis_settings.get('macd_fast', 12)
            self.macd_slow = analysis_settings.get('macd_slow', 26)
            self.macd_signal = analysis_settings.get('macd_signal', 9)
            self.bollinger_period = analysis_settings.get('bollinger_period', 20)
            self.bollinger_std = analysis_settings.get('bollinger_std', 2.0)
            self.atr_period = analysis_settings.get('atr_period', 14)
            self.volume_ma_period = analysis_settings.get('volume_ma_period', 20)
            
            # تنظیمات حجم
            self.avg_trade_size = volume_settings.get('avg_trade_size', 1000)
            self.min_volume_threshold = volume_settings.get('min_volume_threshold', 10)
            
            # تنظیمات الگوها
            self.doji_threshold = pattern_settings.get('doji_threshold', 0.1)
            self.hammer_shadow_ratio = pattern_settings.get('hammer_shadow_ratio', 2.0)
            self.shooting_star_threshold = pattern_settings.get('shooting_star_threshold', 2.0)
            
            # تنظیمات تایم‌فریم‌ها
            self.valid_timeframes = analysis_settings.get('valid_timeframes', ['1m', '5m', '15m', '30m', '1h', '4h', '1d', '1w'])
            self.timeframe_settings = get_timeframe_settings()
            
            logger.info(f"📊 تنظیمات بارگذاری شد:")
            logger.info(f"  min_data_points: {self.min_data_points}")
            logger.info(f"  strict_mode: {self.strict_mode}")
            logger.info(f"  min_volume_threshold: {self.min_volume_threshold}")
            logger.info(f"  data_quality_threshold: {self.data_quality_threshold}")
            
        except Exception as e:
            logger.error(f"❌ خطا در بارگذاری تنظیمات از config_manager: {e}")
            # تنظیمات پیش‌فرض
            self._set_default_configuration()
    
    def _set_default_configuration(self):
        """تنظیمات پیش‌فرض در صورت عدم دسترسی به config_manager"""
        # تنظیمات پایه
        self.rsi_period = 14
        self.macd_fast = 12
        self.macd_slow = 26
        self.macd_signal = 9
        self.bollinger_period = 20
        self.bollinger_std = 2.0
        self.atr_period = 14
        self.volume_ma_period = 20
        
        # تنظیمات کیفی
        self.min_data_points = 30
        self.data_quality_threshold = 30
        self.max_price_deviation = 1.0
        self.strict_mode = False
        
        # تنظیمات الگوها
        self.doji_threshold = 0.1
        self.hammer_shadow_ratio = 2.0
        self.shooting_star_threshold = 2.0
        
        # تنظیمات حجم
        self.avg_trade_size = 1000
        self.min_volume_threshold = 10
        
        # تنظیمات تایم‌فریم‌ها
        self.valid_timeframes = ['1m', '5m', '15m', '30m', '1h', '4h', '1d', '1w']
        self.timeframe_settings = {
            '1m': {'atr_multiplier': 1.0, 'volatility_factor': 5.0},
            '5m': {'atr_multiplier': 1.5, 'volatility_factor': 4.0},
            '15m': {'atr_multiplier': 2.0, 'volatility_factor': 3.0},
            '30m': {'atr_multiplier': 2.5, 'volatility_factor': 2.5},
            '1h': {'atr_multiplier': 3.0, 'volatility_factor': 2.0},
            '4h': {'atr_multiplier': 4.0, 'volatility_factor': 1.5},
            '1d': {'atr_multiplier': 5.0, 'volatility_factor': 1.0},
            '1w': {'atr_multiplier': 6.0, 'volatility_factor': 0.8}
        }
        
        logger.info("⚠️  استفاده از تنظیمات پیش‌فرض به دلیل خطا در config_manager")
    
    # ========== تابع اصلی با کنترل کیفیت ==========
    
    def calculate_all_indicators(self, current_candle: Dict[str, Any], 
                               previous_candles: List[Dict[str, Any]],
                               timeframe: str = '5m') -> Dict[str, Any]:
        """
        محاسبه کامل تمام اندیکاتورها با استفاده از تنظیمات config_manager
        """
        coin_id = current_candle.get('coin_id')
        calculation_key = f"{coin_id}_{timeframe}_{current_candle.get('open_time', '')}"
        
        # بررسی کش
        if calculation_key in self.calculation_cache:
            self.cache_stats['hits'] += 1
            logger.debug(f"💾 استفاده از کش برای Coin {coin_id}")
            return self.calculation_cache[calculation_key]
        
        self.cache_stats['misses'] += 1
        
        logger.info(f"🔍 محاسبه اندیکاتورها برای Coin {coin_id} در {timeframe}")
        
        # اگر strict_mode غیرفعال است، محاسبه ساده انجام بده
        if not self.strict_mode:
            result = self._quick_calculate(current_candle, previous_candles, timeframe)
            
            # ذخیره در کش
            self.calculation_cache[calculation_key] = result
            if len(self.calculation_cache) > 1000:
                self.calculation_cache.pop(next(iter(self.calculation_cache)))
            
            return result
        
        # در حالت strict، کنترل کیفیت کامل انجام بده
        return self._calculate_with_quality_control(current_candle, previous_candles, timeframe, calculation_key)
    
    def _quick_calculate(self, current_candle: Dict[str, Any],
                        previous_candles: List[Dict[str, Any]],
                        timeframe: str) -> Dict[str, Any]:
        """محاسبه سریع با strict_mode=False"""
        try:
            # ترکیب داده‌ها
            all_candles = previous_candles + [current_candle]
            
            # پاکسازی ساده
            cleaned_candles = self._clean_candles_simple(all_candles)
            
            if not cleaned_candles:
                logger.warning(f"⚠️  هیچ داده معتبری برای Coin {current_candle.get('coin_id')} یافت نشد")
                return self._get_default_indicators(current_candle, timeframe)
            
            # محاسبه مستقیم
            indicators = self._compute_all_indicators(cleaned_candles, timeframe)
            
            # تضمین عدم وجود None
            self.quality_system.ensure_no_none_values(indicators)
            
            # اضافه کردن متادیتا
            indicators.update({
                'calculation_status': 'QUICK_MODE',
                'strict_mode': False,
                'calculation_timestamp': datetime.now().isoformat(),
                'coin_id': current_candle.get('coin_id')
            })
            
            logger.debug(f"✅ محاسبه سریع برای Coin {current_candle.get('coin_id')} تکمیل شد")
            return indicators
            
        except Exception as e:
            logger.error(f"❌ خطا در محاسبه سریع: {e}")
            return self._get_default_indicators(current_candle, timeframe)
    
    def _calculate_with_quality_control(self, current_candle: Dict[str, Any],
                                      previous_candles: List[Dict[str, Any]],
                                      timeframe: str,
                                      calculation_key: str) -> Dict[str, Any]:
        """محاسبه با کنترل کیفیت کامل (strict_mode=True)"""
        coin_id = current_candle.get('coin_id')
        
        # اعتبارسنجی اولیه
        validation_result = self._validate_input(current_candle, previous_candles, timeframe)
        if not validation_result['is_valid']:
            logger.warning(f"❌ داده‌های ورودی معتبر نیستند برای Coin {coin_id}")
            result = self._get_safe_default_indicators(current_candle, timeframe, validation_result)
            return result
        
        # محاسبه با کنترل کیفیت
        final_result = None
        quality_report = None
        
        for attempt in range(self.quality_system.max_recalculation_attempts):
            logger.debug(f"   تلاش {attempt + 1} از {self.quality_system.max_recalculation_attempts}")
            
            # محاسبه اصلی
            indicators = self._compute_all_indicators_with_quality(
                current_candle, previous_candles, timeframe, coin_id, attempt
            )
            
            # بررسی کیفیت
            quality_report = self.quality_system.check_quality(indicators, coin_id, timeframe)
            
            if quality_report['is_acceptable']:
                # کیفیت قابل قبول
                final_result = indicators
                final_result['quality_score'] = quality_report['quality_score']
                final_result['calculation_attempts'] = attempt + 1
                final_result['quality_report'] = quality_report
                break
            else:
                # کیفیت پایین - ثبت مشکل
                logger.warning(f"⚠️  کیفیت پایین برای Coin {coin_id} در تلاش {attempt + 1}")
                
                # اگر آخرین تلاش است، از مقادیر ایمن استفاده کن
                if attempt == self.quality_system.max_recalculation_attempts - 1:
                    logger.error(f"❌ نتوانستیم کیفیت قابل قبول برای Coin {coin_id} بدست آوریم")
                    final_result = self._get_safe_indicators_with_quality_report(
                        current_candle, timeframe, coin_id, quality_report
                    )
                else:
                    # آماده‌سازی برای بازمحاسبه
                    logger.info(f"🔄 آماده‌سازی برای بازمحاسبه Coin {coin_id}...")
                    self.quality_system.increment_recalculation()
        
        # ذخیره در کش اگر نتیجه قابل قبول است
        if final_result and final_result.get('quality_score', 0) >= 80:
            self.calculation_cache[calculation_key] = final_result
            # محدودیت اندازه کش
            if len(self.calculation_cache) > 1000:
                self.calculation_cache.pop(next(iter(self.calculation_cache)))
        
        # اضافه کردن متادیتا
        if final_result:
            final_result.update(self._add_calculation_metadata(timeframe, len(previous_candles) + 1))
            final_result['coin_id'] = coin_id
            final_result['strict_mode'] = True
            
            # اگر کیفیت پایین بود، علامت بزن
            if quality_report and not quality_report['is_acceptable']:
                final_result['requires_review'] = True
                final_result['review_reason'] = 'low_quality_indicators'
        
        logger.debug(f"✅ محاسبه strict برای Coin {coin_id} تکمیل شد")
        return final_result or self._get_safe_default_indicators(
            current_candle, timeframe, {'error': 'Calculation failed completely'}
        )
    
    def _clean_candles_simple(self, candles: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """پاکسازی ساده داده‌ها"""
        cleaned = []
        
        for candle in candles:
            cleaned_candle = candle.copy()
            
            # حذف مقادیر نامعقول شدید
            for field in ['open_price', 'high_price', 'low_price', 'close_price']:
                value = cleaned_candle.get(field)
                if value is not None:
                    if value <= 0 or value > 1e15 or math.isnan(value) or math.isinf(value):
                        cleaned_candle[field] = None
            
            # اگر close_price نداریم، نادیده بگیر
            if cleaned_candle.get('close_price') is None:
                continue
            
            # مقادیر پیش‌فرض برای فیلدهای مفقود
            if cleaned_candle.get('volume') is None:
                cleaned_candle['volume'] = 0.0
            
            cleaned.append(cleaned_candle)
        
        # مرتب‌سازی بر اساس زمان
        cleaned.sort(key=lambda x: x.get('open_time', ''))
        
        return cleaned[-500:]  # محدودیت به ۵۰۰ کندل
    
    # ========== توابع محاسباتی (بدون تغییرات عمده) ==========
    
    def _validate_input(self, current_candle: Dict[str, Any], 
                       previous_candles: List[Dict[str, Any]],
                       timeframe: str) -> Dict[str, Any]:
        """اعتبارسنجی جامع داده‌های ورودی"""
        errors = []
        warnings = []
        
        # ۱. بررسی تایم‌فریم
        if timeframe not in self.valid_timeframes:
            errors.append(f"تایم‌فریم نامعتبر: {timeframe}")
        
        # ۲. بررسی کندل فعلی
        required_fields = ['open_price', 'high_price', 'low_price', 'close_price', 'volume']
        for field in required_fields:
            if field not in current_candle or current_candle[field] is None:
                errors.append(f"فیلد ضروری {field} در کندل فعلی وجود ندارد")
        
        # ۳. بررسی مقادیر معقول
        ohlc_fields = ['open_price', 'high_price', 'low_price', 'close_price']
        for field in ohlc_fields:
            value = current_candle.get(field)
            if value is not None:
                if value <= 0:
                    errors.append(f"مقدار {field} نامعتبر (منفی یا صفر): {value}")
                elif value > 1e10:
                    errors.append(f"مقدار {field} غیرمنطقی: {value}")
        
        # ۴. بررسی consistency قیمت‌ها
        high = current_candle.get('high_price')
        low = current_candle.get('low_price')
        close = current_candle.get('close_price')
        open_price = current_candle.get('open_price')
        
        if all(v is not None for v in [high, low, close, open_price]):
            if high < low:
                errors.append(f"high_price ({high}) < low_price ({low})")
            if close > high or close < low:
                warnings.append(f"close_price ({close}) خارج از محدوده high/low")
            if abs(close - open_price) > open_price * self.max_price_deviation:
                warnings.append(f"اختلاف زیاد open/close: {abs(close - open_price):.2f}")
        
        # ۵. بررسی حجم
        volume = current_candle.get('volume', 0)
        if volume < self.min_volume_threshold:
            warnings.append(f"حجم کم: {volume}")
        
        # ۶. بررسی داده‌های تاریخی
        if len(previous_candles) < self.min_data_points // 2:
            warnings.append(f"داده‌های تاریخی کم: {len(previous_candles)} کندل")
        
        result = {
            'is_valid': len(errors) == 0,
            'errors': errors,
            'warnings': warnings,
            'has_enough_data': len(previous_candles) >= self.min_data_points,
            'data_points': len(previous_candles) + 1
        }
        
        if warnings:
            logger.debug(f"⚠️ هشدارهای ورودی: {warnings}")
        
        return result
    
    def _compute_all_indicators_with_quality(self, current_candle: Dict[str, Any],
                                           previous_candles: List[Dict[str, Any]],
                                           timeframe: str,
                                           coin_id: int,
                                           attempt: int = 0) -> Dict[str, Any]:
        """محاسبه با در نظر گرفتن تلاش و کیفیت"""
        try:
            # ترکیب داده‌ها
            all_candles = previous_candles + [current_candle]
            candles = self._clean_and_prepare_data(all_candles, timeframe)
            
            # استخراج آرایه‌های پاک شده
            close_prices = np.array([c.get('close_price', 0) for c in candles if c.get('close_price')])
            open_prices = np.array([c.get('open_price', 0) for c in candles if c.get('open_price')])
            high_prices = np.array([c.get('high_price', 0) for c in candles if c.get('high_price')])
            low_prices = np.array([c.get('low_price', 0) for c in candles if c.get('low_price')])
            volumes = np.array([c.get('volume', 0) for c in candles if c.get('volume')])
            
            indicators = {'timeframe': timeframe, 'coin_id': coin_id}
            
            tf_settings = self.timeframe_settings.get(timeframe, {})
            
            # محاسبات با ایمنی بالا
            indicators.update(self._calculate_price_indicators(
                candles[-1], candles, close_prices, open_prices, high_prices, low_prices, tf_settings
            ))
            
            indicators.update(self._calculate_volume_indicators(
                candles[-1], candles, volumes, close_prices, tf_settings
            ))
            
            indicators.update(self._calculate_technical_indicators(
                candles, close_prices, tf_settings
            ))
            
            indicators.update(self._calculate_candle_patterns(candles[-1], timeframe))
            indicators.update(self._calculate_data_quality(candles))
            indicators.update(self._calculate_pattern_fields(candles[-1], candles))
            indicators.update(self._calculate_metadata(candles[-1], timeframe))
            
            # تضمین عدم وجود None
            self.quality_system.ensure_no_none_values(indicators)
            
            return indicators
            
        except Exception as e:
            logger.error(f"❌ خطا در محاسبه برای Coin {coin_id} (تلاش {attempt}): {e}")
            return self._get_minimal_safe_indicators(current_candle, timeframe, coin_id, str(e))
    
    def _compute_all_indicators(self, candles: List[Dict[str, Any]], 
                               timeframe: str) -> Dict[str, Any]:
        """محاسبه اصلی تمام اندیکاتورها"""
        indicators = {}
        
        # استخراج آرایه‌های پاک شده
        close_prices = np.array([c.get('close_price', 0) for c in candles if c.get('close_price')])
        open_prices = np.array([c.get('open_price', 0) for c in candles if c.get('open_price')])
        high_prices = np.array([c.get('high_price', 0) for c in candles if c.get('high_price')])
        low_prices = np.array([c.get('low_price', 0) for c in candles if c.get('low_price')])
        volumes = np.array([c.get('volume', 0) for c in candles if c.get('volume')])
        
        indicators['timeframe'] = timeframe
        
        tf_settings = self.timeframe_settings.get(timeframe, {})
        
        # محاسبات با اصلاحات
        indicators.update(self._calculate_price_indicators(
            candles[-1], candles, close_prices, open_prices, high_prices, low_prices, tf_settings
        ))
        
        indicators.update(self._calculate_volume_indicators(
            candles[-1], candles, volumes, close_prices, tf_settings
        ))
        
        indicators.update(self._calculate_technical_indicators(
            candles, close_prices, tf_settings
        ))
        
        indicators.update(self._calculate_candle_patterns(candles[-1], timeframe))
        indicators.update(self._calculate_data_quality(candles))
        indicators.update(self._calculate_pattern_fields(candles[-1], candles))
        indicators.update(self._calculate_metadata(candles[-1], timeframe))
        
        return indicators
    
    # ========== توابع محاسباتی اصلی (بدون تغییر) ==========
    
    def _calculate_price_indicators(self, current_candle: Dict[str, Any], 
                                   candles: List[Dict[str, Any]],
                                   close_prices: np.ndarray,
                                   open_prices: np.ndarray,
                                   high_prices: np.ndarray,
                                   low_prices: np.ndarray,
                                   timeframe_settings: Dict[str, Any]) -> Dict[str, Any]:
        """محاسبه اندیکاتورهای قیمت"""
        indicators = {}
        
        try:
            # تغییرات قیمت
            if len(close_prices) >= 2:
                prev_close = close_prices[-2]
                curr_close = close_prices[-1]
                indicators['price_change'] = float(curr_close - prev_close)
                if prev_close != 0:
                    change_percent = ((curr_close - prev_close) / prev_close) * 100
                    indicators['price_change_percent'] = float(max(-100, min(1000, change_percent)))
                else:
                    indicators['price_change_percent'] = 0.0
            
            # میانگین‌های متحرک
            indicators['ma_7'] = float(self._calculate_sma(close_prices, 7)) if len(close_prices) >= 7 else 0.0
            indicators['ma_25'] = float(self._calculate_sma(close_prices, 25)) if len(close_prices) >= 25 else 0.0
            indicators['ma_99'] = float(self._calculate_sma(close_prices, 99)) if len(close_prices) >= 99 else 0.0
            
            # باندهای بولینگر
            bb_upper, bb_middle, bb_lower = self._calculate_bollinger_bands(
                close_prices, self.bollinger_period, self.bollinger_std
            )
            indicators['bollinger_upper'] = float(bb_upper) if bb_upper else 0.0
            indicators['bollinger_middle'] = float(bb_middle) if bb_middle else 0.0
            indicators['bollinger_lower'] = float(bb_lower) if bb_lower else 0.0
            
            # RSI
            indicators['rsi'] = float(self._calculate_rsi(close_prices, self.rsi_period))
            
            # MACD
            macd, signal, histogram = self._calculate_macd(
                close_prices, self.macd_fast, self.macd_slow, self.macd_signal
            )
            indicators['macd'] = float(macd) if macd else 0.0
            indicators['macd_signal'] = float(signal) if signal else 0.0
            indicators['macd_histogram'] = float(histogram) if histogram else 0.0
            
            # ATR با ضریب تایم‌فریم
            atr = self._calculate_atr(high_prices, low_prices, close_prices, self.atr_period)
            atr_multiplier = timeframe_settings.get('atr_multiplier', 1.0)
            indicators['atr'] = float(atr * atr_multiplier)
            
            # نوسان با فاکتور تایم‌فریم
            if len(close_prices) >= 20:
                volatility = np.std(close_prices[-20:]) / np.mean(close_prices[-20:]) if np.mean(close_prices[-20:]) != 0 else 0.0
                volatility_factor = timeframe_settings.get('volatility_factor', 1.0)
                indicators['volatility'] = float(volatility * volatility_factor)
            
            # قدرت روند
            if len(close_prices) >= 50:
                short_ma = np.mean(close_prices[-10:])
                long_ma = np.mean(close_prices[-50:])
                if long_ma != 0:
                    trend_strength = abs((short_ma - long_ma) / long_ma) * 100
                    indicators['trend_strength'] = float(min(trend_strength, 100))
            
        except Exception as e:
            logger.warning(f"خطا در محاسبه اندیکاتورهای قیمت: {e}")
            indicators.update(self._get_safe_price_indicators(current_candle))
        
        return indicators
    
    def _calculate_volume_indicators(self, current_candle: Dict[str, Any], 
                                   candles: List[Dict[str, Any]],
                                   volumes: np.ndarray,
                                   close_prices: np.ndarray,
                                   timeframe_settings: Dict[str, Any]) -> Dict[str, Any]:
        """محاسبه اندیکاتورهای حجم - نسخه اصلاح شده"""
        indicators = {}
        
        try:
            current_volume = current_candle.get('volume', 0)
            
            # میانگین حجم متحرک - با انعطاف بیشتر
            if len(volumes) > 0:
                # حداقل ۵ کندل برای محاسبه معقول
                min_for_ma = 5
                if len(volumes) >= min_for_ma:
                    lookback = min(len(volumes), self.volume_ma_period)
                    volume_ma = np.mean(volumes[-lookback:])
                    indicators['volume_ma_20'] = float(volume_ma)
                    
                    # نسبت حجم
                    if volume_ma != 0 and current_volume != 0:
                        volume_ratio = current_volume / volume_ma
                        indicators['volume_ratio'] = float(max(0, min(10, volume_ratio)))  # حداکثر ۱۰ برابر
                    else:
                        indicators['volume_ratio'] = 1.0
                else:
                    # اگر کمتر از ۵ کندل، میانگین ساده
                    indicators['volume_ma_20'] = float(np.mean(volumes)) if len(volumes) > 0 else float(current_volume)
                    indicators['volume_ratio'] = 1.0
            
            # OBV اصلاح شده
            if len(close_prices) > 0 and len(volumes) > 0:
                indicators['obv'] = self._calculate_obv(close_prices, volumes)
            else:
                indicators['obv'] = float(current_volume)  # اگر داده‌ای نیست، حجم فعلی
            
            # حجم خریدار/فروشنده
            if 'taker_buy_volume' in current_candle and 'taker_sell_volume' in current_candle:
                indicators['taker_buy_volume'] = float(current_candle.get('taker_buy_volume', 0))
                indicators['taker_sell_volume'] = float(current_candle.get('taker_sell_volume', 0))
            
            # حجم نقل‌قول
            if 'quote_volume' in current_candle:
                indicators['quote_volume'] = float(current_candle.get('quote_volume', 0))
            else:
                # محاسبه تخمینی دقیق‌تر
                avg_price = np.mean([
                    current_candle.get('high_price', 0), 
                    current_candle.get('low_price', 0), 
                    current_candle.get('close_price', 0)
                ])
                indicators['quote_volume'] = float(current_candle.get('volume', 0) * avg_price)
            
        except Exception as e:
            logger.warning(f"خطا در محاسبه اندیکاتورهای حجم: {e}")
            # مقادیر ایمن بهتر
            indicators.update({
                'volume_ma_20': float(current_candle.get('volume', 0)),
                'volume_ratio': 1.0,
                'obv': float(current_candle.get('volume', 0)),
                'taker_buy_volume': 0.0,
                'taker_sell_volume': 0.0,
                'quote_volume': 0.0
            })
        
        return indicators
    
    def _calculate_obv(self, close_prices: np.ndarray, volumes: np.ndarray) -> float:
        """محاسبه On-Balance Volume - نسخه اصلاح شده"""
        if len(close_prices) == 0 or len(volumes) == 0:
            return 0.0
        
        try:
            # اگر فقط یک کندل داریم، OBV = حجم آن
            if len(close_prices) == 1:
                return float(volumes[0]) if volumes[0] else 0.0
            
            # محاسبه OBV از اول به آخر (قدیمی به جدید)
            obv = float(volumes[0]) if volumes[0] else 0.0
            
            for i in range(1, len(close_prices)):
                if i >= len(volumes):
                    continue
                    
                if close_prices[i] > close_prices[i-1]:
                    # قیمت افزایش یافته: حجم را اضافه کن
                    obv += float(volumes[i]) if volumes[i] else 0
                elif close_prices[i] < close_prices[i-1]:
                    # قیمت کاهش یافته: حجم را کم کن
                    obv -= float(volumes[i]) if volumes[i] else 0
                # اگر قیمت مساوی باشد، OBV تغییر نمی‌کند
            
            return float(obv)
        except Exception as e:
            logger.warning(f"خطا در محاسبه OBV: {e}")
            # اگر خطا رخ داد، حجم کندل فعلی را برگردان
            if len(volumes) > 0:
                return float(volumes[-1]) if volumes[-1] else 0.0
            return 0.0
    
    def _calculate_atr(self, high_prices: np.ndarray, low_prices: np.ndarray, 
                      close_prices: np.ndarray, period: int = 14) -> float:
        """محاسبه Average True Range - نسخه اصلاح شده"""
        if len(high_prices) < 2 or len(low_prices) < 2:
            # اگر داده کافی نیست، True Range ساده را برگردان
            if len(high_prices) > 0 and len(low_prices) > 0:
                return float(high_prices[-1] - low_prices[-1])
            return 0.0
        
        try:
            # از حداقل داده موجود استفاده کن
            lookback = min(len(high_prices), len(low_prices), len(close_prices), period)
            
            tr_values = []
            for i in range(1, lookback + 1):
                if i < len(close_prices):
                    high_low = high_prices[-i] - low_prices[-i]
                    high_close = abs(high_prices[-i] - close_prices[-i-1])
                    low_close = abs(low_prices[-i] - close_prices[-i-1])
                    true_range = max(high_low, high_close, low_close)
                    tr_values.append(true_range)
            
            return float(np.mean(tr_values)) if tr_values else 0.0
        except Exception as e:
            logger.warning(f"خطا در محاسبه ATR: {e}")
            if len(high_prices) > 0 and len(low_prices) > 0:
                return float(high_prices[-1] - low_prices[-1])
            return 0.0
    
    # ========== توابع کمکی (بدون تغییر) ==========
    
    def _get_minimal_safe_indicators(self, candle: Dict[str, Any], timeframe: str,
                                   coin_id: int, error_message: str) -> Dict[str, Any]:
        """حداقل اندیکاتورهای ایمن"""
        indicators = {
            'timeframe': timeframe,
            'coin_id': coin_id,
            'calculation_status': 'FAILED',
            'calculation_timestamp': datetime.now().isoformat(),
            'error_message': error_message,
            'requires_review': True,
            'review_reason': 'calculation_failed'
        }
        
        # اضافه کردن مقادیر ایمن
        for indicator, default_value in self.quality_system.safe_defaults.items():
            indicators[indicator] = default_value
        
        return indicators
    
    def _get_safe_indicators_with_quality_report(self, candle: Dict[str, Any], timeframe: str,
                                               coin_id: int, quality_report: Dict[str, Any]) -> Dict[str, Any]:
        """اندیکاتورهای ایمن با گزارش کیفیت"""
        indicators = self._get_minimal_safe_indicators(
            candle, timeframe, coin_id, 'Low quality - using safe defaults'
        )
        
        # اضافه کردن اطلاعات کیفیت
        indicators['quality_report'] = quality_report
        indicators['calculation_status'] = 'LOW_QUALITY'
        indicators['used_safe_defaults'] = True
        
        return indicators
    
    def _get_safe_default_indicators(self, current_candle: Dict[str, Any], 
                                    timeframe: str, 
                                    validation_result: Dict[str, Any]) -> Dict[str, Any]:
        """مقادیر پیش‌فرض ایمن با اطلاعات خطا"""
        indicators = self._get_default_indicators(current_candle, timeframe)
        
        indicators['calculation_status'] = 'FAILED'
        indicators['validation_result'] = validation_result
        indicators['data_quality'] = 0
        indicators['is_interpolated'] = True
        
        logger.warning(f"استفاده از مقادیر پیش‌فرض ایمن برای {timeframe}")
        return indicators
    
    def _clean_and_prepare_data(self, candles: List[Dict[str, Any]], 
                               timeframe: str) -> List[Dict[str, Any]]:
        """پاکسازی و آماده‌سازی داده‌ها"""
        cleaned_candles = []
        
        for candle in candles:
            cleaned_candle = candle.copy()
            
            # حذف مقادیر نامعقول
            for field in ['open_price', 'high_price', 'low_price', 'close_price']:
                value = cleaned_candle.get(field)
                if value is not None:
                    if value <= 0 or value > 1e10 or math.isnan(value) or math.isinf(value):
                        cleaned_candle[field] = None
            
            if cleaned_candle.get('close_price') is None:
                continue
            
            # محاسبه تخمینی فیلدهای مفقود
            if cleaned_candle.get('volume') is None:
                cleaned_candle['volume'] = self._estimate_missing_value(candles, 'volume', 0)
            
            cleaned_candles.append(cleaned_candle)
        
        # مرتب‌سازی بر اساس زمان
        cleaned_candles.sort(key=lambda x: x.get('open_time', ''))
        
        logger.debug(f"📊 داده‌های پاکسازی شده: {len(cleaned_candles)} کندل")
        return cleaned_candles[-500:]  # محدودیت به ۵۰۰ کندل برای کارایی
    
    def _get_safe_price_indicators(self, candle: Dict[str, Any]) -> Dict[str, Any]:
        """مقادیر ایمن برای اندیکاتورهای قیمت در صورت خطا"""
        close_price = candle.get('close_price', 0)
        return {
            'price_change': 0.0,
            'price_change_percent': 0.0,
            'ma_7': float(close_price),
            'ma_25': float(close_price),
            'ma_99': float(close_price),
            'bollinger_upper': float(close_price),
            'bollinger_middle': float(close_price),
            'bollinger_lower': float(close_price),
            'rsi': 50.0,
            'macd': 0.0,
            'macd_signal': 0.0,
            'macd_histogram': 0.0,
            'atr': 0.0,
            'volatility': 0.0,
            'trend_strength': 0.0
        }
    
    def _calculate_technical_indicators(self, candles: List[Dict[str, Any]], 
                                       close_prices: np.ndarray,
                                       timeframe_settings: Dict[str, Any]) -> Dict[str, Any]:
        """محاسبه اندیکاتورهای تکنیکال پیچیده"""
        indicators = {}
        
        try:
            # شاخص قدرت نسبی (RSI)
            if len(close_prices) >= self.rsi_period:
                rsi_value = self._calculate_rsi(close_prices, self.rsi_period)
                indicators['rsi'] = float(max(0, min(100, rsi_value)))
            
            # MACD کامل
            if len(close_prices) >= self.macd_slow:
                macd, signal, histogram = self._calculate_macd(
                    close_prices, self.macd_fast, self.macd_slow, self.macd_signal
                )
                if macd:
                    indicators['macd'] = float(macd)
                    indicators['macd_signal'] = float(signal)
                    indicators['macd_histogram'] = float(histogram)
            
        except Exception as e:
            logger.warning(f"خطا در محاسبه اندیکاتورهای تکنیکال: {e}")
            indicators['rsi'] = 50.0
            indicators['macd'] = 0.0
            indicators['macd_signal'] = 0.0
            indicators['macd_histogram'] = 0.0
        
        return indicators
    
    def _calculate_candle_patterns(self, candle: Dict[str, Any], 
                                  timeframe: str) -> Dict[str, Any]:
        """تشخیص الگوهای کندلی"""
        indicators = {}
        
        try:
            open_price = candle.get('open_price', 0)
            close_price = candle.get('close_price', 0)
            high_price = candle.get('high_price', 0)
            low_price = candle.get('low_price', 0)
            body_size = abs(close_price - open_price)
            total_range = high_price - low_price
            
            if total_range == 0:
                indicators.update({
                    'is_doji': False,
                    'is_hammer': False,
                    'is_shooting_star': False,
                    'candle_pattern': 'FLAT'
                })
                return indicators
            
            # دوجی
            is_doji = body_size <= (total_range * self.doji_threshold)
            indicators['is_doji'] = bool(is_doji)
            
            # چکش
            is_hammer = self._is_hammer_candle(candle)
            indicators['is_hammer'] = bool(is_hammer)
            
            # ستاره ثاقب
            is_shooting_star = self._is_shooting_star_candle(candle)
            indicators['is_shooting_star'] = bool(is_shooting_star)
            
            # نام الگوی کندلی
            pattern = self._detect_candle_pattern_name(candle)
            indicators['candle_pattern'] = pattern
            
        except Exception as e:
            logger.debug(f"خطا در تشخیص الگوهای کندلی: {e}")
            indicators.update({
                'is_doji': False,
                'is_hammer': False,
                'is_shooting_star': False,
                'candle_pattern': 'UNKNOWN'
            })
        
        return indicators
    
    def _is_hammer_candle(self, candle: Dict[str, Any]) -> bool:
        """تشخیص کندل چکش"""
        try:
            open_price = candle.get('open_price', 0)
            close_price = candle.get('close_price', 0)
            high_price = candle.get('high_price', 0)
            low_price = candle.get('low_price', 0)
            
            body_size = abs(close_price - open_price)
            upper_shadow = high_price - max(open_price, close_price)
            lower_shadow = min(open_price, close_price) - low_price
            
            if body_size == 0:
                return False
            
            is_bullish_hammer = (lower_shadow >= body_size * self.hammer_shadow_ratio and 
                               upper_shadow <= body_size * 0.3)
            
            return is_bullish_hammer
        except:
            return False
    
    def _is_shooting_star_candle(self, candle: Dict[str, Any]) -> bool:
        """تشخیص کندل ستاره ثاقب"""
        try:
            open_price = candle.get('open_price', 0)
            close_price = candle.get('close_price', 0)
            high_price = candle.get('high_price', 0)
            low_price = candle.get('low_price', 0)
            
            body_size = abs(close_price - open_price)
            upper_shadow = high_price - max(open_price, close_price)
            lower_shadow = min(open_price, close_price) - low_price
            
            if body_size == 0:
                return False
            
            is_shooting_star = (upper_shadow >= body_size * self.shooting_star_threshold and 
                              lower_shadow <= body_size * 0.3)
            
            return is_shooting_star
        except:
            return False
    
    def _detect_candle_pattern_name(self, candle: Dict[str, Any]) -> str:
        """تشخیص نام الگوی کندلی"""
        try:
            if self._is_hammer_candle(candle):
                return "HAMMER"
            elif self._is_shooting_star_candle(candle):
                return "SHOOTING_STAR"
            elif self._is_doji_candle(candle):
                return "DOJI"
            else:
                return "NORMAL"
        except:
            return "UNKNOWN"
    
    def _is_doji_candle(self, candle: Dict[str, Any]) -> bool:
        """تشخیص کندل دوجی"""
        try:
            open_price = candle.get('open_price', 0)
            close_price = candle.get('close_price', 0)
            high_price = candle.get('high_price', 0)
            low_price = candle.get('low_price', 0)
            
            body_size = abs(close_price - open_price)
            total_range = high_price - low_price
            
            if total_range == 0:
                return False
            
            return body_size <= (total_range * self.doji_threshold)
        except:
            return False
    
    def _calculate_data_quality(self, candles: List[Dict[str, Any]]) -> Dict[str, Any]:
        """محاسبه کیفیت داده"""
        indicators = {}
        
        try:
            missing_count = 0
            invalid_count = 0
            total_fields = 0
            
            for candle in candles[-50:]:
                for field in ['open_price', 'high_price', 'low_price', 'close_price', 'volume']:
                    total_fields += 1
                    value = candle.get(field)
                    
                    if value is None:
                        missing_count += 1
                    elif isinstance(value, (int, float)):
                        if field.endswith('_price') and (value <= 0 or value > 1e10):
                            invalid_count += 1
                        elif field == 'volume' and value < 0:
                            invalid_count += 1
            
            total_issues = missing_count + invalid_count
            quality_percentage = ((total_fields - total_issues) / total_fields * 100) if total_fields > 0 else 0
            
            indicators['missing_data_points'] = int(missing_count)
            indicators['invalid_data_points'] = int(invalid_count)
            indicators['data_quality'] = int(max(0, min(100, quality_percentage)))
            indicators['is_interpolated'] = bool(missing_count > 0)
            
        except Exception as e:
            logger.debug(f"خطا در محاسبه کیفیت داده: {e}")
            indicators.update({
                'missing_data_points': 0,
                'invalid_data_points': 0,
                'data_quality': 0,
                'is_interpolated': False
            })
        
        return indicators
    
    def _calculate_pattern_fields(self, current_candle: Dict[str, Any], 
                                 candles: List[Dict[str, Any]]) -> Dict[str, Any]:
        """محاسبه فیلدهای مربوط به Pattern"""
        indicators = {}
        
        try:
            indicators['pattern_markers'] = ''
            indicators['pattern_confidence'] = 0.0
            
            if len(candles) >= 50:
                close_prices = [c.get('close_price', 0) for c in candles[-50:]]
                if len(close_prices) >= 20:
                    short_ma = np.mean(close_prices[-10:])
                    long_ma = np.mean(close_prices[-20:])
                    if long_ma != 0:
                        trend_strength = abs((short_ma - long_ma) / long_ma) * 100
                        indicators['trend_strength'] = float(min(trend_strength, 100))
                    else:
                        indicators['trend_strength'] = 0.0
            else:
                indicators['trend_strength'] = 0.0
            
            if len(candles) >= 20:
                close_prices = [c.get('close_price', 0) for c in candles[-20:]]
                indicators['support_resistance_level'] = float(np.mean(close_prices))
            else:
                indicators['support_resistance_level'] = float(current_candle.get('close_price', 0))
            
        except Exception as e:
            logger.debug(f"خطا در محاسبه فیلدهای Pattern: {e}")
            indicators.update({
                'pattern_markers': '',
                'pattern_confidence': 0.0,
                'trend_strength': 0.0,
                'support_resistance_level': float(current_candle.get('close_price', 0))
            })
        
        return indicators
    
    def _calculate_metadata(self, current_candle: Dict[str, Any], 
                           timeframe: str) -> Dict[str, Any]:
        """محاسبه متادیتا"""
        indicators = {}
        
        try:
            open_time = current_candle.get('open_time')
            if open_time:
                try:
                    if isinstance(open_time, str):
                        date_part = open_time.split(' ')[0] if ' ' in open_time else open_time.split('T')[0]
                        indicators['candle_date'] = date_part
                except:
                    pass
            
            if timeframe in ['1d', '1w']:
                indicators['aggregation_level'] = 3
            elif timeframe in ['4h', '12h']:
                indicators['aggregation_level'] = 2
            else:
                indicators['aggregation_level'] = 1
            
            volume = current_candle.get('volume', 0)
            if volume > 0 and self.avg_trade_size > 0:
                indicators['number_of_trades'] = int(volume / self.avg_trade_size)
            else:
                indicators['number_of_trades'] = 0
            
        except Exception as e:
            logger.debug(f"خطا در محاسبه متادیتا: {e}")
            indicators.update({
                'candle_date': '',
                'aggregation_level': 1,
                'number_of_trades': 0
            })
        
        return indicators
    
    def _estimate_missing_value(self, candles: List[Dict[str, Any]], 
                               field: str, default_value: Any) -> Any:
        """تخمین مقدار فیلد مفقود بر اساس میانگین"""
        values = [c.get(field) for c in candles[-50:] if c.get(field) is not None]
        if values:
            return sum(values) / len(values)
        return default_value
    
    def _add_calculation_metadata(self, timeframe: str, data_points: int) -> Dict[str, Any]:
        """اضافه کردن متادیتای محاسبات"""
        return {
            'calculation_timestamp': datetime.now().isoformat(),
            'timeframe': timeframe,
            'data_points_used': data_points,
            'calculator_version': '3.0-CONFIG',
            'config_used': {
                'rsi_period': self.rsi_period,
                'macd_fast': self.macd_fast,
                'macd_slow': self.macd_slow,
                'bollinger_period': self.bollinger_period,
                'atr_period': self.atr_period,
                'strict_mode': self.strict_mode,
                'min_data_points': self.min_data_points
            }
        }
    
    def _get_default_indicators(self, current_candle: Dict[str, Any], 
                               timeframe: str = '5m') -> Dict[str, Any]:
        """مقادیر پیش‌فرض وقتی داده کافی نیست"""
        indicators = {}
        
        indicators['timeframe'] = timeframe
        
        indicators['price_change'] = 0.0
        indicators['price_change_percent'] = 0.0
        
        close_price = current_candle.get('close_price', 0)
        indicators['ma_7'] = float(close_price)
        indicators['ma_25'] = float(close_price)
        indicators['ma_99'] = float(close_price)
        
        indicators['bollinger_upper'] = float(close_price)
        indicators['bollinger_middle'] = float(close_price)
        indicators['bollinger_lower'] = float(close_price)
        
        indicators['rsi'] = 50.0
        
        indicators['macd'] = 0.0
        indicators['macd_signal'] = 0.0
        indicators['macd_histogram'] = 0.0
        
        indicators['atr'] = 0.0
        indicators['volatility'] = 0.0
        
        indicators['volume_ma_20'] = float(current_candle.get('volume', 0))
        indicators['volume_ratio'] = 1.0
        indicators['obv'] = 0.0
        
        indicators['is_doji'] = False
        indicators['is_hammer'] = False
        indicators['is_shooting_star'] = False
        indicators['candle_pattern'] = "NORMAL"
        
        indicators['data_quality'] = 50
        indicators['is_interpolated'] = True
        indicators['missing_data_points'] = 999
        
        indicators['pattern_markers'] = ''
        indicators['pattern_confidence'] = 0.0
        indicators['trend_strength'] = 0.0
        indicators['support_resistance_level'] = float(close_price)
        
        indicators['aggregation_level'] = 1
        indicators['number_of_trades'] = 0
        indicators['candle_date'] = ''
        
        indicators['quote_volume'] = 0.0
        indicators['taker_buy_volume'] = 0.0
        indicators['taker_sell_volume'] = 0.0
        
        indicators['calculation_status'] = 'DEFAULT'
        indicators['strict_mode'] = self.strict_mode
        
        return indicators
    
    # ========== توابع محاسباتی پایه ==========
    
    def _calculate_sma(self, prices: np.ndarray, period: int) -> float:
        """محاسبه میانگین متحرک ساده"""
        if len(prices) < period:
            return 0.0
        return float(np.mean(prices[-period:]))
    
    def _calculate_ema(self, prices: np.ndarray, period: int) -> float:
        """محاسبه میانگین متحرک نمایی"""
        if len(prices) < period:
            return 0.0
        
        try:
            weights = np.exp(np.linspace(-1., 0., period))
            weights /= weights.sum()
            
            ema = np.convolve(prices, weights, mode='valid')[:1]
            return float(ema[0]) if len(ema) > 0 else 0.0
        except:
            return float(np.mean(prices[-period:]))
    
    def _calculate_rsi(self, prices: np.ndarray, period: int = 14) -> float:
        """محاسبه شاخص قدرت نسبی"""
        if len(prices) < period + 1:
            return 50.0
        
        try:
            deltas = np.diff(prices)
            seed = deltas[:period+1]
            
            up = seed[seed >= 0].sum() / period
            down = -seed[seed < 0].sum() / period
            
            if down == 0:
                return 100.0
            
            rs = up / down
            rsi = 100.0 - (100.0 / (1.0 + rs))
            
            return max(0.0, min(100.0, float(rsi)))
        except:
            return 50.0
    
    def _calculate_macd(self, prices: np.ndarray, fast: int = 12, 
                       slow: int = 26, signal: int = 9) -> Tuple[Optional[float], Optional[float], Optional[float]]:
        """محاسبه MACD"""
        if len(prices) < slow:
            return None, None, None
        
        try:
            ema_fast = self._calculate_ema(prices, fast)
            ema_slow = self._calculate_ema(prices, slow)
            
            macd_line = ema_fast - ema_slow
            
            if len(prices) >= slow + signal:
                macd_values = []
                for i in range(signal):
                    start_idx = max(0, len(prices) - slow - i)
                    end_idx = len(prices) - i
                    if end_idx - start_idx >= slow:
                        segment = prices[start_idx:end_idx]
                        ema_fast_seg = self._calculate_ema(segment, fast)
                        ema_slow_seg = self._calculate_ema(segment, slow)
                        macd_values.append(ema_fast_seg - ema_slow_seg)
                
                if len(macd_values) >= signal:
                    signal_line = np.mean(macd_values[-signal:])
                    histogram = macd_line - signal_line
                    return macd_line, signal_line, histogram
            
            return macd_line, 0.0, macd_line
        except:
            return None, None, None
    
    def _calculate_bollinger_bands(self, prices: np.ndarray, period: int = 20, 
                                  std_dev: float = 2.0) -> Tuple[Optional[float], Optional[float], Optional[float]]:
        """محاسبه باندهای بولینگر"""
        if len(prices) < period:
            return None, None, None
        
        try:
            sma = np.mean(prices[-period:])
            std = np.std(prices[-period:])
            
            upper_band = sma + (std * std_dev)
            middle_band = sma
            lower_band = sma - (std * std_dev)
            
            return float(upper_band), float(middle_band), float(lower_band)
        except:
            return None, None, None
    
    # ========== سیستم گزارش‌گیری ==========
    
    def save_quality_report(self, filepath: str = None):
        """ذخیره گزارش کیفیت"""
        return self.quality_system.save_report(filepath)
    
    def print_quality_summary(self):
        """چاپ خلاصه کیفیت"""
        self.quality_system.print_summary()
        
        # آمار کش
        total_cache = self.cache_stats['hits'] + self.cache_stats['misses']
        hit_rate = (self.cache_stats['hits'] / total_cache * 100) if total_cache > 0 else 0
        
        print(f"\n📊 آمار کش:")
        print(f"  • Hits: {self.cache_stats['hits']:,}")
        print(f"  • Misses: {self.cache_stats['misses']:,}")
        print(f"  • Hit Rate: {hit_rate:.1f}%")
        print(f"  • Cache Size: {len(self.calculation_cache):,}")
        print(f"📊 تنظیمات فعلی:")
        print(f"  • strict_mode: {self.strict_mode}")
        print(f"  • min_data_points: {self.min_data_points}")
        print(f"  • min_volume_threshold: {self.min_volume_threshold}")
        print("="*80)


# Singleton برای استفاده آسان
calculator = IndicatorCalculator()