"""
🔍 بررسی وضعیت پردازش دیتابیس
"""

import sqlite3
import os

def check_processing_status():
    """بررسی وضعیت پردازش"""
    
    db_path = "../../../data/crypto_master.db"
    
    if not os.path.exists(db_path):
        print("❌ دیتابیس پیدا نشد")
        return
    
    print("🔍 وضعیت پردازش دیتابیس")
    print("=" * 60)
    
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    # آمار کلی
    cursor.execute("SELECT COUNT(*) FROM crypto_klines")
    total = cursor.fetchone()[0]
    
    # رکوردهای پردازش شده
    cursor.execute("SELECT COUNT(*) FROM crypto_klines WHERE rsi IS NOT NULL AND rsi != 0")
    processed = cursor.fetchone()[0]
    
    # رکوردهای پردازش نشده
    cursor.execute("SELECT COUNT(*) FROM crypto_klines WHERE rsi IS NULL OR rsi = 0")
    remaining = cursor.fetchone()[0]
    
    # درصد پیشرفت
    percentage = (processed / total) * 100 if total > 0 else 0
    
    print(f"📊 کل رکوردها: {total:,}")
    print(f"✅ پردازش شده: {processed:,}")
    print(f"⏳ باقی‌مانده: {remaining:,}")
    print(f"📈 درصد پیشرفت: {percentage:.1f}%")
    print("-" * 40)
    
    # نمایش وضعیت
    if remaining == 0:
        print("🎉 پردازش کاملاً تمام شده است!")
        print("✅ همه رکوردها اندیکاتور دارند.")
    else:
        print("🔄 پردازش هنوز ادامه دارد...")
        
        # تخمین زمان باقی‌مانده (بر اساس سرعت 356 رکورد/ثانیه)
        estimated_time = remaining / 356
        minutes = estimated_time / 60
        hours = minutes / 60
        
        print(f"⏳ تخمین زمان باقی‌مانده:")
        print(f"  • {estimated_time:.0f} ثانیه")
        print(f"  • {minutes:.1f} دقیقه")
        print(f"  • {hours:.2f} ساعت")
    
    # بررسی کیفیت
    print("-" * 40)
    cursor.execute("SELECT AVG(data_quality) FROM crypto_klines WHERE data_quality IS NOT NULL")
    avg_quality = cursor.fetchone()[0]
    
    if avg_quality:
        print(f"🧪 میانگین کیفیت داده: {avg_quality:.1f}/100")
    
    conn.close()
    print("=" * 60)

if __name__ == "__main__":
    check_processing_status()