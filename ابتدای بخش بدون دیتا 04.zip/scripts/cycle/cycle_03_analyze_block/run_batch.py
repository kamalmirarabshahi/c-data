"""
اسکریپت اجرای پردازش گروهی - نسخه ساده
"""

import sys
import os

# اضافه کردن مسیر جاری
current_dir = os.path.dirname(os.path.abspath(__file__))
if current_dir not in sys.path:
    sys.path.insert(0, current_dir)

# اجرای مستقیم batch_processor
if __name__ == "__main__":
    from batch_processor import main
    main()