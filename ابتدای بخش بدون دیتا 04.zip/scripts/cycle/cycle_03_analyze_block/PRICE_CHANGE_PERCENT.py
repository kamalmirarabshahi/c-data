"""
اسکریپت محاسبه و ذخیره اندیکاتور PRICE_CHANGE_PERCENT برای جدول crypto_klines
"""

import sqlite3
import numpy as np
import pandas as pd
from typing import List, Dict, Any, Optional
import logging
import os
import sys
from datetime import datetime, timedelta
import math
from pathlib import Path
import time

# تنظیمات لاگ‌گیری
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('price_change_calculator.log', encoding='utf-8'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class PriceChangeCalculator:
    """کلاس محاسبه و ذخیره price_change_percent برای جدول crypto_klines"""
    
    def __init__(self, db_path: str):
        """
        مقداردهی اولیه
        
        Args:
            db_path: مسیر فایل دیتابیس
        """
        self.db_path = db_path
        self.connection = None
        
        # بررسی وجود دیتابیس
        if not os.path.exists(db_path):
            logger.error(f"❌ فایل دیتابیس یافت نشد: {db_path}")
            raise FileNotFoundError(f"دیتابیس یافت نشد: {db_path}")
        
        logger.info(f"✅ دیتابیس شناسایی شد: {db_path}")
        
        # راه‌اندازی اتصال
        self._setup_connection()
        
    def _setup_connection(self):
        """راه‌اندازی اتصال به دیتابیس"""
        try:
            self.connection = sqlite3.connect(self.db_path)
            self.connection.row_factory = sqlite3.Row  # برای دسترسی با نام فیلد
            logger.info("✅ اتصال به دیتابیس برقرار شد")
        except Exception as e:
            logger.error(f"❌ خطا در اتصال به دیتابیس: {e}")
            raise
    
    def get_table_stats(self) -> Dict[str, Any]:
        """دریافت آمار جدول crypto_klines"""
        try:
            cursor = self.connection.cursor()
            
            # تعداد کل رکوردها
            cursor.execute("SELECT COUNT(*) as count FROM crypto_klines")
            total_records = cursor.fetchone()['count']
            
            # تعداد coin_id منحصر به فرد
            cursor.execute("SELECT COUNT(DISTINCT coin_id) as count FROM crypto_klines")
            unique_coins = cursor.fetchone()['count']
            
            # تایم‌فریم‌های منحصر به فرد
            cursor.execute("SELECT DISTINCT timeframe FROM crypto_klines ORDER BY timeframe")
            timeframes = [row['timeframe'] for row in cursor.fetchall()]
            
            # رکوردهای دارای price_change_percent
            cursor.execute("SELECT COUNT(*) as count FROM crypto_klines WHERE price_change_percent IS NOT NULL")
            calculated_records = cursor.fetchone()['count']
            
            # قدیمی‌ترین و جدیدترین تاریخ
            cursor.execute("""
                SELECT MIN(open_time) as oldest, MAX(open_time) as newest 
                FROM crypto_klines
            """)
            time_range = cursor.fetchone()
            
            # توزیع بر اساس تایم‌فریم
            cursor.execute("""
                SELECT timeframe, COUNT(*) as count 
                FROM crypto_klines 
                GROUP BY timeframe 
                ORDER BY timeframe
            """)
            timeframe_distribution = {row['timeframe']: row['count'] for row in cursor.fetchall()}
            
            return {
                'total_records': total_records,
                'unique_coins': unique_coins,
                'timeframes': timeframes,
                'calculated_records': calculated_records,
                'remaining_records': total_records - calculated_records,
                'oldest_time': time_range['oldest'],
                'newest_time': time_range['newest'],
                'timeframe_distribution': timeframe_distribution
            }
            
        except Exception as e:
            logger.error(f"❌ خطا در دریافت آمار جدول: {e}")
            return {}
    
    def print_table_summary(self):
        """چاپ خلاصه جدول"""
        stats = self.get_table_stats()
        
        print("\n" + "="*80)
        print("📊 خلاصه جدول crypto_klines")
        print("="*80)
        
        if not stats:
            print("❌ خطا در دریافت آمار")
            return
        
        print(f"\n📈 آمار کلی:")
        print(f"  • تعداد کل رکوردها: {stats['total_records']:,}")
        print(f"  • تعداد ارزهای منحصر به فرد: {stats['unique_coins']}")
        print(f"  • تایم‌فریم‌های موجود: {', '.join(stats['timeframes'])}")
        print(f"  • رکوردهای محاسبه شده: {stats['calculated_records']:,}")
        print(f"  • رکوردهای باقی‌مانده: {stats['remaining_records']:,}")
        
        if stats['oldest_time'] and stats['newest_time']:
            print(f"  • محدوده زمانی: {stats['oldest_time']} تا {stats['newest_time']}")
        
        print(f"\n📋 توزیع بر اساس تایم‌فریم:")
        for tf, count in stats['timeframe_distribution'].items():
            percentage = (count / stats['total_records']) * 100
            print(f"  • {tf:5}: {count:8,} رکورد ({percentage:.1f}%)")
        
        print("="*80)
    
    def calculate_price_change_percent(self, 
                                      current_close: float, 
                                      previous_close: float) -> Optional[float]:
        """
        محاسبه درصد تغییر قیمت
        
        Args:
            current_close: قیمت بسته فعلی
            previous_close: قیمت بسته قبلی
            
        Returns:
            درصد تغییر یا None در صورت خطا
        """
        try:
            if previous_close is None or current_close is None:
                return None
            
            if previous_close == 0:
                logger.debug("قیمت قبلی صفر است - محاسبه ناممکن")
                return 0.0
            
            # محاسبه درصد تغییر
            change_percent = ((current_close - previous_close) / previous_close) * 100
            
            # محدود کردن مقادیر غیرمنطقی (مثلاً تغییرات بیشتر از 1000%)
            if abs(change_percent) > 10000:
                logger.warning(f"تغییر قیمت غیرمنطقی: {change_percent:.2f}% - محدود شده")
                return 10000.0 if change_percent > 0 else -10000.0
            
            return float(change_percent)
            
        except Exception as e:
            logger.error(f"خطا در محاسبه درصد تغییر: {e}")
            return None
    
    def process_coin_timeframe(self, coin_id: int, timeframe: str, 
                              batch_size: int = 1000) -> Dict[str, Any]:
        """
        پردازش تمام کندل‌های یک ارز در یک تایم‌فریم خاص
        
        Args:
            coin_id: شناسه ارز
            timeframe: تایم‌فریم
            batch_size: اندازه بچ
            
        Returns:
            آمار پردازش
        """
        stats = {
            'coin_id': coin_id,
            'timeframe': timeframe,
            'total_records': 0,
            'processed': 0,
            'updated': 0,
            'errors': 0,
            'start_time': datetime.now(),
            'end_time': None,
            'duration_seconds': 0
        }
        
        try:
            cursor = self.connection.cursor()
            
            # دریافت تمام کندل‌های این ارز در این تایم‌فریم
            cursor.execute("""
                SELECT id, open_time, close_price, price_change_percent
                FROM crypto_klines
                WHERE coin_id = ? AND timeframe = ?
                ORDER BY open_time ASC
            """, (coin_id, timeframe))
            
            rows = cursor.fetchall()
            stats['total_records'] = len(rows)
            
            if stats['total_records'] == 0:
                logger.debug(f"  هیچ کندلی برای coin_id={coin_id}, timeframe={timeframe}")
                return stats
            
            logger.info(f"  پردازش {stats['total_records']:,} کندل برای coin_id={coin_id}, timeframe={timeframe}")
            
            # پردازش کندل‌ها
            batch_data = []
            previous_close = None
            
            for i, row in enumerate(rows, 1):
                row_dict = dict(row)
                
                # اگر قبلاً محاسبه شده، رد شو
                if row_dict['price_change_percent'] is not None:
                    stats['processed'] += 1
                    previous_close = row_dict['close_price']
                    continue
                
                current_close = row_dict['close_price']
                
                if previous_close is not None and current_close is not None:
                    # محاسبه درصد تغییر
                    change_percent = self.calculate_price_change_percent(current_close, previous_close)
                    
                    if change_percent is not None:
                        batch_data.append((change_percent, row_dict['id']))
                        stats['updated'] += 1
                    else:
                        stats['errors'] += 1
                        # اگر محاسبه نشد، صفر قرار بده
                        batch_data.append((0.0, row_dict['id']))
                        stats['updated'] += 1
                else:
                    # اولین کندل - تغییر صفر
                    batch_data.append((0.0, row_dict['id']))
                    stats['updated'] += 1
                
                # به‌روزرسانی قیمت قبلی
                previous_close = current_close
                stats['processed'] += 1
                
                # نمایش پیشرفت
                if i % 5000 == 0:
                    logger.info(f"    {i:,}/{stats['total_records']:,} پردازش شد")
                
                # اگر بچ پر شد، ذخیره کن
                if len(batch_data) >= batch_size:
                    self._update_batch(batch_data)
                    batch_data = []
            
            # ذخیره بچ باقی‌مانده
            if batch_data:
                self._update_batch(batch_data)
            
            stats['end_time'] = datetime.now()
            stats['duration_seconds'] = (stats['end_time'] - stats['start_time']).total_seconds()
            
            if stats['updated'] > 0:
                logger.info(f"  ✅ به‌روزرسانی {stats['updated']:,} رکورد در {stats['duration_seconds']:.1f} ثانیه")
            
            return stats
            
        except Exception as e:
            logger.error(f"❌ خطا در پردازش coin_id={coin_id}, timeframe={timeframe}: {e}")
            stats['error'] = str(e)
            stats['end_time'] = datetime.now()
            return stats
    
    def _update_batch(self, batch_data: List[tuple]):
        """
        به‌روزرسانی دسته‌ای داده‌ها
        
        Args:
            batch_data: لیست tuples از (price_change_percent, id)
        """
        if not batch_data:
            return
        
        try:
            cursor = self.connection.cursor()
            
            # استفاده از executemany برای کارایی
            cursor.executemany(
                "UPDATE crypto_klines SET price_change_percent = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?",
                batch_data
            )
            
            self.connection.commit()
            
        except Exception as e:
            self.connection.rollback()
            logger.error(f"خطا در به‌روزرسانی بچ: {e}")
            raise
    
    def process_all(self, batch_size: int = 1000) -> Dict[str, Any]:
        """
        پردازش تمام ارزها و تایم‌فریم‌ها
        
        Args:
            batch_size: اندازه بچ
            
        Returns:
            آمار کلی پردازش
        """
        overall_stats = {
            'start_time': datetime.now(),
            'end_time': None,
            'total_processed': 0,
            'total_updated': 0,
            'total_errors': 0,
            'coin_timeframe_stats': [],
            'timeframe_summary': {}
        }
        
        try:
            # دریافت تمام coin_id و timeframe منحصر به فرد
            cursor = self.connection.cursor()
            cursor.execute("""
                SELECT DISTINCT coin_id, timeframe 
                FROM crypto_klines 
                ORDER BY coin_id, timeframe
            """)
            
            coin_timeframes = cursor.fetchall()
            
            logger.info(f"🚀 شروع پردازش {len(coin_timeframes)} ترکیب coin/تایم‌فریم")
            
            # آمار تایم‌فریم‌ها
            timeframe_counts = {}
            
            for i, row in enumerate(coin_timeframes, 1):
                coin_id = row['coin_id']
                timeframe = row['timeframe']
                
                logger.info(f"\n📊 پردازش {i}/{len(coin_timeframes)}: coin_id={coin_id}, timeframe={timeframe}")
                
                # پردازش این ترکیب
                stats = self.process_coin_timeframe(coin_id, timeframe, batch_size)
                
                overall_stats['coin_timeframe_stats'].append(stats)
                overall_stats['total_processed'] += stats.get('processed', 0)
                overall_stats['total_updated'] += stats.get('updated', 0)
                overall_stats['total_errors'] += stats.get('errors', 0)
                
                # جمع‌آوری آمار تایم‌فریم
                if timeframe not in timeframe_counts:
                    timeframe_counts[timeframe] = 0
                timeframe_counts[timeframe] += stats.get('updated', 0)
                
                # استراحت کوتاه برای جلوگیری از فشار روی دیتابیس
                if i < len(coin_timeframes):
                    time.sleep(0.05)
            
            overall_stats['end_time'] = datetime.now()
            overall_stats['total_duration_seconds'] = (
                overall_stats['end_time'] - overall_stats['start_time']
            ).total_seconds()
            
            overall_stats['timeframe_summary'] = timeframe_counts
            
            # چاپ خلاصه نهایی
            self._print_final_summary(overall_stats)
            
            return overall_stats
            
        except Exception as e:
            logger.error(f"❌ خطای کلی در پردازش: {e}")
            overall_stats['error'] = str(e)
            overall_stats['end_time'] = datetime.now()
            return overall_stats
    
    def _print_final_summary(self, overall_stats: Dict[str, Any]):
        """چاپ خلاصه نهایی پردازش"""
        print("\n" + "="*80)
        print("📊 گزارش نهایی پردازش PRICE_CHANGE_PERCENT")
        print("="*80)
        
        print(f"\n✅ پردازش کامل شد!")
        print(f"\n📈 آمار کلی:")
        print(f"  • زمان شروع: {overall_stats['start_time'].strftime('%Y-%m-%d %H:%M:%S')}")
        print(f"  • زمان پایان: {overall_stats['end_time'].strftime('%Y-%m-%d %H:%M:%S')}")
        print(f"  • مدت زمان: {overall_stats['total_duration_seconds']:.1f} ثانیه")
        print(f"  • تعداد رکوردهای پردازش شده: {overall_stats['total_processed']:,}")
        print(f"  • تعداد رکوردهای به‌روزرسانی شده: {overall_stats['total_updated']:,}")
        print(f"  • تعداد خطاها: {overall_stats['total_errors']:,}")
        
        if overall_stats['total_processed'] > 0:
            success_rate = (overall_stats['total_updated'] / overall_stats['total_processed']) * 100
            print(f"  • نرخ موفقیت: {success_rate:.1f}%")
        
        print(f"\n📋 آمار تفکیکی تایم‌فریم‌ها:")
        for timeframe, count in sorted(overall_stats.get('timeframe_summary', {}).items()):
            print(f"  • {timeframe}: {count:,} رکورد")
        
        print("\n" + "="*80)
    
    def verify_sample(self, sample_size: int = 50) -> Dict[str, Any]:
        """
        تأیید محاسبات با نمونه‌گیری
        
        Args:
            sample_size: تعداد نمونه برای بررسی
            
        Returns:
            نتایج تأیید
        """
        logger.info(f"🔍 تأیید محاسبات با {sample_size} نمونه")
        
        verification_results = {
            'total_samples_checked': 0,
            'correct_calculations': 0,
            'incorrect_calculations': 0,
            'null_values': 0,
            'samples': []
        }
        
        try:
            cursor = self.connection.cursor()
            
            # دریافت نمونه‌های تصادفی
            cursor.execute(f"""
                SELECT k1.id, k1.coin_id, k1.timeframe, k1.open_time, k1.close_price, 
                       k1.price_change_percent as stored_value
                FROM crypto_klines k1
                WHERE k1.price_change_percent IS NOT NULL
                ORDER BY RANDOM()
                LIMIT {sample_size}
            """)
            
            rows = cursor.fetchall()
            
            for row in rows:
                verification_results['total_samples_checked'] += 1
                row_dict = dict(row)
                
                # پیدا کردن کندل قبلی برای مقایسه
                cursor.execute("""
                    SELECT close_price 
                    FROM crypto_klines 
                    WHERE coin_id = ? 
                      AND timeframe = ? 
                      AND open_time < ?
                    ORDER BY open_time DESC 
                    LIMIT 1
                """, (row_dict['coin_id'], row_dict['timeframe'], row_dict['open_time']))
                
                prev_row = cursor.fetchone()
                
                if prev_row:
                    previous_close = prev_row['close_price']
                    current_close = row_dict['close_price']
                    
                    # محاسبه مجدد
                    recalculated = self.calculate_price_change_percent(
                        current_close, previous_close
                    )
                    stored_value = row_dict['stored_value']
                    
                    # مقایسه (با تحمل خطای جزئی به دلیل گرد کردن)
                    if recalculated is not None and stored_value is not None:
                        tolerance = 0.0001  # اختلاف بسیار کوچک قابل قبول
                        if abs(recalculated - stored_value) < tolerance:
                            verification_results['correct_calculations'] += 1
                            status = 'CORRECT'
                        else:
                            verification_results['incorrect_calculations'] += 1
                            status = 'INCORRECT'
                            
                            # ثبت نمونه‌های نادرست برای بررسی
                            verification_results['samples'].append({
                                'coin_id': row_dict['coin_id'],
                                'timeframe': row_dict['timeframe'],
                                'open_time': row_dict['open_time'],
                                'stored': stored_value,
                                'recalculated': recalculated,
                                'difference': abs(recalculated - stored_value)
                            })
                    else:
                        verification_results['null_values'] += 1
                        status = 'NULL_VALUE'
                    
                else:
                    # کندل اول - باید صفر باشد
                    stored_value = row_dict['stored_value']
                    if stored_value == 0 or stored_value is None:
                        verification_results['correct_calculations'] += 1
                        status = 'CORRECT (FIRST CANDLE)'
                    else:
                        verification_results['incorrect_calculations'] += 1
                        status = 'INCORRECT (FIRST CANDLE)'
            
            # چاپ نتایج تأیید
            print("\n" + "="*80)
            print("✅ نتایج تأیید محاسبات")
            print("="*80)
            
            print(f"\n📊 آمار تأیید:")
            print(f"  • تعداد نمونه‌های بررسی شده: {verification_results['total_samples_checked']}")
            print(f"  • محاسبات صحیح: {verification_results['correct_calculations']}")
            print(f"  • محاسبات ناصحیح: {verification_results['incorrect_calculations']}")
            print(f"  • مقادیر null: {verification_results['null_values']}")
            
            if verification_results['total_samples_checked'] > 0:
                accuracy = (verification_results['correct_calculations'] / 
                           verification_results['total_samples_checked']) * 100
                print(f"  • دقت: {accuracy:.1f}%")
            
            # نمایش نمونه‌های نادرست (اگر وجود دارند)
            if verification_results['incorrect_calculations'] > 0:
                print(f"\n⚠️  نمونه‌های نادرست:")
                for i, sample in enumerate(verification_results['samples'][:5], 1):
                    print(f"  {i}. Coin {sample['coin_id']} | {sample['timeframe']} | {sample['open_time']}")
                    print(f"     ذخیره شده: {sample['stored']:.6f}%")
                    print(f"     محاسبه مجدد: {sample['recalculated']:.6f}%")
                    print(f"     اختلاف: {sample['difference']:.6f}%")
            
            print("\n" + "="*80)
            
            return verification_results
            
        except Exception as e:
            logger.error(f"❌ خطا در تأیید محاسبات: {e}")
            print(f"\n❌ خطا در تأیید: {e}")
            return verification_results
    
    def close(self):
        """بستن اتصال به دیتابیس"""
        if self.connection:
            self.connection.close()
            logger.info("🔌 اتصال به دیتابیس بسته شد")


def main():
    """تابع اصلی اجرای اسکریپت"""
    # مسیر دیتابیس
    db_path = r"C:\Users\Kamal\Desktop\py-prg\git\c-data\data\crypto_master.db"
    
    print("\n" + "="*80)
    print("🧮 اسکریپت محاسبه PRICE_CHANGE_PERCENT برای جدول crypto_klines")
    print("="*80)
    
    # بررسی وجود فایل دیتابیس
    if not os.path.exists(db_path):
        print(f"❌ فایل دیتابیس یافت نشد: {db_path}")
        print("لطفاً مسیر صحیح را بررسی کنید.")
        return
    
    print(f"📁 دیتابیس: {db_path}")
    print(f"📅 تاریخ: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("="*80)
    
    # ایجاد نمونه از کلاس
    calculator = None
    
    try:
        calculator = PriceChangeCalculator(db_path)
        
        # نمایش خلاصه جدول
        calculator.print_table_summary()
        
        # تأیید ادامه
        confirm = input("\n❓ آیا می‌خواهید پردازش را شروع کنید؟ (y/n): ")
        if confirm.lower() != 'y':
            print("❌ پردازش لغو شد.")
            return
        
        print("\n🚀 شروع پردازش...")
        print("-"*80)
        
        # پردازش تمام داده‌ها
        overall_stats = calculator.process_all(batch_size=2000)
        
        # تأیید محاسبات
        if overall_stats.get('total_updated', 0) > 0:
            confirm = input("\n❓ آیا می‌خواهید محاسبات را تأیید کنید؟ (y/n): ")
            if confirm.lower() == 'y':
                calculator.verify_sample(sample_size=100)
        
        print("\n🎉 پردازش با موفقیت تکمیل شد!")
        
    except Exception as e:
        logger.error(f"❌ خطای اصلی: {e}")
        print(f"\n❌ خطا رخ داد: {e}")
        
    finally:
        if calculator:
            calculator.close()
            
    # ایجاد گزارش خلاصه
    print("\n📝 گزارش در فایل 'price_change_calculator.log' ذخیره شد.")


if __name__ == "__main__":
    main()