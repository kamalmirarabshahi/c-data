﻿"""
📊 گزارش‌گیر تکه ۳ - نسخه بهبود یافته با پشتیبانی از تایم‌فریم‌ها
تولید گزارش‌های تحلیلی برای نتایج تایم‌فریم‌های مختلف
"""

import json
import os
import logging
from datetime import datetime
from typing import Dict, List, Any, Optional
import pandas as pd
import numpy as np
import sys

# FIX: اضافه کردن مسیر scripts به sys.path
current_file_dir = os.path.dirname(os.path.abspath(__file__))
scripts_dir = os.path.dirname(os.path.dirname(current_file_dir))  # دو سطح بالا!

if scripts_dir not in sys.path:
    sys.path.insert(0, scripts_dir)

# حالا importهای دیگه
from config_manager import get_database_path, get, get_timeframes
if scripts_dir not in sys.path:
    sys.path.insert(0, scripts_dir)

# حالا importهای دیگه
from config_manager import get_database_path, get, get_timeframes

logger = logging.getLogger(__name__)

class ReportGenerator:
    """تولیدکننده گزارش اجرای تکه ۳ - با پشتیبانی از تایم‌فریم‌ها"""
    
    def __init__(self):
        logger.info("ReportGenerator (نسخه تایم‌فریم) راه‌اندازی شد")
        
        # دریافت تنظیمات از config_manager
        self.timeframe_order = self._get_timeframe_order()
        self.reports_dir = self._get_reports_directory()
        
        # ایجاد پوشه گزارش‌ها اگر وجود ندارد
        os.makedirs(self.reports_dir, exist_ok=True)
        
        # پوشه جداگانه برای گزارش‌های تایم‌فریم‌ها
        self.timeframe_reports_dir = os.path.join(self.reports_dir, "timeframes")
        os.makedirs(self.timeframe_reports_dir, exist_ok=True)
        
        logger.debug(f"📁 مسیر گزارش‌ها: {self.reports_dir}")
        logger.debug(f"📅 تایم‌فریم‌های معتبر: {self.timeframe_order}")
    
    def _get_timeframe_order(self) -> List[str]:
        """دریافت لیست ترتیب تایم‌فریم‌ها از config_manager"""
        try:
            from config_manager import get
            # سعی کن از تنظیمات بگیر
            timeframes = get('analysis.valid_timeframes', ['1m', '5m', '15m', '30m', '1h', '4h', '1d', '1w'])
            logger.debug(f"✅ تایم‌فریم‌ها از کانفیگ دریافت شد: {timeframes}")
            return timeframes
        except ImportError as e:
            logger.warning(f"⚠️ config_manager یافت نشد، استفاده از تایم‌فریم‌های پیش‌فرض: {e}")
            return ['1m', '5m', '15m', '30m', '1h', '4h', '1d', '1w']
        except Exception as e:
            logger.error(f"❌ خطا در دریافت تایم‌فریم‌ها: {e}")
            return ['1m', '5m', '15m', '30m', '1h', '4h', '1d', '1w']
    
    def _get_reports_directory(self) -> str:
        """دریافت مسیر پوشه گزارش‌ها از config_manager"""
        try:
            from config_manager import get
            # سعی کن از تنظیمات بگیر
            reports_dir = get('paths.reports_dir', 'reports')
            
            # اضافه کردن پوشه تکه ۳
            full_path = os.path.join(reports_dir, "cycle_03")
            
            # اگر مسیر نسبی است، کاملش کن
            if not os.path.isabs(full_path):
                # سعی کن مسیر را نسبت به پروژه بساز
                try:
                    project_root = get('paths.project_root', '.')
                    full_path = os.path.join(project_root, full_path)
                except:
                    pass
            
            logger.debug(f"✅ مسیر گزارش‌ها از کانفیگ دریافت شد: {full_path}")
            return full_path
            
        except ImportError as e:
            logger.warning(f"⚠️ config_manager یافت نشد، استفاده از مسیر پیش‌فرض: {e}")
            return "reports/cycle_03"
        except Exception as e:
            logger.error(f"❌ خطا در دریافت مسیر گزارش‌ها: {e}")
            return "reports/cycle_03"
    
    def save_report(self, report_data: Dict[str, Any], block_id: int) -> str:
        """
        ذخیره گزارش در فایل JSON - نسخه بهبود یافته با پشتیبانی از تایم‌فریم‌ها
        """
        try:
            # نام فایل گزارش
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"block_{block_id:03d}_{timestamp}.json"
            filepath = os.path.join(self.reports_dir, filename)
            
            # تولید گزارش تایم‌فریم‌ها اگر موجود باشد
            if self._has_timeframe_data(report_data):
                timeframe_report = self._generate_timeframe_report(report_data, block_id)
                if timeframe_report:
                    tf_filename = f"block_{block_id:03d}_timeframes_{timestamp}.json"
                    tf_filepath = os.path.join(self.timeframe_reports_dir, tf_filename)
                    
                    with open(tf_filepath, 'w', encoding='utf-8') as f:
                        json.dump(timeframe_report, f, indent=2, ensure_ascii=False)
                    
                    logger.info(f"📅 گزارش تایم‌فریم‌های بلوک {block_id} ذخیره شد: {tf_filename}")
            
            # ذخیره گزارش اصلی
            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump(report_data, f, indent=2, ensure_ascii=False)
            
            logger.info(f"✅ گزارش بلوک {block_id} ذخیره شد: {filename}")
            return filepath
            
        except Exception as e:
            logger.error(f"❌ خطا در ذخیره گزارش بلوک {block_id}: {e}")
            return None
    
    def _has_timeframe_data(self, report_data: Dict[str, Any]) -> bool:
        """بررسی وجود داده‌های تایم‌فریم در گزارش"""
        try:
            if 'coin_results' not in report_data:
                return False
            
            for coin_result in report_data['coin_results']:
                if 'timeframe_results' in coin_result or 'timeframes_processed' in coin_result:
                    return True
            
            return False
        except:
            return False
    
    def _generate_timeframe_report(self, report_data: Dict[str, Any], block_id: int) -> Dict[str, Any]:
        """تولید گزارش تخصصی برای تایم‌فریم‌ها"""
        try:
            if 'coin_results' not in report_data:
                return None
            
            timeframe_report = {
                'block_id': block_id,
                'generated_at': datetime.now().isoformat(),
                'timeframe_summary': {},
                'coin_timeframe_details': [],
                'timeframe_order': self.timeframe_order  # اضافه کردن لیست ترتیب
            }
            
            # جمع‌آوری آمار تایم‌فریم‌ها
            timeframe_stats = {}
            total_processed_by_timeframe = {}
            
            for coin_result in report_data['coin_results']:
                coin_symbol = coin_result.get('symbol', 'N/A')
                
                if 'timeframe_results' in coin_result:
                    coin_timeframes = []
                    
                    for tf_result in coin_result['timeframe_results']:
                        timeframe = tf_result.get('timeframe', 'unknown')
                        processed = tf_result.get('processed_candles', 0)
                        total = tf_result.get('total_candles', 0)
                        success_rate = tf_result.get('success_rate', 0)
                        
                        # آمار تجمعی تایم‌فریم
                        if timeframe not in timeframe_stats:
                            timeframe_stats[timeframe] = {
                                'total_coins': 0,
                                'total_candles': 0,
                                'processed_candles': 0,
                                'coins_completed': 0,
                                'coins_failed': 0
                            }
                        
                        timeframe_stats[timeframe]['total_coins'] += 1
                        timeframe_stats[timeframe]['total_candles'] += total
                        timeframe_stats[timeframe]['processed_candles'] += processed
                        
                        if tf_result.get('status') == 'COMPLETED':
                            timeframe_stats[timeframe]['coins_completed'] += 1
                        elif tf_result.get('status') == 'FAILED':
                            timeframe_stats[timeframe]['coins_failed'] += 1
                        
                        # آمار کلی تایم‌فریم
                        if timeframe not in total_processed_by_timeframe:
                            total_processed_by_timeframe[timeframe] = 0
                        total_processed_by_timeframe[timeframe] += processed
                        
                        # جزئیات تایم‌فریم برای این ارز
                        coin_timeframes.append({
                            'timeframe': timeframe,
                            'processed_candles': processed,
                            'total_candles': total,
                            'success_rate': success_rate,
                            'status': tf_result.get('status', 'UNKNOWN')
                        })
                    
                    # اضافه کردن جزئیات ارز با تایم‌فریم‌هایش
                    if coin_timeframes:
                        timeframe_report['coin_timeframe_details'].append({
                            'symbol': coin_symbol,
                            'timeframes': coin_timeframes,
                            'total_timeframes': len(coin_timeframes)
                        })
            
            # محاسبه آمار نهایی تایم‌فریم‌ها
            for tf, stats in timeframe_stats.items():
                if stats['total_candles'] > 0:
                    stats['success_rate'] = round((stats['processed_candles'] / stats['total_candles']) * 100, 2)
                else:
                    stats['success_rate'] = 0
                
                if stats['total_coins'] > 0:
                    stats['completion_rate'] = round((stats['coins_completed'] / stats['total_coins']) * 100, 2)
                else:
                    stats['completion_rate'] = 0
            
            # مرتب‌سازی تایم‌فریم‌ها بر اساس ترتیب از کانفیگ
            sorted_timeframes = sorted(
                timeframe_stats.items(),
                key=lambda x: self.timeframe_order.index(x[0]) if x[0] in self.timeframe_order else 99
            )
            
            timeframe_report['timeframe_summary'] = {
                timeframe: stats for timeframe, stats in sorted_timeframes
            }
            
            # بهترین و بدترین تایم‌فریم
            if timeframe_stats:
                best_tf = max(timeframe_stats.items(), key=lambda x: x[1].get('success_rate', 0))
                worst_tf = min(timeframe_stats.items(), key=lambda x: x[1].get('success_rate', 100))
                
                timeframe_report['performance_analysis'] = {
                    'best_timeframe': {
                        'timeframe': best_tf[0],
                        'success_rate': best_tf[1].get('success_rate', 0),
                        'processed_candles': best_tf[1].get('processed_candles', 0)
                    },
                    'worst_timeframe': {
                        'timeframe': worst_tf[0],
                        'success_rate': worst_tf[1].get('success_rate', 0),
                        'processed_candles': worst_tf[1].get('processed_candles', 0)
                    },
                    'most_processed_timeframe': max(
                        total_processed_by_timeframe.items(), 
                        key=lambda x: x[1]
                    )[0] if total_processed_by_timeframe else 'N/A'
                }
            
            logger.info(f"📅 گزارش تایم‌فریم‌های بلوک {block_id} تولید شد: {len(timeframe_stats)} تایم‌فریم")
            return timeframe_report
            
        except Exception as e:
            logger.error(f"❌ خطا در تولید گزارش تایم‌فریم‌ها: {e}")
            return None
    
    def generate_summary_report(self, block_reports: List[Dict[str, Any]]) -> str:
        """
        تولید گزارش خلاصه از چندین بلوک - نسخه بهبود یافته
        """
        try:
            summary = {
                'generated_at': datetime.now().isoformat(),
                'total_blocks': len(block_reports),
                'blocks': [],
                'timeframe_analysis': {},
                'performance_over_time': [],
                'timeframe_order': self.timeframe_order  # اضافه کردن لیست ترتیب
            }
            
            total_coins = 0
            total_candles = 0
            total_processed = 0
            
            # آمار تجمعی تایم‌فریم‌ها
            cumulative_timeframe_stats = {}
            
            for report in block_reports:
                if not report or 'summary' not in report:
                    continue
                
                block_summary = report['summary']
                block_id = report.get('block_id', 0)
                
                # اطلاعات بلوک
                block_info = {
                    'block_id': block_id,
                    'coins_completed': block_summary.get('coins_completed', 0),
                    'coins_failed': block_summary.get('coins_failed', 0),
                    'total_candles': block_summary.get('total_candles', 0),
                    'processed_candles': block_summary.get('processed_candles', 0),
                    'success_rate': block_summary.get('success_rate', 0),
                    'duration_seconds': report.get('duration_seconds', 0)
                }
                
                summary['blocks'].append(block_info)
                
                # جمع‌آوری آمار
                total_coins += block_summary.get('coins_completed', 0)
                total_candles += block_summary.get('total_candles', 0)
                total_processed += block_summary.get('processed_candles', 0)
                
                # تحلیل تایم‌فریم‌ها برای این بلوک
                if self._has_timeframe_data(report):
                    tf_report = self._generate_timeframe_report(report, block_id)
                    if tf_report and 'timeframe_summary' in tf_report:
                        for tf, stats in tf_report['timeframe_summary'].items():
                            if tf not in cumulative_timeframe_stats:
                                cumulative_timeframe_stats[tf] = {
                                    'total_candles': 0,
                                    'processed_candles': 0,
                                    'blocks_processed': 0
                                }
                            
                            cumulative_timeframe_stats[tf]['total_candles'] += stats.get('total_candles', 0)
                            cumulative_timeframe_stats[tf]['processed_candles'] += stats.get('processed_candles', 0)
                            cumulative_timeframe_stats[tf]['blocks_processed'] += 1
                
                # روند عملکرد
                summary['performance_over_time'].append({
                    'block_id': block_id,
                    'success_rate': block_summary.get('success_rate', 0),
                    'processed_candles': block_summary.get('processed_candles', 0),
                    'timestamp': report.get('end_time', datetime.now().isoformat())
                })
            
            # محاسبه آمار کلی
            summary['overall'] = {
                'total_coins_processed': total_coins,
                'total_candles': total_candles,
                'total_processed_candles': total_processed,
                'overall_success_rate': round((total_processed / total_candles * 100), 2) if total_candles > 0 else 0,
                'average_duration_per_block': round(sum(b.get('duration_seconds', 0) for b in summary['blocks']) / len(summary['blocks']), 2) if summary['blocks'] else 0,
                'blocks_completed': len([b for b in summary['blocks'] if b.get('success_rate', 0) > 90]),
                'blocks_partial': len([b for b in summary['blocks'] if 50 <= b.get('success_rate', 0) <= 90]),
                'blocks_failed': len([b for b in summary['blocks'] if b.get('success_rate', 0) < 50])
            }
            
            # تحلیل تایم‌فریم‌ها
            if cumulative_timeframe_stats:
                for tf, stats in cumulative_timeframe_stats.items():
                    if stats['total_candles'] > 0:
                        stats['success_rate'] = round((stats['processed_candles'] / stats['total_candles']) * 100, 2)
                    else:
                        stats['success_rate'] = 0
                
                # مرتب‌سازی تایم‌فریم‌ها بر اساس ترتیب از کانفیگ
                sorted_tfs = sorted(
                    cumulative_timeframe_stats.items(),
                    key=lambda x: self.timeframe_order.index(x[0]) if x[0] in self.timeframe_order else 99
                )
                
                summary['timeframe_analysis'] = {
                    'timeframes_processed': len(cumulative_timeframe_stats),
                    'cumulative_stats': {tf: stats for tf, stats in sorted_tfs},
                    'recommendations': self._generate_timeframe_recommendations(cumulative_timeframe_stats)
                }
            
            # ذخیره گزارش خلاصه
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            summary_file = os.path.join(self.reports_dir, f"summary_{timestamp}.json")
            
            with open(summary_file, 'w', encoding='utf-8') as f:
                json.dump(summary, f, indent=2, ensure_ascii=False)
            
            # تولید گزارش CSV برای تحلیل آسان‌تر
            csv_file = self._generate_csv_report(summary)
            if csv_file:
                logger.info(f"📈 گزارش CSV تولید شد: {csv_file}")
            
            logger.info(f"✅ گزارش خلاصه ذخیره شد: {summary_file}")
            return summary_file
            
        except Exception as e:
            logger.error(f"❌ خطا در تولید گزارش خلاصه: {e}")
            return None
    
    def _generate_timeframe_recommendations(self, timeframe_stats: Dict[str, Dict[str, Any]]) -> List[str]:
        """تولید توصیه‌های بر اساس آمار تایم‌فریم‌ها"""
        recommendations = []
        
        try:
            if not timeframe_stats:
                recommendations.append("⚠️ هیچ داده تایم‌فریمی برای تحلیل موجود نیست")
                return recommendations
            
            # پیدا کردن بهترین و بدترین تایم‌فریم
            best_tf = max(timeframe_stats.items(), key=lambda x: x[1].get('success_rate', 0))
            worst_tf = min(timeframe_stats.items(), key=lambda x: x[1].get('success_rate', 100))
            
            # تحلیل عملکرد
            if best_tf[1].get('success_rate', 0) > 90:
                recommendations.append(f"✅ تایم‌فریم {best_tf[0]} عملکرد عالی دارد (نرخ موفقیت: {best_tf[1].get('success_rate', 0):.1f}%)")
            
            if worst_tf[1].get('success_rate', 0) < 50:
                recommendations.append(f"⚠️ تایم‌فریم {worst_tf[0]} نیاز به بررسی دارد (نرخ موفقیت: {worst_tf[1].get('success_rate', 0):.1f}%)")
            
            # تحلیل پوشش تایم‌فریم‌ها
            total_timeframes = len(timeframe_stats)
            expected_timeframes = len(self.timeframe_order)
            
            if total_timeframes < expected_timeframes:
                missing = [tf for tf in self.timeframe_order if tf not in timeframe_stats]
                if missing:
                    recommendations.append(f"⚠️ تایم‌فریم‌های مفقود: {', '.join(missing)}")
            
            # تحلیل حجم داده
            for tf, stats in timeframe_stats.items():
                processed = stats.get('processed_candles', 0)
                if processed < 100:
                    recommendations.append(f"📊 تایم‌فریم {tf} داده کمی دارد ({processed} کندل). برای تحلیل دقیق‌تر نیاز به داده بیشتر است.")
            
            return recommendations
            
        except Exception as e:
            logger.error(f"خطا در تولید توصیه‌های تایم‌فریم: {e}")
            return ["خطا در تولید توصیه‌ها"]
    
    def _generate_csv_report(self, summary_data: Dict[str, Any]) -> Optional[str]:
        """تولید گزارش CSV برای تحلیل آسان‌تر"""
        try:
            if 'blocks' not in summary_data:
                return None
            
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            csv_file = os.path.join(self.reports_dir, f"summary_{timestamp}.csv")
            
            # ایجاد DataFrame
            data = []
            for block in summary_data['blocks']:
                data.append({
                    'block_id': block.get('block_id', 0),
                    'coins_completed': block.get('coins_completed', 0),
                    'coins_failed': block.get('coins_failed', 0),
                    'total_candles': block.get('total_candles', 0),
                    'processed_candles': block.get('processed_candles', 0),
                    'success_rate': block.get('success_rate', 0),
                    'duration_seconds': block.get('duration_seconds', 0)
                })
            
            if data:
                df = pd.DataFrame(data)
                df.to_csv(csv_file, index=False, encoding='utf-8-sig')
                return csv_file
            
            return None
            
        except Exception as e:
            logger.error(f"❌ خطا در تولید گزارش CSV: {e}")
            return None
    
    def print_console_report(self, report_data: Dict[str, Any]):
        """
        چاپ گزارش در کنسول - نسخه بهبود یافته با نمایش تایم‌فریم‌ها
        """
        try:
            print("\n" + "=" * 70)
            print("📊 گزارش تکه ۳ - تحلیل کندل‌ها و اندیکاتورها")
            print("=" * 70)
            
            if 'summary' in report_data:
                summary = report_data['summary']
                
                print(f"\n📦 بلوک: {report_data.get('block_id', 'N/A')}")
                print(f"⏱️  زمان اجرا: {report_data.get('duration_seconds', 0):.2f} ثانیه")
                
                print(f"\n📈 آمار کلی:")
                print(f"   • ارزهای پردازش شده: {summary.get('total_coins', 0)}")
                print(f"   • ارزهای موفق: {summary.get('coins_completed', 0)}")
                print(f"   • ارزهای ناموفق: {summary.get('coins_failed', 0)}")
                print(f"   • کل کندل‌ها: {summary.get('total_candles', 0):,}")
                print(f"   • کندل‌های پردازش شده: {summary.get('processed_candles', 0):,}")
                print(f"   • نرخ موفقیت: {summary.get('success_rate', 0):.1f}%")
            
            # نمایش تایم‌فریم‌ها اگر موجود باشد
            if self._has_timeframe_data(report_data):
                print(f"\n📅 تحلیل تایم‌فریم‌ها:")
                
                timeframe_summary = {}
                for coin_result in report_data.get('coin_results', []):
                    if 'timeframe_results' in coin_result:
                        for tf_result in coin_result['timeframe_results']:
                            tf = tf_result.get('timeframe', 'unknown')
                            if tf not in timeframe_summary:
                                timeframe_summary[tf] = {
                                    'coins': 0,
                                    'total_candles': 0,
                                    'processed_candles': 0
                                }
                            
                            timeframe_summary[tf]['coins'] += 1
                            timeframe_summary[tf]['total_candles'] += tf_result.get('total_candles', 0)
                            timeframe_summary[tf]['processed_candles'] += tf_result.get('processed_candles', 0)
                
                # مرتب‌سازی تایم‌فریم‌ها بر اساس ترتیب از کانفیگ
                sorted_tfs = sorted(
                    timeframe_summary.items(),
                    key=lambda x: self.timeframe_order.index(x[0]) if x[0] in self.timeframe_order else 99
                )
                
                for tf, stats in sorted_tfs:
                    success_rate = (stats['processed_candles'] / stats['total_candles'] * 100) if stats['total_candles'] > 0 else 0
                    print(f"   • {tf}: {stats['coins']} ارز، {stats['processed_candles']:,}/{stats['total_candles']:,} کندل ({success_rate:.1f}%)")
            
            # نمایش ۵ ارز اول با تایم‌فریم‌ها
            if 'coin_results' in report_data and report_data['coin_results']:
                print(f"\n🎯 ۵ ارز اول:")
                for i, coin in enumerate(report_data['coin_results'][:5], 1):
                    symbol = coin.get('symbol', f'Coin_{i}')
                    status = coin.get('status', 'UNKNOWN')
                    processed = coin.get('processed_candles', 0)
                    total = coin.get('total_candles', 0)
                    rate = coin.get('success_rate', 0)
                    
                    status_icon = '✅' if status == 'COMPLETED' else '⚠️' if status == 'PARTIAL' else '❌'
                    
                    # نمایش تعداد تایم‌فریم‌ها اگر موجود باشد
                    timeframe_info = ""
                    if 'timeframes_processed' in coin:
                        timeframe_info = f" ({coin['timeframes_processed']} تایم‌فریم)"
                    elif 'timeframe_results' in coin:
                        timeframe_info = f" ({len(coin['timeframe_results'])} تایم‌فریم)"
                    
                    print(f"   {status_icon} {symbol}{timeframe_info}: {processed}/{total} ({rate:.1f}%)")
                    
                    # نمایش تایم‌فریم‌های این ارز
                    if 'timeframe_results' in coin and logger.isEnabledFor(logging.DEBUG):
                        for tf_result in coin['timeframe_results'][:3]:  # فقط ۳ تایم‌فریم اول
                            tf = tf_result.get('timeframe', 'unknown')
                            tf_processed = tf_result.get('processed_candles', 0)
                            tf_total = tf_result.get('total_candles', 0)
                            tf_rate = tf_result.get('success_rate', 0)
                            print(f"      📅 {tf}: {tf_processed}/{tf_total} ({tf_rate:.1f}%)")
                
                if len(report_data['coin_results']) > 5:
                    print(f"   ... و {len(report_data['coin_results']) - 5} ارز دیگر")
            
            print("\n" + "=" * 70)
            
        except Exception as e:
            logger.error(f"❌ خطا در چاپ گزارش کنسولی: {e}")
            print(f"❌ خطا در تولید گزارش: {e}")
    
    def generate_timeframe_comparison_report(self, block_ids: List[int], 
                                           reports_dir: Optional[str] = None) -> str:
        """
        تولید گزارش مقایسه‌ای تایم‌فریم‌ها بین بلوک‌های مختلف
        """
        try:
            if reports_dir is None:
                reports_dir = self.reports_dir
            
            # جمع‌آوری گزارش‌های بلوک‌ها
            block_reports = []
            for block_id in block_ids:
                # جستجوی آخرین گزارش برای این بلوک
                report_file = self._find_latest_block_report(block_id, reports_dir)
                if report_file:
                    try:
                        with open(report_file, 'r', encoding='utf-8') as f:
                            report_data = json.load(f)
                            block_reports.append({
                                'block_id': block_id,
                                'data': report_data,
                                'file': report_file
                            })
                    except Exception as e:
                        logger.error(f"خطا در خواندن گزارش بلوک {block_id}: {e}")
            
            if not block_reports:
                logger.warning("⚠️ هیچ گزارشی برای مقایسه پیدا نشد")
                return None
            
            # تولید گزارش مقایسه‌ای
            comparison_report = {
                'generated_at': datetime.now().isoformat(),
                'blocks_compared': [r['block_id'] for r in block_reports],
                'timeframe_comparison': {},
                'performance_trends': {},
                'timeframe_order': self.timeframe_order  # اضافه کردن لیست ترتیب
            }
            
            # تحلیل تایم‌فریم‌ها در هر بلوک
            timeframe_performance = {}
            
            for block_report in block_reports:
                block_id = block_report['block_id']
                report_data = block_report['data']
                
                # جمع‌آوری آمار تایم‌فریم‌ها برای این بلوک
                if self._has_timeframe_data(report_data):
                    for coin_result in report_data.get('coin_results', []):
                        if 'timeframe_results' in coin_result:
                            for tf_result in coin_result['timeframe_results']:
                                tf = tf_result.get('timeframe', 'unknown')
                                if tf not in timeframe_performance:
                                    timeframe_performance[tf] = []
                                
                                success_rate = tf_result.get('success_rate', 0)
                                timeframe_performance[tf].append({
                                    'block_id': block_id,
                                    'success_rate': success_rate,
                                    'processed_candles': tf_result.get('processed_candles', 0),
                                    'total_candles': tf_result.get('total_candles', 0)
                                })
            
            # محاسبه میانگین و روند
            for tf, performances in timeframe_performance.items():
                if performances:
                    success_rates = [p['success_rate'] for p in performances]
                    avg_success_rate = sum(success_rates) / len(success_rates)
                    
                    total_candles = sum(p['total_candles'] for p in performances)
                    total_processed = sum(p['processed_candles'] for p in performances)
                    
                    comparison_report['timeframe_comparison'][tf] = {
                        'average_success_rate': round(avg_success_rate, 2),
                        'total_candles_processed': total_processed,
                        'total_candles_available': total_candles,
                        'performance_range': {
                            'min': round(min(success_rates), 2),
                            'max': round(max(success_rates), 2),
                            'std_dev': round(np.std(success_rates), 2) if len(success_rates) > 1 else 0
                        },
                        'performance_trend': self._calculate_trend(success_rates)
                    }
            
            # مرتب‌سازی نتایج بر اساس ترتیب تایم‌فریم‌ها
            sorted_comparison = dict(sorted(
                comparison_report['timeframe_comparison'].items(),
                key=lambda x: self.timeframe_order.index(x[0]) if x[0] in self.timeframe_order else 99
            ))
            comparison_report['timeframe_comparison'] = sorted_comparison
            
            # ذخیره گزارش مقایسه‌ای
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            comparison_file = os.path.join(self.reports_dir, f"timeframe_comparison_{timestamp}.json")
            
            with open(comparison_file, 'w', encoding='utf-8') as f:
                json.dump(comparison_report, f, indent=2, ensure_ascii=False)
            
            logger.info(f"📊 گزارش مقایسه‌ای تایم‌فریم‌ها ذخیره شد: {comparison_file}")
            return comparison_file
            
        except Exception as e:
            logger.error(f"❌ خطا در تولید گزارش مقایسه‌ای تایم‌فریم‌ها: {e}")
            return None
    
    def _find_latest_block_report(self, block_id: int, reports_dir: str) -> Optional[str]:
        """یافتن آخرین گزارش برای یک بلوک"""
        try:
            if not os.path.exists(reports_dir):
                return None
            
            report_files = []
            for filename in os.listdir(reports_dir):
                if filename.startswith(f"block_{block_id:03d}_") and filename.endswith('.json'):
                    report_files.append(os.path.join(reports_dir, filename))
            
            if not report_files:
                return None
            
            # برگرداندن آخرین فایل بر اساس timestamp
            return max(report_files, key=os.path.getmtime)
            
        except Exception as e:
            logger.error(f"خطا در یافتن گزارش بلوک {block_id}: {e}")
            return None
    
    def _calculate_trend(self, values: List[float]) -> str:
        """محاسبه روند (صعودی، نزولی، ثابت)"""
        if len(values) < 2:
            return "نامشخص"
        
        try:
            # رگرسیون خطی ساده
            x = list(range(len(values)))
            y = values
            
            # محاسبه شیب
            n = len(x)
            sum_x = sum(x)
            sum_y = sum(y)
            sum_xy = sum(x[i] * y[i] for i in range(n))
            sum_x2 = sum(x[i] ** 2 for i in range(n))
            
            if n * sum_x2 - sum_x ** 2 == 0:
                return "ثابت"
            
            slope = (n * sum_xy - sum_x * sum_y) / (n * sum_x2 - sum_x ** 2)
            
            if slope > 0.1:
                return "صعودی"
            elif slope < -0.1:
                return "نزولی"
            else:
                return "ثابت"
                
        except:
            return "نامشخص"

# Singleton برای استفاده آسان
report_generator = ReportGenerator()