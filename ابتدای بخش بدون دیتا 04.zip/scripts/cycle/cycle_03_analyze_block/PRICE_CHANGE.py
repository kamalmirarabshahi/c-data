"""
اسکریپت بررسی نهایی و آنالیز نتایج PRICE_CHANGE (بدون گرافیک)
"""

import sqlite3
import pandas as pd
import numpy as np
from datetime import datetime
import os

def analyze_price_change_results(db_path: str):
    """آنالیز نهایی نتایج محاسبات PRICE_CHANGE"""
    
    print("\n" + "="*80)
    print("🔍 آنالیز نهایی نتایج PRICE_CHANGE (تغییر مطلق قیمت)")
    print("="*80)
    
    if not os.path.exists(db_path):
        print("❌ فایل دیتابیس یافت نشد!")
        return
    
    try:
        conn = sqlite3.connect(db_path)
        
        # 1. آمار کلی
        print("\n📊 آمار کلی جدول crypto_klines:")
        print("-"*40)
        
        df_stats = pd.read_sql_query("""
            SELECT 
                COUNT(*) as total_records,
                COUNT(CASE WHEN price_change IS NOT NULL THEN 1 END) as calculated,
                COUNT(CASE WHEN price_change IS NULL THEN 1 END) as not_calculated,
                AVG(price_change) as avg_change,
                MIN(price_change) as min_change,
                MAX(price_change) as max_change,
                STDDEV(price_change) as std_change,
                SUM(CASE WHEN price_change > 0 THEN 1 ELSE 0 END) as positive_changes,
                SUM(CASE WHEN price_change < 0 THEN 1 ELSE 0 END) as negative_changes,
                SUM(CASE WHEN price_change = 0 THEN 1 ELSE 0 END) as zero_changes
            FROM crypto_klines
        """, conn)
        
        print(f"✅ تعداد کل رکوردها: {df_stats['total_records'].iloc[0]:,}")
        print(f"✅ رکوردهای محاسبه شده: {df_stats['calculated'].iloc[0]:,}")
        print(f"✅ رکوردهای محاسبه نشده: {df_stats['not_calculated'].iloc[0]:,}")
        
        if df_stats['calculated'].iloc[0] > 0:
            percentage = (df_stats['calculated'].iloc[0] / df_stats['total_records'].iloc[0]) * 100
            print(f"✅ درصد پر شدن: {percentage:.1f}%")
        
        print(f"\n📈 آمار تغییرات:")
        print(f"  • میانگین تغییر: {df_stats['avg_change'].iloc[0]:.6f}")
        print(f"  • کمترین تغییر: {df_stats['min_change'].iloc[0]:.6f}")
        print(f"  • بیشترین تغییر: {df_stats['max_change'].iloc[0]:.6f}")
        print(f"  • انحراف معیار: {df_stats['std_change'].iloc[0]:.6f}")
        
        print(f"\n📊 توزیع جهت تغییرات:")
        total_calculated = df_stats['calculated'].iloc[0]
        if total_calculated > 0:
            positive_pct = (df_stats['positive_changes'].iloc[0] / total_calculated) * 100
            negative_pct = (df_stats['negative_changes'].iloc[0] / total_calculated) * 100
            zero_pct = (df_stats['zero_changes'].iloc[0] / total_calculated) * 100
            
            print(f"  • تغییرات مثبت: {df_stats['positive_changes'].iloc[0]:,} ({positive_pct:.1f}%)")
            print(f"  • تغییرات منفی: {df_stats['negative_changes'].iloc[0]:,} ({negative_pct:.1f}%)")
            print(f"  • بدون تغییر: {df_stats['zero_changes'].iloc[0]:,} ({zero_pct:.1f}%)")
        
        # 2. آمار تفکیکی بر اساس تایم‌فریم
        print("\n📈 آمار بر اساس تایم‌فریم:")
        print("-"*40)
        
        df_timeframe = pd.read_sql_query("""
            SELECT 
                timeframe,
                COUNT(*) as total,
                COUNT(CASE WHEN price_change IS NOT NULL THEN 1 END) as calculated,
                COUNT(CASE WHEN price_change IS NULL THEN 1 END) as not_calculated,
                AVG(price_change) as avg_change,
                MIN(price_change) as min_change,
                MAX(price_change) as max_change,
                STDDEV(price_change) as std_change,
                SUM(CASE WHEN price_change > 0 THEN 1 ELSE 0 END) as positive,
                SUM(CASE WHEN price_change < 0 THEN 1 ELSE 0 END) as negative
            FROM crypto_klines
            GROUP BY timeframe
            ORDER BY timeframe
        """, conn)
        
        print(df_timeframe.to_string(index=False))
        
        # 3. بررسی توزیع مقادیر
        print("\n📊 توزیع مقادیر price_change:")
        print("-"*40)
        
        df_distribution = pd.read_sql_query("""
            SELECT 
                CASE 
                    WHEN price_change IS NULL THEN 'NULL'
                    WHEN price_change = 0 THEN 'ZERO'
                    WHEN price_change > 0 AND price_change <= 0.1 THEN '0-0.1'
                    WHEN price_change > 0.1 AND price_change <= 1 THEN '0.1-1'
                    WHEN price_change > 1 AND price_change <= 10 THEN '1-10'
                    WHEN price_change > 10 AND price_change <= 100 THEN '10-100'
                    WHEN price_change > 100 THEN '>100'
                    WHEN price_change < 0 AND price_change >= -0.1 THEN '-0.1-0'
                    WHEN price_change < -0.1 AND price_change >= -1 THEN '-1--0.1'
                    WHEN price_change < -1 AND price_change >= -10 THEN '-10--1'
                    WHEN price_change < -10 THEN '<-10'
                END as change_range,
                COUNT(*) as count,
                ROUND(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM crypto_klines WHERE price_change IS NOT NULL), 2) as percentage
            FROM crypto_klines
            WHERE price_change IS NOT NULL
            GROUP BY change_range
            ORDER BY 
                CASE change_range
                    WHEN 'NULL' THEN 0
                    WHEN 'ZERO' THEN 1
                    WHEN '<-10' THEN 2
                    WHEN '-10--1' THEN 3
                    WHEN '-1--0.1' THEN 4
                    WHEN '-0.1-0' THEN 5
                    WHEN '0-0.1' THEN 6
                    WHEN '0.1-1' THEN 7
                    WHEN '1-10' THEN 8
                    WHEN '10-100' THEN 9
                    WHEN '>100' THEN 10
                END
        """, conn)
        
        print(df_distribution.to_string(index=False))
        
        # 4. بررسی ارزهای با بیشترین تغییرات
        print("\n🏆 10 ارز با بیشترین افزایش قیمت مطلق:")
        print("-"*40)
        
        df_top_increases = pd.read_sql_query("""
            SELECT 
                c.symbol,
                c.coin_name,
                k.timeframe,
                k.price_change,
                k.close_price,
                k.open_time
            FROM crypto_klines k
            JOIN crypto_coins c ON k.coin_id = c.id
            WHERE k.price_change IS NOT NULL
            ORDER BY k.price_change DESC
            LIMIT 10
        """, conn)
        
        print(df_top_increases[['symbol', 'coin_name', 'timeframe', 'price_change', 'open_time']].to_string(index=False))
        
        print("\n📉 10 ارز با بیشترین کاهش قیمت مطلق:")
        print("-"*40)
        
        df_top_decreases = pd.read_sql_query("""
            SELECT 
                c.symbol,
                c.coin_name,
                k.timeframe,
                k.price_change,
                k.close_price,
                k.open_time
            FROM crypto_klines k
            JOIN crypto_coins c ON k.coin_id = c.id
            WHERE k.price_change IS NOT NULL
            ORDER BY k.price_change ASC
            LIMIT 10
        """, conn)
        
        print(df_top_decreases[['symbol', 'coin_name', 'timeframe', 'price_change', 'open_time']].to_string(index=False))
        
        # 5. بررسی ارتباط بین price_change و price_change_percent
        print("\n🔗 بررسی ارتباط بین price_change و price_change_percent:")
        print("-"*40)
        
        df_correlation = pd.read_sql_query("""
            SELECT 
                CORR(price_change, price_change_percent) as correlation,
                AVG(price_change) as avg_abs_change,
                AVG(price_change_percent) as avg_percent_change,
                COUNT(*) as sample_size
            FROM crypto_klines
            WHERE price_change IS NOT NULL AND price_change_percent IS NOT NULL
        """, conn)
        
        print(f"  • ضریب همبستگی: {df_correlation['correlation'].iloc[0]:.4f}")
        print(f"  • میانگین تغییر مطلق: {df_correlation['avg_abs_change'].iloc[0]:.6f}")
        print(f"  • میانگین تغییر درصدی: {df_correlation['avg_percent_change'].iloc[0]:.4f}%")
        print(f"  • تعداد نمونه: {df_correlation['sample_size'].iloc[0]:,}")
        
        # 6. بررسی نمونه‌های خاص
        print("\n🔍 بررسی نمونه‌های خاص:")
        print("-"*40)
        
        # کندل‌های اول (باید صفر باشند)
        df_first_candles = pd.read_sql_query("""
            WITH ranked_candles AS (
                SELECT 
                    coin_id,
                    timeframe,
                    open_time,
                    price_change,
                    ROW_NUMBER() OVER (PARTITION BY coin_id, timeframe ORDER BY open_time ASC) as rn
                FROM crypto_klines
                WHERE price_change IS NOT NULL
            )
            SELECT 
                COUNT(*) as first_candles,
                SUM(CASE WHEN price_change = 0 THEN 1 ELSE 0 END) as zero_values,
                SUM(CASE WHEN price_change != 0 THEN 1 ELSE 0 END) as non_zero_values
            FROM ranked_candles
            WHERE rn = 1
        """, conn)
        
        print(f"کندل‌های اول هر ارز/تایم‌فریم:")
        print(f"  • تعداد کل: {df_first_candles['first_candles'].iloc[0]}")
        print(f"  • مقدار صفر: {df_first_candles['zero_values'].iloc[0]}")
        print(f"  • مقدار غیرصفر: {df_first_candles['non_zero_values'].iloc[0]}")
        
        if df_first_candles['non_zero_values'].iloc[0] > 0:
            print(f"  ⚠️  {df_first_candles['non_zero_values'].iloc[0]} کندل اول مقدار غیرصفر دارند!")
            
            # نمایش نمونه‌هایی که مشکل دارند
            df_problem_candles = pd.read_sql_query("""
                WITH ranked_candles AS (
                    SELECT 
                        k.coin_id,
                        c.symbol,
                        k.timeframe,
                        k.open_time,
                        k.close_price,
                        k.price_change,
                        ROW_NUMBER() OVER (PARTITION BY k.coin_id, k.timeframe ORDER BY k.open_time ASC) as rn
                    FROM crypto_klines k
                    JOIN crypto_coins c ON k.coin_id = c.id
                    WHERE k.price_change IS NOT NULL
                )
                SELECT 
                    symbol,
                    timeframe,
                    open_time,
                    close_price,
                    price_change
                FROM ranked_candles
                WHERE rn = 1 AND price_change != 0
                LIMIT 5
            """, conn)
            
            print(f"\n  نمونه‌های مشکل‌دار:")
            print(df_problem_candles.to_string(index=False))
        
        # 7. بررسی مقادیر غیرمنطقی
        print("\n⚠️  بررسی مقادیر غیرمنطقی:")
        print("-"*40)
        
        # تغییرات بسیار بزرگ
        df_extreme = pd.read_sql_query("""
            SELECT 
                COUNT(*) as extreme_count,
                AVG(price_change) as avg_extreme,
                MIN(price_change) as min_extreme,
                MAX(price_change) as max_extreme
            FROM crypto_klines
            WHERE price_change IS NOT NULL 
              AND ABS(price_change) > 10000
        """, conn)
        
        print(f"تغییرات مطلق بیشتر از 10,000: {df_extreme['extreme_count'].iloc[0]:,}")
        if df_extreme['extreme_count'].iloc[0] > 0:
            print(f"  • میانگین: {df_extreme['avg_extreme'].iloc[0]:.2f}")
            print(f"  • کمینه: {df_extreme['min_extreme'].iloc[0]:.2f}")
            print(f"  • بیشینه: {df_extreme['max_extreme'].iloc[0]:.2f}")
            
            df_extreme_samples = pd.read_sql_query("""
                SELECT 
                    c.symbol,
                    k.timeframe,
                    k.open_time,
                    k.close_price,
                    k.price_change
                FROM crypto_klines k
                JOIN crypto_coins c ON k.coin_id = c.id
                WHERE k.price_change IS NOT NULL 
                  AND ABS(k.price_change) > 10000
                LIMIT 5
            """, conn)
            
            print(f"\nنمونه‌های تغییرات شدید:")
            print(df_extreme_samples.to_string(index=False))
        
        # 8. خلاصه نهایی
        print("\n" + "="*80)
        print("✅ خلاصه نهایی آنالیز PRICE_CHANGE")
        print("="*80)
        
        total_records = df_stats['total_records'].iloc[0]
        calculated = df_stats['calculated'].iloc[0]
        completion_rate = (calculated / total_records) * 100
        
        print(f"\n📊 وضعیت کامل بودن:")
        print(f"  • تکمیل شده: {completion_rate:.1f}%")
        
        if calculated > 0:
            avg_change = df_stats['avg_change'].iloc[0]
            print(f"\n📈 میانگین تغییر مطلق قیمت: {avg_change:.6f}")
            
            if 'positive_changes' in df_stats.columns:
                positive_ratio = (df_stats['positive_changes'].iloc[0] / calculated) * 100
                print(f"📊 نسبت تغییرات مثبت: {positive_ratio:.1f}%")
        
        print(f"\n✅ آنالیز کامل شد!")
        print("="*80)
        
        conn.close()
        
    except Exception as e:
        print(f"❌ خطا در آنالیز نتایج: {e}")


def main():
    """تابع اصلی"""
    db_path = r"C:\Users\Kamal\Desktop\py-prg\git\c-data\data\crypto_master.db"
    
    print("\n" + "="*80)
    print("🔍 آنالیز نتایج PRICE_CHANGE")
    print("="*80)
    
    if not os.path.exists(db_path):
        print(f"❌ فایل دیتابیس یافت نشد: {db_path}")
        return
    
    analyze_price_change_results(db_path)


if __name__ == "__main__":
    main()