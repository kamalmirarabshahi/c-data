"""
✅ ماژول اعتبارسنجی اندیکاتورها و داده‌ها - نسخه کامل
اعتبارسنجی برای تمام ۴۹ فیلد جدول crypto_klines
"""

import logging
from typing import Dict, Any, List, Optional, Tuple
import math
import sys
import os

# FIX: اضافه کردن مسیر scripts به sys.path
current_file_dir = os.path.dirname(os.path.abspath(__file__))
scripts_dir = os.path.dirname(os.path.dirname(current_file_dir))  # دو سطح بالا!

if scripts_dir not in sys.path:
    sys.path.insert(0, scripts_dir)

# حالا importهای دیگه
from config_manager import get_database_path, get, get_timeframes

logger = logging.getLogger(__name__)

class Validator:
    """اعتبارسنج کامل داده‌ها و اندیکاتورها"""
    
    def __init__(self):
        self.logger = logger
        self.logger.info("✅ Validator (نسخه کامل) ایجاد شد")
        
        # ✅ دریافت محدوده‌ها از config_manager
        try:
            from config_manager import get
            
            # دریافت محدوده‌ها از کانفیگ
            self.indicator_ranges = {
                'rsi': (0, 100, "RSI باید بین ۰ تا ۱۰۰ باشد"),
                'macd': (get('validation.macd_min', -10), get('validation.macd_max', 10), 
                        "MACD معمولاً بین -۱۰ تا ۱۰ است"),
                'macd_signal': (get('validation.macd_signal_min', -10), get('validation.macd_signal_max', 10), 
                               "سیگنال MACD معمولاً بین -۱۰ تا ۱۰ است"),
                'macd_histogram': (get('validation.macd_histogram_min', -5), get('validation.macd_histogram_max', 5), 
                                  "هیستوگرام MACD معمولاً بین -۵ تا ۵ است"),
                'atr': (0, get('validation.atr_max', 1000), "ATR باید مثبت باشد"),
                'volatility': (0, get('validation.volatility_max', 10), "نوسان باید بین ۰ تا ۱۰ باشد"),
                'volume_ratio': (0, get('validation.volume_ratio_max', 100), "نسبت حجم باید مثبت باشد"),
                'price_change_percent': (get('validation.price_change_min', -100), 
                                        get('validation.price_change_max', 1000), 
                                        "درصد تغییر قیمت غیرمنطقی"),
                'ma_7': (0, get('validation.ma_max', 1000000), "MA7 مقدار غیرمنطقی"),
                'ma_25': (0, get('validation.ma_max', 1000000), "MA25 مقدار غیرمنطقی"),
                'ma_99': (0, get('validation.ma_max', 1000000), "MA99 مقدار غیرمنطقی"),
                'bollinger_upper': (0, get('validation.bollinger_max', 1000000), "باند بالایی مقدار غیرمنطقی"),
                'bollinger_middle': (0, get('validation.bollinger_max', 1000000), "باند میانی مقدار غیرمنطقی"),
                'bollinger_lower': (0, get('validation.bollinger_max', 1000000), "باند پایینی مقدار غیرمنطقی"),
                'volume_ma_20': (0, get('validation.volume_ma_max', 1e12), "میانگین حجم مقدار غیرمنطقی"),
                'obv': (get('validation.obv_min', -1e15), get('validation.obv_max', 1e15), "OBV مقدار غیرمنطقی"),
                'data_quality': (0, 100, "کیفیت داده باید بین ۰ تا ۱۰۰ باشد"),
                'pattern_confidence': (0, 100, "اعتماد الگو باید بین ۰ تا ۱۰۰ باشد"),
                'trend_strength': (0, 100, "قدرت روند باید بین ۰ تا ۱۰۰ باشد"),
                'support_resistance_level': (0, get('validation.support_resistance_max', 1000000), 
                                           "سطح حمایت/مقاومت غیرمنطقی")
            }
            
            logger.info("✅ محدوده‌های اعتبارسنجی از کانفیگ بارگذاری شد")
            
        except ImportError:
            logger.warning("⚠️ config_manager import نشد - استفاده از مقادیر پیش‌فرض")
            # مقادیر پیش‌فرض
            self.indicator_ranges = {
                'rsi': (0, 100, "RSI باید بین ۰ تا ۱۰۰ باشد"),
                'macd': (-10, 10, "MACD معمولاً بین -۱۰ تا ۱۰ است"),
                'macd_signal': (-10, 10, "سیگنال MACD معمولاً بین -۱۰ تا ۱۰ است"),
                'macd_histogram': (-5, 5, "هیستوگرام MACD معمولاً بین -۵ تا ۵ است"),
                'atr': (0, 1000, "ATR باید مثبت باشد"),
                'volatility': (0, 10, "نوسان باید بین ۰ تا ۱۰ باشد"),
                'volume_ratio': (0, 100, "نسبت حجم باید مثبت باشد"),
                'price_change_percent': (-100, 1000, "درصد تغییر قیمت غیرمنطقی"),
                'ma_7': (0, 1000000, "MA7 مقدار غیرمنطقی"),
                'ma_25': (0, 1000000, "MA25 مقدار غیرمنطقی"),
                'ma_99': (0, 1000000, "MA99 مقدار غیرمنطقی"),
                'bollinger_upper': (0, 1000000, "باند بالایی مقدار غیرمنطقی"),
                'bollinger_middle': (0, 1000000, "باند میانی مقدار غیرمنطقی"),
                'bollinger_lower': (0, 1000000, "باند پایینی مقدار غیرمنطقی"),
                'volume_ma_20': (0, 1e12, "میانگین حجم مقدار غیرمنطقی"),
                'obv': (-1e15, 1e15, "OBV مقدار غیرمنطقی"),
                'data_quality': (0, 100, "کیفیت داده باید بین ۰ تا ۱۰۰ باشد"),
                'pattern_confidence': (0, 100, "اعتماد الگو باید بین ۰ تا ۱۰۰ باشد"),
                'trend_strength': (0, 100, "قدرت روند باید بین ۰ تا ۱۰۰ باشد"),
                'support_resistance_level': (0, 1000000, "سطح حمایت/مقاومت غیرمنطقی")
            }
        
        # روابط منطقی بین فیلدها
        self.logical_checks = [
            # باندهای بولینگر
            ('bollinger_upper', 'bollinger_lower', 
             lambda u, l: u > l, "باند بالایی باید از باند پایینی بزرگتر باشد"),
            
            # میانگین‌های متحرک
            ('ma_7', 'ma_25', 
             lambda m7, m25: abs(m7 - m25) < m25 * 10, "تفاوت MAها غیرمنطقی است"),
            
            # قیمت‌ها
            ('high_price', 'low_price',
             lambda h, l: h >= l, "قیمت بالا باید از قیمت پایین بیشتر باشد"),
            
            ('close_price', 'open_price',
             lambda c, o: abs(c - o) < o * 5, "تفاوت قیمت باز و بسته غیرمنطقی"),
        ]
    
    def validate_indicators(self, indicators: Dict[str, Any]) -> List[str]:
        """
        اعتبارسنجی کامل مقادیر اندیکاتورها
        برای تمام ۴۹ فیلد
        
        Returns:
            List[str]: لیست خطاهای یافت شده
        """
        errors = []
        
        try:
            # ۱. اعتبارسنجی محدوده مقادیر
            for field_name, (min_val, max_val, error_msg) in self.indicator_ranges.items():
                if field_name in indicators:
                    value = indicators[field_name]
                    
                    if value is None:
                        continue  # مقادیر None ایراد نیست
                    
                    try:
                        num_value = float(value)
                        
                        # بررسی محدوده
                        if not (min_val <= num_value <= max_val):
                            errors.append(f"{field_name}: {error_msg} (مقدار: {num_value:.4f})")
                    
                    except (ValueError, TypeError):
                        # اگر مقدار عددی نیست اما None هم نیست
                        if value is not None:
                            errors.append(f"{field_name}: مقدار غیرعددی ({type(value).__name__})")
            
            # ۲. بررسی روابط منطقی
            for field1, field2, check_func, error_msg in self.logical_checks:
                if field1 in indicators and field2 in indicators:
                    val1 = indicators[field1]
                    val2 = indicators[field2]
                    
                    if val1 is not None and val2 is not None:
                        try:
                            if not check_func(float(val1), float(val2)):
                                errors.append(f"{field1}/{field2}: {error_msg}")
                        except (ValueError, TypeError):
                            pass  # اگر مقادیر عددی نباشند، از این چک عبور می‌کنیم
            
            # ۳. اعتبارسنجی فیلدهای Pattern
            pattern_errors = self._validate_pattern_fields(indicators)
            errors.extend(pattern_errors)
            
            # ۴. اعتبارسنجی فیلدهای حجم
            volume_errors = self._validate_volume_fields(indicators)
            errors.extend(volume_errors)
            
            # ۵. اعتبارسنجی فیلدهای بولین
            boolean_errors = self._validate_boolean_fields(indicators)
            errors.extend(boolean_errors)
            
            # ۶. اعتبارسنجی کیفیت داده
            quality_errors = self._validate_data_quality(indicators)
            errors.extend(quality_errors)
            
            # ۷. اعتبارسنجی تایم‌فریم‌ها
            timeframe_errors = self._validate_timeframe_fields(indicators)
            errors.extend(timeframe_errors)
            
        except Exception as e:
            errors.append(f"خطا در فرآیند اعتبارسنجی: {str(e)}")
        
        # ثبت لاگ
        if errors:
            self.logger.warning(f"اعتبارسنجی {len(errors)} خطا یافت")
            # فقط ۵ خطای اول را لاگ کنید
            for error in errors[:5]:
                self.logger.debug(f"  - {error}")
            if len(errors) > 5:
                self.logger.debug(f"  ... و {len(errors) - 5} خطای دیگر")
        else:
            self.logger.debug("اعتبارسنجی بدون خطا")
        
        return errors
    
    def _validate_pattern_fields(self, indicators: Dict[str, Any]) -> List[str]:
        """اعتبارسنجی فیلدهای Pattern"""
        errors = []
        
        # pattern_confidence
        if 'pattern_confidence' in indicators:
            conf = indicators['pattern_confidence']
            if conf is not None:
                try:
                    conf_val = float(conf)
                    if not (0 <= conf_val <= 100):
                        errors.append(f"pattern_confidence: باید بین ۰ تا ۱۰۰ باشد (مقدار: {conf_val})")
                except (ValueError, TypeError):
                    errors.append(f"pattern_confidence: مقدار غیرعددی ({conf})")
        
        # trend_strength
        if 'trend_strength' in indicators:
            strength = indicators['trend_strength']
            if strength is not None:
                try:
                    strength_val = float(strength)
                    if not (0 <= strength_val <= 100):
                        errors.append(f"trend_strength: باید بین ۰ تا ۱۰۰ باشد (مقدار: {strength_val})")
                except (ValueError, TypeError):
                    errors.append(f"trend_strength: مقدار غیرعددی ({strength})")
        
        # support_resistance_level
        if 'support_resistance_level' in indicators:
            level = indicators['support_resistance_level']
            if level is not None:
                try:
                    level_val = float(level)
                    if level_val < 0:
                        errors.append(f"support_resistance_level: مقدار منفی ({level_val})")
                    # حداکثر مقدار از کانفیگ
                    max_val = self.indicator_ranges.get('support_resistance_level', (0, 1000000, ''))[1]
                    if level_val > max_val:
                        errors.append(f"support_resistance_level: مقدار خیلی بزرگ ({level_val})")
                except (ValueError, TypeError):
                    errors.append(f"support_resistance_level: مقدار غیرعددی ({level})")
        
        # pattern_markers
        if 'pattern_markers' in indicators:
            markers = indicators['pattern_markers']
            if markers is not None and not isinstance(markers, str):
                errors.append(f"pattern_markers: باید رشته باشد ({type(markers).__name__})")
        
        return errors
    
    def _validate_volume_fields(self, indicators: Dict[str, Any]) -> List[str]:
        """اعتبارسنجی فیلدهای حجم"""
        errors = []
        
        volume_fields = [
            'volume',
            'quote_volume',
            'taker_buy_volume',
            'taker_sell_volume',
            'taker_buy_quote_volume'
        ]
        
        for field in volume_fields:
            if field in indicators:
                value = indicators[field]
                if value is not None:
                    try:
                        vol = float(value)
                        if vol < 0:
                            errors.append(f"{field}: حجم منفی ({vol})")
                        # حداکثر حجم از کانفیگ
                        if field == 'volume_ma_20':
                            max_val = self.indicator_ranges.get('volume_ma_20', (0, 1e12, ''))[1]
                        else:
                            max_val = 1e12  # پیش‌فرض
                        if vol > max_val:
                            errors.append(f"{field}: حجم خیلی بزرگ ({vol})")
                    except (ValueError, TypeError):
                        errors.append(f"{field}: مقدار غیرعددی ({value})")
        
        # بررسی consistency بین حجم‌ها
        if ('taker_buy_volume' in indicators and 'taker_sell_volume' in indicators and
            'volume' in indicators):
            buy = indicators['taker_buy_volume']
            sell = indicators['taker_sell_volume']
            total = indicators['volume']
            
            if buy is not None and sell is not None and total is not None:
                try:
                    buy_val = float(buy)
                    sell_val = float(sell)
                    total_val = float(total)
                    
                    # حجم خرید + فروش باید حدوداً برابر با حجم کل باشد
                    sum_buy_sell = buy_val + sell_val
                    if total_val > 0:
                        ratio = sum_buy_sell / total_val
                        if not (0.5 <= ratio <= 2.0):  # تلرانس ۵۰٪ تا ۲۰۰٪
                            errors.append(f"حجم‌ها ناسازگار: خرید+فروش={sum_buy_sell:.2f}, کل={total_val:.2f}")
                except (ValueError, TypeError):
                    pass
        
        return errors
    
    def _validate_boolean_fields(self, indicators: Dict[str, Any]) -> List[str]:
        """اعتبارسنجی فیلدهای بولین"""
        errors = []
        
        boolean_fields = [
            'is_doji',
            'is_hammer',
            'is_shooting_star',
            'is_interpolated',
            'is_verified'
        ]
        
        for field in boolean_fields:
            if field in indicators:
                value = indicators[field]
                if value is not None:
                    if not isinstance(value, bool) and value not in (0, 1):
                        errors.append(f"{field}: باید بولین باشد ({value})")
        
        return errors
    
    def _validate_data_quality(self, indicators: Dict[str, Any]) -> List[str]:
        """اعتبارسنجی فیلدهای کیفیت داده"""
        errors = []
        
        # data_quality
        if 'data_quality' in indicators:
            quality = indicators['data_quality']
            if quality is not None:
                try:
                    qual = int(quality)
                    if not (0 <= qual <= 100):
                        errors.append(f"data_quality: باید بین ۰ تا ۱۰۰ باشد ({qual})")
                except (ValueError, TypeError):
                    errors.append(f"data_quality: مقدار غیرعددی ({quality})")
        
        # missing_data_points
        if 'missing_data_points' in indicators:
            missing = indicators['missing_data_points']
            if missing is not None:
                try:
                    miss = int(missing)
                    if miss < 0:
                        errors.append(f"missing_data_points: مقدار منفی ({miss})")
                except (ValueError, TypeError):
                    errors.append(f"missing_data_points: مقدار غیرعددی ({missing})")
        
        # consistency بین data_quality و missing_data_points
        if ('data_quality' in indicators and 'missing_data_points' in indicators):
            quality = indicators['data_quality']
            missing = indicators['missing_data_points']
            
            if quality is not None and missing is not None:
                try:
                    qual = int(quality)
                    miss = int(missing)
                    
                    # اگر missing_data_points > 0، quality باید < 100 باشد
                    if miss > 0 and qual >= 100:
                        errors.append(f"کیفیت داده ناسازگار: missing={miss} ولی quality={qual}")
                    
                    # اگر quality = 100، missing باید = 0 باشد
                    if qual == 100 and miss > 0:
                        errors.append(f"کیفیت داده ناسازگار: quality=100 ولی missing={miss}")
                except (ValueError, TypeError):
                    pass
        
        return errors
    
    def _validate_timeframe_fields(self, indicators: Dict[str, Any]) -> List[str]:
        """اعتبارسنجی فیلدهای زمانی"""
        errors = []
        
        # timeframe
        if 'timeframe' in indicators:
            tf = indicators['timeframe']
            if tf is not None:
                # ✅ دریافت تایم‌فریم‌های معتبر از کانفیگ
                try:
                    from config_manager import get
                    valid_timeframes = get('analysis.valid_timeframes', 
                                          ['1m', '5m', '15m', '30m', '1h', '4h', '1d', '1w'])
                except ImportError:
                    valid_timeframes = ['1m', '5m', '15m', '30m', '1h', '4h', '1d', '1w']
                
                if tf not in valid_timeframes:
                    errors.append(f"timeframe: مقدار نامعتبر ({tf}) - معتبر: {valid_timeframes}")
        
        # aggregation_level
        if 'aggregation_level' in indicators:
            level = indicators['aggregation_level']
            if level is not None:
                try:
                    lev = int(level)
                    if not (1 <= lev <= 3):
                        errors.append(f"aggregation_level: باید ۱، ۲ یا ۳ باشد ({lev})")
                except (ValueError, TypeError):
                    errors.append(f"aggregation_level: مقدار غیرعددی ({level})")
        
        return errors
    
    def calculate_data_quality(self, indicators: Dict[str, Any], 
                             required_fields: Optional[List[str]] = None) -> float:
        """
        محاسبه کیفیت داده
        
        Args:
            indicators: دیکشنری اندیکاتورها
            required_fields: لیست فیلدهای ضروری (اگر None باشد از لیست پیش‌فرض استفاده می‌شود)
            
        Returns:
            float: کیفیت داده (۰ تا ۱۰۰)
        """
        try:
            if required_fields is None:
                # فیلدهای ضروری برای کیفیت داده
                required_fields = [
                    'close_price',
                    'volume',
                    'rsi',
                    'macd',
                    'ma_7',
                    'ma_25',
                    'bollinger_middle'
                ]
            
            total = len(required_fields)
            if total == 0:
                return 100.0
            
            # شمارش فیلدهای پر شده
            filled = 0
            for field in required_fields:
                if field in indicators and indicators[field] is not None:
                    # اعتبارسنجی اضافی برای مقادیر
                    value = indicators[field]
                    
                    # بررسی مقادیر نامعقول
                    if isinstance(value, (int, float)):
                        # بررسی NaN یا infinity
                        if math.isnan(value) or math.isinf(value):
                            continue
                        
                        # بررسی محدوده برای فیلدهای خاص
                        if field == 'rsi' and not (0 <= value <= 100):
                            continue
                        elif field == 'volume' and value < 0:
                            continue
                    
                    filled += 1
            
            # کیفیت پایه
            base_quality = (filled / total) * 100
            
            # کیفیت اضافی بر اساس اعتبارسنجی
            validation_errors = self.validate_indicators(indicators)
            error_penalty = min(len(validation_errors) * 5, 50)  # حداکثر ۵۰٪ جریمه
            
            final_quality = max(0, base_quality - error_penalty)
            
            # رند کردن به ۲ رقم اعشار
            return round(final_quality, 2)
            
        except Exception as e:
            self.logger.error(f"خطا در محاسبه کیفیت داده: {e}")
            return 0.0
    
    def validate_candle_consistency(self, candle_data: Dict[str, Any]) -> List[str]:
        """
        اعتبارسنجی consistency داده‌های یک کندل
        
        Args:
            candle_data: داده‌های کامل یک کندل (همه فیلدها)
            
        Returns:
            List[str]: خطاهای consistency
        """
        errors = []
        
        try:
            # ۱. بررسی OHLC consistency
            if all(field in candle_data for field in ['open_price', 'high_price', 'low_price', 'close_price']):
                open_price = candle_data.get('open_price')
                high_price = candle_data.get('high_price')
                low_price = candle_data.get('low_price')
                close_price = candle_data.get('close_price')
                
                if all(v is not None for v in [open_price, high_price, low_price, close_price]):
                    # High باید بزرگترین باشد
                    if high_price < max(open_price, close_price):
                        errors.append(f"high_price ({high_price}) باید ≥ max(open={open_price}, close={close_price})")
                    
                    # Low باید کوچکترین باشد
                    if low_price > min(open_price, close_price):
                        errors.append(f"low_price ({low_price}) باید ≤ min(open={open_price}, close={close_price})")
                    
                    # High باید ≥ Low
                    if high_price < low_price:
                        errors.append(f"high_price ({high_price}) < low_price ({low_price})")
            
            # ۲. بررسی consistency قیمت و میانگین‌ها
            if 'close_price' in candle_data and 'ma_7' in candle_data:
                close = candle_data.get('close_price')
                ma7 = candle_data.get('ma_7')
                
                if close is not None and ma7 is not None:
                    # قیمت بسته شدن نباید خیلی از میانگین دور باشد (مثلاً بیشتر از ۵۰٪)
                    if ma7 > 0:
                        diff_percent = abs(close - ma7) / ma7 * 100
                        if diff_percent > 50:
                            errors.append(f"اختلاف زیاد قیمت و MA7: {diff_percent:.1f}% (price={close}, ma7={ma7})")
            
            # ۳. بررسی consistency حجم‌ها
            if 'volume' in candle_data and 'quote_volume' in candle_data:
                volume = candle_data.get('volume')
                quote_volume = candle_data.get('quote_volume')
                
                if volume is not None and quote_volume is not None and volume > 0:
                    # قیمت میانگین تقریبی
                    avg_price = quote_volume / volume
                    
                    if 'close_price' in candle_data:
                        close = candle_data.get('close_price')
                        if close is not None and close > 0:
                            # قیمت میانگین نباید خیلی از قیمت بسته شدن دور باشد
                            price_diff_percent = abs(avg_price - close) / close * 100
                            if price_diff_percent > 20:  # بیش از ۲۰٪ اختلاف
                                errors.append(f"اختلاف قیمت حجم نقل‌قول: {price_diff_percent:.1f}%")
            
            # ۴. بررسی consistency فیلدهای Pattern
            if ('pattern_confidence' in candle_data and 
                'trend_strength' in candle_data):
                conf = candle_data.get('pattern_confidence')
                strength = candle_data.get('trend_strength')
                
                if conf is not None and strength is not None:
                    # اگر اعتماد الگو بالاست، قدرت روند نباید خیلی پایین باشد
                    if conf > 70 and strength < 30:
                        errors.append(f"اعتماد الگو بالا ({conf}) ولی قدرت روند پایین ({strength})")
            
        except Exception as e:
            errors.append(f"خطا در بررسی consistency: {e}")
        
        return errors
    
    def get_validation_summary(self, indicators: Dict[str, Any]) -> Dict[str, Any]:
        """
        دریافت خلاصه اعتبارسنجی
        
        Returns:
            Dict: خلاصه وضعیت اعتبارسنجی
        """
        try:
            errors = self.validate_indicators(indicators)
            quality = self.calculate_data_quality(indicators)
            
            # دسته‌بندی خطاها
            error_categories = {
                'range_errors': [],
                'logical_errors': [],
                'pattern_errors': [],
                'volume_errors': [],
                'quality_errors': [],
                'other_errors': []
            }
            
            for error in errors:
                if 'باید بین' in error or 'مقدار غیرمنطقی' in error:
                    error_categories['range_errors'].append(error)
                elif 'باید از' in error or 'تفاوت' in error:
                    error_categories['logical_errors'].append(error)
                elif 'pattern_' in error or 'الگو' in error:
                    error_categories['pattern_errors'].append(error)
                elif 'volume' in error or 'حجم' in error:
                    error_categories['volume_errors'].append(error)
                elif 'quality' in error or 'کیفیت' in error:
                    error_categories['quality_errors'].append(error)
                else:
                    error_categories['other_errors'].append(error)
            
            # شمارش فیلدهای پر شده
            total_fields = len(indicators)
            filled_fields = sum(1 for v in indicators.values() if v is not None)
            
            percentage = (filled_fields / total_fields * 100) if total_fields > 0 else 0
            
            summary = {
                'total_errors': len(errors),
                'data_quality': quality,
                'error_categories': {
                    cat: len(errors) for cat, errors in error_categories.items()
                },
                'fields_info': {
                    'total': total_fields,
                    'filled': filled_fields,
                    'percentage': percentage
                },
                'has_errors': len(errors) > 0,
                'is_valid': len(errors) == 0,
                'validation_level': 'HIGH' if quality > 80 else 'MEDIUM' if quality > 50 else 'LOW'
            }
            
            return summary
            
        except Exception as e:
            self.logger.error(f"خطا در تولید خلاصه اعتبارسنجی: {e}")
            return {
                'total_errors': 1,
                'data_quality': 0,
                'has_errors': True,
                'is_valid': False,
                'error': str(e)
            }

# Singleton instance
validator = Validator()