"""
اسکریپت محاسبه و ذخیره PRICE_CHANGE (تغییر قیمت) برای جدول crypto_klines
"""

import sqlite3
import numpy as np
import pandas as pd
from typing import List, Dict, Any, Optional
import logging
import os
import sys
from datetime import datetime
import math
import time

# تنظیمات لاگ‌گیری
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('price_change_calculator.log', encoding='utf-8'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class PriceChangeCalculator:
    """کلاس محاسبه و ذخیره تغییر قیمت برای جدول crypto_klines"""
    
    def __init__(self, db_path: str):
        """
        مقداردهی اولیه
        
        Args:
            db_path: مسیر فایل دیتابیس
        """
        self.db_path = db_path
        self.connection = None
        
        # بررسی وجود دیتابیس
        if not os.path.exists(db_path):
            logger.error(f"❌ فایل دیتابیس یافت نشد: {db_path}")
            raise FileNotFoundError(f"دیتابیس یافت نشد: {db_path}")
        
        logger.info(f"✅ دیتابیس شناسایی شد: {db_path}")
        
        # راه‌اندازی اتصال
        self._setup_connection()
    
    def _setup_connection(self):
        """راه‌اندازی اتصال به دیتابیس"""
        try:
            self.connection = sqlite3.connect(self.db_path)
            self.connection.row_factory = sqlite3.Row
            logger.info("✅ اتصال به دیتابیس برقرار شد")
        except Exception as e:
            logger.error(f"❌ خطا در اتصال به دیتابیس: {e}")
            raise
    
    def get_table_stats(self) -> Dict[str, Any]:
        """دریافت آمار جدول crypto_klines برای PRICE_CHANGE"""
        try:
            cursor = self.connection.cursor()
            
            # تعداد کل رکوردها
            cursor.execute("SELECT COUNT(*) as count FROM crypto_klines")
            total_records = cursor.fetchone()['count']
            
            # رکوردهای دارای PRICE_CHANGE
            cursor.execute("SELECT COUNT(*) as count FROM crypto_klines WHERE price_change IS NOT NULL")
            calculated_records = cursor.fetchone()['count']
            
            # آمار PRICE_CHANGE
            cursor.execute("""
                SELECT 
                    AVG(price_change) as avg_change,
                    MIN(price_change) as min_change,
                    MAX(price_change) as max_change,
                    AVG(price_change_percent) as avg_change_percent,
                    MIN(price_change_percent) as min_change_percent,
                    MAX(price_change_percent) as max_change_percent,
                    COUNT(CASE WHEN price_change > 0 THEN 1 END) as positive_changes,
                    COUNT(CASE WHEN price_change < 0 THEN 1 END) as negative_changes,
                    COUNT(CASE WHEN price_change = 0 THEN 1 END) as zero_changes
                FROM crypto_klines 
                WHERE price_change IS NOT NULL
            """)
            change_stats = cursor.fetchone()
            
            return {
                'total_records': total_records,
                'calculated_records': calculated_records,
                'remaining_records': total_records - calculated_records,
                'change_stats': dict(change_stats) if change_stats else {}
            }
            
        except Exception as e:
            logger.error(f"❌ خطا در دریافت آمار جدول: {e}")
            return {}
    
    def print_table_summary(self):
        """چاپ خلاصه جدول"""
        stats = self.get_table_stats()
        
        print("\n" + "="*80)
        print("📊 خلاصه جدول crypto_klines - PRICE_CHANGE (تغییر قیمت)")
        print("="*80)
        
        if not stats:
            print("❌ خطا در دریافت آمار")
            return
        
        print(f"\n📈 آمار کلی:")
        print(f"  • تعداد کل رکوردها: {stats['total_records']:,}")
        print(f"  • PRICE_CHANGE محاسبه شده: {stats['calculated_records']:,}")
        print(f"  • رکوردهای باقی‌مانده: {stats['remaining_records']:,}")
        
        if stats['calculated_records'] > 0:
            percentage = (stats['calculated_records'] / stats['total_records']) * 100
            print(f"  • درصد پر شدن: {percentage:.1f}%")
            
            # آمار اضافی PRICE_CHANGE
            change_stats = stats.get('change_stats', {})
            if change_stats.get('avg_change') is not None:
                print(f"\n📊 آمار تغییر قیمت:")
                print(f"  • میانگین تغییر قیمت: {change_stats['avg_change']:.6f}")
                print(f"  • کمترین تغییر قیمت: {change_stats['min_change']:.6f}")
                print(f"  • بیشترین تغییر قیمت: {change_stats['max_change']:.6f}")
                
                if change_stats.get('avg_change_percent'):
                    print(f"\n📊 آمار تغییر درصدی:")
                    print(f"  • میانگین تغییر درصدی: {change_stats['avg_change_percent']:.4f}%")
                    print(f"  • کمترین تغییر درصدی: {change_stats['min_change_percent']:.4f}%")
                    print(f"  • بیشترین تغییر درصدی: {change_stats['max_change_percent']:.4f}%")
                
                print(f"\n📈 توزیع تغییرات قیمت:")
                print(f"  • تغییرات مثبت: {change_stats['positive_changes']:,} رکورد")
                print(f"  • تغییرات منفی: {change_stats['negative_changes']:,} رکورد")
                print(f"  • تغییرات صفر: {change_stats['zero_changes']:,} رکورد")
                
                total_calculated = stats['calculated_records']
                pos_pct = (change_stats['positive_changes'] / total_calculated * 100) if total_calculated > 0 else 0
                neg_pct = (change_stats['negative_changes'] / total_calculated * 100) if total_calculated > 0 else 0
                zero_pct = (change_stats['zero_changes'] / total_calculated * 100) if total_calculated > 0 else 0
                
                print(f"\n📊 درصد توزیع:")
                print(f"  • مثبت: {pos_pct:.1f}%")
                print(f"  • منفی: {neg_pct:.1f}%")
                print(f"  • صفر: {zero_pct:.1f}%")
        
        print(f"\n⚙️  تنظیمات محاسبه:")
        print(f"  • فرمول PRICE_CHANGE:")
        print(f"    ◦ PRICE_CHANGE = قیمت بسته شدن فعلی - قیمت بسته شدن قبلی")
        print(f"    ◦ PRICE_CHANGE_PERCENT = ((قیمت فعلی - قیمت قبلی) / قیمت قبلی) × 100")
        print(f"  • برای اولین کندل هر دنباله، PRICE_CHANGE = 0")
        
        print("="*80)
    
    def calculate_price_change(self, current_close: float, previous_close: float) -> tuple:
        """
        محاسبه تغییر قیمت و تغییر درصدی
        
        Args:
            current_close: قیمت بسته شدن فعلی
            previous_close: قیمت بسته شدن قبلی
            
        Returns:
            tuple: (price_change, price_change_percent)
        """
        try:
            # تغییر قیمت مطلق
            price_change = current_close - previous_close
            
            # تغییر قیمت درصدی
            if previous_close != 0:
                price_change_percent = ((current_close - previous_close) / previous_close) * 100
            else:
                price_change_percent = 0.0
            
            return float(price_change), float(price_change_percent)
            
        except Exception as e:
            logger.warning(f"خطا در محاسبه تغییر قیمت: {e}")
            return 0.0, 0.0
    
    def calculate_price_changes_for_sequence(self, close_prices: List[float]) -> List[tuple]:
        """
        محاسبه تغییرات قیمت برای یک دنباله از داده‌ها
        
        Args:
            close_prices: لیست قیمت‌های بسته شدن
            
        Returns:
            لیست tuples: [(price_change, price_change_percent), ...]
        """
        changes = []
        
        try:
            if len(close_prices) == 0:
                return changes
            
            # اولین کندل: تغییر صفر
            changes.append((0.0, 0.0))
            
            # محاسبه تغییرات برای کندل‌های بعدی
            for i in range(1, len(close_prices)):
                current_close = close_prices[i] if close_prices[i] is not None else 0
                previous_close = close_prices[i-1] if close_prices[i-1] is not None else 0
                
                change, change_percent = self.calculate_price_change(current_close, previous_close)
                changes.append((change, change_percent))
            
            return changes
            
        except Exception as e:
            logger.error(f"خطا در محاسبه تغییرات قیمت: {e}")
            return []
    
    def process_coin_timeframe_bulk(self, coin_id: int, timeframe: str, 
                                   batch_size: int = 500) -> Dict[str, Any]:
        """
        پردازش کندل‌های یک ارز در یک تایم‌فریم خاص به صورت گروهی
        
        Args:
            coin_id: شناسه ارز
            timeframe: تایم‌فریم
            batch_size: اندازه بچ
            
        Returns:
            آمار پردازش
        """
        stats = {
            'coin_id': coin_id,
            'timeframe': timeframe,
            'total_records': 0,
            'processed': 0,
            'updated': 0,
            'updated_percent': 0,
            'errors': 0,
            'start_time': datetime.now(),
            'end_time': None,
            'duration_seconds': 0
        }
        
        try:
            cursor = self.connection.cursor()
            
            # دریافت تمام کندل‌های این ارز در این تایم‌فریم (مرتب شده)
            cursor.execute("""
                SELECT id, open_time, close_price, price_change, price_change_percent
                FROM crypto_klines
                WHERE coin_id = ? AND timeframe = ?
                ORDER BY open_time ASC
            """, (coin_id, timeframe))
            
            rows = cursor.fetchall()
            stats['total_records'] = len(rows)
            
            if stats['total_records'] == 0:
                logger.debug(f"  هیچ کندلی برای coin_id={coin_id}, timeframe={timeframe}")
                return stats
            
            logger.info(f"  پردازش {stats['total_records']:,} کندل برای coin_id={coin_id}, timeframe={timeframe}")
            
            # استخراج قیمت‌های بسته شدن
            close_prices = []
            record_ids = []
            needs_update = []  # اندیس‌هایی که نیاز به به‌روزرسانی دارند
            
            for i, row in enumerate(rows):
                row_dict = dict(row)
                
                close_price = row_dict['close_price'] or 0
                
                close_prices.append(float(close_price))
                record_ids.append(row_dict['id'])
                
                if row_dict['price_change'] is None or row_dict['price_change_percent'] is None:
                    needs_update.append(i)
            
            if not needs_update:
                logger.info(f"  همه رکوردها قبلاً محاسبه شده‌اند")
                stats['processed'] = stats['total_records']
                return stats
            
            # محاسبه تغییرات قیمت برای تمام دنباله
            changes = self.calculate_price_changes_for_sequence(close_prices)
            
            if len(changes) != len(close_prices):
                logger.error(f"  تعداد تغییرات محاسبه شده ({len(changes)}) با تعداد کندل‌ها ({len(close_prices)}) مطابقت ندارد")
                return stats
            
            # به‌روزرسانی رکوردهای مورد نیاز
            batch_data = []
            
            for idx in needs_update:
                if idx < len(changes):
                    price_change, price_change_percent = changes[idx]
                    batch_data.append((float(price_change), float(price_change_percent), record_ids[idx]))
                    stats['updated'] += 1
                
                stats['processed'] += 1
                
                # نمایش پیشرفت
                if stats['processed'] % 1000 == 0:
                    logger.info(f"    {stats['processed']:,}/{stats['total_records']:,} پردازش شد")
                
                # اگر بچ پر شد، ذخیره کن
                if len(batch_data) >= batch_size:
                    self._update_batch(batch_data)
                    batch_data = []
            
            # ذخیره بچ باقی‌مانده
            if batch_data:
                self._update_batch(batch_data)
            
            stats['end_time'] = datetime.now()
            stats['duration_seconds'] = (stats['end_time'] - stats['start_time']).total_seconds()
            
            if stats['updated'] > 0:
                stats['updated_percent'] = (stats['updated'] / stats['total_records']) * 100
                logger.info(f"  ✅ به‌روزرسانی {stats['updated']:,} رکورد در {stats['duration_seconds']:.1f} ثانیه")
            
            # آمار تغییرات برای این ارز
            if changes and stats['updated'] > 0:
                price_changes = [c[0] for c in changes]
                percent_changes = [c[1] for c in changes]
                
                stats['avg_price_change'] = float(np.mean(price_changes))
                stats['avg_percent_change'] = float(np.mean(percent_changes))
                stats['max_price_change'] = float(np.max(price_changes))
                stats['min_price_change'] = float(np.min(price_changes))
                stats['positive_changes'] = int(np.sum(np.array(price_changes) > 0))
                stats['negative_changes'] = int(np.sum(np.array(price_changes) < 0))
                stats['zero_changes'] = int(np.sum(np.array(price_changes) == 0))
            
            return stats
            
        except Exception as e:
            logger.error(f"❌ خطا در پردازش coin_id={coin_id}, timeframe={timeframe}: {e}")
            stats['error'] = str(e)
            stats['end_time'] = datetime.now()
            return stats
    
    def process_coin_timeframe_sequential(self, coin_id: int, timeframe: str, 
                                         batch_size: int = 500) -> Dict[str, Any]:
        """
        پردازش کندل‌های یک ارز در یک تایم‌فریم خاص به صورت ترتیبی
        
        Args:
            coin_id: شناسه ارز
            timeframe: تایم‌فریم
            batch_size: اندازه بچ
            
        Returns:
            آمار پردازش
        """
        stats = {
            'coin_id': coin_id,
            'timeframe': timeframe,
            'total_records': 0,
            'processed': 0,
            'updated': 0,
            'updated_percent': 0,
            'errors': 0,
            'start_time': datetime.now(),
            'end_time': None,
            'duration_seconds': 0
        }
        
        try:
            cursor = self.connection.cursor()
            
            # دریافت تمام کندل‌های این ارز در این تایم‌فریم (مرتب شده)
            cursor.execute("""
                SELECT id, open_time, close_price, price_change, price_change_percent
                FROM crypto_klines
                WHERE coin_id = ? AND timeframe = ?
                ORDER BY open_time ASC
            """, (coin_id, timeframe))
            
            rows = cursor.fetchall()
            stats['total_records'] = len(rows)
            
            if stats['total_records'] == 0:
                logger.debug(f"  هیچ کندلی برای coin_id={coin_id}, timeframe={timeframe}")
                return stats
            
            logger.info(f"  پردازش {stats['total_records']:,} کندل برای coin_id={coin_id}, timeframe={timeframe}")
            
            # پردازش کندل‌ها به صورت ترتیبی
            batch_data = []
            previous_close = None
            
            price_changes_list = []  # برای آمار نهایی
            percent_changes_list = []  # برای آمار نهایی
            
            for i, row in enumerate(rows, 1):
                row_dict = dict(row)
                
                current_close = row_dict['close_price'] or 0
                
                # محاسبه تغییر قیمت
                if previous_close is None:
                    # اولین کندل
                    price_change = 0.0
                    price_change_percent = 0.0
                else:
                    price_change, price_change_percent = self.calculate_price_change(
                        current_close, previous_close
                    )
                
                # ذخیره برای آمار نهایی
                price_changes_list.append(price_change)
                percent_changes_list.append(price_change_percent)
                
                # بررسی آیا نیاز به به‌روزرسانی داریم
                if row_dict['price_change'] is None or row_dict['price_change_percent'] is None:
                    batch_data.append((float(price_change), float(price_change_percent), row_dict['id']))
                    stats['updated'] += 1
                
                # به‌روزرسانی قیمت قبلی
                previous_close = current_close
                stats['processed'] += 1
                
                # نمایش پیشرفت
                if i % 1000 == 0:
                    logger.info(f"    {i:,}/{stats['total_records']:,} پردازش شد")
                
                # اگر بچ پر شد، ذخیره کن
                if len(batch_data) >= batch_size:
                    self._update_batch(batch_data)
                    batch_data = []
            
            # ذخیره بچ باقی‌مانده
            if batch_data:
                self._update_batch(batch_data)
            
            stats['end_time'] = datetime.now()
            stats['duration_seconds'] = (stats['end_time'] - stats['start_time']).total_seconds()
            
            if stats['updated'] > 0:
                stats['updated_percent'] = (stats['updated'] / stats['total_records']) * 100
                logger.info(f"  ✅ به‌روزرسانی {stats['updated']:,} رکورد در {stats['duration_seconds']:.1f} ثانیه")
            
            # آمار برای این ارز
            if price_changes_list:
                stats['avg_price_change'] = float(np.mean(price_changes_list))
                stats['avg_percent_change'] = float(np.mean(percent_changes_list))
                stats['max_price_change'] = float(np.max(price_changes_list))
                stats['min_price_change'] = float(np.min(price_changes_list))
                stats['positive_changes'] = int(np.sum(np.array(price_changes_list) > 0))
                stats['negative_changes'] = int(np.sum(np.array(price_changes_list) < 0))
                stats['zero_changes'] = int(np.sum(np.array(price_changes_list) == 0))
            
            return stats
            
        except Exception as e:
            logger.error(f"❌ خطا در پردازش coin_id={coin_id}, timeframe={timeframe}: {e}")
            stats['error'] = str(e)
            stats['end_time'] = datetime.now()
            return stats
    
    def _update_batch(self, batch_data: List[tuple]):
        """
        به‌روزرسانی دسته‌ای داده‌ها
        
        Args:
            batch_data: لیست tuples از (price_change, price_change_percent, id)
        """
        if not batch_data:
            return
        
        try:
            cursor = self.connection.cursor()
            
            # استفاده از executemany برای کارایی
            cursor.executemany(
                """UPDATE crypto_klines 
                   SET price_change = ?, price_change_percent = ?, updated_at = CURRENT_TIMESTAMP 
                   WHERE id = ?""",
                batch_data
            )
            
            self.connection.commit()
            
        except Exception as e:
            self.connection.rollback()
            logger.error(f"خطا در به‌روزرسانی بچ: {e}")
            raise
    
    def process_all(self, batch_size: int = 500, bulk_mode: bool = True) -> Dict[str, Any]:
        """
        پردازش تمام ارزها و تایم‌فریم‌ها
        
        Args:
            batch_size: اندازه بچ
            bulk_mode: استفاده از حالت گروهی
            
        Returns:
            آمار کلی پردازش
        """
        overall_stats = {
            'start_time': datetime.now(),
            'end_time': None,
            'total_processed': 0,
            'total_updated': 0,
            'total_errors': 0,
            'coin_timeframe_stats': [],
            'timeframe_summary': {},
            'coin_summary': {}
        }
        
        try:
            # دریافت تمام coin_id و timeframe منحصر به فرد
            cursor = self.connection.cursor()
            cursor.execute("""
                SELECT DISTINCT coin_id, timeframe 
                FROM crypto_klines 
                ORDER BY coin_id, timeframe
            """)
            
            coin_timeframes = cursor.fetchall()
            
            logger.info(f"🚀 شروع پردازش {len(coin_timeframes)} ترکیب coin/تایم‌فریم")
            
            # آمار تایم‌فریم‌ها و ارزها
            timeframe_counts = {}
            coin_counts = {}
            
            for i, row in enumerate(coin_timeframes, 1):
                coin_id = row['coin_id']
                timeframe = row['timeframe']
                
                logger.info(f"\n📊 پردازش {i}/{len(coin_timeframes)}: coin_id={coin_id}, timeframe={timeframe}")
                
                # انتخاب روش پردازش
                if bulk_mode:
                    stats = self.process_coin_timeframe_bulk(coin_id, timeframe, batch_size)
                else:
                    stats = self.process_coin_timeframe_sequential(coin_id, timeframe, batch_size)
                
                overall_stats['coin_timeframe_stats'].append(stats)
                overall_stats['total_processed'] += stats.get('processed', 0)
                overall_stats['total_updated'] += stats.get('updated', 0)
                overall_stats['total_errors'] += stats.get('errors', 0)
                
                # جمع‌آوری آمار تایم‌فریم
                if timeframe not in timeframe_counts:
                    timeframe_counts[timeframe] = 0
                timeframe_counts[timeframe] += stats.get('updated', 0)
                
                # جمع‌آوری آمار ارز
                if coin_id not in coin_counts:
                    coin_counts[coin_id] = 0
                coin_counts[coin_id] += stats.get('updated', 0)
                
                # استراحت کوتاه برای جلوگیری از فشار روی دیتابیس
                if i < len(coin_timeframes):
                    time.sleep(0.05)
            
            overall_stats['end_time'] = datetime.now()
            overall_stats['total_duration_seconds'] = (
                overall_stats['end_time'] - overall_stats['start_time']
            ).total_seconds()
            
            overall_stats['timeframe_summary'] = timeframe_counts
            overall_stats['coin_summary'] = coin_counts
            
            # چاپ خلاصه نهایی
            self._print_final_summary(overall_stats)
            
            return overall_stats
            
        except Exception as e:
            logger.error(f"❌ خطای کلی در پردازش: {e}")
            overall_stats['error'] = str(e)
            overall_stats['end_time'] = datetime.now()
            return overall_stats
    
    def _print_final_summary(self, overall_stats: Dict[str, Any]):
        """چاپ خلاصه نهایی پردازش"""
        print("\n" + "="*80)
        print("📊 گزارش نهایی پردازش PRICE_CHANGE")
        print("="*80)
        
        print(f"\n✅ پردازش کامل شد!")
        print(f"\n📈 آمار کلی:")
        print(f"  • زمان شروع: {overall_stats['start_time'].strftime('%Y-%m-%d %H:%M:%S')}")
        print(f"  • زمان پایان: {overall_stats['end_time'].strftime('%Y-%m-%d %H:%M:%S')}")
        print(f"  • مدت زمان: {overall_stats['total_duration_seconds']:.1f} ثانیه")
        print(f"  • تعداد رکوردهای پردازش شده: {overall_stats['total_processed']:,}")
        print(f"  • تعداد رکوردهای به‌روزرسانی شده: {overall_stats['total_updated']:,}")
        print(f"  • تعداد خطاها: {overall_stats['total_errors']:,}")
        
        if overall_stats['total_processed'] > 0:
            success_rate = (overall_stats['total_updated'] / overall_stats['total_processed']) * 100
            print(f"  • نرخ موفقیت: {success_rate:.1f}%")
        
        print(f"\n📋 آمار تفکیکی تایم‌فریم‌ها:")
        for timeframe, count in sorted(overall_stats.get('timeframe_summary', {}).items()):
            print(f"  • {timeframe}: {count:,} رکورد")
        
        print(f"\n📋 آمار تفکیکی ارزها (10 مورد اول):")
        coin_items = sorted(overall_stats.get('coin_summary', {}).items(), 
                          key=lambda x: x[1], reverse=True)[:10]
        for coin_id, count in coin_items:
            print(f"  • Coin {coin_id}: {count:,} رکورد")
        
        # آمار اضافی از دیتابیس
        try:
            cursor = self.connection.cursor()
            
            # میانگین‌های کلی
            cursor.execute("""
                SELECT 
                    AVG(price_change) as overall_avg_change,
                    MIN(price_change) as overall_min_change,
                    MAX(price_change) as overall_max_change,
                    AVG(price_change_percent) as overall_avg_percent,
                    MIN(price_change_percent) as overall_min_percent,
                    MAX(price_change_percent) as overall_max_percent,
                    COUNT(*) as count_with_change,
                    COUNT(CASE WHEN price_change > 0 THEN 1 END) as positive_changes,
                    COUNT(CASE WHEN price_change < 0 THEN 1 END) as negative_changes,
                    COUNT(CASE WHEN price_change = 0 THEN 1 END) as zero_changes,
                    STDDEV(price_change) as change_stddev,
                    STDDEV(price_change_percent) as percent_stddev
                FROM crypto_klines 
                WHERE price_change IS NOT NULL
            """)
            result = cursor.fetchone()
            
            if result and result['count_with_change'] > 0:
                print(f"\n📊 آمار نهایی تغییر قیمت:")
                print(f"  • میانگین تغییر مطلق: {result['overall_avg_change']:.6f}")
                print(f"  • کمترین تغییر مطلق: {result['overall_min_change']:.6f}")
                print(f"  • بیشترین تغییر مطلق: {result['overall_max_change']:.6f}")
                
                if result['overall_avg_percent']:
                    print(f"  • میانگین تغییر درصدی: {result['overall_avg_percent']:.4f}%")
                    print(f"  • کمترین تغییر درصدی: {result['overall_min_percent']:.4f}%")
                    print(f"  • بیشترین تغییر درصدی: {result['overall_max_percent']:.4f}%")
                
                if result['change_stddev']:
                    print(f"  • انحراف معیار تغییر مطلق: {result['change_stddev']:.6f}")
                if result['percent_stddev']:
                    print(f"  • انحراف معیار تغییر درصدی: {result['percent_stddev']:.4f}%")
                
                print(f"  • تعداد رکوردهای دارای تغییر قیمت: {result['count_with_change']:,}")
                
                # محاسبه درصدها
                total = result['count_with_change']
                pos_pct = (result['positive_changes'] / total * 100) if total > 0 else 0
                neg_pct = (result['negative_changes'] / total * 100) if total > 0 else 0
                zero_pct = (result['zero_changes'] / total * 100) if total > 0 else 0
                
                print(f"\n📈 توزیع تغییرات:")
                print(f"  • تغییرات مثبت: {result['positive_changes']:,} ({pos_pct:.1f}%)")
                print(f"  • تغییرات منفی: {result['negative_changes']:,} ({neg_pct:.1f}%)")
                print(f"  • تغییرات صفر: {result['zero_changes']:,} ({zero_pct:.1f}%)")
                
                # آمار برای تایم‌فریم‌های مختلف
                print(f"\n📊 تغییرات بر اساس تایم‌فریم:")
                cursor.execute("""
                    SELECT 
                        timeframe,
                        AVG(price_change) as avg_change,
                        AVG(price_change_percent) as avg_percent,
                        COUNT(*) as count
                    FROM crypto_klines 
                    WHERE price_change IS NOT NULL
                    GROUP BY timeframe
                    ORDER BY ABS(avg_change) DESC
                """)
                
                timeframe_stats = cursor.fetchall()
                for stat in timeframe_stats:
                    avg_change = stat['avg_change'] or 0
                    avg_percent = stat['avg_percent'] or 0
                    print(f"  • {stat['timeframe']}:")
                    print(f"    ◦ تغییر مطلق: {avg_change:.6f}")
                    print(f"    ◦ تغییر درصدی: {avg_percent:.4f}%")
                    print(f"    ◦ تعداد: {stat['count']:,}")
        
        except Exception as e:
            logger.debug(f"خطا در دریافت آمار اضافی: {e}")
        
        print("\n" + "="*80)
    
    def verify_calculations(self, sample_size: int = 1000) -> Dict[str, Any]:
        """
        تأیید صحت محاسبات با نمونه‌گیری تصادفی
        
        Args:
            sample_size: تعداد نمونه‌ها
            
        Returns:
            نتایج تأیید
        """
        verification_results = {
            'sample_size': sample_size,
            'correct': 0,
            'incorrect': 0,
            'errors': 0,
            'details': []
        }
        
        try:
            cursor = self.connection.cursor()
            
            # دریافت نمونه‌های تصادفی
            cursor.execute(f"""
                SELECT 
                    k1.id, k1.coin_id, k1.timeframe, k1.open_time, 
                    k1.close_price, k1.price_change, k1.price_change_percent,
                    (
                        SELECT k2.close_price
                        FROM crypto_klines k2
                        WHERE k2.coin_id = k1.coin_id 
                        AND k2.timeframe = k1.timeframe
                        AND k2.open_time < k1.open_time
                        ORDER BY k2.open_time DESC
                        LIMIT 1
                    ) as prev_close
                FROM crypto_klines k1
                WHERE k1.price_change IS NOT NULL 
                AND k1.close_price IS NOT NULL
                ORDER BY RANDOM()
                LIMIT ?
            """, (sample_size,))
            
            samples = cursor.fetchall()
            
            logger.info(f"🔍 تأیید صحت {len(samples)} نمونه تصادفی")
            
            for sample in samples:
                sample_dict = dict(sample)
                
                try:
                    current_close = sample_dict['close_price'] or 0
                    stored_change = sample_dict['price_change'] or 0
                    stored_percent = sample_dict['price_change_percent'] or 0
                    prev_close = sample_dict['prev_close']
                    
                    if prev_close is None:
                        # اولین کندل در دنباله
                        calculated_change = 0.0
                        calculated_percent = 0.0
                    else:
                        # محاسبه تغییرات
                        calculated_change = current_close - prev_close
                        if prev_close != 0:
                            calculated_percent = ((current_close - prev_close) / prev_close) * 100
                        else:
                            calculated_percent = 0.0
                    
                    # مقایسه با مقدار ذخیره شده
                    tolerance_abs = 0.000001  # تحمل خطا برای تغییر مطلق
                    tolerance_percent = 0.0001  # تحمل خطا برای تغییر درصدی
                    
                    abs_match = abs(calculated_change - stored_change) <= tolerance_abs
                    percent_match = abs(calculated_percent - stored_percent) <= tolerance_percent
                    
                    if abs_match and percent_match:
                        verification_results['correct'] += 1
                        status = 'CORRECT'
                    else:
                        verification_results['incorrect'] += 1
                        status = 'INCORRECT'
                        if not abs_match:
                            logger.warning(f"  عدم تطابق تغییر مطلق برای رکورد {sample_dict['id']}: "
                                         f"محاسبه شده={calculated_change:.6f}, ذخیره شده={stored_change:.6f}")
                        if not percent_match:
                            logger.warning(f"  عدم تطابق تغییر درصدی برای رکورد {sample_dict['id']}: "
                                         f"محاسبه شده={calculated_percent:.4f}%, ذخیره شده={stored_percent:.4f}%")
                    
                    verification_results['details'].append({
                        'id': sample_dict['id'],
                        'status': status,
                        'stored_change': stored_change,
                        'calculated_change': calculated_change,
                        'stored_percent': stored_percent,
                        'calculated_percent': calculated_percent,
                        'current_close': current_close,
                        'prev_close': prev_close
                    })
                    
                except Exception as e:
                    verification_results['errors'] += 1
                    logger.error(f"خطا در تأیید رکورد {sample_dict['id']}: {e}")
            
            # چاپ نتایج تأیید
            print("\n" + "="*80)
            print("🔍 نتایج تأیید صحت محاسبات PRICE_CHANGE")
            print("="*80)
            
            print(f"\n📊 آمار تأیید:")
            print(f"  • تعداد نمونه‌ها: {verification_results['sample_size']}")
            print(f"  • صحیح: {verification_results['correct']}")
            print(f"  • ناصحیح: {verification_results['incorrect']}")
            print(f"  • خطاها: {verification_results['errors']}")
            
            if verification_results['correct'] + verification_results['incorrect'] > 0:
                accuracy = (verification_results['correct'] / 
                          (verification_results['correct'] + verification_results['incorrect'])) * 100
                print(f"  • دقت: {accuracy:.2f}%")
            
            print("="*80)
            
            return verification_results
            
        except Exception as e:
            logger.error(f"❌ خطا در تأیید محاسبات: {e}")
            verification_results['error'] = str(e)
            return verification_results
    
    def analyze_price_changes(self):
        """تحلیل تغییرات قیمت"""
        try:
            cursor = self.connection.cursor()
            
            print("\n" + "="*80)
            print("🔍 تحلیل تغییرات قیمت")
            print("="*80)
            
            # تحلیل بزرگترین تغییرات
            print(f"\n🏆 بزرگترین تغییرات مثبت:")
            cursor.execute("""
                SELECT 
                    coin_id, timeframe, open_time, 
                    price_change, price_change_percent
                FROM crypto_klines 
                WHERE price_change IS NOT NULL
                ORDER BY price_change_percent DESC
                LIMIT 10
            """)
            
            top_gainers = cursor.fetchall()
            for i, gainer in enumerate(top_gainers, 1):
                print(f"  {i}. Coin {gainer['coin_id']} ({gainer['timeframe']}) - {gainer['open_time']}:")
                print(f"     ◦ تغییر قیمت: {gainer['price_change']:.6f}")
                print(f"     ◦ تغییر درصدی: {gainer['price_change_percent']:.4f}%")
            
            print(f"\n📉 بزرگترین تغییرات منفی:")
            cursor.execute("""
                SELECT 
                    coin_id, timeframe, open_time, 
                    price_change, price_change_percent
                FROM crypto_klines 
                WHERE price_change IS NOT NULL
                ORDER BY price_change_percent ASC
                LIMIT 10
            """)
            
            top_losers = cursor.fetchall()
            for i, loser in enumerate(top_losers, 1):
                print(f"  {i}. Coin {loser['coin_id']} ({loser['timeframe']}) - {loser['open_time']}:")
                print(f"     ◦ تغییر قیمت: {loser['price_change']:.6f}")
                print(f"     ◦ تغییر درصدی: {loser['price_change_percent']:.4f}%")
            
            # تحلیل نوسان روزانه
            print(f"\n📊 نوسان تغییرات روزانه:")
            cursor.execute("""
                SELECT 
                    DATE(open_time) as date,
                    AVG(ABS(price_change_percent)) as avg_daily_volatility,
                    COUNT(*) as count
                FROM crypto_klines 
                WHERE price_change_percent IS NOT NULL
                AND open_time IS NOT NULL
                GROUP BY DATE(open_time)
                ORDER BY avg_daily_volatility DESC
                LIMIT 10
            """)
            
            volatile_days = cursor.fetchall()
            for i, day in enumerate(volatile_days, 1):
                print(f"  {i}. تاریخ {day['date']}:")
                print(f"     ◦ میانگین نوسان: {day['avg_daily_volatility']:.4f}%")
                print(f"     ◦ تعداد کندل: {day['count']:,}")
            
            # همبستگی تغییر قیمت با سایر اندیکاتورها
            cursor.execute("""
                SELECT 
                    CORR(price_change, volume) as corr_price_volume,
                    CORR(price_change_percent, volume_ratio) as corr_percent_volume_ratio,
                    CORR(price_change_percent, volatility) as corr_percent_volatility,
                    CORR(price_change, obv) as corr_price_obv
                FROM crypto_klines 
                WHERE price_change IS NOT NULL 
                AND volume IS NOT NULL
                AND volume_ratio IS NOT NULL
                AND volatility IS NOT NULL
                AND obv IS NOT NULL
                LIMIT 1
            """)
            
            correlation = cursor.fetchone()
            
            if correlation:
                print(f"\n📈 همبستگی‌های تغییر قیمت:")
                if correlation['corr_price_volume']:
                    print(f"  • همبستگی تغییر قیمت و حجم: {correlation['corr_price_volume']:.4f}")
                if correlation['corr_percent_volume_ratio']:
                    print(f"  • همبستگی تغییر درصدی و نسبت حجم: {correlation['corr_percent_volume_ratio']:.4f}")
                if correlation['corr_percent_volatility']:
                    print(f"  • همبستگی تغییر درصدی و نوسان: {correlation['corr_percent_volatility']:.4f}")
                if correlation['corr_price_obv']:
                    print(f"  • همبستگی تغییر قیمت و OBV: {correlation['corr_price_obv']:.4f}")
            
            print("="*80)
            
        except Exception as e:
            logger.error(f"خطا در تحلیل تغییرات قیمت: {e}")
    
    def close(self):
        """بستن اتصال به دیتابیس"""
        if self.connection:
            self.connection.close()
            logger.info("🔌 اتصال به دیتابیس بسته شد")


def main():
    """تابع اصلی اجرای اسکریپت"""
    # مسیر دیتابیس
    db_path = r"C:\Users\Kamal\Desktop\py-prg\git\c-data\data\crypto_master.db"
    
    print("\n" + "="*80)
    print("📈 اسکریپت محاسبه PRICE_CHANGE (تغییر قیمت)")
    print("="*80)
    
    # بررسی وجود فایل دیتابیس
    if not os.path.exists(db_path):
        print(f"❌ فایل دیتابیس یافت نشد: {db_path}")
        print("لطفاً مسیر صحیح را بررسی کنید.")
        return
    
    print(f"📁 دیتابیس: {db_path}")
    print(f"📅 تاریخ: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("="*80)
    
    # ایجاد نمونه از کلاس
    calculator = None
    
    try:
        calculator = PriceChangeCalculator(db_path)
        
        # نمایش خلاصه جدول
        calculator.print_table_summary()
        
        # تأیید ادامه
        confirm = input("\n❓ آیا می‌خواهید پردازش را شروع کنید؟ (y/n): ")
        if confirm.lower() != 'y':
            print("❌ پردازش لغو شد.")
            return
        
        # انتخاب حالت پردازش
        print("\n⚙️  انتخاب حالت پردازش:")
        print("  1. حالت گروهی (پیشنهادی - سریع)")
        print("  2. حالت ترتیبی (برای اشکال‌زدایی)")
        mode_choice = input("❓ انتخاب کنید (1 یا 2): ").strip()
        
        bulk_mode = True
        if mode_choice == '2':
            bulk_mode = False
            print("✅ حالت ترتیبی انتخاب شد")
        else:
            print("✅ حالت گروهی انتخاب شد")
        
        print("\n🚀 شروع پردازش...")
        print("-"*80)
        
        # پردازش تمام داده‌ها
        overall_stats = calculator.process_all(batch_size=500, bulk_mode=bulk_mode)
        
        print("\n🎉 پردازش با موفقیت تکمیل شد!")
        
        # تحلیل تغییرات قیمت
        analyze_choice = input("\n❓ آیا می‌خواهید تغییرات قیمت را تحلیل کنید؟ (y/n): ")
        if analyze_choice.lower() == 'y':
            calculator.analyze_price_changes()
        
        # تأیید اختیاری
        verify_choice = input("\n❓ آیا می‌خواهید صحت محاسبات را تأیید کنید؟ (y/n): ")
        if verify_choice.lower() == 'y':
            sample_size_input = input("❓ تعداد نمونه برای تأیید (پیش‌فرض: 1000): ").strip()
            sample_size = int(sample_size_input) if sample_size_input.isdigit() else 1000
            calculator.verify_calculations(sample_size=sample_size)
        
    except Exception as e:
        logger.error(f"❌ خطای اصلی: {e}")
        print(f"\n❌ خطا رخ داد: {e}")
        
    finally:
        if calculator:
            calculator.close()
            
    # ایجاد گزارش خلاصه
    print("\n📝 گزارش در فایل 'price_change_calculator.log' ذخیره شد.")
    print("📊 برای بررسی آماری بیشتر، از گزارش‌های بالا استفاده کنید.")


if __name__ == "__main__":
    main()