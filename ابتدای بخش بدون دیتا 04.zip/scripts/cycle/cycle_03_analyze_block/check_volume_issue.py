"""
🔍 بررسی مشکل اندیکاتورهای حجم
"""

import sqlite3
import pandas as pd
import os

def analyze_volume_issues():
    """تحلیل مشکلات حجم"""
    
    db_path = "../../../data/crypto_master.db"
    conn = sqlite3.connect(db_path)
    
    print("🔍 تحلیل مشکلات اندیکاتورها")
    print("=" * 70)
    
    # ۱. بررسی داده‌های حجم
    print("\n📊 ۱. آمار داده‌های حجم:")
    volume_stats = pd.read_sql_query("""
        SELECT 
            COUNT(*) as total,
            COUNT(CASE WHEN volume IS NULL THEN 1 END) as null_volume,
            COUNT(CASE WHEN volume = 0 THEN 1 END) as zero_volume,
            COUNT(CASE WHEN volume > 0 THEN 1 END) as positive_volume,
            AVG(volume) as avg_volume
        FROM crypto_klines
    """, conn)
    print(volume_stats.to_string(index=False))
    
    # ۲. بررسی ارتباط OBV با حجم
    print("\n📊 ۲. ارتباط OBV و حجم:")
    obv_stats = pd.read_sql_query("""
        SELECT 
            COUNT(*) as total,
            COUNT(CASE WHEN obv IS NULL THEN 1 END) as null_obv,
            COUNT(CASE WHEN obv = 0 THEN 1 END) as zero_obv,
            COUNT(CASE WHEN obv IS NOT NULL AND obv != 0 THEN 1 END) as valid_obv,
            COUNT(CASE WHEN obv IS NULL AND volume IS NOT NULL AND volume > 0 THEN 1 END) as missing_obv_with_volume
        FROM crypto_klines
    """, conn)
    print(obv_stats.to_string(index=False))
    
    # ۳. نمونه‌هایی از مشکل
    print("\n📊 ۳. نمونه‌های مشکل‌دار (۱۰ مورد):")
    problem_samples = pd.read_sql_query("""
        SELECT 
            id, coin_id, timeframe, open_time,
            volume, obv, volume_ma_20, volume_ratio,
            atr, volatility, price_change, price_change_percent
        FROM crypto_klines 
        WHERE (obv IS NULL OR obv = 0)
        AND volume IS NOT NULL 
        AND volume > 0
        LIMIT 10
    """, conn)
    print(problem_samples.to_string(index=False))
    
    # ۴. بررسی بر اساس coin_id
    print("\n📊 ۴. مشکلات بر اساس ارز:")
    coin_problems = pd.read_sql_query("""
        SELECT 
            coin_id,
            COUNT(*) as total_candles,
            COUNT(CASE WHEN obv IS NULL OR obv = 0 THEN 1 END) as missing_obv,
            ROUND(COUNT(CASE WHEN obv IS NULL OR obv = 0 THEN 1 END) * 100.0 / COUNT(*), 1) as percent_missing
        FROM crypto_klines
        GROUP BY coin_id
        HAVING percent_missing > 50
        ORDER BY percent_missing DESC
        LIMIT 10
    """, conn)
    print(coin_problems.to_string(index=False))
    
    # ۵. بررسی تاریخچه داده‌ها
    print("\n📊 ۵. بررسی تاریخچه برای یک نمونه:")
    sample_coin = "BTCUSDT" if len(coin_problems) > 0 else "BTCUSDT"
    
    history_check = pd.read_sql_query(f"""
        SELECT 
            COUNT(*) as history_count,
            COUNT(CASE WHEN volume IS NULL OR volume = 0 THEN 1 END) as bad_volume_count,
            MIN(open_time) as earliest,
            MAX(open_time) as latest
        FROM crypto_klines 
        WHERE coin_id = '{sample_coin}'
        AND timeframe = '15m'
    """, conn)
    print(history_check.to_string(index=False))
    
    conn.close()
    
    # تحلیل نهایی
    print("\n" + "=" * 70)
    print("🎯 تحلیل و راه‌حل:")
    print("=" * 70)
    
    total_candles = volume_stats.iloc[0]['total']
    null_volume = volume_stats.iloc[0]['null_volume']
    zero_volume = volume_stats.iloc[0]['zero_volume']
    
    if null_volume + zero_volume > total_candles * 0.1:
        print(f"❌ مشکل اصلی: {null_volume + zero_volume:,} کندل حجم نامعتبر دارند")
        print("   ↳ حجم NULL یا صفر باعث عدم محاسبه OBV و Volume MA می‌شود")
        print("   ↳ راه‌حل: بازسازی داده‌های حجم یا پرکردن مقادیر پیش‌فرض")
    else:
        print("✅ داده‌های حجم به نظر می‌رسد معتبر هستند")
        print("   ↳ مشکل ممکن است در منطق محاسبه باشد")
    
    # توصیه‌ها
    print("\n💡 توصیه‌ها:")
    print("1. بررسی indicator_calculator.py - تابع _calculate_volume_indicators")
    print("2. اطمینان از وجود داده‌های تاریخی کافی برای محاسبات")
    print("3. اجرای دوباره پردازش برای رکوردهای مشکل‌دار")
    print("4. استفاده از fix_indicators.py برای ترمیم")

if __name__ == "__main__":
    analyze_volume_issues()