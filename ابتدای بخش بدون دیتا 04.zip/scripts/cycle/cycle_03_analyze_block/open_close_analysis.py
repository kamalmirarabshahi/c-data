"""
🔍 تحلیل کوین‌های مشکل‌دار
"""

import sqlite3

DB_PATH = r"C:\Users\Kamal\Desktop\py-prg\git\c-data\data\crypto_master.db"

def analyze_problem_coins():
    """تحلیل کوین‌هایی که بیشترین مشکل را دارند"""
    
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    print("🔍 کوین‌های با بیشترین مشکل:")
    print("="*60)
    
    # کوین‌های با بیشترین درصد بدون OBV در 15m
    cursor.execute("""
        SELECT 
            coin_id,
            COUNT(*) as total,
            SUM(CASE WHEN obv IS NULL THEN 1 ELSE 0 END) as no_obv,
            SUM(CASE WHEN price_change IS NULL THEN 1 ELSE 0 END) as no_price_change,
            SUM(CASE WHEN volume_ma_20 IS NULL THEN 1 ELSE 0 END) as no_volume_ma
        FROM crypto_klines 
        WHERE timeframe = '15m'
        GROUP BY coin_id
        HAVING total > 100
        ORDER BY no_obv DESC
        LIMIT 10
    """)
    
    print("\n🔥 ۱۰ کوین با بیشترین مشکل OBV:")
    print(f"{'Coin ID':<8} {'کل':>6} {'بدون OBV':>10} {'%':>6} {'بدون PC':>9} {'بدون VMA':>10}")
    print("-" * 60)
    
    for row in cursor.fetchall():
        coin_id, total, no_obv, no_price_change, no_volume_ma = row
        percent_obv = (no_obv / total * 100) if total > 0 else 0
        percent_pc = (no_price_change / total * 100) if total > 0 else 0
        percent_vma = (no_volume_ma / total * 100) if total > 0 else 0
        
        print(f"{coin_id:<8} {total:>6,} {no_obv:>10,} {percent_obv:>5.1f}% "
              f"{no_price_change:>9,} {no_volume_ma:>10,}")
    
    # کوین‌های بدون مشکل
    cursor.execute("""
        SELECT 
            coin_id,
            COUNT(*) as total
        FROM crypto_klines 
        WHERE timeframe = '15m' AND obv IS NOT NULL
        GROUP BY coin_id
        HAVING COUNT(*) > 100
        ORDER BY COUNT(*) DESC
        LIMIT 5
    """)
    
    print("\n✅ ۵ کوین بدون مشکل (همه OBV دارند):")
    for row in cursor.fetchall():
        print(f"  • Coin {row[0]}: {row[1]:,} کندل با OBV")
    
    # تحلیل نمونه از یک کوین مشکل‌دار
    print("\n🔍 تحلیل عمیق یک کوین مشکل‌دار:")
    
    cursor.execute("""
        SELECT coin_id 
        FROM crypto_klines 
        WHERE timeframe = '15m' AND obv IS NULL
        GROUP BY coin_id
        ORDER BY COUNT(*) DESC
        LIMIT 1
    """)
    
    problem_coin = cursor.fetchone()
    if problem_coin:
        coin_id = problem_coin[0]
        
        print(f"\n📊 تحلیل Coin {coin_id}:")
        
        # بررسی توزیع زمانی
        cursor.execute("""
            SELECT 
                strftime('%Y-%m', open_time) as month,
                COUNT(*) as total,
                SUM(CASE WHEN obv IS NULL THEN 1 ELSE 0 END) as no_obv
            FROM crypto_klines 
            WHERE coin_id = ? AND timeframe = '15m'
            GROUP BY strftime('%Y-%m', open_time)
            ORDER BY month
        """, (coin_id,))
        
        print("  • توزیع ماهانه:")
        for row in cursor.fetchall():
            month, total, no_obv = row
            percent = (no_obv / total * 100) if total > 0 else 0
            print(f"    - {month}: {no_obv}/{total} ({percent:.1f}%) بدون OBV")
        
        # بررسی نمونه‌های خاص
        cursor.execute("""
            SELECT open_time, open_price, close_price, volume
            FROM crypto_klines 
            WHERE coin_id = ? AND timeframe = '15m' AND obv IS NULL
            ORDER BY open_time
            LIMIT 5
        """, (coin_id,))
        
        print("  • نمونه‌های اولیه بدون OBV:")
        for row in cursor.fetchall():
            open_time, open_price, close_price, volume = row
            is_same = abs(open_price - close_price) < 0.000001
            same_mark = " ⚠️" if is_same else ""
            print(f"    - {open_time}: O={open_price:.8f}, C={close_price:.8f}, "
                  f"V={volume:.2f}{same_mark}")
        
        # بررسی آیا کوین در تایم‌فریم‌های دیگر هم مشکل دارد
        print("  • وضعیت در تایم‌فریم‌های دیگر:")
        for tf in ['15m', '1h', '4h']:
            cursor.execute("""
                SELECT 
                    COUNT(*) as total,
                    SUM(CASE WHEN obv IS NULL THEN 1 ELSE 0 END) as no_obv
                FROM crypto_klines 
                WHERE coin_id = ? AND timeframe = ?
            """, (coin_id, tf))
            
            row = cursor.fetchone()
            if row:
                total, no_obv = row
                percent = (no_obv / total * 100) if total > 0 else 0
                print(f"    - {tf}: {no_obv}/{total} ({percent:.1f}%) بدون OBV")
    
    conn.close()

def check_data_quality():
    """بررسی کیفیت داده‌های ورودی"""
    
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    print("\n" + "="*60)
    print("🔍 بررسی کیفیت داده‌های ورودی:")
    print("="*60)
    
    # بررسی ترتیب زمانی
    cursor.execute("""
        SELECT coin_id, timeframe, COUNT(*) as out_of_order
        FROM (
            SELECT 
                coin_id,
                timeframe,
                open_time,
                LAG(open_time) OVER (PARTITION BY coin_id, timeframe ORDER BY open_time) as prev_time
            FROM crypto_klines 
            WHERE timeframe = '15m'
        ) 
        WHERE prev_time IS NOT NULL AND open_time <= prev_time
        GROUP BY coin_id, timeframe
        ORDER BY out_of_order DESC
        LIMIT 5
    """)
    
    print("\n⚠️  کوین‌های با مشکل ترتیب زمانی:")
    for row in cursor.fetchall():
        print(f"  • Coin {row[0]} ({row[1]}): {row[2]} کندل خارج از ترتیب")
    
    # بررسی داده‌های مفقود
    cursor.execute("""
        SELECT 
            coin_id,
            SUM(CASE WHEN open_price IS NULL THEN 1 ELSE 0 END) as missing_open,
            SUM(CASE WHEN close_price IS NULL THEN 1 ELSE 0 END) as missing_close,
            SUM(CASE WHEN volume IS NULL THEN 1 ELSE 0 END) as missing_volume
        FROM crypto_klines 
        WHERE timeframe = '15m'
        GROUP BY coin_id
        HAVING missing_open > 0 OR missing_close > 0 OR missing_volume > 0
        LIMIT 5
    """)
    
    print("\n⚠️  کوین‌های با داده‌های مفقود:")
    for row in cursor.fetchall():
        print(f"  • Coin {row[0]}: Open={row[1]}, Close={row[2]}, Volume={row[3]}")
    
    conn.close()

if __name__ == "__main__":
    analyze_problem_coins()
    check_data_quality()