"""
🔍 بررسی توالی کندل‌ها در دیتابیس
"""

import sqlite3
import pandas as pd
from datetime import datetime, timedelta
import os

def check_candle_sequence(coin_id=None, timeframe=None, limit=10):
    """بررسی توالی کندل‌ها برای یک ارز"""
    
    db_path = "../../../data/crypto_master.db"
    conn = sqlite3.connect(db_path)
    
    print("🔍 بررسی توالی کندل‌ها")
    print("=" * 70)
    
    # دریافت لیست ارزهای مشکل‌دار (بر اساس OBV)
    cursor = conn.cursor()
    
    if coin_id:
        query_coins = f"SELECT '{coin_id}' as coin_id"
    else:
        query_coins = """
        SELECT DISTINCT coin_id
        FROM crypto_klines 
        WHERE (obv IS NULL OR obv = 0) 
        AND rsi IS NOT NULL  -- یعنی پردازش شده ولی OBV نداره
        ORDER BY coin_id
        LIMIT 5
        """
    
    cursor.execute(query_coins)
    coins = [row[0] for row in cursor.fetchall()]
    
    for coin in coins:
        print(f"\n💰 ارز: {coin}")
        print("-" * 50)
        
        # بررسی برای هر تایم‌فریم
        query_timeframes = """
        SELECT DISTINCT timeframe 
        FROM crypto_klines 
        WHERE coin_id = ?
        ORDER BY timeframe
        """
        cursor.execute(query_timeframes, (coin,))
        timeframes = [row[0] for row in cursor.fetchall()]
        
        for tf in timeframes:
            print(f"\n  ⏱️ تایم‌فریم: {tf}")
            
            # دریافت کندل‌ها به ترتیب زمانی
            query = f"""
            SELECT 
                id,
                open_time,
                open_price,
                high_price,
                low_price,
                close_price,
                volume,
                rsi,
                obv,
                atr,
                price_change
            FROM crypto_klines 
            WHERE coin_id = ? AND timeframe = ?
            ORDER BY open_time ASC
            LIMIT {limit}
            """
            
            df = pd.read_sql_query(query, conn, params=(coin, tf))
            
            # نمایش اطلاعات
            print(f"  📊 تعداد کندل‌ها در دیتابیس: {len(df)}")
            
            if len(df) > 0:
                # بررسی توالی زمانی
                df['open_time'] = pd.to_datetime(df['open_time'])
                time_gaps = df['open_time'].diff().dropna()
                
                print(f"  ⏰ اولین کندل: {df['open_time'].iloc[0]}")
                print(f"  ⏰ آخرین کندل: {df['open_time'].iloc[-1]}")
                print(f"  📅 بازه زمانی: {(df['open_time'].iloc[-1] - df['open_time'].iloc[0]).days} روز")
                
                # بررسی شکاف‌های زمانی
                if len(time_gaps) > 0:
                    avg_gap = time_gaps.mean()
                    max_gap = time_gaps.max()
                    gaps_issues = time_gaps[time_gaps > avg_gap * 2]  # شکاف‌های غیرعادی
                    
                    print(f"  ⏱️ میانگین فاصله بین کندل‌ها: {avg_gap}")
                    print(f"  ⏱️ بیشترین فاصله: {max_gap}")
                    
                    if len(gaps_issues) > 0:
                        print(f"  ⚠️ {len(gaps_issues)} شکاف غیرعادی زمانی پیدا شد")
                
                # بررسی داده‌های مفقود
                missing_obv = df['obv'].isna().sum()
                missing_atr = df['atr'].isna().sum()
                missing_price_change = df['price_change'].isna().sum()
                
                print(f"  ❌ OBV مفقود: {missing_obv}/{len(df)} ({missing_obv/len(df)*100:.1f}%)")
                print(f"  ❌ ATR مفقود: {missing_atr}/{len(df)} ({missing_atr/len(df)*100:.1f}%)")
                print(f"  ❌ Price Change مفقود: {missing_price_change}/{len(df)} ({missing_price_change/len(df)*100:.1f}%)")
                
                # نمایش نمونه‌ها
                if len(df) >= 10:
                    print("\n  📋 ۵ کندل اول:")
                    print(df[['open_time', 'close_price', 'volume', 'rsi', 'obv']].head().to_string(index=False))
                    
                    print("\n  📋 ۵ کندل آخر:")
                    print(df[['open_time', 'close_price', 'volume', 'rsi', 'obv']].tail().to_string(index=False))
                    
                    # بررسی کندل‌های خاص
                    if missing_obv > 0:
                        problematic = df[df['obv'].isna()]
                        print(f"\n  🔍 {len(problematic)} کندل با OBV مفقود:")
                        print(problematic[['open_time', 'close_price', 'volume']].head(3).to_string(index=False))
    
    conn.close()

def analyze_sequence_issues():
    """تحلیل عمیق مشکلات توالی"""
    
    db_path = "../../../data/crypto_master.db"
    conn = sqlite3.connect(db_path)
    
    print("\n📊 تحلیل مشکلات توالی داده‌ها")
    print("=" * 70)
    
    # ۱. بررسی ارزهایی که OBV ندارند اما RSI دارند
    query = """
    SELECT 
        coin_id,
        COUNT(*) as total_candles,
        SUM(CASE WHEN rsi IS NOT NULL AND rsi != 0 THEN 1 ELSE 0 END) as has_rsi,
        SUM(CASE WHEN obv IS NULL OR obv = 0 THEN 1 ELSE 0 END) as missing_obv,
        SUM(CASE WHEN atr IS NULL OR atr = 0 THEN 1 ELSE 0 END) as missing_atr,
        MIN(open_time) as first_candle,
        MAX(open_time) as last_candle
    FROM crypto_klines
    GROUP BY coin_id
    HAVING missing_obv > total_candles * 0.3  -- بیش از 30% OBV ندارند
    ORDER BY missing_obv DESC
    LIMIT 10
    """
    
    df_problematic = pd.read_sql_query(query, conn)
    
    if len(df_problematic) > 0:
        print("🔴 ارزهای با بیشترین مشکل OBV:")
        for idx, row in df_problematic.iterrows():
            print(f"\n{idx+1}. {row['coin_id']}:")
            print(f"   📊 کل کندل‌ها: {row['total_candles']}")
            print(f"   ✅ دارای RSI: {row['has_rsi']} ({row['has_rsi']/row['total_candles']*100:.1f}%)")
            print(f"   ❌ فاقد OBV: {row['missing_obv']} ({row['missing_obv']/row['total_candles']*100:.1f}%)")
            print(f"   ❌ فاقد ATR: {row['missing_atr']} ({row['missing_atr']/row['total_candles']*100:.1f}%)")
            print(f"   📅 بازه: {row['first_candle']} تا {row['last_candle']}")
    
    # ۲. بررسی بر اساس تایم‌فریم
    print("\n📊 مشکلات بر اساس تایم‌فریم:")
    query_tf = """
    SELECT 
        timeframe,
        COUNT(*) as total_candles,
        SUM(CASE WHEN obv IS NULL OR obv = 0 THEN 1 ELSE 0 END) as missing_obv,
        ROUND(SUM(CASE WHEN obv IS NULL OR obv = 0 THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 1) as percent_missing
    FROM crypto_klines
    GROUP BY timeframe
    ORDER BY percent_missing DESC
    """
    
    df_tf = pd.read_sql_query(query_tf, conn)
    print(df_tf.to_string(index=False))
    
    # ۳. بررسی شکاف‌های زمانی
    print("\n🔍 بررسی شکاف‌های زمانی در داده‌ها:")
    
    # نمونه: بررسی برای یک ارز مشکل‌دار
    if len(df_problematic) > 0:
        sample_coin = df_problematic.iloc[0]['coin_id']
        
        query_gaps = f"""
        WITH ordered_candles AS (
            SELECT 
                open_time,
                LAG(open_time) OVER (ORDER BY open_time) as prev_time
            FROM crypto_klines 
            WHERE coin_id = '{sample_coin}'
            AND timeframe = '15m'
            ORDER BY open_time
        )
        SELECT 
            COUNT(*) as total_candles,
            AVG(julianday(open_time) - julianday(prev_time)) * 24 * 60 as avg_gap_minutes,
            MAX(julianday(open_time) - julianday(prev_time)) * 24 * 60 as max_gap_minutes,
            SUM(CASE WHEN (julianday(open_time) - julianday(prev_time)) * 24 * 60 > 20 THEN 1 ELSE 0 END) as large_gaps
        FROM ordered_candles
        WHERE prev_time IS NOT NULL
        """
        
        df_gaps = pd.read_sql_query(query_gaps, conn)
        print(f"ارز نمونه: {sample_coin} (15m)")
        print(f"میانگین فاصله: {df_gaps.iloc[0]['avg_gap_minutes']:.1f} دقیقه")
        print(f"بیشترین فاصله: {df_gaps.iloc[0]['max_gap_minutes']:.1f} دقیقه")
        print(f"شکاف‌های بزرگ (>20 دقیقه): {df_gaps.iloc[0]['large_gaps']}")
    
    conn.close()
    
    # تحلیل نهایی
    print("\n" + "=" * 70)
    print("🎯 تحلیل احتمالی مشکلات:")
    print("=" * 70)
    
    if len(df_problematic) > 0:
        print("✅ مشکل شناسایی شد: برخی ارزها داده‌های تاریخی ناقص دارند")
        print("📌 دلایل احتمالی:")
        print("1. دریافت داده‌ها از API با شکاف‌های زمانی")
        print("2. عدم وجود تاریخچه کافی برای محاسبه اندیکاتورهای وابسته")
        print("3. مشکل در توالی ذخیره‌سازی داده‌ها")
        print("\n💡 راه‌حل‌ها:")
        print("1. بازسازی تاریخچه کامل برای ارزهای مشکل‌دار")
        print("2. اصلاح indicator_calculator برای کار با داده‌های ناقص")
        print("3. اجرای پردازش مجدد فقط برای ارزهای مشکل‌دار")
    else:
        print("✅ همه ارزها داده‌های نسبتاً کاملی دارند")
        print("📌 مشکل احتمالاً در منطق محاسبه است")

def fix_specific_coin(coin_id):
    """بررسی و ترمیم یک ارز خاص"""
    
    db_path = "../../../data/crypto_master.db"
    conn = sqlite3.connect(db_path)
    
    print(f"\n🔧 بررسی و ترمیم ارز: {coin_id}")
    print("=" * 70)
    
    # ۱. آمار ارز
    query_stats = f"""
    SELECT 
        timeframe,
        COUNT(*) as total,
        SUM(CASE WHEN obv IS NULL OR obv = 0 THEN 1 ELSE 0 END) as missing_obv,
        SUM(CASE WHEN atr IS NULL OR atr = 0 THEN 1 ELSE 0 END) as missing_atr,
        MIN(open_time) as first_candle,
        MAX(open_time) as last_candle
    FROM crypto_klines 
    WHERE coin_id = '{coin_id}'
    GROUP BY timeframe
    """
    
    df_stats = pd.read_sql_query(query_stats, conn)
    print("📊 آمار ارز:")
    print(df_stats.to_string(index=False))
    
    # ۲. بررسی توالی برای هر تایم‌فریم
    for idx, row in df_stats.iterrows():
        tf = row['timeframe']
        
        print(f"\n⏱️ تایم‌فریم {tf}:")
        print(f"   کل کندل‌ها: {row['total']}")
        print(f"   فاقد OBV: {row['missing_obv']} ({row['missing_obv']/row['total']*100:.1f}%)")
        print(f"   فاقد ATR: {row['missing_atr']} ({row['missing_atr']/row['total']*100:.1f}%)")
        print(f"   بازه: {row['first_candle']} تا {row['last_candle']}")
        
        # بررسی ۱۰ کندل اول
        query_first = f"""
        SELECT id, open_time, close_price, volume, rsi, obv, atr
        FROM crypto_klines 
        WHERE coin_id = '{coin_id}' AND timeframe = '{tf}'
        ORDER BY open_time ASC
        LIMIT 10
        """
        
        df_first = pd.read_sql_query(query_first, conn)
        print(f"\n   🔍 ۵ کندل اول:")
        print(df_first.head(5)[['open_time', 'close_price', 'volume', 'obv', 'atr']].to_string(index=False))
        
        # بررسی کندل‌های با OBV مفقود
        if row['missing_obv'] > 0:
            query_missing = f"""
            SELECT id, open_time, close_price, volume
            FROM crypto_klines 
            WHERE coin_id = '{coin_id}' 
            AND timeframe = '{tf}'
            AND (obv IS NULL OR obv = 0)
            ORDER BY open_time ASC
            LIMIT 5
            """
            
            df_missing = pd.read_sql_query(query_missing, conn)
            print(f"\n   ❌ نمونه کندل‌های بدون OBV:")
            print(df_missing.to_string(index=False))
    
    conn.close()
    
    # تشخیص
    print("\n" + "=" * 70)
    print("📋 تشخیص:")
    
    if df_stats['missing_obv'].sum() == 0:
        print("✅ این ارز مشکل OBV ندارد")
        return
    
    # اگر بیشتر مشکلات در کندل‌های اولیه است
    first_candle_time = df_stats['first_candle'].min()
    print(f"📅 اولین کندل: {first_candle_time}")
    print("🔍 احتمالاً مشکل در کندل‌های اولیه است (تاریخچه ناقص)")
    
    return df_stats

if __name__ == "__main__":
    print("🔍 بررسی توالی و مشکلات داده‌های دیتابیس")
    print("=" * 70)
    
    # ۱. بررسی کلی
    check_candle_sequence(limit=15)
    
    # ۲. تحلیل عمیق
    analyze_sequence_issues()
    
    # ۳. بررسی یک ارز خاص (اختیاری)
    # coin_to_check = "1190"  # مثلاً یک ارز با 100% مشکل
    # fix_specific_coin(coin_to_check)