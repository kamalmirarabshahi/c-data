"""
🕐 بروزرسان ۲۴ ساعته - محاسبه آمار ۲۴ ساعته
مهم: هیچ جدولی ایجاد نمی‌کند، فقط UPDATE روی crypto_coins
نسخه اصلاح شده - رفع خطای Import
"""

from typing import List, Dict, Any, Optional, Tuple
from datetime import datetime, timedelta
import numpy as np
import logging
import sys
import os

# FIX: اضافه کردن مسیر scripts به sys.path
current_file_dir = os.path.dirname(os.path.abspath(__file__))
scripts_dir = os.path.dirname(os.path.dirname(current_file_dir))  # دو سطح بالا!

if scripts_dir not in sys.path:
    sys.path.insert(0, scripts_dir)

# حالا importهای دیگه
from config_manager import get_database_path, get, get_timeframes
# ایجاد لاگر برای این ماژول
logger = logging.getLogger(__name__)

class CommonUtils:
    """کلاس کمکی برای عملیات مشترک"""
    
    @staticmethod
    def parse_datetime(dt_str):
        """تبدیل رشته تاریخ به datetime"""
        try:
            # فرمت‌های مختلف
            formats = [
                '%Y-%m-%d %H:%M:%S',
                '%Y-%m-%dT%H:%M:%S',
                '%Y-%m-%dT%H:%M:%S.%f'
            ]
            
            for fmt in formats:
                try:
                    return datetime.strptime(dt_str, fmt)
                except ValueError:
                    continue
            return None
        except Exception:
            return None
    
    @staticmethod
    def calculate_percentage_change(old_value, new_value):
        """محاسبه درصد تغییر"""
        if old_value == 0:
            return 0
        return ((new_value - old_value) / abs(old_value)) * 100
    
    @staticmethod
    def get_database_connection():
        """ایجاد اتصال به دیتابیس"""
        try:
            import sqlite3
            conn = sqlite3.connect('data/crypto_master.db')
            return conn
        except Exception as e:
            logger.error(f"خطا در اتصال به دیتابیس: {e}")
            return None
    
    @staticmethod
    def check_table_exists(conn, table_name):
        """بررسی وجود جدول"""
        try:
            cursor = conn.cursor()
            cursor.execute(f"SELECT name FROM sqlite_master WHERE type='table' AND name='{table_name}'")
            return cursor.fetchone() is not None
        except Exception:
            return False
    
    @staticmethod
    def execute_query(conn, query, params=None, fetch=False):
        """اجرای کوئری"""
        try:
            cursor = conn.cursor()
            if params:
                cursor.execute(query, params)
            else:
                cursor.execute(query)
            
            if fetch:
                return cursor.fetchall()
            else:
                conn.commit()
                return cursor
        except Exception as e:
            logger.error(f"خطا در اجرای کوئری: {e}")
            return None

class TwentyFourHourUpdater:
    """محاسبه و بروزرسانی آمار ۲۴ ساعته"""
    
    def __init__(self):
        logger.info("TwentyFourHourUpdater راه‌اندازی شد")
    
    def calculate_24h_stats_from_candles(self, candles: List[Dict[str, Any]]) -> Dict[str, Any]:
        """محاسبه آمار ۲۴ ساعته از کندل‌ها"""
        try:
            if not candles:
                logger.warning("لیست کندل‌ها برای محاسبه آمار ۲۴ ساعته خالی است")
                return {}
            
            # مرتب کردن کندل‌ها بر اساس زمان
            sorted_candles = sorted(candles, key=lambda x: x.get('open_time', ''))
            
            if not sorted_candles:
                return {}
            
            # تعیین بازه زمانی ۲۴ ساعت گذشته
            twenty_four_hours_ago = datetime.now() - timedelta(hours=24)
            
            # فیلتر کندل‌های ۲۴ ساعت گذشته
            recent_candles = []
            for candle in sorted_candles:
                open_time = candle.get('open_time')
                if not open_time:
                    continue
                
                candle_time = CommonUtils.parse_datetime(str(open_time))
                if candle_time and candle_time >= twenty_four_hours_ago:
                    recent_candles.append(candle)
            
            if not recent_candles:
                logger.warning("هیچ کندلی در ۲۴ ساعت گذشته یافت نشد")
                return {}
            
            # استخراج داده‌ها
            open_prices = [c.get('open_price') for c in recent_candles if c.get('open_price')]
            close_prices = [c.get('close_price') for c in recent_candles if c.get('close_price')]
            high_prices = [c.get('high_price') for c in recent_candles if c.get('high_price')]
            low_prices = [c.get('low_price') for c in recent_candles if c.get('low_price')]
            volumes = [c.get('volume') for c in recent_candles if c.get('volume')]
            
            if not open_prices or not close_prices:
                return {}
            
            # محاسبه آمار
            first_price = open_prices[0]
            last_price = close_prices[-1]
            
            price_change = last_price - first_price
            price_change_percent = CommonUtils.calculate_percentage_change(first_price, last_price)
            
            high_24h = max(high_prices) if high_prices else 0
            low_24h = min(low_prices) if low_prices else 0
            volume_24h = sum(volumes) if volumes else 0
            
            # محاسبه VWAP (Volume Weighted Average Price)
            vwap = self._calculate_vwap(recent_candles)
            
            # محاسبه تعداد کندل‌ها در ۲۴ ساعت
            candle_count_24h = len(recent_candles)
            
            # محاسبه درصد تغییر نسبت به ۲۴ ساعت قبل
            if len(close_prices) >= 2:
                oldest_close = close_prices[0]
                newest_close = close_prices[-1]
                change_from_start = CommonUtils.calculate_percentage_change(oldest_close, newest_close)
            else:
                change_from_start = price_change_percent
            
            stats = {
                'price_change_24h': round(price_change, 4),
                'price_change_percent_24h': round(price_change_percent, 2),
                'high_24h': round(high_24h, 4),
                'low_24h': round(low_24h, 4),
                'volume_24h': round(volume_24h, 2),
                'vwap_24h': round(vwap, 4) if vwap else None,
                'current_price': round(last_price, 4),
                'candle_count_24h': candle_count_24h,
                'change_from_start_24h': round(change_from_start, 2),
                'avg_volume_24h': round(volume_24h / max(1, candle_count_24h), 2),
                'price_range_24h': round(high_24h - low_24h, 4),
                'price_range_percent_24h': round(((high_24h - low_24h) / low_24h * 100), 2) if low_24h > 0 else 0
            }
            
            logger.debug(f"آمار ۲۴ ساعته محاسبه شد: تغییر قیمت {price_change_percent}%")
            return stats
            
        except Exception as e:
            logger.error(f"خطا در محاسبه آمار ۲۴ ساعته: {e}")
            return {}
    
    def _calculate_vwap(self, candles: List[Dict[str, Any]]) -> Optional[float]:
        """محاسبه VWAP (Volume Weighted Average Price)"""
        try:
            if not candles:
                return None
            
            total_volume_value = 0
            total_volume = 0
            
            for candle in candles:
                high = candle.get('high_price', 0)
                low = candle.get('low_price', 0)
                close = candle.get('close_price', 0)
                volume = candle.get('volume', 0)
                
                # قیمت معمول (Typical Price)
                typical_price = (high + low + close) / 3
                
                total_volume_value += typical_price * volume
                total_volume += volume
            
            if total_volume == 0:
                return None
            
            vwap = total_volume_value / total_volume
            return vwap
            
        except Exception as e:
            logger.debug(f"خطا در محاسبه VWAP: {e}")
            return None
    
    def update_coin_24h_stats(self, coin_id: int, stats: Dict[str, Any]) -> bool:
        """بروزرسانی آمار ۲۴ ساعته در جدول crypto_coins"""
        try:
            if not stats:
                logger.warning(f"هیچ آمار ۲۴ ساعته‌ای برای ارز {coin_id} وجود ندارد")
                return False
            
            conn = CommonUtils.get_database_connection()
            if not conn:
                return False
            
            # بررسی وجود جدول
            if not CommonUtils.check_table_exists(conn, 'crypto_coins'):
                logger.error("جدول crypto_coins وجود ندارد")
                conn.close()
                return False
            
            # ساخت کوئری UPDATE
            query = """
                UPDATE crypto_coins 
                SET current_price = ?,
                    price_change_24h = ?,
                    price_change_percent_24h = ?,
                    high_24h = ?,
                    low_24h = ?,
                    volume_24h = ?,
                    last_updated = CURRENT_TIMESTAMP
                WHERE id = ?
            """
            
            params = (
                stats.get('current_price', 0),
                stats.get('price_change_24h', 0),
                stats.get('price_change_percent_24h', 0),
                stats.get('high_24h', 0),
                stats.get('low_24h', 0),
                stats.get('volume_24h', 0),
                coin_id
            )
            
            cursor = CommonUtils.execute_query(conn, query, params)
            conn.close()
            
            if cursor:
                logger.info(f"آمار ۲۴ ساعته ارز {coin_id} آپدیت شد: {stats.get('price_change_percent_24h', 0)}%")
                return True
            else:
                logger.warning(f"آپدیت آمار ۲۴ ساعته ارز {coin_id} ناموفق بود")
                return False
                
        except Exception as e:
            logger.error(f"خطا در آپدیت آمار ۲۴ ساعته ارز {coin_id}: {e}")
            return False
    
    def process_coin_24h_stats(self, coin_id: int, coin_symbol: str = "") -> Dict[str, Any]:
        """پردازش کامل آمار ۲۴ ساعته برای یک ارز"""
        try:
            # دریافت کندل‌های ۲۴ ساعت گذشته - اصلاح خطای Import
            # از این به جای Import مستقیم استفاده می‌کنیم
            from candle_processor import CandleProcessor
            
            candle_processor = CandleProcessor()
            candles = candle_processor.get_candles_for_coin(coin_symbol, limit=288)  # 288 کندل = 24 ساعت برای 5 دقیقه
            
            if not candles:
                return {
                    'coin_id': coin_id,
                    'symbol': coin_symbol,
                    'success': False,
                    'error': 'هیچ کندلی یافت نشد',
                    'stats': {}
                }
            
            # محاسبه آمار
            stats = self.calculate_24h_stats_from_candles(candles)
            
            if not stats:
                return {
                    'coin_id': coin_id,
                    'symbol': coin_symbol,
                    'success': False,
                    'error': 'محاسبه آمار ناموفق بود',
                    'stats': {}
                }
            
            # بروزرسانی در دیتابیس
            update_success = self.update_coin_24h_stats(coin_id, stats)
            
            result = {
                'coin_id': coin_id,
                'symbol': coin_symbol,
                'success': update_success,
                'stats': stats,
                'candles_used': len(candles)
            }
            
            if update_success:
                logger.info(f"آمار ۲۴ ساعته ارز {coin_symbol or coin_id} پردازش شد: تغییر {stats.get('price_change_percent_24h', 0)}%")
            else:
                logger.warning(f"پردازش آمار ۲۴ ساعته ارز {coin_symbol or coin_id} ناموفق بود")
            
            return result
            
        except Exception as e:
            logger.error(f"خطا در پردازش آمار ۲۴ ساعته ارز {coin_id}: {e}")
            return {
                'coin_id': coin_id,
                'symbol': coin_symbol,
                'success': False,
                'error': str(e),
                'stats': {}
            }
    
    def get_market_cap_info(self, coin_id: int) -> Optional[Dict[str, Any]]:
        """دریافت اطلاعات مارکت‌کپ ارز"""
        try:
            conn = CommonUtils.get_database_connection()
            if not conn:
                return None
            
            query = """
                SELECT symbol, current_price, market_cap, market_cap_rank, 
                       circulating_supply, total_supply
                FROM crypto_coins 
                WHERE id = ?
            """
            
            result = CommonUtils.execute_query(conn, query, (coin_id,), fetch=True)
            conn.close()
            
            if result and len(result) > 0:
                return dict(result[0])
            
            return None
            
        except Exception as e:
            logger.error(f"خطا در دریافت اطلاعات مارکت‌کپ: {e}")
            return None
    
    def calculate_market_cap_change(self, current_price: float, circulating_supply: float, 
                                   previous_price: float) -> Dict[str, float]:
        """محاسبه تغییر مارکت‌کپ"""
        try:
            if not circulating_supply or not previous_price:
                return {}
            
            current_market_cap = current_price * circulating_supply
            previous_market_cap = previous_price * circulating_supply
            
            market_cap_change = current_market_cap - previous_market_cap
            market_cap_change_percent = CommonUtils.calculate_percentage_change(
                previous_market_cap, current_market_cap
            )
            
            return {
                'current_market_cap': round(current_market_cap, 2),
                'previous_market_cap': round(previous_market_cap, 2),
                'market_cap_change': round(market_cap_change, 2),
                'market_cap_change_percent': round(market_cap_change_percent, 2)
            }
            
        except Exception as e:
            logger.error(f"خطا در محاسبه تغییر مارکت‌کپ: {e}")
            return {}
    
    def batch_update_24h_stats(self, coin_stats_list: List[Dict[str, Any]]) -> Dict[str, Any]:
        """بروزرسانی دسته‌ای آمار ۲۴ ساعته"""
        try:
            if not coin_stats_list:
                return {'success': True, 'updated': 0, 'failed': 0, 'total': 0}
            
            total_coins = len(coin_stats_list)
            successful_updates = 0
            failed_updates = 0
            
            logger.info(f"شروع بروزرسانی دسته‌ای آمار ۲۴ ساعته برای {total_coins} ارز...")
            
            results = []
            for i, coin_data in enumerate(coin_stats_list):
                coin_id = coin_data.get('coin_id')
                stats = coin_data.get('stats', {})
                
                if not coin_id or not stats:
                    logger.warning(f"ارز {i}: داده ناقص")
                    failed_updates += 1
                    continue
                
                success = self.update_coin_24h_stats(coin_id, stats)
                
                if success:
                    successful_updates += 1
                else:
                    failed_updates += 1
                
                results.append({
                    'coin_id': coin_id,
                    'success': success,
                    'symbol': coin_data.get('symbol', '')
                })
                
                # نمایش پیشرفت
                if (i + 1) % 5 == 0 or (i + 1) == total_coins:
                    logger.info(f"پیشرفت آپدیت آمار: {i + 1}/{total_coins}")
            
            summary = {
                'success': failed_updates == 0,
                'updated': successful_updates,
                'failed': failed_updates,
                'total': total_coins,
                'success_rate': (successful_updates / total_coins * 100) if total_coins > 0 else 0,
                'results': results
            }
            
            logger.info(f"بروزرسانی آمار ۲۴ ساعته کامل شد: {successful_updates}/{total_coins} موفق")
            return summary
            
        except Exception as e:
            logger.error(f"خطا در بروزرسانی دسته‌ای آمار: {e}")
            return {'success': False, 'error': str(e)}