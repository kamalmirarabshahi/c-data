"""
signal_generator.py - تولید سیگنال‌های معاملاتی
تاریخ: 2025-12-21
هدف: تولید سیگنال از اندیکاتورها
ورودی: اندیکاتورها از دیتابیس
خروجی: سیگنال‌های ذخیره شده
"""

import json
from datetime import datetime, timedelta
import logging

# ایمپورت config_manager در ابتدای فایل
try:
    from config_manager import get, get_signal_config
    CONFIG_LOADED = True
except ImportError:
    CONFIG_LOADED = False

logger = logging.getLogger(__name__)


class SignalGenerator:
    """تولیدکننده سیگنال‌های معاملاتی"""
    
    def __init__(self, db_manager=None):
        self.db = db_manager
        self._load_config()
        
    def _load_config(self):
        """بارگذاری تنظیمات از config_manager"""
        try:
            if CONFIG_LOADED:
                # دریافت تنظیمات سیگنال
                signal_config = get_signal_config()
                
                self.min_confidence = signal_config.get('min_confidence_score', 70)
                self.risk_per_trade = signal_config.get('risk_per_trade_percent', 2.0)
                self.default_stop_loss = signal_config.get('default_stop_loss_percent', 2.0)
                self.default_take_profit = signal_config.get('default_take_profit_percent', 4.0)
                self.max_active_signals = signal_config.get('max_active_signals', 10)
                
                logger.info(f"✅ تنظیمات سیگنال بارگذاری شد (حداقل اطمینان: {self.min_confidence}%)")
            else:
                # مقادیر پیش‌فرض
                self.min_confidence = 70
                self.risk_per_trade = 2.0
                self.default_stop_loss = 2.0
                self.default_take_profit = 4.0
                self.max_active_signals = 10
                logger.warning("⚠️ از تنظیمات پیش‌فرض سیگنال استفاده می‌شود")
                
        except Exception as e:
            logger.error(f"❌ خطا در بارگذاری تنظیمات سیگنال: {e}")
            # مقادیر پیش‌فرض
            self.min_confidence = 70
            self.risk_per_trade = 2.0
            self.default_stop_loss = 2.0
            self.default_take_profit = 4.0
            self.max_active_signals = 10
    
    def generate_all_signals(self, min_confidence=None):
        """
        تولید سیگنال برای تمام ارزها
        پارامترها:
            min_confidence: حداقل امتیاز اطمینان (اختیاری)
        """
        if not self.db:
            logger.error("❌ دیتابیس متصل نیست")
            return False
        
        try:
            # استفاده از مقدار ورودی یا تنظیمات
            confidence_threshold = min_confidence if min_confidence is not None else self.min_confidence
            
            # بررسی تعداد سیگنال‌های فعال
            active_count = self._count_active_signals()
            if active_count >= self.max_active_signals:
                logger.warning(f"⚠️ حداکثر سیگنال فعال ({self.max_active_signals})، تولید جدید متوقف شد")
                return False
            
            # دریافت آخرین اندیکاتورهای هر ارز
            logger.info(f"🔍 جستجوی سیگنال‌ها با اطمینان ≥{confidence_threshold}%...")
            
            query = """
            SELECT ti.*, cc.symbol as coin_symbol, cc.current_price
            FROM (
                SELECT coin_id, MAX(timestamp) as latest_timestamp
                FROM technical_indicators
                WHERE timestamp > datetime('now', '-1 hour')
                GROUP BY coin_id
            ) latest
            JOIN technical_indicators ti 
                ON ti.coin_id = latest.coin_id 
                AND ti.timestamp = latest.latest_timestamp
            JOIN crypto_coins cc ON cc.id = ti.coin_id
            WHERE ti.signal_score >= ?
                AND ti.signal_hint IN ('STRONG_BUY', 'BUY', 'STRONG_SELL', 'SELL')
            ORDER BY ti.signal_score DESC
            LIMIT ?
            """
            
            limit = self.max_active_signals - active_count
            indicators_list = self.db.fetch_all(query, (confidence_threshold, limit))
            
            if not indicators_list:
                logger.info("⚠️ هیچ سیگنال با اطمینان کافی یافت نشد")
                return True
            
            logger.info(f"📊 شروع تولید سیگنال برای {len(indicators_list)} ارز...")
            
            success_count = 0
            
            for i, indicator in enumerate(indicators_list, 1):
                try:
                    symbol = indicator['coin_symbol']
                    signal_score = indicator['signal_score']
                    signal_hint = indicator['signal_hint']
                    current_price = indicator['current_price']
                    
                    # بررسی عدم وجود سیگنال فعال مشابه
                    if self._has_active_signal(indicator['coin_id'], signal_hint):
                        logger.debug(f"  [{i}] ⚠️ سیگنال فعال برای {symbol} وجود دارد")
                        continue
                    
                    # تولید سیگنال
                    signal = self._generate_signal_from_indicator(indicator, current_price)
                    
                    if signal:
                        # ذخیره سیگنال
                        if self._save_signal(signal):
                            success_count += 1
                            logger.info(f"  [{i}] ✅ سیگنال {signal['signal_type']} برای {symbol} تولید شد (امتیاز: {signal_score})")
                        else:
                            logger.warning(f"  [{i}] ⚠️ ذخیره سیگنال {symbol} ناموفق بود")
                    else:
                        logger.debug(f"  [{i}] ⚠️ تولید سیگنال {symbol} ناموفق بود")
                        
                except Exception as e:
                    logger.error(f"  [{i}] ❌ خطا در تولید سیگنال: {str(e)[:50]}")
                    continue
            
            logger.info(f"✅ تولید سیگنال کامل شد: {success_count}/{len(indicators_list)} سیگنال موفق")
            return success_count > 0
            
        except Exception as e:
            logger.error(f"❌ خطا در تولید سیگنال خودکار: {e}")
            return False
    
    def _count_active_signals(self) -> int:
        """شمارش سیگنال‌های فعال"""
        try:
            query = "SELECT COUNT(*) FROM trading_signals WHERE status = 'ACTIVE'"
            return self.db.fetch_scalar(query) or 0
        except Exception as e:
            logger.error(f"❌ خطا در شمارش سیگنال‌های فعال: {e}")
            return 0
    
    def _has_active_signal(self, coin_id: int, signal_type: str) -> bool:
        """بررسی وجود سیگنال فعال مشابه"""
        try:
            query = """
            SELECT COUNT(*) FROM trading_signals 
            WHERE coin_id = ? AND status = 'ACTIVE' 
            AND signal_type LIKE ?
            """
            
            # تطبیق نوع سیگنال
            if 'BUY' in signal_type:
                pattern = '%BUY%'
            elif 'SELL' in signal_type:
                pattern = '%SELL%'
            else:
                pattern = signal_type
            
            count = self.db.fetch_scalar(query, (coin_id, pattern))
            return count and count > 0
            
        except Exception as e:
            logger.error(f"❌ خطا در بررسی سیگنال‌های فعال: {e}")
            return False
    
    def _generate_signal_from_indicator(self, indicator: dict, current_price: float) -> dict:
        """تولید سیگنال از یک اندیکاتور"""
        try:
            signal_score = indicator['signal_score']
            signal_hint = indicator['signal_hint']
            coin_id = indicator['coin_id']
            symbol = indicator.get('coin_symbol', 'UNKNOWN')
            
            # تعیین نوع سیگنال
            signal_type = signal_hint
            if signal_hint == 'STRONG_BUY':
                category = 'TREND_FOLLOW'
                confidence = min(95, signal_score + 10)
            elif signal_hint == 'BUY':
                category = 'TREND_FOLLOW'
                confidence = signal_score
            elif signal_hint == 'STRONG_SELL':
                category = 'REVERSAL'
                confidence = min(95, 100 - signal_score + 10)
            elif signal_hint == 'SELL':
                category = 'REVERSAL'
                confidence = 100 - signal_score
            else:
                return None  # سیگنال خنثی
            
            # محاسبه قیمت‌های مدیریت ریسک
            if 'BUY' in signal_type:
                entry_price = current_price * 1.001  # کمی بالاتر از قیمت فعلی
                stop_loss = entry_price * (1 - self.default_stop_loss / 100)
                take_profit_1 = entry_price * (1 + self.default_take_profit / 100)
                take_profit_2 = entry_price * (1 + (self.default_take_profit * 1.5) / 100)
                take_profit_3 = entry_price * (1 + (self.default_take_profit * 2) / 100)
            else:  # SELL signals
                entry_price = current_price * 0.999  # کمی پایین‌تر از قیمت فعلی
                stop_loss = entry_price * (1 + self.default_stop_loss / 100)
                take_profit_1 = entry_price * (1 - self.default_take_profit / 100)
                take_profit_2 = entry_price * (1 - (self.default_take_profit * 1.5) / 100)
                take_profit_3 = entry_price * (1 - (self.default_take_profit * 2) / 100)
            
            # محاسبه نسبت ریسک به ریوارد
            risk = abs(entry_price - stop_loss)
            reward = abs(take_profit_1 - entry_price)
            risk_reward = round(reward / risk, 2) if risk > 0 else 1.0
            
            # ایجاد دیکشنری سیگنال
            signal = {
                'coin_id': coin_id,
                'symbol': symbol,
                'timeframe': '5m',
                'signal_time': datetime.now().isoformat(),
                'signal_type': signal_type,
                'signal_category': category,
                'entry_price': round(entry_price, 4),
                'current_price': round(current_price, 4),
                'stop_loss': round(stop_loss, 4),
                'take_profit_1': round(take_profit_1, 4),
                'take_profit_2': round(take_profit_2, 4),
                'take_profit_3': round(take_profit_3, 4),
                'risk_reward_ratio': risk_reward,
                'position_size_percent': self.risk_per_trade,
                'confidence_score': confidence,
                'indicators_json': json.dumps({
                    'rsi_14': indicator.get('rsi_14'),
                    'macd_histogram': indicator.get('macd_histogram'),
                    'signal_score': signal_score,
                    'signal_hint': signal_hint
                }),
                'status': 'ACTIVE'
            }
            
            return signal
            
        except Exception as e:
            logger.error(f"❌ خطا در تولید سیگنال: {e}")
            return None
    
    def _save_signal(self, signal: dict) -> bool:
        """ذخیره سیگنال در دیتابیس"""
        try:
            # بررسی وجود جدول
            if not self.db.table_exists('trading_signals'):
                self._create_signals_table()
            
            # ذخیره سیگنال
            query = """
            INSERT INTO trading_signals 
            (coin_id, symbol, timeframe, signal_time, signal_type, signal_category,
             entry_price, current_price, stop_loss, take_profit_1, take_profit_2, take_profit_3,
             risk_reward_ratio, position_size_percent, confidence_score,
             indicators_json, status, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """
            
            params = (
                signal['coin_id'],
                signal['symbol'],
                signal['timeframe'],
                signal['signal_time'],
                signal['signal_type'],
                signal['signal_category'],
                signal['entry_price'],
                signal['current_price'],
                signal['stop_loss'],
                signal['take_profit_1'],
                signal['take_profit_2'],
                signal['take_profit_3'],
                signal['risk_reward_ratio'],
                signal['position_size_percent'],
                signal['confidence_score'],
                signal['indicators_json'],
                signal['status'],
                datetime.now().isoformat()
            )
            
            result = self.db.execute_query(query, params)
            return result > 0
            
        except Exception as e:
            logger.error(f"❌ خطا در ذخیره سیگنال: {e}")
            return False
    
    def _create_signals_table(self):
        """ایجاد جدول trading_signals"""
        try:
            create_table_query = """
            CREATE TABLE IF NOT EXISTS trading_signals (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                coin_id INTEGER NOT NULL,
                symbol TEXT NOT NULL,
                timeframe TEXT NOT NULL DEFAULT '5m',
                signal_time TIMESTAMP NOT NULL,
                
                -- نوع سیگنال
                signal_type TEXT NOT NULL,
                signal_category TEXT,
                
                -- قیمت‌ها
                entry_price REAL NOT NULL,
                current_price REAL NOT NULL,
                stop_loss REAL,
                take_profit_1 REAL,
                take_profit_2 REAL,
                take_profit_3 REAL,
                
                -- مدیریت ریسک
                risk_reward_ratio REAL,
                position_size_percent REAL DEFAULT 2.0,
                confidence_score INTEGER,
                
                -- اندیکاتورهای لحظه سیگنال
                indicators_json TEXT,
                
                -- وضعیت
                status TEXT DEFAULT 'ACTIVE',
                
                -- متادیتا
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                
                -- محدودیت‌ها
                FOREIGN KEY (coin_id) REFERENCES crypto_coins (id),
                CHECK (signal_type IN ('STRONG_BUY', 'BUY', 'NEUTRAL', 'SELL', 'STRONG_SELL')),
                CHECK (confidence_score BETWEEN 0 AND 100)
            )
            """
            
            self.db.execute_query(create_table_query)
            
            # ایجاد ایندکس
            indexes = [
                "CREATE INDEX IF NOT EXISTS idx_signals_active ON trading_signals(symbol, status, signal_time DESC)",
                "CREATE INDEX IF NOT EXISTS idx_signals_type ON trading_signals(signal_type, signal_time DESC)",
                "CREATE INDEX IF NOT EXISTS idx_signals_confidence ON trading_signals(confidence_score DESC, signal_time DESC)",
                "CREATE INDEX IF NOT EXISTS idx_signals_coin ON trading_signals(coin_id, signal_time DESC)"
            ]
            
            for index_query in indexes:
                self.db.execute_query(index_query)
            
            logger.info("✅ جدول trading_signals ایجاد شد")
            return True
            
        except Exception as e:
            logger.error(f"❌ خطا در ایجاد جدول سیگنال: {e}")
            return False
    
    def close_expired_signals(self, hours: int = 24):
        """بستن سیگنال‌های منقضی شده"""
        try:
            time_threshold = (datetime.now() - timedelta(hours=hours)).isoformat()
            
            query = """
            UPDATE trading_signals 
            SET status = 'EXPIRED', 
                updated_at = ? 
            WHERE status = 'ACTIVE' 
            AND signal_time < ?
            """
            
            updated = self.db.execute_query(query, (datetime.now().isoformat(), time_threshold))
            
            if updated > 0:
                logger.info(f"✅ {updated} سیگنال منقضی بسته شد")
            
            return updated
            
        except Exception as e:
            logger.error(f"❌ خطا در بستن سیگنال‌های منقضی: {e}")
            return 0


# تست مستقل
if __name__ == "__main__":
    print("🔧 تست فایل signal_generator.py")
    print("=" * 50)
    
    from database_manager import DatabaseManager
    
    try:
        # ایجاد نمونه دیتابیس
        db = DatabaseManager()
        
        # ایجاد نمونه signal_generator
        generator = SignalGenerator(db)
        
        print("📊 تنظیمات بارگذاری شده:")
        print(f"  • حداقل اطمینان: {generator.min_confidence}%")
        print(f"  • ریسک هر معامله: {generator.risk_per_trade}%")
        print(f"  • حد ضرر پیش‌فرض: {generator.default_stop_loss}%")
        print(f"  • حد سود پیش‌فرض: {generator.default_take_profit}%")
        print(f"  • حداکثر سیگنال فعال: {generator.max_active_signals}")
        
        # تست تولید سیگنال
        print("\n🧪 تست تولید سیگنال:")
        success = generator.generate_all_signals(min_confidence=70)
        
        if success:
            print("✅ تست تولید سیگنال موفق بود")
        else:
            print("⚠️ هیچ سیگنالی تولید نشد")
        
        # بستن اتصال
        db.close()
        
    except Exception as e:
        print(f"❌ خطا در تست: {e}")
    
    print("=" * 50)