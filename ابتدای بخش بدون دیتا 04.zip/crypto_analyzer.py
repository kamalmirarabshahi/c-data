# fixed_binance_filter.py
import requests
import pandas as pd
from datetime import datetime

def get_filtered_binance_coins_fixed():
    """
    دریافت و فیلتر ارزهای بایننس - نسخه اصلاح شده
    """
    print("📡 دریافت ارزهای بایننس با فیلتر...")
    print("=" * 80)
    
    try:
        # 1. دریافت داده از بایننس
        url = "https://api.binance.com/api/v3/ticker/24hr"
        response = requests.get(url, timeout=20)
        
        if response.status_code != 200:
            print(f"❌ خطای API: {response.status_code}")
            return pd.DataFrame()
        
        all_tickers = response.json()
        
        # 2. پردازش و فیلتر
        filtered_data = []
        
        for ticker in all_tickers:
            symbol = ticker.get('symbol', '')
            
            # فقط جفت‌های USDT
            if symbol.endswith('USDT'):
                try:
                    # تبدیل مقادیر
                    current_price = float(ticker.get('lastPrice', 0))
                    volume_24h = float(ticker.get('quoteVolume', 0))  # حجم به USDT
                    high_24h = float(ticker.get('highPrice', 0))
                    low_24h = float(ticker.get('lowPrice', 0))
                    price_change_percent = float(ticker.get('priceChangePercent', 0))
                    
                    # اعمال فیلترها
                    if (current_price >= 0.1 and 
                        volume_24h >= 2000000):
                        # مارکت‌کپ تخمینی (حجم × قیمت میانگین وزنی)
                        weighted_price = float(ticker.get('weightedAvgPrice', current_price))
                        market_cap_estimate = volume_24h  # یا volume_24h * weighted_price برای دقت بیشتر
                        
                        if market_cap_estimate >= 50000000:
                            coin_info = {
                                'symbol': symbol,
                                'current_price': current_price,
                                'volume_24h_usdt': volume_24h,
                                'market_cap_estimate': market_cap_estimate,
                                'high_24h': high_24h,
                                'low_24h': low_24h,
                                'price_change_percent': price_change_percent,
                                'last_updated': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                            }
                            filtered_data.append(coin_info)
                            
                except (ValueError, TypeError, KeyError) as e:
                    continue  # اگر خطا در تبدیل داده بود، رد شو
        
        # 3. تبدیل به DataFrame
        if not filtered_data:
            print("❌ هیچ ارزی با معیارهای مشخص شده یافت نشد!")
            return pd.DataFrame()
        
        df = pd.DataFrame(filtered_data)
        
        print(f"✅ {len(df)} ارز پیدا شد:")
        print(f"   - قیمت: ≥ $0.1")
        print(f"   - حجم 24h: ≥ $2,000,000")
        print(f"   - مارکت‌کپ تخمینی: ≥ $50,000,000")
        
        # 4. مرتب‌سازی بر اساس حجم
        df = df.sort_values('volume_24h_usdt', ascending=False).reset_index(drop=True)
        
        return df
        
    except Exception as e:
        print(f"❌ خطای کلی: {e}")
        return pd.DataFrame()

def save_results(df, filename="filtered_binance_coins.csv"):
    """
    ذخیره نتایج و نمایش خلاصه
    """
    if df.empty:
        print("❌ هیچ داده‌ای برای ذخیره وجود ندارد!")
        return
    
    # ذخیره فایل CSV
    df.to_csv(filename, index=False, encoding='utf-8-sig')
    print(f"\n📄 فایل ذخیره شد: {filename}")
    
    # نمایش آماری
    print("\n📊 آمار کلی:")
    print(f"   تعداد ارزها: {len(df)}")
    print(f"   میانگین قیمت: ${df['current_price'].mean():.4f}")
    print(f"   میانگین حجم 24h: ${df['volume_24h_usdt'].mean()/1e6:.1f}M")
    print(f"   مجموع حجم: ${df['volume_24h_usdt'].sum()/1e9:.2f}B")
    print(f"   بیشترین تغییر مثبت: {df['price_change_percent'].max():.2f}%")
    print(f"   بیشترین تغییر منفی: {df['price_change_percent'].min():.2f}%")
    
    # نمایش 20 ارز برتر
    print("\n🏆 20 ارز برتر بر اساس حجم:")
    print("=" * 100)
    print(f"{'#':<3} {'نماد':<10} {'قیمت':<12} {'حجم 24h':<15} {'مارکت‌کپ':<15} {'تغییر':<10} {'بازه قیمت':<25}")
    print("-" * 100)
    
    for i, (idx, row) in enumerate(df.head(20).iterrows(), 1):
        volume_m = row['volume_24h_usdt'] / 1e6
        market_cap_m = row['market_cap_estimate'] / 1e6
        price_range = f"${row['low_24h']:.4f}-${row['high_24h']:.4f}"
        
        print(f"{i:<3} {row['symbol']:<10} ${row['current_price']:<11.4f} "
              f"${volume_m:<13.1f}M "
              f"${market_cap_m:<13.1f}M "
              f"{row['price_change_percent']:<9.2f}% "
              f"{price_range:<25}")

def export_for_cycle_01(df, output_file="coins_for_cycle_01.csv"):
    """
    ذخیره در فرمت مناسب برای cycle_01_coin_filter.py
    """
    if df.empty:
        return
    
    # انتخاب و مرتب‌سازی ستون‌ها برای سازگاری با cycle_01
    export_df = df[[
        'symbol', 'current_price', 'volume_24h_usdt', 
        'market_cap_estimate', 'high_24h', 'low_24h',
        'price_change_percent', 'last_updated'
    ]].copy()
    
    # تغییر نام ستون‌ها برای سازگاری
    export_df = export_df.rename(columns={
        'symbol': 'symbol',
        'current_price': 'price',
        'volume_24h_usdt': 'volume_24h',
        'market_cap_estimate': 'market_cap',
        'high_24h': 'high_24h',
        'low_24h': 'low_24h',
        'price_change_percent': 'price_change_24h',
        'last_updated': 'last_updated'
    })
    
    export_df.to_csv(output_file, index=False, encoding='utf-8-sig')
    print(f"\n📁 فایل برای cycle_01 ذخیره شد: {output_file}")
    
    return export_df

# اجرای اصلی
if __name__ == "__main__":
    print("🚀 دریافت و فیلتر ارزهای بایننس")
    print("=" * 80)
    
    # دریافت داده
    df = get_filtered_binance_coins_fixed()
    
    if not df.empty:
        # ذخیره و نمایش
        save_results(df, "filtered_coins.csv")
        
        # ذخیره برای استفاده در cycle_01
        export_for_cycle_01(df, "coins_for_filtering.csv")
        
        # گزینه‌های بیشتر
        print("\n" + "=" * 80)
        print("🎯 گزینه‌های بیشتر:")
        print("1. نمایش همه ارزها")
        print("2. ذخیره در فایل Excel")
        print("3. فیلتر بیشتر بر اساس قیمت")
        print("4. خروج")
        
        choice = input("\nانتخاب کنید (1-4): ")
        
        if choice == "1":
            print("\n📋 لیست کامل ارزها:")
            pd.set_option('display.max_rows', None)
            pd.set_option('display.width', None)
            print(df[['symbol', 'current_price', 'volume_24h_usdt', 'price_change_percent']].to_string())
            
        elif choice == "2":
            excel_file = "filtered_coins.xlsx"
            df.to_excel(excel_file, index=False)
            print(f"✅ فایل Excel ذخیره شد: {excel_file}")
            
        elif choice == "3":
            min_price = float(input("حداقل قیمت (دلار): ") or "0.1")
            max_price = float(input("حداکثر قیمت (دلار): ") or "10000")
            
            filtered = df[(df['current_price'] >= min_price) & (df['current_price'] <= max_price)]
            print(f"\n🔍 {len(filtered)} ارز در بازه ${min_price}-${max_price}")
            save_results(filtered, f"filtered_price_{min_price}_{max_price}.csv")
    
    print("\n" + "=" * 80)
    print("✅ عملیات کامل شد!")