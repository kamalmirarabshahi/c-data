#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ایجاد فایل JSON و HTML از فهرست ارزهای فعال (is_active < 5) با سورت بر اساس رتبه بازار
"""

import sqlite3
import os
import json
from datetime import datetime
from pathlib import Path

def get_active_coins():
    """دریافت ارزهای فعال از دیتابیس"""
    
    # مسیر دیتابیس اصلی
    db_file = r"C:\Users\Kamal\Desktop\py-prg\git\c-data\data\crypto_master.db"
    
    if not os.path.exists(db_file):
        print(f"❌ دیتابیس {db_file} یافت نشد!")
        return []
    
    try:
        conn = sqlite3.connect(db_file)
        cursor = conn.cursor()
        
        # بررسی وجود جدول و ستون is_active
        cursor.execute("PRAGMA table_info(crypto_coins)")
        columns_info = cursor.fetchall()
        column_names = [col[1] for col in columns_info]
        
        if 'is_active' not in column_names:
            print("❌ ستون is_active در جدول یافت نشد!")
            return []
        
        # کوئری برای دریافت ارزهای فعال (is_active < 5)
        query = """
        SELECT 
            id,
            symbol,
            base_asset,
            coin_name,
            current_price,
            price_change_24h,
            price_change_percent_24h,
            high_24h,
            low_24h,
            volume_24h,
            market_cap,
            market_cap_rank,
            circulating_supply,
            total_supply,
            max_supply,
            last_updated,
            is_active
        FROM crypto_coins 
        WHERE is_active < 5
        AND market_cap_rank != 9999
        ORDER BY market_cap_rank ASC
        """
        
        cursor.execute(query)
        rows = cursor.fetchall()
        
        # تبدیل به لیست دیکشنری
        coins = []
        for row in rows:
            coin = {
                'id': row[0],
                'symbol': row[1],
                'base_asset': row[2],
                'coin_name': row[3],
                'current_price': row[4],
                'price_change_24h': row[5],
                'price_change_percent_24h': row[6],
                'high_24h': row[7],
                'low_24h': row[8],
                'volume_24h': row[9],
                'market_cap': row[10],
                'market_cap_rank': row[11],
                'circulating_supply': row[12],
                'total_supply': row[13],
                'max_supply': row[14],
                'last_updated': row[15],
                'is_active': row[16]
            }
            coins.append(coin)
        
        conn.close()
        return coins
        
    except Exception as e:
        print(f"❌ خطا در خواندن دیتابیس: {e}")
        return []

def format_number(num):
    """قالب‌بندی اعداد برای نمایش بهتر"""
    if num is None:
        return None
    
    try:
        num = float(num)
        
        # فرمت‌بندی بر اساس بزرگی عدد
        if abs(num) >= 1_000_000_000:
            return f"${num/1_000_000_000:.2f}B"
        elif abs(num) >= 1_000_000:
            return f"${num/1_000_000:.2f}M"
        elif abs(num) >= 1_000:
            return f"${num/1_000:.1f}K"
        elif abs(num) >= 1:
            return f"${num:,.2f}"
        elif abs(num) >= 0.01:
            return f"${num:.4f}"
        else:
            return f"${num:.8f}"
    except:
        return str(num)

def generate_json_file(coins, output_dir):
    """ایجاد فایل JSON"""
    
    # آماده‌سازی داده‌ها برای JSON
    json_data = {
        'metadata': {
            'generated_at': datetime.now().isoformat(),
            'total_coins': len(coins),
            'description': 'لیست ارزهای فعال (is_active < 5) مرتب شده بر اساس رتبه بازار'
        },
        'coins': coins
    }
    
    # ایجاد مسیر خروجی
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    
    json_file = output_dir / "active_coins.json"
    
    try:
        with open(json_file, 'w', encoding='utf-8') as f:
            json.dump(json_data, f, ensure_ascii=False, indent=2)
        print(f"✅ فایل JSON ایجاد شد: {json_file}")
        return json_file
    except Exception as e:
        print(f"❌ خطا در ایجاد فایل JSON: {e}")
        return None

def generate_html_file(json_file_path, output_dir):
    """ایجاد فایل HTML از داده‌های JSON"""
    
    try:
        # خواندن داده‌های JSON
        with open(json_file_path, 'r', encoding='utf-8') as f:
            json_data = json.load(f)
        
        coins = json_data['coins']
        metadata = json_data['metadata']
        
        # ایجاد HTML
        html_content = f"""
        <!DOCTYPE html>
        <html lang="fa" dir="rtl">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>فهرست ارزهای فعال - {metadata['total_coins']} ارز</title>
            <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
            <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
            <style>
                body {{
                    font-family: 'Vazir', 'Tahoma', sans-serif;
                    background-color: #f8f9fa;
                    padding-top: 20px;
                }}
                .header {{
                    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                    color: white;
                    border-radius: 10px;
                    padding: 20px;
                    margin-bottom: 30px;
                }}
                .coin-card {{
                    transition: transform 0.3s, box-shadow 0.3s;
                    border: none;
                    border-radius: 15px;
                    overflow: hidden;
                }}
                .coin-card:hover {{
                    transform: translateY(-5px);
                    box-shadow: 0 10px 20px rgba(0,0,0,0.1);
                }}
                .positive {{
                    color: #28a745;
                }}
                .negative {{
                    color: #dc3545;
                }}
                .rank-badge {{
                    font-size: 0.9em;
                    padding: 5px 10px;
                    border-radius: 20px;
                }}
                .table-responsive {{
                    border-radius: 10px;
                    overflow: hidden;
                    box-shadow: 0 5px 15px rgba(0,0,0,0.08);
                }}
                .active-status {{
                    font-size: 0.8em;
                    padding: 3px 8px;
                    border-radius: 12px;
                }}
                .active-1 {{ background-color: #d4edda; color: #155724; }}
                .active-2 {{ background-color: #cce5ff; color: #004085; }}
                .active-3 {{ background-color: #fff3cd; color: #856404; }}
                .active-4 {{ background-color: #f8d7da; color: #721c24; }}
            </style>
        </head>
        <body>
            <div class="container">
                <!-- هدر -->
                <div class="header text-center">
                    <h1 class="mb-3"><i class="bi bi-currency-exchange"></i> فهرست ارزهای فعال</h1>
                    <p class="lead mb-0">تعداد ارزها: {metadata['total_coins']} | تاریخ تولید: {metadata['generated_at'][:19].replace('T', ' ')}</p>
                    <small class="text-light">ارزهای با is_active < 5 | مرتب شده بر اساس رتبه بازار</small>
                </div>

                <!-- کارت آمار -->
                <div class="row mb-4">
                    <div class="col-md-3">
                        <div class="card text-center bg-primary text-white p-3">
                            <h5><i class="bi bi-coin"></i> تعداد ارزها</h5>
                            <h3>{metadata['total_coins']}</h3>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card text-center bg-success text-white p-3">
                            <h5><i class="bi bi-graph-up"></i> میانگین حجم</h5>
                            <h3>{format_number(sum(coin['volume_24h'] or 0 for coin in coins) / len(coins) if coins else 0)}</h3>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card text-center bg-info text-white p-3">
                            <h5><i class="bi bi-star"></i> بهترین رتبه</h5>
                            <h3>#{min(coin['market_cap_rank'] for coin in coins) if coins else 'N/A'}</h3>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card text-center bg-warning text-white p-3">
                            <h5><i class="bi bi-activity"></i> وضعیت فعال</h5>
                            <h3>is_active < 5</h3>
                        </div>
                    </div>
                </div>

                <!-- جدول ارزها -->
                <div class="card">
                    <div class="card-header bg-dark text-white">
                        <h5 class="mb-0"><i class="bi bi-table"></i> جدول ارزهای فعال</h5>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-hover table-striped mb-0">
                            <thead class="table-dark">
                                <tr>
                                    <th width="60">#</th>
                                    <th>نماد</th>
                                    <th>نام ارز</th>
                                    <th>قیمت</th>
                                    <th>تغییر ۲۴h</th>
                                    <th>حجم ۲۴h</th>
                                    <th>مارکت‌کپ</th>
                                    <th>وضعیت</th>
                                    <th>بروزرسانی</th>
                                </tr>
                            </thead>
                            <tbody>
        """
        
        # اضافه کردن ردیف‌های جدول
        for coin in coins:
            change_class = "positive" if (coin['price_change_percent_24h'] or 0) > 0 else "negative"
            change_icon = "bi-arrow-up" if (coin['price_change_percent_24h'] or 0) > 0 else "bi-arrow-down"
            change_sign = "+" if (coin['price_change_percent_24h'] or 0) > 0 else ""
            
            html_content += f"""
                                <tr>
                                    <td><span class="badge rank-badge bg-secondary">#{coin['market_cap_rank']}</span></td>
                                    <td>
                                        <strong>{coin['base_asset'] or coin['symbol']}</strong>
                                        <br><small class="text-muted">{coin['symbol']}</small>
                                    </td>
                                    <td>{coin['coin_name'] or 'نامشخص'}</td>
                                    <td><strong>{format_number(coin['current_price'])}</strong></td>
                                    <td class="{change_class}">
                                        <i class="bi {change_icon}"></i>
                                        {change_sign}{coin['price_change_percent_24h'] or 0:.2f}%
                                    </td>
                                    <td>{format_number(coin['volume_24h'])}</td>
                                    <td>{format_number(coin['market_cap'])}</td>
                                    <td><span class="active-status active-{coin['is_active']}">is_active={coin['is_active']}</span></td>
                                    <td><small>{coin['last_updated'][:19].replace('T', ' ') if coin['last_updated'] else 'نامشخص'}</small></td>
                                </tr>
            """
        
        html_content += """
                            </tbody>
                        </table>
                    </div>
                </div>

                <!-- فوتر -->
                <footer class="mt-5 text-center text-muted">
                    <p>
                        <i class="bi bi-code-slash"></i> تولید شده توسط سیستم مدیریت ارزهای دیجیتال
                        <br>
                        <small>آخرین بروزرسانی: """ + metadata['generated_at'][:19].replace('T', ' ') + """</small>
                    </p>
                </footer>
            </div>

            <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
            <script>
                // قابلیت جستجو ساده
                document.addEventListener('DOMContentLoaded', function() {{
                    console.log('فهرست ارزهای فعال با موفقیت بارگیری شد.');
                    
                    // هایلایت ردیف‌ها روی hover
                    const rows = document.querySelectorAll('tbody tr');
                    rows.forEach(row => {{
                        row.addEventListener('mouseenter', function() {{
                            this.style.backgroundColor = '#f8f9fa';
                        }});
                        row.addEventListener('mouseleave', function() {{
                            this.style.backgroundColor = '';
                        }});
                    }});
                }});
            </script>
        </body>
        </html>
        """
        
        # ذخیره فایل HTML
        output_dir = Path(output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)
        
        html_file = output_dir / "active_coins.html"
        
        with open(html_file, 'w', encoding='utf-8') as f:
            f.write(html_content)
        
        print(f"✅ فایل HTML ایجاد شد: {html_file}")
        return html_file
        
    except Exception as e:
        print(f"❌ خطا در ایجاد فایل HTML: {e}")
        return None

def generate_data_files():
    """تابع اصلی برای تولید فایل‌های JSON و HTML"""
    
    print("=" * 70)
    print("🔄 سیستم تولید فهرست ارزهای فعال")
    print("=" * 70)
    
    # مسیر خروجی
    output_dir = r"C:\Users\Kamal\Desktop\py-prg\git\c-data\output"
    
    # دریافت داده‌ها از دیتابیس
    print("📊 در حال دریافت داده‌ها از دیتابیس...")
    coins = get_active_coins()
    
    if not coins:
        print("❌ هیچ ارز فعالی یافت نشد!")
        return
    
    print(f"✅ {len(coins)} ارز فعال یافت شد")
    
    # ایجاد فایل JSON
    print("\n📄 در حال ایجاد فایل JSON...")
    json_file = generate_json_file(coins, output_dir)
    
    if json_file:
        # ایجاد فایل HTML
        print("\n🌐 در حال ایجاد فایل HTML...")
        html_file = generate_html_file(json_file, output_dir)
        
        if html_file:
            print("\n" + "=" * 70)
            print("🎉 عملیات با موفقیت کامل شد!")
            print("=" * 70)
            print(f"📁 فایل JSON: {json_file}")
            print(f"📁 فایل HTML: {html_file}")
            print(f"📊 تعداد ارزها: {len(coins)}")
            print(f"📅 تاریخ تولید: {datetime.now().strftime('%Y/%m/%d %H:%M:%S')}")
            print("=" * 70)
            
            # نمایش نمونه داده
            print("\n📋 نمونه داده‌ها:")
            print("-" * 50)
            for i, coin in enumerate(coins[:5], 1):
                print(f"{i}. {coin['base_asset']} ({coin['coin_name']}) - رتبه: #{coin['market_cap_rank']} - قیمت: {format_number(coin['current_price'])}")

if __name__ == "__main__":
    generate_data_files()