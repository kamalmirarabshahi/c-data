#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
نمایش فهرست ارزها با قابلیت سورت بر اساس volume_24h یا price_change_percent_24h
"""

import sqlite3
import os
from datetime import datetime

def check_table_structure(db_file):
    """بررسی ساختار جدول و ستون‌های موجود"""
    
    try:
        conn = sqlite3.connect(db_file)
        cursor = conn.cursor()
        
        # بررسی وجود جدول crypto_coins
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='crypto_coins'")
        if not cursor.fetchone():
            print("❌ جدول crypto_coins یافت نشد!")
            return None
        
        # دریافت ستون‌های جدول
        cursor.execute("PRAGMA table_info(crypto_coins)")
        columns_info = cursor.fetchall()
        
        column_names = [col[1] for col in columns_info]
        
        conn.close()
        
        print(f"✅ جدول crypto_coins با {len(column_names)} ستون یافت شد")
        print("📋 ستون‌های موجود:")
        for i, col in enumerate(column_names, 1):
            print(f"  {i:2}. {col}")
        
        return column_names
        
    except Exception as e:
        print(f"❌ خطا در بررسی ساختار جدول: {e}")
        return None

def display_coins_sorted(sort_by=1, limit=None):
    """
    نمایش ارزها با قابلیت سورت بر اساس دو فیلد مختلف
    
    پارامترها:
    ----------
    sort_by : int
        1 = سورت بر اساس volume_24h (نزولی)
        2 = سورت بر اساس price_change_percent_24h (نزولی)
    limit : int یا None
        تعداد رکوردهای مورد نیاز (None = همه)
    """
    
    # مسیر دیتابیس اصلی
    db_file = r"C:\Users\Kamal\Desktop\py-prg\git\c-data\data\crypto_master.db"
    
    if not os.path.exists(db_file):
        print(f"❌ دیتابیس {db_file} یافت نشد!")
        print("📂 جستجوی دیتابیس در مسیرهای دیگر...")
        
        # جستجو در مسیرهای احتمالی
        possible_paths = [
            r"C:\Users\Kamal\Desktop\py-prg\git\c-data\crypto_master.db",
            r"C:\Users\Kamal\Desktop\py-prg\git\c-data\data\crypto_data.db",
            "./data/crypto_master.db",
            "./crypto_master.db"
        ]
        
        for path in possible_paths:
            if os.path.exists(path):
                db_file = path
                print(f"✅ دیتابیس در {path} یافت شد")
                break
        else:
            print("❌ دیتابیس یافت نشد!")
            return []
    
    # بررسی ساختار جدول
    table_columns = check_table_structure(db_file)
    if not table_columns:
        return []
    
    try:
        conn = sqlite3.connect(db_file)
        cursor = conn.cursor()
        
        # لیست ستون‌های مورد درخواست
        requested_columns = ['base_asset', 'coin_name', 'current_price', 
                           'price_change_percent_24h', 'volume_24h', 
                           'market_cap_rank', 'last_update']
        
        # بررسی وجود ستون‌های درخواستی و جایگزینی برای ستون‌های missing
        selected_columns = []
        column_aliases = {}  # نگاشت نام نمایشی به نام واقعی ستون
        
        for req_col in requested_columns:
            if req_col in table_columns:
                selected_columns.append(req_col)
                column_aliases[req_col] = req_col
            else:
                # جستجوی ستون مشابه
                found = False
                similar_names = []
                
                # جستجوی نام‌های مشابه
                for table_col in table_columns:
                    if req_col.lower() in table_col.lower() or table_col.lower() in req_col.lower():
                        similar_names.append(table_col)
                
                if similar_names:
                    # استفاده از اولین ستون مشابه
                    selected_columns.append(similar_names[0])
                    column_aliases[req_col] = similar_names[0]
                    print(f"⚠️  ستون {req_col} موجود نیست، استفاده از {similar_names[0]}")
                    found = True
                
                if not found:
                    print(f"⚠️  ستون {req_col} موجود نیست و جایگزینی یافت نشد!")
        
        if not selected_columns:
            print("❌ هیچ یک از ستون‌های مورد نیاز موجود نیست!")
            return []
        
        # بررسی ستون‌های سورت
        sort_columns = {
            1: 'volume_24h',
            2: 'price_change_percent_24h'
        }
        
        if sort_by not in sort_columns:
            sort_by = 1
        
        requested_sort_column = sort_columns[sort_by]
        
        # پیدا کردن ستون سورت واقعی
        if requested_sort_column in table_columns:
            sort_column = requested_sort_column
        else:
            # جستجوی ستون مشابه برای سورت
            sort_found = False
            for table_col in table_columns:
                if requested_sort_column.lower() in table_col.lower():
                    sort_column = table_col
                    sort_found = True
                    print(f"⚠️  ستون {requested_sort_column} برای سورت موجود نیست، استفاده از {sort_column}")
                    break
            
            if not sort_found:
                print(f"⚠️  ستون {requested_sort_column} برای سورت موجود نیست، استفاده از اولین ستون")
                sort_column = table_columns[0]
        
        sort_direction = 'DESC'
        sort_names = {
            1: "حجم معاملات ۲۴ ساعته",
            2: "درصد تغییر قیمت ۲۴ ساعته"
        }
        sort_name = sort_names.get(sort_by, "حجم معاملات ۲۴ ساعته")
        
        # ساخت کوئری
        query = f"""
        SELECT {', '.join(selected_columns)}
        FROM crypto_coins 
        WHERE {sort_column} IS NOT NULL
        ORDER BY {sort_column} {sort_direction}
        """
        
        if limit:
            query += f" LIMIT {limit}"
        
        print(f"\n📝 اجرای کوئری: {query}")
        
        # اجرای کوئری
        cursor.execute(query)
        rows = cursor.fetchall()
        
        conn.close()
        
        # نمایش نتایج
        print("\n" + "=" * 140)
        print("📊 فهرست ارزها با سورت انتخابی")
        print(f"📅 {datetime.now().strftime('%Y/%m/%d %H:%M:%S')}")
        print(f"🗄️  دیتابیس: {os.path.basename(db_file)}")
        print(f"🔢 سورت شده بر اساس: {sort_name} ({sort_column})")
        print(f"📊 تعداد رکوردها: {len(rows)}")
        print("=" * 140)
        
        if not rows:
            print("❌ هیچ داده‌ای برای نمایش وجود ندارد!")
            return selected_columns, rows
        
        # نمایش هدر جدول
        print("\n" + "-" * 140)
        
        # ایجاد هدر بر اساس نام‌های نمایشی
        header = ""
        display_names = {
            'base_asset': 'نماد',
            'coin_name': 'نام ارز',
            'current_price': 'قیمت (USD)',
            'price_change_percent_24h': 'تغییر % 24h',
            'volume_24h': 'حجم 24h',
            'market_cap_rank': 'رتبه',
            'last_update': 'آخرین بروزرسانی'
        }
        
        for req_col in requested_columns:
            if req_col in column_aliases:
                display_name = display_names.get(req_col, req_col)
                if req_col == 'base_asset':
                    header += f"{display_name:10} "
                elif req_col == 'coin_name':
                    header += f"{display_name:25} "
                elif req_col == 'current_price':
                    header += f"{display_name:15} "
                elif req_col == 'price_change_percent_24h':
                    header += f"{display_name:15} "
                elif req_col == 'volume_24h':
                    header += f"{display_name:20} "
                elif req_col == 'market_cap_rank':
                    header += f"{display_name:10} "
                elif req_col == 'last_update':
                    header += f"{display_name:25} "
                else:
                    header += f"{display_name:15} "
        
        print(header)
        print("-" * 140)
        
        # نمایش داده‌ها
        for row in rows:
            row_str = ""
            
            for req_col_idx, req_col in enumerate(requested_columns):
                if req_col in column_aliases:
                    # پیدا کردن اندیس ستون در selected_columns
                    actual_col = column_aliases[req_col]
                    col_idx = selected_columns.index(actual_col)
                    value = row[col_idx]
                    
                    # قالب‌بندی نمایش
                    display_value = format_value(req_col, value)
                    
                    # اضافه کردن به ردیف با عرض مناسب
                    if req_col == 'base_asset':
                        row_str += f"{display_value:10} "
                    elif req_col == 'coin_name':
                        row_str += f"{display_value:25} "
                    elif req_col == 'current_price':
                        row_str += f"{display_value:15} "
                    elif req_col == 'price_change_percent_24h':
                        row_str += f"{display_value:15} "
                    elif req_col == 'volume_24h':
                        row_str += f"{display_value:20} "
                    elif req_col == 'market_cap_rank':
                        row_str += f"{display_value:10} "
                    elif req_col == 'last_update':
                        row_str += f"{display_value:25} "
                    else:
                        row_str += f"{display_value:15} "
            
            print(row_str)
        
        print("-" * 140)
        
        # نمایش آمار
        if rows:
            print("\n📈 آمار کلی:")
            print("-" * 40)
            display_statistics(rows, selected_columns, column_aliases)
        
        return selected_columns, rows
        
    except Exception as e:
        print(f"❌ خطا: {e}")
        import traceback
        traceback.print_exc()
        return [], []

def format_value(column_name, value):
    """قالب‌بندی مقدار بر اساس نوع ستون"""
    
    if value is None:
        return "N/A"
    
    try:
        if column_name == 'current_price':
            price = float(value)
            if price >= 1:
                return f"${price:,.2f}"
            elif price >= 0.0001:
                return f"${price:.6f}"
            else:
                return f"${price:.10f}"
        
        elif column_name == 'price_change_percent_24h':
            change = float(value)
            if change >= 0:
                return f"📈 {change:+.2f}%"
            else:
                return f"📉 {change:.2f}%"
        
        elif column_name == 'volume_24h':
            vol = float(value)
            if vol >= 1000000000:
                return f"${vol/1000000000:,.2f}B"
            elif vol >= 1000000:
                return f"${vol/1000000:,.2f}M"
            elif vol >= 1000:
                return f"${vol/1000:,.1f}K"
            else:
                return f"${vol:,.0f}"
        
        elif column_name == 'market_cap_rank':
            rank = int(value)
            if rank != 9999:
                return f"#{rank}"
            else:
                return "N/A"
        
        elif column_name == 'last_update':
            if isinstance(value, (int, float)):
                if value > 1000000000000:  # میلی‌ثانیه
                    dt = datetime.fromtimestamp(value/1000)
                else:  # ثانیه
                    dt = datetime.fromtimestamp(value)
                return dt.strftime('%Y-%m-%d %H:%M')
            else:
                return str(value)[:25]
        
        elif column_name == 'base_asset':
            return str(value)[:10]
        
        elif column_name == 'coin_name':
            return str(value)[:24] if value else "N/A"
        
        else:
            return str(value)[:20]
            
    except:
        return str(value)[:20]

def display_statistics(rows, selected_columns, column_aliases):
    """نمایش آمار داده‌ها"""
    
    # ایجاد نگاشت معکوس از نام نمایشی به نام واقعی
    reverse_map = {}
    for display_name, actual_name in column_aliases.items():
        if actual_name in selected_columns:
            idx = selected_columns.index(actual_name)
            reverse_map[display_name] = idx
    
    # آمار قیمت
    if 'current_price' in reverse_map:
        price_idx = reverse_map['current_price']
        prices = []
        for row in rows:
            try:
                price = float(row[price_idx])
                if price > 0:
                    prices.append(price)
            except:
                pass
        
        if prices:
            avg_price = sum(prices) / len(prices)
            print(f"💰 میانگین قیمت: ${avg_price:,.2f}")
            print(f"💰 بیشترین قیمت: ${max(prices):,.2f}")
            print(f"💰 کمترین قیمت: ${min(prices):,.2f}")
    
    # آمار تغییرات
    if 'price_change_percent_24h' in reverse_map:
        change_idx = reverse_map['price_change_percent_24h']
        changes = []
        for row in rows:
            try:
                change = float(row[change_idx])
                changes.append(change)
            except:
                pass
        
        if changes:
            positive = [c for c in changes if c > 0]
            negative = [c for c in changes if c < 0]
            print(f"\n📊 ارزهای مثبت: {len(positive)} | ارزهای منفی: {len(negative)}")
            print(f"📈 بیشترین رشد: {max(changes):+.2f}%")
            print(f"📉 بیشترین کاهش: {min(changes):.2f}%")
            print(f"📊 میانگین تغییر: {sum(changes)/len(changes):+.2f}%")
    
    # آمار حجم
    if 'volume_24h' in reverse_map:
        volume_idx = reverse_map['volume_24h']
        volumes = []
        for row in rows:
            try:
                vol = float(row[volume_idx])
                if vol > 0:
                    volumes.append(vol)
            except:
                pass
        
        if volumes:
            avg_volume = sum(volumes) / len(volumes)
            total_volume = sum(volumes)
            print(f"\n💎 میانگین حجم: ${avg_volume:,.0f}")
            print(f"💎 حجم کل: ${total_volume:,.0f}")
            print(f"💎 بیشترین حجم: ${max(volumes):,.0f}")

def main():
    """تابع اصلی"""
    
    print("=" * 80)
    print("📋 سیستم نمایش و سورت ارزهای دیجیتال")
    print("=" * 80)
    print("1️⃣  سورت بر اساس حجم معاملات ۲۴ ساعته")
    print("2️⃣  سورت بر اساس درصد تغییر قیمت ۲۴ ساعته")
    print("=" * 80)
    
    try:
        # دریافت نوع سورت
        sort_input = input("👉 گزینه سورت را انتخاب کنید (1 یا 2): ").strip()
        
        if sort_input not in ['1', '2']:
            print("⚠️  گزینه نامعتبر! از گزینه ۱ استفاده می‌شود")
            sort_by = 1
        else:
            sort_by = int(sort_input)
        
        # دریافت تعداد رکوردها
        limit_input = input("👉 تعداد ارزهای مورد نظر را وارد کنید (خالی = همه): ").strip()
        
        if limit_input:
            limit = int(limit_input)
            if limit <= 0:
                print("⚠️  تعداد باید بزرگتر از صفر باشد")
                return
        else:
            limit = None
        
        # نمایش داده‌ها
        columns, rows = display_coins_sorted(sort_by, limit)
        
        print("\n" + "=" * 80)
        print("✅ عملیات کامل شد")
        print("=" * 80)
        
    except ValueError:
        print("⚠️  ورودی نامعتبر!")
    except Exception as e:
        print(f"❌ خطا: {e}")

if __name__ == "__main__":
    main()
    