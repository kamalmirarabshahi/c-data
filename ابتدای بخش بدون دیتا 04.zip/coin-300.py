"""
تهیه لیست 300 ارز برتر بایننس - فقط جفت‌های USDT با قیمت ≥ 0.001
"""

import sqlite3
import requests
import pandas as pd
from datetime import datetime
from decimal import Decimal, getcontext
import time

# تنظیم دقت Decimal
getcontext().prec = 12

def get_top_300_binance_coins():
    """
    دریافت 300 ارز برتر از بایننس - فقط جفت‌های USDT با قیمت ≥ 0.001
    """
    print("📡 دریافت 300 ارز برتر بایننس (USDT جفت‌ها، قیمت ≥ 0.001)")
    print("=" * 80)
    
    try:
        # 1. دریافت داده از بایننس
        url = "https://api.binance.com/api/v3/ticker/24hr"
        print("📥 در حال دریافت داده از API بایننس...")
        response = requests.get(url, timeout=30)
        
        if response.status_code != 200:
            print(f"❌ خطای API: {response.status_code}")
            return pd.DataFrame()
        
        all_tickers = response.json()
        print(f"✅ {len(all_tickers)} تیکر دریافت شد")
        
        # 2. پردازش فقط جفت‌های USDT
        usdt_coins = []
        skipped_low_price = 0
        skipped_other = 0
        
        for ticker in all_tickers:
            symbol = ticker.get('symbol', '')
            
            # فقط جفت‌های USDT
            if not symbol.endswith('USDT'):
                skipped_other += 1
                continue
            
            try:
                # حذف ارزهای مشکوک (لوریج، فیوچرز و استیبل‌ها)
                base_asset = symbol.replace('USDT', '')
                if any(x in base_asset.upper() for x in ['UP', 'DOWN', 'BULL', 'BEAR', 'LONG', 'SHORT']):
                    skipped_other += 1
                    continue
                
                # حذف استیبل کوین‌های دیگر
                stable_keywords = ['USDC', 'BUSD', 'DAI', 'TUSD', 'FDUSD', 'USD', 'EUR', 'GBP']
                if any(base_asset.upper().endswith(kw) for kw in stable_keywords):
                    skipped_other += 1
                    continue
                
                # تبدیل قیمت
                current_price_raw = ticker.get('lastPrice', '0')
                current_price_dec = Decimal(current_price_raw)
                
                # فیلتر قیمت (حداقل 0.001)
                if current_price_dec < Decimal('0.001'):
                    skipped_low_price += 1
                    continue
                
                # حجم معاملات
                quote_volume_raw = ticker.get('quoteVolume', '0')
                quote_volume_dec = Decimal(quote_volume_raw)
                
                # فیلتر حجم (حداقل 10,000 دلار)
                if quote_volume_dec < Decimal('10000'):
                    continue
                
                # محاسبه تغییرات قیمت
                price_change_raw = ticker.get('priceChange', '0')
                price_change_dec = Decimal(price_change_raw)
                
                if current_price_dec > 0 and price_change_dec != 0:
                    price_change_percent_dec = (price_change_dec / (current_price_dec - price_change_dec)) * 100
                else:
                    price_change_percent_dec = Decimal('0')
                
                # ذخیره اطلاعات
                coin_info = {
                    'symbol': symbol,
                    'base_asset': base_asset,
                    'current_price': float(current_price_dec),
                    'current_price_dec': str(current_price_dec),  # برای دقت
                    'price_change_24h': float(price_change_dec),
                    'price_change_percent_24h': float(price_change_percent_dec),
                    'high_24h': float(Decimal(ticker.get('highPrice', '0'))),
                    'low_24h': float(Decimal(ticker.get('lowPrice', '0'))),
                    'volume_24h': float(Decimal(ticker.get('volume', '0'))),
                    'quote_volume_24h': float(quote_volume_dec),
                    'market_cap': float(quote_volume_dec),  # تخمین از روی حجم
                    'last_updated': datetime.now().isoformat(),
                    'raw_volume': float(quote_volume_dec)  # برای مرتب‌سازی
                }
                
                usdt_coins.append(coin_info)
                    
            except Exception as e:
                print(f"⚠️ خطا در پردازش {symbol}: {e}")
                continue
        
        print(f"\n📊 آمار فیلترینگ:")
        print(f"   - کل تیکرها: {len(all_tickers)}")
        print(f"   - جفت‌های USDT پردازش شده: {len(usdt_coins)}")
        print(f"   - حذف شده بخاطر قیمت < 0.001: {skipped_low_price}")
        print(f"   - حذف شده بخاطر نوع جفت: {skipped_other}")
        
        if not usdt_coins:
            print("❌ هیچ ارز USDT واجد شرایط یافت نشد!")
            return pd.DataFrame()
        
        # 3. تبدیل به DataFrame و مرتب‌سازی
        df = pd.DataFrame(usdt_coins)
        
        # مرتب‌سازی بر اساس حجم معاملات (نزولی)
        df = df.sort_values('raw_volume', ascending=False)
        
        # محدود به 300 ارز برتر
        top_300 = df.head(300).copy()
        
        # تنظیم رتبه‌بندی
        top_300['market_cap_rank'] = range(1, len(top_300) + 1)
        
        print(f"\n🎯 {len(top_300)} ارز USDT برتر (قیمت ≥ 0.001) انتخاب شدند")
        
        # نمایش نمونه
        print("\n📈 نمونه 10 ارز برتر:")
        print("-" * 80)
        for idx, row in top_300.head(10).iterrows():
            price = row['current_price']
            if price >= 1:
                price_str = f"${price:,.4f}"
            elif price >= 0.1:
                price_str = f"${price:.6f}"
            else:
                price_str = f"${price:.8f}"
            
            volume_str = f"${row['quote_volume_24h']/1e6:.2f}M"
            print(f"{row['market_cap_rank']:3}. {row['symbol']:15} "
                  f"قیمت: {price_str:15} حجم: {volume_str:10} "
                  f"تغییر: {row['price_change_percent_24h']:+.2f}%")
        
        return top_300
        
    except Exception as e:
        print(f"❌ خطای کلی: {e}")
        import traceback
        traceback.print_exc()
        return pd.DataFrame()

def get_database_structure(db_path):
    """دریافت ساختار جدول"""
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        cursor.execute("PRAGMA table_info(crypto_coins)")
        columns = cursor.fetchall()
        column_names = [col[1] for col in columns]
        conn.close()
        return column_names
    except:
        return []

def save_to_database(df, db_path):
    """ذخیره در دیتابیس"""
    if df.empty:
        print("❌ داده‌ای برای ذخیره وجود ندارد!")
        return False
    
    print("\n💾 ذخیره در دیتابیس...")
    
    try:
        # دریافت ساختار دیتابیس
        db_columns = get_database_structure(db_path)
        if not db_columns:
            print("❌ جدول crypto_coins یافت نشد!")
            return False
        
        # تطابق ستون‌ها
        available_columns = [col for col in db_columns if col in df.columns and col != 'id']
        
        print(f"📋 فیلدهای قابل ذخیره ({len(available_columns)}):")
        print("   " + ", ".join(available_columns))
        
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # 1. غیرفعال کردن همه کوین‌های قبلی
        cursor.execute("UPDATE crypto_coins SET is_active = 5 WHERE is_active = 1")
        print(f"♻️  کوین‌های قبلی غیرفعال شدند")
        
        # 2. درج یا به‌روزرسانی
        new_count = 0
        update_count = 0
        
        for _, row in df.iterrows():
            try:
                # بررسی وجود
                cursor.execute("SELECT id FROM crypto_coins WHERE symbol = ?", (row['symbol'],))
                existing = cursor.fetchone()
                
                values = [row.get(col, None) for col in available_columns]
                
                if existing:
                    # به‌روزرسانی
                    set_clause = ", ".join([f"{col} = ?" for col in available_columns])
                    cursor.execute(f"""
                        UPDATE crypto_coins 
                        SET {set_clause}, is_active = 1, last_updated = ?
                        WHERE symbol = ?
                    """, values + [row['last_updated'], row['symbol']])
                    update_count += 1
                else:
                    # درج جدید
                    placeholders = ", ".join(['?'] * len(available_columns))
                    cursor.execute(f"""
                        INSERT INTO crypto_coins ({', '.join(available_columns)}, is_active)
                        VALUES ({placeholders}, 1)
                    """, values)
                    new_count += 1
                    
            except Exception as e:
                print(f"⚠️ خطا در {row.get('symbol', 'Unknown')}: {e}")
                continue
        
        conn.commit()
        
        # آمار نهایی
        cursor.execute("SELECT COUNT(*) FROM crypto_coins WHERE is_active = 1")
        active_count = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM crypto_coins")
        total_count = cursor.fetchone()[0]
        
        conn.close()
        
        print(f"\n✅ عملیات ذخیره‌سازی کامل شد:")
        print(f"   - {new_count} کوین جدید اضافه شد")
        print(f"   - {update_count} کوین به‌روزرسانی شد")
        print(f"   - {active_count} کوین فعال در دیتابیس")
        print(f"   - {total_count} کل کوین‌های موجود")
        
        return True
        
    except Exception as e:
        print(f"❌ خطا در ذخیره دیتابیس: {e}")
        import traceback
        traceback.print_exc()
        return False

def export_report(df, filename="top_300_binance_coins.csv"):
    """ایجاد گزارش CSV"""
    if df.empty:
        return
    
    # انتخاب فیلدهای مهم
    report_fields = ['symbol', 'base_asset', 'current_price', 'price_change_percent_24h',
                    'high_24h', 'low_24h', 'volume_24h', 'quote_volume_24h',
                    'market_cap', 'market_cap_rank', 'last_updated']
    
    report_df = df[[col for col in report_fields if col in df.columns]].copy()
    report_df = report_df.sort_values('market_cap_rank')
    report_df.to_csv(filename, index=False, encoding='utf-8-sig')
    
    print(f"\n📄 گزارش CSV ذخیره شد: {filename}")
    
    # نمایش خلاصه
    print("\n🏆 15 ارز برتر:")
    print("=" * 120)
    print(f"{'رتبه':<5} {'نماد':<12} {'قیمت (USDT)':<20} {'تغییر %':<10} {'حجم 24h':<15} {'قیمت بالا':<15} {'قیمت پایین':<15}")
    print("-" * 120)
    
    for idx, row in report_df.head(15).iterrows():
        price = row['current_price']
        if price >= 100:
            price_fmt = f"${price:,.0f}"
        elif price >= 1:
            price_fmt = f"${price:,.2f}"
        elif price >= 0.01:
            price_fmt = f"${price:.4f}"
        else:
            price_fmt = f"${price:.8f}"
        
        high_fmt = f"${row['high_24h']:.8f}"[:15]
        low_fmt = f"${row['low_24h']:.8f}"[:15]
        volume_fmt = f"${row['quote_volume_24h']/1e6:.1f}M"
        
        print(f"{row['market_cap_rank']:<5} {row['symbol']:<12} "
              f"{price_fmt:<20} {row['price_change_percent_24h']:>+7.2f}% "
              f"{volume_fmt:<15} {high_fmt:<15} {low_fmt:<15}")

# اجرای اصلی
if __name__ == "__main__":
    print("🚀 سیستم جمع‌آوری 300 ارز برتر بایننس")
    print("📌 شرط: فقط جفت‌های USDT با قیمت ≥ 0.001")
    print("=" * 80)
    
    db_path = r"C:\Users\Kamal\Desktop\py-prg\git\c-data\data\crypto_master.db"
    
    # مرحله 1: دریافت داده
    print("\n" + "=" * 80)
    print("📥 مرحله 1: دریافت داده از بایننس")
    df = get_top_300_binance_coins()
    
    if df.empty:
        print("\n❌ دریافت داده ناموفق بود!")
        exit(1)
    
    # مرحله 2: ذخیره در دیتابیس
    print("\n" + "=" * 80)
    print("💾 مرحله 2: ذخیره در دیتابیس")
    if not save_to_database(df, db_path):
        print("\n❌ ذخیره در دیتابیس ناموفق بود!")
        exit(1)
    
    # مرحله 3: گزارش
    print("\n" + "=" * 80)
    print("📊 مرحله 3: ایجاد گزارش")
    export_report(df)
    
    # آمار نهایی
    print("\n" + "=" * 80)
    print("📈 آمار نهایی:")
    print(f"   تعداد کل: {len(df)} ارز")
    print(f"   محدوده قیمت: ${df['current_price'].min():.8f} - ${df['current_price'].max():.2f}")
    print(f"   میانگین قیمت: ${df['current_price'].mean():.6f}")
    print(f"   مجموع حجم 24h: ${df['quote_volume_24h'].sum()/1e9:.2f}B")
    
    print("\n" + "=" * 80)
    print("✅ عملیات با موفقیت کامل شد!")
    print("=" * 80)