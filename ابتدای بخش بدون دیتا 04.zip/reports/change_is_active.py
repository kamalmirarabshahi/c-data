# change_is_active.py (نسخه اصلاح شده)
import sqlite3
import argparse
import sys
from pathlib import Path
from datetime import datetime

def change_is_active(db_path, symbols_str, new_status, dry_run=False):
    """
    تغییر وضعیت is_active برای لیست ارزها
    """
    # پارس کردن نمادها
    symbols = [symbol.strip().upper() for symbol in symbols_str.split(',') if symbol.strip()]
    
    if not symbols:
        print("❌ هیچ نمادی وارد نشده است")
        return False
    
    # بررسی وضعیت جدید
    if not isinstance(new_status, int) or new_status < 0 or new_status > 5:
        print(f"❌ وضعیت نامعتبر: {new_status}. باید عددی بین 0 تا 5 باشد.")
        return False
    
    # بررسی وجود فایل دیتابیس
    db_file = Path(db_path)
    if not db_file.exists():
        print(f"❌ فایل دیتابیس یافت نشد: {db_path}")
        return False
    
    print("=" * 60)
    print(f"🔧 تغییر وضعیت is_active ارزها")
    print("=" * 60)
    print(f"📁 مسیر دیتابیس: {db_path}")
    print(f"📋 تعداد نمادها: {len(symbols)}")
    print(f"🎯 وضعیت جدید: {new_status}")
    print(f"🧪 حالت آزمایشی: {'بله' if dry_run else 'خیر'}")
    print("=" * 60)
    
    try:
        # اتصال به دیتابیس
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # ابتدا وضعیت فعلی ارزها را بررسی کنیم
        print("\n🔍 بررسی ارزهای موجود:")
        print("-" * 40)
        
        existing_symbols = []
        non_existing_symbols = []
        
        for symbol in symbols:
            cursor.execute("SELECT symbol, is_active FROM crypto_coins WHERE symbol = ?", (symbol,))
            result = cursor.fetchone()
            
            if result:
                existing_symbols.append((symbol, result[1]))  # (symbol, current_status)
                print(f"   ✓ {symbol}: وضعیت فعلی = {result[1]}")
            else:
                non_existing_symbols.append(symbol)
                print(f"   ✗ {symbol}: یافت نشد")
        
        if non_existing_symbols:
            print(f"\n⚠️  {len(non_existing_symbols)} نماد یافت نشد:")
            for symbol in non_existing_symbols:
                print(f"   - {symbol}")
            
            # جستجوی نمادهای مشابه
            print(f"\n🔍 جستجوی نمادهای مشابه:")
            for symbol in non_existing_symbols:
                cursor.execute("SELECT symbol FROM crypto_coins WHERE symbol LIKE ? LIMIT 3", (f"%{symbol}%",))
                similar = cursor.fetchall()
                if similar:
                    print(f"   برای '{symbol}': {', '.join([s[0] for s in similar])}")
        
        if not existing_symbols:
            print("\n❌ هیچ یک از نمادها در دیتابیس یافت نشد")
            conn.close()
            return False
        
        # نمایش خلاصه تغییرات
        print(f"\n📊 خلاصه تغییرات:")
        print("-" * 40)
        
        status_changes = {}
        for symbol, current_status in existing_symbols:
            if current_status == new_status:
                status_changes[symbol] = 'بدون تغییر'
            else:
                status_changes[symbol] = f"{current_status} → {new_status}"
        
        for symbol, change in status_changes.items():
            print(f"   {symbol}: {change}")
        
        # اگر حالت آزمایشی است، همینجا متوقف شو
        if dry_run:
            print(f"\n✅ حالت آزمایشی - هیچ تغییری اعمال نشد")
            print(f"   تعداد ارزهای قابل تغییر: {len([c for c in status_changes.values() if '→' in c])}")
            conn.close()
            return True
        
        # تایید کاربر
        print(f"\n⚠️  آیا مطمئن هستید که می‌خواهید تغییرات را اعمال کنید؟")
        print(f"   این عمل غیرقابل بازگشت است!")
        
        confirmation = input("   برای تأیید 'yes' را وارد کنید: ").strip().lower()
        
        if confirmation != 'yes':
            print("❌ تغییرات لغو شد")
            conn.close()
            return False
        
        # اعمال تغییرات
        print(f"\n🔄 در حال اعمال تغییرات...")
        
        changed_count = 0
        
        # بررسی وجود ستون updated_at
        cursor.execute("PRAGMA table_info(crypto_coins)")
        columns = [col[1] for col in cursor.fetchall()]
        has_updated_at = 'updated_at' in columns
        
        for symbol, current_status in existing_symbols:
            if current_status != new_status:
                if has_updated_at:
                    # اگر ستون updated_at وجود دارد
                    cursor.execute(
                        "UPDATE crypto_coins SET is_active = ?, updated_at = datetime('now') WHERE symbol = ?",
                        (new_status, symbol)
                    )
                else:
                    # اگر ستون updated_at وجود ندارد
                    cursor.execute(
                        "UPDATE crypto_coins SET is_active = ? WHERE symbol = ?",
                        (new_status, symbol)
                    )
                changed_count += 1
        
        conn.commit()
        
        # ثبت لاگ تغییرات
        try:
            cursor.execute('''
            CREATE TABLE IF NOT EXISTS status_change_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                symbol TEXT,
                old_status INTEGER,
                new_status INTEGER,
                change_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                notes TEXT
            )
            ''')
            
            for symbol, current_status in existing_symbols:
                if current_status != new_status:
                    cursor.execute('''
                    INSERT INTO status_change_log (symbol, old_status, new_status, notes)
                    VALUES (?, ?, ?, ?)
                    ''', (symbol, current_status, new_status, "دستور تغییر وضعیت"))
            conn.commit()
        except Exception as e:
            print(f"⚠️  خطا در ثبت لاگ (بی‌خطر): {e}")
        
        print(f"\n✅ تغییرات با موفقیت اعمال شد")
        print(f"   • تعداد ارزهای تغییر یافته: {changed_count}")
        print(f"   • تعداد ارزهای بدون تغییر: {len(existing_symbols) - changed_count}")
        
        # نمایش وضعیت نهایی
        print(f"\n📋 وضعیت نهایی:")
        print("-" * 40)
        
        placeholders = ','.join(['?'] * len(existing_symbols))
        cursor.execute(f"""
            SELECT symbol, is_active 
            FROM crypto_coins 
            WHERE symbol IN ({placeholders})
            ORDER BY symbol
        """, [s[0] for s in existing_symbols])
        
        final_status = cursor.fetchall()
        for symbol, status in final_status:
            print(f"   {symbol}: is_active = {status}")
        
        conn.close()
        
        # ذخیره گزارش
        save_report(existing_symbols, new_status, changed_count, db_path)
        
        return True
        
    except sqlite3.Error as e:
        print(f"❌ خطای دیتابیس: {e}")
        return False
    except Exception as e:
        print(f"❌ خطای غیرمنتظره: {e}")
        return False

def save_report(existing_symbols, new_status, changed_count, db_path):
    """
    ذخیره گزارش تغییرات در فایل متنی
    """
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    report_file = f"status_change_report_{timestamp}.txt"
    
    try:
        with open(report_file, 'w', encoding='utf-8') as f:
            f.write("=" * 60 + "\n")
            f.write("📋 گزارش تغییر وضعیت is_active\n")
            f.write("=" * 60 + "\n\n")
            
            f.write(f"📅 تاریخ: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
            f.write(f"📁 دیتابیس: {db_path}\n")
            f.write(f"🎯 وضعیت جدید: {new_status}\n")
            f.write(f"🔄 تعداد تغییرات: {changed_count}\n\n")
            
            f.write("📊 لیست ارزها:\n")
            f.write("-" * 40 + "\n")
            
            for symbol, old_status in existing_symbols:
                if old_status == new_status:
                    status_text = f"بدون تغییر ({old_status})"
                else:
                    status_text = f"{old_status} → {new_status}"
                f.write(f"• {symbol}: {status_text}\n")
            
            f.write("\n" + "=" * 60 + "\n")
            f.write("✅ تغییرات با موفقیت ثبت شد\n")
            f.write("=" * 60 + "\n")
        
        print(f"\n📄 گزارش در فایل ذخیره شد: {report_file}")
        
    except Exception as e:
        print(f"⚠️  خطا در ذخیره گزارش: {e}")

def main():
    """
    تابع اصلی برای اجرای از خط فرمان
    """
    parser = argparse.ArgumentParser(
        description='تغییر وضعیت is_active برای لیست ارزها',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
مثال‌ها:
  python change_is_active.py BTCUSDT,ETHUSDT,BNBUSDT 1
  python change_is_active.py "0GUSDT, 2ZUSDT, 1000CATUSDT" 5 --dry-run
  python change_is_active.py "BTCUSDT, ETHUSDT" 0 --db custom.db
        """
    )
    
    parser.add_argument(
        'symbols',
        help='نمادهای ارزها با کاما جداکننده (مثال: BTCUSDT,ETHUSDT,BNBUSDT)'
    )
    
    parser.add_argument(
        'status',
        type=int,
        help='وضعیت جدید is_active (عدد 0 تا 5)'
    )
    
    parser.add_argument(
        '--db',
        default=r'data\crypto_master.db',
        help='مسیر فایل دیتابیس (پیش‌فرض: data/crypto_master.db)'
    )
    
    parser.add_argument(
        '--dry-run',
        action='store_true',
        help='حالت آزمایشی - بدون اعمال تغییرات واقعی'
    )
    
    args = parser.parse_args()
    
    # اجرای تابع اصلی
    success = change_is_active(
        db_path=args.db,
        symbols_str=args.symbols,
        new_status=args.status,
        dry_run=args.dry_run
    )
    
    # کد خروج
    sys.exit(0 if success else 1)

if __name__ == "__main__":
    main()