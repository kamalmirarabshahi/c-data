# report_unconventional_coins_final.py
import sqlite3
import pandas as pd
from pathlib import Path
from datetime import datetime
import re

def identify_unconventional_coins(db_path):
    """
    شناسایی ارزهای نامتعارف با شرایط:
    1. ❌ عدد در ابتدای نماد: مشکل دارد
    2. ✅ عدد در وسط نماد: مشکلی ندارد
    3. ✅ نماد و نام یکسان: مشکلی ندارد
    4. ✅ نام یا نماد خالی: مشکلی ندارد
    """
    try:
        db_file = Path(db_path)
        if not db_file.exists():
            print(f"❌ فایل دیتابیس یافت نشد: {db_path}")
            return None
        
        print(f"🔍 شناسایی ارزهای نامتعارف (فقط عدد اول)")
        print(f"📅 تاریخ گزارش: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        print("=" * 70)
        
        conn = sqlite3.connect(db_path)
        
        # دریافت تمام داده‌ها
        query = """
        SELECT 
            id,
            symbol,
            base_asset,
            coin_name,
            current_price,
            is_active,
            created_at,
            volume_24h,
            market_cap
        FROM crypto_coins;
        """
        
        df = pd.read_sql_query(query, conn)
        conn.close()
        
        if df.empty:
            print("❌ داده‌ای یافت نشد")
            return None
        
        print(f"📊 تحلیل {len(df):,} ارز...")
        
        # ==================== فیلترهای اصلی ====================
        
        unconventional_coins = []
        
        for idx, row in df.iterrows():
            flags = []
            symbol = str(row['symbol']).upper()
            coin_name = str(row['coin_name']) if pd.notna(row['coin_name']) else ""
            
            # ============ تنها فیلتر اصلی: عدد در ابتدای نماد ============
            
            # حذف USDT/BUSD/... از انتهای نماد برای بررسی بهتر
            symbol_clean = re.sub(r'(USDT|BUSD|BTC|ETH|BNB|DAI|USD)$', '', symbol)
            
            # بررسی: آیا نماد با عدد شروع می‌شود؟
            if re.match(r'^\d', symbol_clean):
                flags.append("عدد در ابتدای نماد")
                
                # جزئیات بیشتر:
                match = re.match(r'^(\d+)', symbol_clean)
                if match:
                    number = match.group(1)
                    if len(number) >= 4:
                        flags.append(f"عدد طولانی در ابتدا ({number})")
            
            # ============ فیلترهای جانبی (اختیاری) ============
            
            # 1. نماد خیلی کوتاه (کمتر از 2 کاراکتر بدون پسوند)
            if len(symbol_clean) < 2:
                flags.append("نماد بسیار کوتاه")
            
            # 2. نماد خیلی طولانی (بیش از 12 کاراکتر بدون پسوند)
            if len(symbol_clean) > 12:
                flags.append("نماد بسیار طولانی")
            
            # 3. کاراکترهای غیرلاتین (مانند چینی، عربی)
            if re.search(r'[^\x00-\x7F]', symbol):  # کاراکترهای غیر ASCII
                flags.append("کاراکتر غیرلاتین")
            
            # 4. ارزهای با حجم بسیار پایین (اختیاری - فقط برای اطلاعات)
            if row['volume_24h'] and row['volume_24h'] < 1000:
                flags.append("حجم معاملات کم")
            
            # اگر حداقل یک فیلتر فعال شد، به لیست اضافه کن
            if flags:
                unconventional_coins.append({
                    'id': row['id'],
                    'symbol': row['symbol'],
                    'base_asset': row['base_asset'],
                    'coin_name': coin_name if coin_name else "N/A",
                    'current_price': row['current_price'],
                    'is_active': row['is_active'],
                    'volume_24h': row['volume_24h'],
                    'market_cap': row['market_cap'],
                    'flags': ' | '.join(flags),
                    'flag_count': len(flags),
                    'created_date': row['created_at'][:10] if row['created_at'] else 'N/A'
                })
        
        # ایجاد DataFrame از ارزهای نامتعارف
        if unconventional_coins:
            df_unconventional = pd.DataFrame(unconventional_coins)
            
            # مرتب‌سازی: اول عدد در ابتدا، سپس بقیه
            df_unconventional['has_number_start'] = df_unconventional['flags'].str.contains('عدد در ابتدای نماد')
            df_unconventional = df_unconventional.sort_values(
                by=['has_number_start', 'flag_count', 'symbol'], 
                ascending=[False, False, True]
            )
            
            # حذف ستون موقت
            df_unconventional = df_unconventional.drop(columns=['has_number_start'])
            
            return df_unconventional
        else:
            print("✅ هیچ ارز نامتعارفی یافت نشد")
            return pd.DataFrame()
            
    except Exception as e:
        print(f"❌ خطا: {e}")
        import traceback
        traceback.print_exc()
        return None

def generate_final_report(df_unconventional, df_all):
    """
    تولید گزارش نهایی
    """
    if df_unconventional.empty:
        print("\n🎉 هیچ ارز نامتعارفی شناسایی نشد!")
        return
    
    total_unconventional = len(df_unconventional)
    
    print(f"\n⚠️  شناسایی {total_unconventional:,} ارز نامتعارف")
    print("=" * 70)
    
    # جدا کردن ارزهایی که عدد در ابتدای نماد دارند
    number_start_coins = df_unconventional[df_unconventional['flags'].str.contains('عدد در ابتدای نماد')]
    other_unconventional = df_unconventional[~df_unconventional['flags'].str.contains('عدد در ابتدای نماد')]
    
    print(f"\n🔢 ارزهای با عدد در ابتدای نماد: {len(number_start_coins)}")
    print("-" * 50)
    
    if not number_start_coins.empty:
        # نمایش ارزها با عدد در ابتدا
        for idx, row in number_start_coins.head(20).iterrows():
            symbol = row['symbol']
            name = str(row['coin_name'])[:20] + '...' if len(str(row['coin_name'])) > 20 else str(row['coin_name'])
            price = f"${row['current_price']:.8f}" if row['current_price'] and row['current_price'] < 0.01 else f"${row['current_price']:.2f}" if row['current_price'] else 'N/A'
            
            print(f"   {symbol:<15} {name:<25} {price:<12} is_active: {row['is_active']}")
    
    print(f"\n📊 سایر ارزهای نامتعارف: {len(other_unconventional)}")
    if not other_unconventional.empty:
        print("   (نمادهای بسیار کوتاه/طولانی، کاراکترهای غیرلاتین، حجم کم)")
        
        # تحلیل انواع دیگر
        other_flags = []
        for flags in other_unconventional['flags']:
            other_flags.extend(flags.split(' | '))
        
        flag_counts = pd.Series(other_flags).value_counts()
        
        print("\n   توزیع سایر مشکلات:")
        for flag, count in flag_counts.items():
            if 'عدد در ابتدای نماد' not in flag:
                print(f"     {flag}: {count}")
    
    # آمار کلی
    print(f"\n📈 آمار کلی:")
    print("-" * 40)
    print(f"   • کل ارزها در دیتابیس: {len(df_all):,}")
    print(f"   • ارزهای نامتعارف شناسایی شده: {total_unconventional:,}")
    print(f"   • درصد نامتعارف: {(total_unconventional/len(df_all)*100):.1f}%")
    
    if not number_start_coins.empty:
        print(f"   • ارزهای با عدد در ابتدا: {len(number_start_coins):,}")
        print(f"   • درصد ارزهای با عدد در ابتدا: {(len(number_start_coins)/len(df_all)*100):.1f}%")
    
    # تحلیل بر اساس is_active
    print(f"\n🎯 تحلیل بر اساس وضعیت is_active:")
    print("-" * 40)
    
    if not df_unconventional.empty and 'is_active' in df_unconventional.columns:
        status_analysis = df_unconventional.groupby('is_active').agg({
            'symbol': 'count'
        }).round(2)
        
        for status, row in status_analysis.iterrows():
            percentage = (row['symbol'] / total_unconventional) * 100
            print(f"   وضعیت {status}: {int(row['symbol'])} ارز ({percentage:.1f}%)")
    
    # ذخیره در فایل CSV
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"number_start_coins_{timestamp}.csv"
    
    # فقط ارزهای با عدد در ابتدا را ذخیره کن
    if not number_start_coins.empty:
        number_start_coins.to_csv(filename, index=False, encoding='utf-8-sig')
        print(f"\n💾 فایل CSV ذخیره شد: {filename}")
        print(f"📋 {len(number_start_coins)} ارز با عدد در ابتدای نماد")
    
    return number_start_coins

def analyze_number_patterns(df_unconventional):
    """
    تحلیل الگوهای عددی در ابتدای نمادها
    """
    print("\n🎯 تحلیل الگوهای عددی:")
    print("=" * 70)
    
    # استخراج اعداد از ابتدای نمادها
    number_patterns = []
    
    for symbol in df_unconventional['symbol']:
        # حذف پسوندها
        clean_symbol = re.sub(r'(USDT|BUSD|BTC|ETH|BNB|DAI|USD)$', '', symbol.upper())
        
        # استخراج عدد از ابتدا
        match = re.match(r'^(\d+)', clean_symbol)
        if match:
            number = match.group(1)
            number_patterns.append({
                'number': number,
                'length': len(number),
                'symbol': symbol
            })
    
    if number_patterns:
        df_patterns = pd.DataFrame(number_patterns)
        
        print(f"\n📊 توزیع طول اعداد:")
        length_dist = df_patterns['length'].value_counts().sort_index()
        for length, count in length_dist.items():
            print(f"   {length} رقم: {count} ارز")
        
        print(f"\n🏆 پرتکرارترین اعداد:")
        number_dist = df_patterns['number'].value_counts().head(10)
        for number, count in number_dist.items():
            print(f"   {number}: {count} ارز")
        
        print(f"\n🔢 نمونه‌های خاص:")
        # ارزهای با اعداد طولانی
        long_numbers = df_patterns[df_patterns['length'] >= 3].head(5)
        for _, row in long_numbers.iterrows():
            print(f"   {row['symbol']} - عدد: {row['number']} ({row['length']} رقم)")

def get_all_coins(db_path):
    """
    دریافت تمام ارزها از دیتابیس
    """
    try:
        conn = sqlite3.connect(db_path)
        query = """
        SELECT id, symbol, coin_name, is_active 
        FROM crypto_coins;
        """
        df = pd.read_sql_query(query, conn)
        conn.close()
        return df
    except:
        return pd.DataFrame()

# ==================== اجرای اصلی ====================
if __name__ == "__main__":
    db_path = r"C:\Users\Kamal\Desktop\py-prg\git\c-data\data\crypto_master.db"
    
    print("🔍 شناسایی ارزهای با عدد در ابتدای نماد")
    print("=" * 70)
    
    # دریافت تمام ارزها
    df_all = get_all_coins(db_path)
    
    # شناسایی ارزهای نامتعارف
    unconventional_df = identify_unconventional_coins(db_path)
    
    if unconventional_df is not None:
        # تولید گزارش
        number_start_df = generate_final_report(unconventional_df, df_all)
        
        # تحلیل الگوهای عددی
        if number_start_df is not None and not number_start_df.empty:
            analyze_number_patterns(number_start_df)
        
        print("\n" + "=" * 70)
        print("✅ گزارش با موفقیت تولید شد")
        
        if number_start_df is not None and not number_start_df.empty:
            print(f"\n🎯 ارزهای مشکوک اولویت‌دار:")
            print("-" * 50)
            
            # ارزهای با is_active=1 که عدد در ابتدا دارند
            active_problematic = number_start_df[number_start_df['is_active'] == 1]
            
            if not active_problematic.empty:
                print(f"   ⚠️  {len(active_problematic)} ارز فعال با عدد در ابتدای نماد:")
                for _, row in active_problematic.head(10).iterrows():
                    print(f"      {row['symbol']} - {row['coin_name']}")
            
            # پیشنهاد برای اصلاح
            print(f"\n💡 پیشنهاد برای اصلاح:")
            print("   1. بررسی ارزهای با is_active=1 که عدد در ابتدای نماد دارند")
            print("   2. تغییر وضعیت ارزهای مشکوک به is_active=0 یا 5")
            print("   3. به‌روزرسانی نمادها در صورت امکان")
            
    else:
        print("\n⚠️ تولید گزارش با مشکل مواجه شد.")